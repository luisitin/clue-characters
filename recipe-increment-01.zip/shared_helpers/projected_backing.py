"""Conservative analytical full-triangle AND full-edge retained support proof.
Recovered from the corrected former Plum376 method. No source edits or deletion decision.
Axes U,V span projection; D points toward camera. All are orthonormal world vectors.
Candidate/excluded IDs must cover the ENTIRE proposed removal family.
"""
import numpy as np

def area(q):
 q=np.asarray(q,float)
 return abs(np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1)))/2 if len(q)>2 else 0.
def ccw(q):
 q=np.asarray(q,float)
 return q if np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1))>0 else q[::-1]
def clip(q,n,c):
 if len(q)<3:return np.empty((0,2))
 out=[]
 for x,y in zip(q,np.roll(q,-1,axis=0)):
  a=x@n+c;b=y@n+c;ia=a>=-1e-13;ib=b>=-1e-13
  if ia:out.append(x)
  if ia!=ib:out.append(x+(y-x)*(a/(a-b)))
 q=np.array(out).reshape(-1,2)
 if len(q):q=q[np.linalg.norm(q-np.roll(q,1,axis=0),axis=1)>1e-12]
 return q
def halfplanes(poly):
 p=ccw(poly)
 for x,y in zip(p,np.roll(p,-1,axis=0)):
  d=y-x
  if np.linalg.norm(d)<1e-12:continue
  n=np.array([-d[1],d[0]]);yield n,-n@x
def intersection(q,r):
 for n,c in halfplanes(r):q=clip(q,n,c)
 return q
def subtract(q,r):
 inside=q;pieces=[]
 for n,c in halfplanes(r):
  out=clip(inside,-n,-c)
  if area(out)>1e-18:pieces.append(out)
  inside=clip(inside,n,c)
  if len(inside)<3 or area(inside)<1e-18:break
 return pieces

def prove_coverage(subject_world,support_world,support_ids,U,V,D,excluded_support_ids=(),minimum_depth=-5e-6,maximum_ray_depth=.003,minimum_support_facing=.1,maximum_normal_separation=None,edge_gap_tolerance=1e-7):
 S=np.asarray(subject_world,float);T=np.asarray(support_world,float);support_ids=np.asarray(support_ids,int);axes=np.array([U,V,D],float);assert S.shape==(3,3)and T.ndim==3 and T.shape[1:]==(3,3)and len(T)==len(support_ids);assert np.allclose(axes@axes.T,np.eye(3),atol=1e-10);assert maximum_ray_depth>minimum_depth
 sp=S@axes.T;tp=T@axes.T;subject=ccw(sp[:,:2]);subject_area=area(subject)
 if subject_area<1e-18:return {'passed':False,'reason':'Projection-degenerate subject; choose a justified chart, not a convex hull.'}
 coef=np.linalg.solve(np.c_[sp[:,:2],np.ones(3)],sp[:,2]);N=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);length=np.linalg.norm(N,axis=1);N/=np.maximum(length[:,None],1e-30);facing=N@np.asarray(D);excluded=set(map(int,excluded_support_ids));covers=[];records=[]
 for i,faceid in enumerate(support_ids):
  if int(faceid)in excluded or facing[i]<=minimum_support_facing or length[i]<1e-20:continue
  proj=tp[i,:,:2]
  if area(proj)<1e-18:continue
  cover=intersection(subject,proj)
  if area(cover)<1e-18:continue
  cf=np.linalg.solve(np.c_[proj,np.ones(3)],tp[i,:,2]);delta=coef-cf;cover=clip(cover,delta[:2],delta[2]-minimum_depth);cover=clip(cover,-delta[:2],maximum_ray_depth-delta[2]);normaldelta=delta*facing[i]
  if maximum_normal_separation is not None:cover=clip(cover,-normaldelta[:2],maximum_normal_separation-normaldelta[2])
  if area(cover)<1e-18:continue
  dep=cover@delta[:2]+delta[2];normdep=cover@normaldelta[:2]+normaldelta[2];covers.append(cover);records.append({'retained_face':int(faceid),'cover_polygon':cover.tolist(),'ray_depth_range_m':[float(dep.min()),float(dep.max())],'support_normal_separation_range_m':[float(normdep.min()),float(normdep.max())],'geometric_facing':float(facing[i])})
 remaining=[subject]
 for cover in covers:
  before=sum(area(q)for q in remaining);remaining=[p for q in remaining for p in subtract(q,cover)];after=sum(area(q)for q in remaining);assert after<=before+1e-14,('Non-monotone subtraction',before,after)
  if not remaining:break
 missing=sum(area(q)for q in remaining);gaps=[]
 for start,end in zip(subject,np.roll(subject,-1,axis=0)):
  direction=end-start;intervals=[]
  for cover in covers:
   low,high=0.,1.
   for n,c in halfplanes(cover):
    aa=start@n+c;bb=direction@n
    if abs(bb)<1e-18:
     if aa<-1e-12:low,high=1.,0.;break
    elif bb>0:low=max(low,(-aa-1e-12)/bb)
    else:high=min(high,(-aa-1e-12)/bb)
   if low<=high:intervals.append((max(low,0),min(high,1)))
  cursor=gap=0.
  for low,high in sorted(intervals):
   if low>cursor:gap+=low-cursor
   cursor=max(cursor,high)
  gap+=max(0,1-cursor);gaps.append(float(gap*np.linalg.norm(direction)))
 passed=missing<=max(1e-15,subject_area*1e-7)and max(gaps)<edge_gap_tolerance
 return {'passed':bool(passed),'projected_subject_area_m2':subject_area,'uncovered_projected_area_m2':missing,'uncovered_edge_lengths_m':gaps,'remaining_polygons':[q.tolist()for q in remaining],'support_records':records,'excluded_support_ids':sorted(excluded),'parameters':{'minimum_depth_m':minimum_depth,'maximum_ray_depth_m':maximum_ray_depth,'minimum_support_facing':minimum_support_facing,'maximum_normal_separation_m':maximum_normal_separation,'edge_gap_tolerance_m':edge_gap_tolerance},'scope':'Coverage proof only. It does not prove ownership, complete branch incidence, tangent continuity, absence of an exposed retained partner, or final appearance.'}

if __name__=='__main__':
 subject=np.array([[0.,0.],[1.,0.],[0.,1.]]);cover=[np.array([[0.,0.],[.5,0.],[.5,.5],[0.,1.]]),np.array([[.5,0.],[1.,0.],[.5,.5],[.5,.5]])];left=[subject]
 for cv in cover:left=[p for q in left for p in subtract(q,cv)]
 assert sum(area(p)for p in left)<1e-14
 S=np.array([[0,.001,0],[1,.001,0],[0,.001,1.]]);T=np.array([[[0,0,0],[0,0,1.],[1.,0,0]]]);r=prove_coverage(S,T,[7],[1,0,0],[0,0,1],[0,1,0]);assert r['passed'];r2=prove_coverage(S,T,[7],[1,0,0],[0,0,1],[0,1,0],excluded_support_ids=[7]);assert not r2['passed'];T[:, :,1]=.01;r3=prove_coverage(S,T,[7],[1,0,0],[0,0,1],[0,1,0]);assert not r3['passed'];print('PASS repeated-vertex subtraction, full area+edge coverage, excluded-family and negative-depth fixtures',flush=True)
