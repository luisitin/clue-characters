"""Exact rays above/below the visible sleeve splice, including raw normals and backing."""
import pathlib,sys,json,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from PIL import Image
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_sleeve75_assembly.glb';j,b,A=read_glb(src);pp=[];nn=[];ff=[];owner=[];off=0
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:
  M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
  P=A(p['attributes']['POSITION']).astype('float32').astype(float);N=A(p['attributes']['NORMAL']);F=A(p['indices']).reshape(-1,3);pp.append((P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]);nw=N@np.linalg.inv(M[:3,:3]);nw=nw[:,[0,2,1]]*[1,-1,1];nw/=np.linalg.norm(nw,axis=1)[:,None];nn.append(nw);ff.append(F+off);off+=len(P);owner.extend([[ni,pi]]*len(F))
P=np.vstack(pp);N=np.vstack(nn);F=np.vstack(ff);owner=np.array(owner);tree=BVHTree.FromPolygons(P.tolist(),F.tolist(),all_triangles=True);rows=[]
for tag,x,ys in [('sleeve_under71',435,[525,530,535,540]),('sleeve_under71',510,[595,600,605,610,615])]:
 imgpath=R/'renders/sleeve75'/f'{tag}_clay.png';im=np.array(Image.open(imgpath).convert('RGB'));meta=json.loads(imgpath.with_suffix('.json').read_text());assert meta['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();M=np.array(meta['camera_world_matrix']);scale=meta['ortho_scale'];w,h=meta['resolution'];direction=-M[:3,2]
 for y in ys:
  o=M[:3,3]+M[:3,0]*((x+.5)/w-.5)*scale+M[:3,1]*(.5-(y+.5)/h)*scale;hit,gn,fi,dist=tree.ray_cast(Vector(o),Vector(direction),20.)
  if hit is None:continue
  Q=P[F[fi]];ww=np.linalg.lstsq(np.column_stack([Q[1]-Q[0],Q[2]-Q[0]]),np.array(hit)-Q[0],rcond=None)[0];bc=np.r_[1-ww.sum(),ww];n=bc@N[F[fi]];n/=np.linalg.norm(n);hit2,gn2,f2,d2=tree.ray_cast(Vector(np.array(hit)+direction*1e-5),Vector(direction),1.);shadow=[]
  for pos in [(-3,-4,4),(4,-2,2),(0,3,3)]:
   dd=np.array(pos)-np.array(hit);dd/=np.linalg.norm(dd);hh,gg,ff,ds=tree.ray_cast(Vector(np.array(hit)+np.array(gn)*1e-5),Vector(dd),8.)
   shadow.append(None if hh is None else{'owner':owner[ff].tolist(),'distance':float(ds)})
  rows.append({'view':tag,'pixel':[x,y],'rgb':im[y,x].tolist(),'owner':owner[fi].tolist(),'face':int(fi),'world_point':list(hit),'geometric_normal':list(gn),'stored_normal':n.tolist(),'geometric_stored_dot':float(np.dot(gn,n)),'front_facing':float(np.dot(gn,direction))<0,'next_camera_hit':None if hit2 is None else{'owner':owner[f2].tolist(),'distance':float(d2),'world_point':list(hit2)},'shadow_toward_area_light_centers':shadow})
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'samples':rows,'scope':'Read-only attribution. Shadow rays use area-light centers only and do not measure complete integrated illumination.'};(R/'audit/sleeve_cavity75_rays.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
