import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
from intersection_kernel_v4_selected import audit
src=R/'Green_sleeve69_assembly.glb';j,b,A=read_glb(src);P=[];N=[];F=[];owners=[];offset=0
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 M=np.eye(4)
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  p=A(pr['attributes']['POSITION']).astype('float32').astype(float);f=A(pr['indices']).reshape(-1,3);P.append((p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]);N.append(A(pr['attributes']['NORMAL']));F.append(f+offset);owners.extend([[ni,pi]]*len(f));offset+=len(p)
P=np.vstack(P);N=np.vstack(N);F=np.vstack(F);owners=np.array(owners);z=np.load(R/'audit/sleeve69_binding.npz');q=z['new_world'];bounds=np.r_[q.min(0)-.003,q.max(0)+.003].tolist();newpr=len(j['meshes'][0]['primitives'])-2;isnew=(owners[:,0]==0)&(owners[:,1]>=newpr);tri=P[F];lo=tri.min(1);hi=tri.max(1);ulo=lo[isnew].min(0);uhi=hi[isnew].max(0);potential=np.all(hi>=ulo-1e-8,axis=1)&np.all(lo<=uhi+1e-8,axis=1);ids=np.flatnonzero(potential);assert potential[isnew].all();used,inv=np.unique(F[ids],return_inverse=True);selected=np.flatnonzero(isnew[ids]);print(dict(stage='COMPACT_READY',new_faces=len(selected),potential_faces=len(ids),whole_faces=len(F)),flush=True);res=audit(P[used],inv.reshape(-1,3),selected_faces=selected,progress_interval=1000)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in res[key]:row['faces']=[int(ids[x])for x in row['faces']]
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:
 res[key]=[[int(ids[x])for x in row]for row in res[key]]
res['zero_area_faces']=[int(ids[x])for x in res['zero_area_faces']];res.update(whole_faces=len(F),selected_changed_faces=len(selected),retained_potential_faces=int((~isnew[ids]).sum()),all_original_coordinates_held=True,global_face_ids_restored=True)

for kind in ['proper_crossings','positive_area_coplanar_pairs']:
 for entry in res[kind]:entry['owners']=owners[entry['faces']].tolist();entry['involves_new_cuff']=bool(isnew[entry['faces']].any())
res.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),new_cuff_proper=sum(x['involves_new_cuff']for x in res['proper_crossings']),new_cuff_coplanar=sum(x['involves_new_cuff']for x in res['positive_area_coplanar_pairs']),new_cuff_folds=[x for x in res['manifold_edge_folds_over_105_degrees']if isnew[x].any()],new_cuff_copies=[x for x in res['position_triangle_copy_groups']if isnew[x].any()],new_cuff_zero_area=[x for x in res['zero_area_faces']if isnew[x]],scope='Exact merged raw coordinates; all changed garment triangles versus every potentially intersecting retained AABB. Topology counts are for the compact neighborhood, not a whole-character clearance.');(R/'audit/sleeve69_surface_v4_compact.json').write_text(json.dumps(res,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in res.items()},flush=True)
