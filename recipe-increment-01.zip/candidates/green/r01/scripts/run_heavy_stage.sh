#!/usr/bin/env bash
set -u
stage=$1; shift
printf 'QUEUED %s %s\n' "$(date -u +%FT%TZ)" "$stage"
flock "${CHARACTER_BUILD_LOCK:-/tmp/character-build-heavy.lock}" bash -c '
 stage=$1; shift
 printf "START %s stage=%s pid=%s command=" "$(date -u +%FT%TZ)" "$stage" "$$"
 printf "%q " "$@"; printf "\n"
 "$@"; rc=$?
 printf "END %s stage=%s exit=%s\n" "$(date -u +%FT%TZ)" "$stage" "$rc"
 exit "$rc"
' _ "$stage" "$@"
