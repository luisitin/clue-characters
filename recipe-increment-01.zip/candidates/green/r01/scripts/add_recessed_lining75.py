"""Back the diagnosed cuff cavity with a recessed sewn lining, holding mouth/hand fit."""
import pathlib,sys,json,hashlib,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'))
from glb_source import read_glb,append_accessor,write_glb
src=R/'Green_sleeve74_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][-1];Pold=A(pr['attributes']['POSITION']);Nold=A(pr['attributes']['NORMAL']);scale=np.array(j['nodes'][0]['scale']);trans=np.array(j['nodes'][0]['translation']);z=np.load(R/'audit/sleeve69_binding.npz');c=z['hem_center'];axis=z['hem_normal'];frame=z['hem_frame'];q=z['innerq'];n=len(q);startP=Pold[-n:].copy();startW=(startP*scale+trans)[:,[0,2,1]]*[1,-1,1];assert np.max(abs(startW-(c+q@frame.T-axis*.006)))<1e-7
V=[*startW];UV=[*[[(k/n)*.96+.02,.02]for k in range(n)]];F=[]
for depth,factor in [(.012,1.),(.022,.90),(.030,.58)]:
 V.extend(c+q@frame.T*factor-axis*depth);UV.extend([[(k/n)*.96+.02,.02+depth*20]for k in range(n)])
for row in range(3):
 for k in range(n):a=row*n+k;b0=row*n+(k+1)%n;cc=(row+1)*n+(k+1)%n;d=(row+1)*n+k;F.extend([[a,b0,cc],[a,cc,d]])
center=len(V);V.append(c-axis*.034);UV.append([.5,.95])
for k in range(n):F.append([3*n+k,3*n+(k+1)%n,center])
V=np.array(V);F=np.array(F);UV=np.array(UV);tri=V[F];gn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);gn/=np.linalg.norm(gn,axis=1)[:,None];N=np.zeros_like(V)
for k in range(3):
 a=tri[:,(k+1)%3]-tri[:,k];bb=tri[:,(k+2)%3]-tri[:,k];a/=np.linalg.norm(a,axis=1)[:,None];bb/=np.linalg.norm(bb,axis=1)[:,None];ang=np.arccos(np.clip(np.sum(a*bb,axis=1),-1,1));np.add.at(N,F[:,k],gn*ang[:,None])
N/=np.linalg.norm(N,axis=1)[:,None];P=((V[:,[0,2,1]]*[1,1,-1]-trans)/scale).astype('float32');N=(N[:,[0,2,1]]*[1,1,-1]).astype('float32');P[:n]=startP;N[:n]=Nold[-n:];attrs={}
for name,a,kind in [('POSITION',P,'VEC3'),('NORMAL',N,'VEC3'),('TEXCOORD_0',UV.astype('float32'),'VEC2')]:attrs[name],b=append_accessor(j,b,a,kind,34962)
ix,b=append_accessor(j,b,F.astype('uint32'),'SCALAR',34963);mi=len(j['materials']);j['materials'].append({'name':'Recessed charcoal sleeve lining','pbrMetallicRoughness':{'baseColorFactor':[.025,.03,.027,1],'metallicFactor':0,'roughnessFactor':.86},'doubleSided':False});j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4});out=R/'Green_sleeve75_body.glb';write_glb(out,j,b)
zz=np.load(R/'audit/sleeve74_binding.npz');np.savez_compressed(R/'audit/sleeve75_binding.npz',new_world=np.vstack([zz['new_world'],V]));rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_source_geometry_normals_UV_materials_maps_held':True,'exact_shared_lining_start_vertices':n,'lining_depth_from_hem_m':[.006,.012,.022,.03,.034],'new_triangles':len(F),'status':'Recessed lining study; contact, winding, first-hit and actual under/outside checks pending.'};(R/'audit/sleeve75.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
