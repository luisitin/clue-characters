"""Attribute the exact sleeve38 root splice to geometric and shading continuity."""
import pathlib,json,hashlib,numpy as np
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_sleeve38_body.glb';j,b,A=read_glb(src);sc=np.array(j['nodes'][0]['scale']);tr=np.array(j['nodes'][0]['translation']);pp=[];nn=[];ff=[];owner=[];off=0
for pi,p in enumerate(j['meshes'][0]['primitives']):
 P=A(p['attributes']['POSITION']);N=A(p['attributes']['NORMAL']);F=A(p['indices']).reshape(-1,3);pp.append((P*sc+tr)[:,[0,2,1]]*[1,-1,1]);nn.append((N/sc)[:,[0,2,1]]*[1,-1,1]);ff.append(F+off);owner.extend([pi]*len(F));off+=len(P)
P=np.vstack(pp);N=np.vstack(nn);N/=np.linalg.norm(N,axis=1)[:,None];F=np.vstack(ff);owner=np.array(owner);U,g=np.unique(P,axis=0,return_inverse=True);G=g[F];T=P[F];GN=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);GN/=np.maximum(np.linalg.norm(GN,axis=1)[:,None],1e-30);edges={}
for fi,tri in enumerate(G):
 for a,b in zip(tri,np.roll(tri,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
rows=[]
for edge,fs in edges.items():
 if len(fs)!=2 or not((owner[fs]==3).any()and(owner[fs]<3).any()):continue
 source=fs[0]if owner[fs[0]]<3 else fs[1];new=fs[1]if source==fs[0]else fs[0];normalDiff=[]
 for v in edge:
  ni=F[new][G[new]==v][0];oi=F[source][G[source]==v][0];normalDiff.append(float(np.degrees(np.arccos(np.clip(N[ni]@N[oi],-1,1)))))
 rows.append({'source_face':source,'new_face':new,'source_primitive':int(owner[source]),'edge_world':U[list(edge)].tolist(),'geometric_dihedral_degrees':float(np.degrees(np.arccos(np.clip(GN[source]@GN[new],-1,1)))),'max_stored_normal_difference_degrees':max(normalDiff),'source_geometric_to_corner_normal_dot':float(GN[source]@N[F[source]].mean(0)),'new_geometric_to_corner_normal_dot':float(GN[new]@N[F[new]].mean(0))})
angles=np.array([x['geometric_dihedral_degrees']for x in rows]);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'root_edges':len(rows),'geometric_dihedral_max_degrees':float(angles.max()),'geometric_dihedral_p95_degrees':float(np.percentile(angles,95)),'geometric_dihedral_median_degrees':float(np.median(angles)),'max_stored_normal_difference_degrees':max(x['max_stored_normal_difference_degrees']for x in rows),'edges':sorted(rows,key=lambda x:x['geometric_dihedral_degrees'],reverse=True),'status':'Read-only geometric/normal attribution of the actual visible root transition; no sleeve mutation.'};(R/'audit/sleeve_root61.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k!='edges'},flush=True)
