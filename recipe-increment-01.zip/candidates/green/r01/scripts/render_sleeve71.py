"""Reframe depth68 sleeve from its actual target, retaining exact camera provenance."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/render_exact.py').read_text()
code=code.replace("target,scale,angle,elev=regions[tag];", "regions['sleeve_side71']=((-.27,.06,.24),.46,79,.04)\nregions['sleeve_under71']=((-.27,.06,.24),.46,-11,-5)\nregions['sleeve_oblique71']=((-.27,.06,.24),.46,124,.04)\ntarget,scale,angle,elev=regions[tag];")
exec(compile(code,'render_sleeve71','exec'))
