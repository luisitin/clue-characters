"""Replace only the near-eye source-projection maps after reversed-sheet attribution."""
import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_physical_eyes50_bounded_cap_body.glb';j,buf,A=read_glb(src);old=copy.deepcopy(j);textures={}
for kind in ['BaseColor','ORM']:
 p=R/'textures'/f'Green_Eye1_Skin59_{kind}_2K.png';data=p.read_bytes();buf=bytes(buf)+b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(data)});buf+=data;ii=len(j['images']);j['images'].append({'name':p.name,'mimeType':'image/png','bufferView':vi});ti=len(j['textures']);j['textures'].append({'source':ii,'sampler':0});textures[kind]=ti
pr=j['meshes'][0]['primitives'][8];mat=copy.deepcopy(j['materials'][pr['material']]);mat['name']='Green near-eye correct front-source projection60';mat['pbrMetallicRoughness']['baseColorTexture']['index']=textures['BaseColor'];mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=textures['ORM'];mat['occlusionTexture']['index']=textures['ORM'];pr['material']=len(j['materials']);j['materials'].append(mat);out=R/'Green_physical_eyes60_clean_paint_body.glb';write_glb(out,j,buf);k,c,B=read_glb(out)
for x,y in zip(old['meshes'][0]['primitives'],k['meshes'][0]['primitives']):
 assert x['attributes']==y['attributes'] and x['indices']==y['indices']
 for key in x['attributes']:assert np.array_equal(A(x['attributes'][key]),B(y['attributes'][key]))
 assert np.array_equal(A(x['indices']),B(y['indices']))
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'geometry_indices_normals_UVs_exactly_held':True,'only_changed_binding':'Near-eye skin primitive8 BaseColor/ORM/occlusion images; original-color first front-facing source sheet, with zero occupied misses.','attribution':'eye_source_marks58.json','transfer_proof':'eye1_skin59_material.json','status':'Material-only actual-view check pending; eye geometry finish gates remain separate.'};(R/'audit/eyes60.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
