"""Bounded raw GLB accessor access and exact single-mesh source reconstruction."""
import json,struct,pathlib,numpy as np

def read_glb(path):
 raw=pathlib.Path(path).read_bytes();magic,version,total=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and total==len(raw);n,typ=struct.unpack_from('<II',raw,12);assert typ==0x4e4f534a;j=json.loads(raw[20:20+n]);start=20+n;bn,bt=struct.unpack_from('<II',raw,start);assert bt==0x004e4942;buf=memoryview(raw)[start+8:start+8+bn]
 def accessor(i):
  a=j['accessors'][i];v=j['bufferViews'][a['bufferView']];assert not a.get('sparse');dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1',5122:'<i2',5120:'i1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];item=np.dtype(dtype).itemsize;offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',dim*item);arr=np.ndarray((a['count'],dim),dtype=dtype,buffer=buf,offset=offset,strides=(stride,item)).copy()
  if a.get('normalized'):
   info=np.iinfo(np.dtype(dtype));arr=arr.astype(np.float64)/info.max
   if info.min<0:arr=np.maximum(arr,-1)
  return arr[:,0]if dim==1 else arr
 return j,buf,accessor

def replace_single_source_mesh(path):
 import bpy
 j,buf,A=read_glb(path);assert len(j['meshes'])==1 and len(j['meshes'][0]['primitives'])==1;pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION'])[:,[0,2,1]]*np.array([1,-1,1]);N=A(pr['attributes']['NORMAL'])[:,[0,2,1]]*np.array([1,-1,1]);UV=A(pr['attributes']['TEXCOORD_0']).astype(float);UV[:,1]=1-UV[:,1];F=A(pr['indices']).reshape(-1,3);obs=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(obs)==1;ob=obs[0];mats=list(ob.data.materials);me=bpy.data.meshes.new('Raw accessor source topology');me.from_pydata(P.tolist(),[],F.tolist());me.update();assert len(me.polygons)==len(F) and np.array_equal(np.array([p.vertices[:]for p in me.polygons]),F)
 for mat in mats:me.materials.append(mat)
 for p in me.polygons:p.use_smooth=True
 uv=me.uv_layers.new(name='Source UV');lv=np.array([l.vertex_index for l in me.loops]);uv.data.foreach_set('uv',UV[lv].astype('float32').ravel());me.normals_split_custom_set(N[lv].tolist());old=ob.data;ob.data=me
 if old.users==0:bpy.data.meshes.remove(old)
 return ob,j,A

def append_accessor(j,buf,array,kind,target=None):
 a=np.ascontiguousarray(array)
 if kind=='SCALAR':a=a.ravel()
 ct={np.dtype('float32'):5126,np.dtype('uint32'):5125,np.dtype('uint16'):5123}[a.dtype];buf=bytes(buf);buf+=b'\0'*((-len(buf))%4);view={'buffer':0,'byteOffset':len(buf),'byteLength':a.nbytes}
 if target is not None:view['target']=target
 vi=len(j['bufferViews']);j['bufferViews'].append(view);acc={'bufferView':vi,'componentType':ct,'count':len(a),'type':kind}
 if kind!='SCALAR':acc.update(min=a.min(0).astype(float).tolist(),max=a.max(0).astype(float).tolist())
 ai=len(j['accessors']);j['accessors'].append(acc);return ai,buf+a.tobytes()

def write_glb(path,j,buf):
 j['buffers']=[{'byteLength':len(buf)}];head=json.dumps(j,separators=(',',':')).encode();head+=b' '*((-len(head))%4);buf=bytes(buf);buf+=b'\0'*((-len(buf))%4);payload=struct.pack('<4sII',b'glTF',2,28+len(head)+len(buf))+struct.pack('<II',len(head),0x4e4f534a)+head+struct.pack('<II',len(buf),0x004e4942)+buf
 target=pathlib.Path(path)
 if target.exists():assert target.read_bytes()==payload,'Immutable GLB target already exists with different bytes: '+str(target)
 else:target.write_bytes(payload)
