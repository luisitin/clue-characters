"""Create a local reproducible increment; remote publishing is coordinated separately."""
import pathlib,json,hashlib,shutil,ast,datetime
R=pathlib.Path(__file__).resolve().parents[1];ROOT=R.parents[2];out=ROOT/'component_snapshots/green-sleeve75-eye60-20261004-2020';out.mkdir(parents=True,exist_ok=True)
selected=[]
for name in ['glb_source.py','merge_exact_components.py','run_heavy_stage.sh','bake_eye_skin59.py','stitch_eye_paint60.py','audit_sleeve_root61.py','fit_hand_depth67.py','fit_hand_depth68.py','build_sleeve69.py','audit_sleeve69_compact.py','audit_moved_hand70.py','render_sleeve71.py','render_sleeve73.py','fair_sleeve74.py','audit_sleeve74_compact.py','add_recessed_lining75.py','audit_sleeve75_compact.py','attribute_sleeve_cavity75.py','freeze_increment75.py']:
 p=R/'scripts'/name
 if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
 selected.append(p)
for name in ['eyes60.json','eye1_skin59_material.json','sleeve_root61.json','hand_depth67.json','hand_depth68.json','sleeve69.json','hand70_body_v4_compact.json','sleeve74.json','sleeve74_surface_v4_compact.json','sleeve75.json','sleeve75_surface_v4_compact.json','sleeve_cavity75_rays.json','Green_sleeve75_assembly_components.json']:
 selected.append(R/'audit'/name)
selected.extend([R/'textures/Green_Eye1_Skin59_BaseColor_2K.png',R/'textures/Green_Eye1_Skin59_ORM_2K.png'])
for folder,tags in [('eyes60',['head_angle_0_paint','head_angle_0_unlit']),('sleeve74',['cuff_context_clay','cuff_opposite_clay']),('sleeve75',['sleeve_under71_clay','sleeve_outside73_clay'])]:
 for tag in tags:
  for ext in ['.json','.png']:selected.append(R/'renders'/folder/(tag+ext))
records=[]
for p in selected:
 assert p.is_file(),p
 rel=p.relative_to(ROOT);dst=out/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes()
 if dst.exists():assert dst.read_bytes()==data
 else:dst.write_bytes(data)
 records.append({'relative_path':str(rel),'snapshot_path':str(dst),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
build=['Restore exact pinned pre-LOD source, maps, original art, official CC0 donor and previous green-combined-recipes-20261004-1830 plus its1833 build order/camera.','Rebuild prior held sleeve38 body/assembly and closed27 hand using the previous recipe.','Run audit_sleeve_root61.py, fit_hand_depth67.py, fit_hand_depth68.py, build_sleeve69.py, fair_sleeve74.py, add_recessed_lining75.py sequentially. fit67 writes a comparison hand that68 does not adopt.','Run merge_exact_components.py Green_sleeve75_assembly Green_sleeve75_body Green_openhand_depth68 using bare stems without .glb.','Run audit_sleeve75_compact.py; it covers all changed garment faces versus conservative retained candidates. The moved hand70 check uses its explicitly named69 assembly and also needs that optional merge.','Separately rebuild eyes50 via the previous recipe, run bake_eye_skin59.py 1 then stitch_eye_paint60.py. Eye60 remains a separate component study; it is not present in sleeve75.','All Blender/NumPy-heavy steps acquire the shared external flock via run_heavy_stage.sh before process launch; release between stages/views.']
j={'scope':'Public-safe local WIP recipe and proof increment. No final visual approval or remote commit implied.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'depends_on':'green-combined-recipes-20261004-1830 and companion green_recipe_build_order_20261004_1833.json','build_order':build,'current_candidate':{'path':str(R/'Green_sleeve75_assembly.glb'),'sha256':'cc8f26fdf5fefaf2cd999916a630d7c0c22aa44ed6640ed16a9ea6908dcbe8bc','triangles':170121,'status':'Local anatomy/sleeve study. Actual garment paint/UVs, old gripping hand/case/shoes and whole-character validation remain unfinished; new eyes are separate.'},'files':records,'total_bytes':sum(x['bytes']for x in records),'verification':'All listed files copied exactly, hashes recorded, Python syntax parsed. No clean-room full rebuild performed.'};(out/'MANIFEST.json').write_text(json.dumps(j,indent=2));print(out/'MANIFEST.json');print(len(records),j['total_bytes'])
