"""Fair only sleeve69's interior rings in physical arc length; preserve construction ends."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.interpolate import CubicSpline
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'))
from glb_source import read_glb,append_accessor,write_glb
src=R/'Green_sleeve69_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][-2:];Pold=A(pr[0]['attributes']['POSITION']);Nold=A(pr[0]['attributes']['NORMAL']);UVold=A(pr[0]['attributes']['TEXCOORD_0']);oldF=np.vstack([A(p['indices']).reshape(-1,3)for p in pr]);oldPart=np.r_[np.zeros(len(A(pr[0]['indices']))//3,int),np.ones(len(A(pr[1]['indices']))//3,int)]
z=np.load(R/'audit/sleeve69_binding.npz');W=z['new_world'];F0=z['new_triangles'];n=len(z['root_world']);fractions=np.array([0,.009,.018,.04,.07,.11,.16,.22,.29,.37,.46,.55,.64,.72,.79,.85,.90,.94,.97,1]);length=json.loads((R/'audit/sleeve69.json').read_text())['root_to_hem_distance_m'];oldGuide=20*n;oldCuff=oldGuide+n
edges=np.linalg.norm(np.roll(W[:n],-1,axis=0)-W[:n],axis=1);u=np.r_[0,np.cumsum(edges[:-1])]/edges.sum();uniform=np.arange(192)/192;denseU=np.arange(4096)/4096;V=[];UV=[];rings=[];params=[];mapping={};oldNWorld=Nold[:,[0,2,1]]*[1,-1,1];newHeldN={};maxMove=0;ratios=[]
def add_ring(points,uu,t,oldids=None):
 ids=np.arange(len(V),len(V)+len(points));V.extend(points);UV.extend(np.column_stack([.02+.60*uu,np.full(len(points),.02+.96*t)]));rings.append(ids);params.append(uu)
 if oldids is not None:
  for a0,a1 in zip(oldids,ids):mapping[int(a0)]=int(a1);newHeldN[int(a1)]=oldNWorld[a0]
 return ids
for row,t in enumerate(fractions):
 old=W[row*n:(row+1)*n]
 if row in [0,1,19]:add_ring(old,u,t,np.arange(row*n,(row+1)*n));continue
 dense=np.column_stack([np.interp(denseU,np.r_[u,1],np.r_[old[:,k],old[0,k]])for k in range(3)]);perimeter=np.linalg.norm(np.roll(old,-1,axis=0)-old,axis=1).sum();smooth=gaussian_filter1d(dense,.003/perimeter*len(dense),axis=0,mode='wrap');center=dense.mean(0);smooth=center+(smooth-center)*np.sqrt(np.sum((dense-center)**2)/np.sum((smooth-center)**2));arc=t*length;a0=np.clip((arc-.0015)/.018,0,1);a0=a0*a0*(3-2*a0);a1=np.clip((length-arc)/.012,0,1);a1=a1*a1*(3-2*a1);newDense=dense+(smooth-dense)*(a0*a1);maxMove=max(maxMove,float(np.linalg.norm(newDense-dense,axis=1).max()));new=CubicSpline(np.r_[denseU,1],np.vstack([newDense,newDense[0]]),bc_type='periodic')(uniform);add_ring(new,uniform,t);dd=np.linalg.norm(np.roll(new,-1,axis=0)-new,axis=1);ratios.append(float(dd.max()/dd.min()))
newGuide=len(V)
for k in range(n):mapping[oldGuide+k]=len(V);newHeldN[len(V)]=oldNWorld[oldGuide+k];V.append(W[oldGuide+k]);UV.append(UVold[oldGuide+k])
newCuff=len(V)
for k in range(oldCuff,len(W)):mapping[k]=len(V);newHeldN[len(V)]=oldNWorld[k];V.append(W[k]);UV.append(UVold[k])
F=[];part=[]
# Exact original source/tangent wedge faces.
for k in range(n*4):F.append([mapping[int(v)]for v in F0[k]]);part.append(0)
def stitch(aa,ua,bb,ub):
 i=k=0;out=[];na=len(aa);nb=len(bb)
 while i<na or k<nb:
  ai=aa[i%na];bk=bb[k%nb];an=ua[i+1]if i+1<na else 1.;bn=ub[k+1]if k+1<nb else 1.
  if i<na and (k==nb or an<=bn):out.append([ai,aa[(i+1)%na],bk]);i+=1
  else:out.append([ai,bb[(k+1)%nb],bk]);k+=1
 return out
for row in range(1,19):
 fs=stitch(rings[row],params[row],rings[row+1],params[row+1]);F.extend(fs);part.extend([0]*len(fs))
# Held hem annulus and lining topology; exact original positions and normals.
for f,k in zip(oldF,oldPart):
 if np.min(f)>=oldCuff:F.append([mapping[int(v)]for v in f]);part.append(int(k))
V=np.array(V);F=np.array(F);UV=np.array(UV);part=np.array(part);tri=V[F];gn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(gn,axis=1);assert area.min()>1e-16;gn/=area[:,None];N=np.zeros_like(V)
for k in range(3):
 x=tri[:,(k+1)%3]-tri[:,k];y=tri[:,(k+2)%3]-tri[:,k];x/=np.linalg.norm(x,axis=1)[:,None];y/=np.linalg.norm(y,axis=1)[:,None];a=np.arccos(np.clip(np.sum(x*y,axis=1),-1,1));np.add.at(N,F[:,k],gn*a[:,None])
_,groups=np.unique(np.round(V,9),axis=0,return_inverse=True);s=np.zeros((groups.max()+1,3));np.add.at(s,groups,N);N=s[groups];N/=np.linalg.norm(N,axis=1)[:,None]
# Short harmonic continuation of exact root/guide shading into the fair surface.
residual=np.zeros_like(N);fixed=np.ones(len(V),bool)
for row,t in enumerate(fractions):
 if row>1 and t*length<.05:fixed[rings[row]]=False
for k,nn in newHeldN.items():residual[k]=nn-N[k]
ed=np.unique(np.sort(np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),axis=1),axis=0);w=1/np.maximum(np.linalg.norm(V[ed[:,0]]-V[ed[:,1]],axis=1),1e-8);adj=coo_matrix((np.r_[w,w],(np.r_[ed[:,0],ed[:,1]],np.r_[ed[:,1],ed[:,0]])),shape=(len(V),len(V))).tocsr();L=diags(np.asarray(adj.sum(1)).ravel())-adj;free=np.flatnonzero(~fixed);held=np.flatnonzero(fixed);residual[free]=spsolve(L[free][:,free],-L[free][:,held]@residual[held]);N+=residual;N/=np.linalg.norm(N,axis=1)[:,None]
scale=np.array(j['nodes'][0]['scale']);trans=np.array(j['nodes'][0]['translation']);P=(V[:,[0,2,1]]*[1,1,-1]-trans)/scale;N=N[:,[0,2,1]]*[1,1,-1];P=P.astype('float32');N=N.astype('float32')
for a0,a1 in mapping.items():P[a1]=Pold[a0];N[a1]=Nold[a0];UV[a1]=UVold[a0]
attrs={}
for name,x,kind in [('POSITION',P,'VEC3'),('NORMAL',N,'VEC3'),('TEXCOORD_0',UV.astype('float32'),'VEC2')]:attrs[name],b=append_accessor(j,b,x,kind,34962)
for k,p in enumerate(pr):p['attributes']=attrs.copy();p['indices'],b=append_accessor(j,b,F[part==k].astype('uint32'),'SCALAR',34963)
out=R/'Green_sleeve74_body.glb';write_glb(out,j,b);rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'root_first_row_guides_hem_cuff_exact':True,'new_triangles':len(F),'periodic_fair_sigma_m':.003,'maximum_parameter_matched_displacement_m':maxMove,'interior_ring_edge_ratio_max':max(ratios),'status':'Unadopted uniform interior sampling and bounded periodic fairing; exact contact/shape checks pending.'};(R/'audit/sleeve74.json').write_text(json.dumps(rep,indent=2));np.savez_compressed(R/'audit/sleeve74_binding.npz',new_world=V,new_triangles=F,held_old_indices=np.array(list(mapping)),held_new_indices=np.array(list(mapping.values())));print(rep,flush=True)
