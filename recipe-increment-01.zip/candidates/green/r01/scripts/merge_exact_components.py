"""Append immutable GLB components with attribute/image buffers and node transforms preserved."""
import pathlib,sys,json,hashlib,copy,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,write_glb
out=R/(sys.argv[1]+'.glb');sources=[R/(s+'.glb')for s in sys.argv[2:]];J,B,A=read_glb(sources[0]);J=copy.deepcopy(J);B=bytes(B);records=[]
def inventory(path):
 j,b,a=read_glb(path);return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'triangles':sum(j['accessors'][p['indices']]['count']//3 for m in j['meshes']for p in m['primitives'])}
records.append(inventory(sources[0]))
for src in sources[1:]:
 j,b,a=read_glb(src);assert not j.get('skins')and not j.get('animations')and not j.get('cameras');offset={k:len(J.get(k,[]))for k in ['accessors','bufferViews','images','textures','samplers','materials','meshes','nodes']};B+=b'\0'*((-len(B))%4);bo=len(B);B+=bytes(b)
 for v in j.get('bufferViews',[]):v['byteOffset']=v.get('byteOffset',0)+bo;v['buffer']=0
 for ac in j.get('accessors',[]):ac['bufferView']+=offset['bufferViews'];assert not ac.get('sparse')
 for im in j.get('images',[]):
  if'bufferView'in im:im['bufferView']+=offset['bufferViews']
 for tex in j.get('textures',[]):
  if'source'in tex:tex['source']+=offset['images']
  if'sampler'in tex:tex['sampler']+=offset['samplers']
  for ext in tex.get('extensions',{}).values():
   if'source'in ext:ext['source']+=offset['images']
 def material_walk(d):
  if isinstance(d,dict):
   for k,v in d.items():
    if k.endswith('Texture')and isinstance(v,dict)and'index'in v:v['index']+=offset['textures']
    else:material_walk(v)
  elif isinstance(d,list):
   for v in d:material_walk(v)
 for mat in j.get('materials',[]):material_walk(mat)
 for mesh in j.get('meshes',[]):
  for pr in mesh['primitives']:
   pr['attributes']={k:v+offset['accessors']for k,v in pr['attributes'].items()}
   if'indices'in pr:pr['indices']+=offset['accessors']
   if'material'in pr:pr['material']+=offset['materials']
   assert not pr.get('targets')
 for node in j.get('nodes',[]):
  if'mesh'in node:node['mesh']+=offset['meshes']
  if'children'in node:node['children']=[n+offset['nodes']for n in node['children']]
 for k in offset:J.setdefault(k,[]).extend(j.get(k,[]))
 roots=j['scenes'][j.get('scene',0)]['nodes'];J['scenes'][J.get('scene',0)]['nodes'].extend([n+offset['nodes']for n in roots])
 for k in ['extensionsUsed','extensionsRequired']:J[k]=sorted(set(J.get(k,[])+j.get(k,[])))
 records.append(inventory(src))
write_glb(out,J,B);j,b,a=read_glb(out);report={'output':str(out),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'components':records,'total_triangles':sum(x['triangles']for x in records),'merge_semantics':'Buffer payloads, component node transforms and all corner attributes are preserved; only cross-reference indices and buffer offsets are rebased. No pose or material change.','unapproved':True};(R/'audit'/(out.stem+'_components.json')).write_text(json.dumps(report,indent=2));print(report,flush=True)
