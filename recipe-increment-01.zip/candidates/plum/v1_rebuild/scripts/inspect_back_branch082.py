"""Read-only bounded reverse-branch support proof on source purple strip.
No color selection, no removal. Complete proposed candidate family is excluded
from every retained support test. Source exact positions define edge incidence.
"""
from pathlib import Path
import sys,json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(R/'shared_helpers'))
from projected_backing import prove_coverage
src=O/'components/plum_raw_cleanup003.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(p['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(p['indices']).reshape(-1,3).astype(np.int64);T=P[F];G=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);G/=np.linalg.norm(G,axis=1)[:,None];SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];cent=T.mean(1);dot=(G*SN).sum(1)
# Entire triangle must be inside the explicitly inspected garment-strip world box.
lo=np.array([.09,.12,.15]);hi=np.array([.19,.24,.40]);domain=((T>=lo).all((1,2)) & (T<=hi).all((1,2)))
candidates=np.flatnonzero(domain&(dot<-.5)&(G[:,1]<-.15));U,iv=np.unique(P,axis=0,return_inverse=True);FT=iv[F];edges=collections.defaultdict(list)
for fi,f in enumerate(FT):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append(fi)
rows=[]
seen=set()
for seed in candidates:
 if int(seed) in seen:continue
 group={int(seed)};todo=[int(seed)]
 while todo:
  fi=todo.pop()
  for aa,bb in zip(FT[fi],np.roll(FT[fi],-1)):
   family=edges[tuple(sorted((int(aa),int(bb))))]
   if len(family)!=2:continue
   for other in family:
    if other not in group:group.add(other);todo.append(other)
  if len(group)>500:break
 seen.update(group);ids=np.array(sorted(group));tri=T[ids];boundary=[]
 for fi in ids:
  for aa,bb in zip(FT[fi],np.roll(FT[fi],-1)):
   edgekey=tuple(sorted((int(aa),int(bb))));fam=edges[edgekey]
   if any(ff not in group for ff in fam)or len(fam)==1:boundary.append({'edge':list(edgekey),'source_family':fam,'retained_family':[ff for ff in fam if ff not in group]})
 rows.append({'seed':int(seed),'faces':ids.tolist(),'face_count':len(ids),'within_inspected_domain':bool(domain[ids].all()),'world_bounds':[tri.min((0,1)).tolist(),tri.max((0,1)).tolist()],'geometric_stored_normal_dot_range':[float(dot[ids].min()),float(dot[ids].max())],'boundary':boundary})
 print('BRANCH082',int(seed),len(ids),bool(domain[ids].all()),flush=True)
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'components':rows,'scope':'Read-only complete manifold patches separated at original nonmanifold edges. No deletion or coverage approval.'};(O/'checks/source_back_branch082.json').write_text(json.dumps(r,indent=2))
