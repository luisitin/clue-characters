"""Read-only conforming source-plane sections for neck/shirt and sleeve integration planning.
Every source triangle is intersected before any anatomical region is ranked. No
spatial-guard clipping, convex hull, topology welding by proximity, or model edit.
"""
from pathlib import Path
import json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/plum_raw_cleanup003.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION']).astype(float);M=node_matrix(j['nodes'][0]);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];specs=[]
neckN=np.array([0.,-.263,1.]);neckN/=np.linalg.norm(neckN);neckC=np.array([-.030,.080,.59634]);armN=np.array([.55,-.35,.76]);armN/=np.linalg.norm(armN);armC=np.array([-.141,-.036,.488])
for tilt in [.3,.45,.6]:
 for height in [.62,.635,.65]:
  NN=np.array([0.,-tilt,1.]);NN/=np.linalg.norm(NN);CC=np.array([-.03,.08,height]);specs.append((f'neck_t{tilt:.2f}',height,CC,NN))
rows=[];arrays={}
for name,delta,C,N in specs:
 signed=(U-C)@N;triD=signed[T];active=np.flatnonzero((triD.min(1)<=1e-10)&(triD.max(1)>=-1e-10));keys={};Q=[];segs=[];faceids=[];coplanar=[]
 def node(key,point):
  if key not in keys:keys[key]=len(Q);Q.append(point)
  return keys[key]
 for fi in active:
  ids=T[fi];ds=signed[ids]
  if np.all(abs(ds)<1e-10):coplanar.append(int(fi));continue
  hits=[]
  for aa,bb in zip(ids,np.roll(ids,-1)):
   aa=int(aa);bb=int(bb);da=signed[aa];db=signed[bb]
   if abs(da)<1e-10:hits.append(node(('v',aa),U[aa]))
   if da*db<0:
    lo,hi=sorted((aa,bb));t=-signed[lo]/(signed[hi]-signed[lo]);hits.append(node(('e',lo,hi),U[lo]+t*(U[hi]-U[lo])))
  hits=list(dict.fromkeys(hits))
  if len(hits)==2:segs.append(hits);faceids.append(int(fi))
  elif len(hits)>2:raise AssertionError(('Ambiguous noncoplanar intersection',name,fi,hits))
 Q=np.array(Q);S=np.array(segs,int);multiplicity=collections.Counter(tuple(sorted(e))for e in segs);adj=collections.defaultdict(set)
 for aa,bb in multiplicity:adj[aa].add(bb);adj[bb].add(aa)
 left=set(adj);components=[]
 while left:
  first=min(left);group={first};todo=[first];left.remove(first)
  while todo:
   k=todo.pop()
   for other in adj[k]&left:left.remove(other);group.add(other);todo.append(other)
  ids=np.array(sorted(group));degrees=[len(adj[int(i)])for i in ids];duplicates=sum(m-1 for e,m in multiplicity.items()if e[0]in group);closed=set(degrees)=={2}and duplicates==0;cycle=[]
  if closed:
   cycle=[int(ids[0])];previous=None;current=cycle[0]
   while True:
    nxt=next(k for k in sorted(adj[current])if k!=previous)
    if nxt==cycle[0]:break
    assert nxt not in cycle;cycle.append(nxt);previous,current=current,nxt
   assert len(cycle)==len(ids)
  center=Q[ids].mean(0);perimeter=None
  if cycle:pp=Q[cycle];perimeter=float(np.linalg.norm(np.roll(pp,-1,axis=0)-pp,axis=1).sum())
  components.append({'nodes':len(ids),'closed_simple_graph':closed,'degree_counts':dict(collections.Counter(degrees)),'duplicate_segments':duplicates,'center_world':center.tolist(),'distance_from_plane_target_m':float(np.linalg.norm(center-C)),'world_bounds':[Q[ids].min(0).tolist(),Q[ids].max(0).tolist()],'perimeter_m':perimeter,'ordered_node_ids':cycle,'branch_nodes':[int(i)for i in ids if len(adj[int(i)])!=2]})
 components.sort(key=lambda r:r['distance_from_plane_target_m']);label=f'{name}_{delta:+.3f}';arrays[label+'_points']=Q;arrays[label+'_segments']=S;arrays[label+'_source_faces']=np.array(faceids);rows.append({'label':label,'origin_world':C.tolist(),'normal_world':N.tolist(),'intersected_triangles':len(active),'segments':len(S),'coplanar_source_faces':coplanar,'components':components});print('SECTION078',label,[(x['nodes'],x['closed_simple_graph'],round(x['distance_from_plane_target_m'],4),x['degree_counts'])for x in components[:5]],flush=True)
np.savez_compressed(O/'checks/join_sections078.npz',**arrays);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'sections':rows,'scope':'Graph/simple-loop evidence only. Candidate loops are not certified anatomical wrist or neck boundaries. Surface/part ownership, true all-around reference fit and retained-sheet continuity must be visually checked before any cut or bridge.'};(O/'checks/join_sections078.json').write_text(json.dumps(r,indent=2))
