"""Source-preserving body extraction at inspected neck and cuff construction planes.
The cuff split is temporary for component classification. Only the explicitly
isolated old-hand positive component is removed; all unrelated torso triangles
are restored unsplit. Every retained corner attribute is interpolated consistently.
This does not certify the construction seam as the final anatomical cuff entry.
"""
from pathlib import Path
import collections,hashlib,json,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/plum_cuff_sheet122.glb';j,b,a=read_glb(src);assert len(j['meshes'])==len(j['nodes'])==1;pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);attrs={k:a(ai).astype(float)for k,ai in pr['attributes'].items()};assert set(attrs)<= {'POSITION','NORMAL','TANGENT','TEXCOORD_0','TEXCOORD_1','COLOR_0'};F=a(pr['indices']).reshape(-1,3).astype(np.int64)
P=attrs['POSITION'];attrs['POSITION']=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=attrs['NORMAL']@np.linalg.inv(M[:3,:3]);N=N[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];attrs['NORMAL']=N
if 'TANGENT'in attrs:
 T=attrs['TANGENT'].copy();T[:,:3]=(T[:,:3]@M[:3,:3].T)[:,[0,2,1]]*[1,-1,1];T[:,:3]-=np.sum(T[:,:3]*N,axis=1)[:,None]*N;T[:,:3]/=np.linalg.norm(T[:,:3],axis=1)[:,None];T[:,3]*=np.sign(np.linalg.det(M[:3,:3]));attrs['TANGENT']=T
original={k:v.copy()for k,v in attrs.items()};lineage=np.arange(len(F));split_records=[]
def split_both(A,F,C,N,tag):
 P=A['POSITION'];U,iv=np.unique(P,axis=0,return_inverse=True);ds=(U-C)@N;lists={k:v.tolist()for k,v in A.items()};cache={};geom={};sides={1:[], -1:[]};parents={1:[], -1:[]};records=[]
 def point(aa,bb):
  key=tuple(sorted((int(aa),int(bb))))
  if key in cache:return cache[key]
  ia,ib=map(int,iv[[aa,bb]]);gk=tuple(sorted((ia,ib)))
  if gk not in geom:
   ga,gb=gk;t=-ds[ga]/(ds[gb]-ds[ga]);geom[gk]=U[ga]+t*(U[gb]-U[ga])
  da,db=ds[[ia,ib]];t=-da/(db-da);new={k:(1-t)*v[aa]+t*v[bb]for k,v in A.items()};new['POSITION']=geom[gk];new['NORMAL']/=np.linalg.norm(new['NORMAL'])
  if 'TANGENT'in new:
   assert A['TANGENT'][aa,3]==A['TANGENT'][bb,3];new['TANGENT'][3]=A['TANGENT'][aa,3];new['TANGENT'][:3]-=new['NORMAL']*(new['TANGENT'][:3]@new['NORMAL']);new['TANGENT'][:3]/=np.linalg.norm(new['TANGENT'][:3])
  ix=len(lists['POSITION'])
  for k,v in new.items():lists[k].append(v.tolist())
  cache[key]=ix;records.append({'vertex':ix,'edge':[aa,bb],'t':float(t),'stage':tag});return ix
 for fi,f in enumerate(F):
  for sign in [1,-1]:
   dd=ds[iv[f]]*sign
   if dd.min()>=0:sides[sign].append(f.tolist());parents[sign].append(fi);continue
   if dd.max()<=0:continue
   poly=[]
   for aa,bb in zip(f,np.roll(f,-1)):
    da,db=ds[iv[[aa,bb]]]*sign
    if da>=0:poly.append(int(aa))
    if da*db<0:poly.append(point(int(aa),int(bb)))
   assert len(poly)in(3,4)
   for q in range(1,len(poly)-1):sides[sign].append([poly[0],poly[q],poly[q+1]]);parents[sign].append(fi)
 return {k:np.array(v)for k,v in lists.items()},{s:np.array(v,np.int64)for s,v in sides.items()},{s:np.array(v,np.int64)for s,v in parents.items()},records
NC=np.array([-.03,.08,.635]);NN=np.array([0,-.45,1.]);NN/=np.linalg.norm(NN);A,FF,pp,rec=split_both(attrs,F,NC,NN,'neck');neckF=FF[-1];neck_lineage=lineage[pp[-1]];split_records+=rec
CC=np.array([-.1227316962,-.0569141390,.4987297898]);CN=np.array([.4198321007,-.1199520288,.8996402159]);CN/=np.linalg.norm(CN);B,CF,cp,rec=split_both(A,neckF,CC,CN,'cuff');split_records+=rec
U,iv=np.unique(B['POSITION'],axis=0,return_inverse=True);TF=iv[CF[1]];parent=np.arange(len(TF));edges=collections.defaultdict(list)
def root(k):
 while parent[k]!=k:parent[k]=parent[parent[k]];k=int(parent[k])
 return k
for fi,f in enumerate(TF):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append(fi)
for fam in edges.values():
 for fi in fam[1:]:parent[root(fi)]=root(fam[0])
bins=collections.defaultdict(list)
for fi in range(len(TF)):bins[root(fi)].append(fi)
rows=[];selected=[]
for ids in sorted(bins.values(),key=len,reverse=True):
 xyz=U[TF[ids]].reshape(-1,3);bounds=np.array([xyz.min(0),xyz.max(0)]);is_hand=bounds[1,2]<.61 and bounds[0,0]<-.14 and bounds[1,0]<0 and bounds[0,1]<-.10;rows.append({'triangles':len(ids),'world_bounds':bounds.tolist(),'selected_old_hand':bool(is_hand)})
 if is_hand:selected.extend(ids)
assert len(bins)==2 and len(selected)==2545,('Unexpected components',rows)
hand_parents=np.unique(cp[1][selected]);assert len(hand_parents)>2000
# Unrelated torso triangles retain their existing indices and do not inherit the
# temporary cuff plane's split vertices. Selected hand parents retain only their
# negative fragments; full positive parents are removed.
held=np.flatnonzero(~np.isin(np.arange(len(neckF)),hand_parents));nf=[neckF[held]];nl=[neck_lineage[held]];mask=np.isin(cp[-1],hand_parents);nf.append(CF[-1][mask]);nl.append(neck_lineage[cp[-1][mask]]);outF=np.vstack(nf);out_lineage=np.concatenate(nl);used=np.unique(outF);mapping=np.full(len(B['POSITION']),-1,np.int64);mapping[used]=np.arange(len(used));Q={k:v[used]for k,v in B.items()};outF=mapping[outF]
# Exact exported positional incidence at both explicit cut loops.
P32=Q['POSITION'].astype('<f4').astype(float);W,inv=np.unique(P32,axis=0,return_inverse=True);WT=inv[outF];ed=collections.defaultdict(list)
for fi,f in enumerate(WT):
 for aa,bb in zip(f,np.roll(f,-1)):ed[tuple(sorted((int(aa),int(bb))))].append(fi)
loops=[]
for label,C,N,expected in [('neck',NC,NN,129),('cuff_construction',CC,CN,117)]:
 cut=[e for e,fam in ed.items()if len(fam)==1 and max(abs((W[list(e)]-C)@N))<4e-8];adj=collections.defaultdict(list)
 for aa,bb in cut:adj[aa].append(bb);adj[bb].append(aa)
 assert len(cut)==expected and all(len(v)==2 for v in adj.values()),(label,len(cut));start=min(adj);ring=[start];prev=None;cur=start
 while True:
  nxt=next(k for k in adj[cur]if k!=prev)
  if nxt==start:break
  assert nxt not in ring;ring.append(nxt);prev,cur=cur,nxt
 assert len(ring)==expected;xyz=W[ring];loops.append({'label':label,'edge_count':len(cut),'ordered_world_points':xyz.tolist(),'perimeter_m':float(np.linalg.norm(np.roll(xyz,-1,axis=0)-xyz,axis=1).sum()),'maximum_diameter_m':float(np.linalg.norm(xyz[:,None]-xyz[None,:],axis=2).max()),'maximum_plane_residual_m':float(abs((xyz-C)@N).max())})
# Append all replacement arrays; embedded original textures and BIN remain intact.
payload=bytearray(b);newattrs={};attribute_errors={}
for semantic,values in Q.items():
 values=values.copy()
 if semantic in ['POSITION','NORMAL']:values=values[:,[0,2,1]]*[1,1,-1]
 elif semantic=='TANGENT':values[:,:3]=values[:,:3][:,[0,2,1]]*[1,1,-1]
 float64_values=values.copy();values=values.astype('<f4');payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':values.nbytes,'target':34962});payload.extend(values.tobytes());ai=len(j['accessors']);row={'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC'+str(values.shape[1])}
 if semantic=='POSITION':row.update(min=values.min(0).tolist(),max=values.max(0).tolist())
 j['accessors'].append(row);newattrs[semantic]=ai;attribute_errors[semantic]=float(np.max(abs(values.astype(float)-float64_values)))
ix=outF.astype('<u4').ravel();payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':ix.nbytes,'target':34963});payload.extend(ix.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':len(ix),'type':'SCALAR','min':[int(ix.min())],'max':[int(ix.max())]});pr['indices']=ai;pr['attributes']=newattrs;j['nodes'][0]={'name':'Plum retained source body144, construction cuff open','mesh':0};j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_body144.glb';dst.write_bytes(raw)
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'triangles':len(outF),'vertices':len(used),'temporary_cuff_positive_components':rows,'removed_hand_parent_count':len(hand_parents),'unrelated_neck_clipped_triangles_retained_unsplit':len(held),'explicit_boundaries':loops,'all_original_attribute_semantics_retained':list(newattrs),'all_attribute_float32_max_difference':attribute_errors,'native_UV_float32_max_difference':{k:v for k,v in attribute_errors.items()if k.startswith('TEXCOORD')},'embedded_original_BIN_prefix_held':True,'scope':'Unapproved body extraction with original paint. Exact selected old-hand component is removed after neck clipping. The oversized cuff construction seam remains open for a new measured garment interface; this is not a completed anatomical or material assembly.'};(O/'checks/source_body144.json').write_text(json.dumps(r,indent=2));np.savez_compressed(O/'checks/source_body144_lineage.npz',source122_face=out_lineage,source122_vertex_or_appended=used);print('BODY144',{k:v for k,v in r.items()if k!='explicit_boundaries'},flush=True)
