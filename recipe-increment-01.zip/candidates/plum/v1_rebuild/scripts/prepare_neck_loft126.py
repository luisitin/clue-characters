"""Isolated neck-join study between explicit, anatomically inspected source section
and a higher section of the held donor. No source/head position edits or body cut.
Exact source ring vertices remain endpoints; angular zipper topology preserves
all endpoint edges without inventing a convex hull or tolerance-collapsing knots.
"""
from pathlib import Path
import json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1]
C=np.array([-.03,.08,.635]);N=np.array([0.,-.45,1.]);N/=np.linalg.norm(N);U=np.array([1.,0.,0.]);V=np.cross(N,U);AX=np.array([U,V,N]);height=.006

def section(src,C):
 j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];VN=a(pr['attributes']['NORMAL']).astype(float);VN=(VN@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];VN/=np.linalg.norm(VN,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);W,iv=np.unique(P,axis=0,return_inverse=True);WF=iv[F];d=(W-C)@N;triD=d[WF];active=np.flatnonzero((triD.min(1)<0)&(triD.max(1)>0));keys={};Q=[];normals=[];S=[];origin=[]
 for fi in active:
  hits=[]
  for la,lb in [(0,1),(1,2),(2,0)]:
   aa,bb=map(int,WF[fi,[la,lb]]);da,db=d[[aa,bb]]
   if da*db>=0:continue
   lo,hi=sorted((aa,bb));key=(lo,hi);t=-d[lo]/(d[hi]-d[lo]);q=W[lo]+t*(W[hi]-W[lo]);tt=-da/(db-da);normal=VN[F[fi,la]]*(1-tt)+VN[F[fi,lb]]*tt;normal/=np.linalg.norm(normal)
   if key not in keys:keys[key]=len(Q);Q.append(q);normals.append([]);origin.append({'welded_source_edge':list(key),'interpolation_t':float(t),'incident_source_faces':[]})
   ix=keys[key];normals[ix].append(normal);origin[ix]['incident_source_faces'].append(int(fi));hits.append(ix)
  assert len(hits)==2;S.append(hits)
 adj=collections.defaultdict(set)
 for aa,bb in S:adj[aa].add(bb);adj[bb].add(aa)
 left=set(adj);comps=[]
 while left:
  seed=min(left);group={seed};left.remove(seed);todo=[seed]
  while todo:
   k=todo.pop()
   for nxt in adj[k]&left:left.remove(nxt);group.add(nxt);todo.append(nxt)
  if len(group)>20 and all(len(adj[k])==2 for k in group):comps.append(group)
 assert comps,'No simple section';Q=np.array(Q);group=min(comps,key=lambda g:np.linalg.norm(Q[list(g)].mean(0)-C));ring=[min(group)];prev=None;cur=ring[0]
 while True:
  nxt=next(k for k in sorted(adj[cur])if k!=prev)
  if nxt==ring[0]:break
  assert nxt not in ring;ring.append(nxt);prev,cur=cur,nxt
 assert len(ring)==len(group)
 Q=Q[ring];NN=np.array([np.mean(normals[k],axis=0)for k in ring]);NN/=np.linalg.norm(NN,axis=1)[:,None];spread=max(float(np.degrees(np.arccos(np.clip(n@NN[i],-1,1))))for i,k in enumerate(ring)for n in normals[k]);orig=[origin[k]for k in ring];ctr=Q.mean(0);xy=(Q-ctr)@AX[:2].T
 # Area centroid avoids assigning different polar phases solely from source tessellation density.
 cc=xy[:,0]*np.roll(xy[:,1],-1)-np.roll(xy[:,0],-1)*xy[:,1];signed_area=cc.sum()/2;offset_xy=np.sum((xy+np.roll(xy,-1,axis=0))*cc[:,None],axis=0)/(6*signed_area);ctr=ctr+offset_xy@AX[:2];xy=(Q-ctr)@AX[:2].T
 if np.sum(xy[:,0]*np.roll(xy[:,1],-1)-xy[:,1]*np.roll(xy[:,0],-1))<0:Q=Q[::-1];NN=NN[::-1];orig=orig[::-1];xy=xy[::-1]
 theta=np.mod(np.arctan2(xy[:,1],xy[:,0]),2*np.pi);i=int(theta.argmin());Q=np.roll(Q,-i,axis=0);NN=np.roll(NN,-i,axis=0);orig=orig[i:]+orig[:i];theta=np.roll(theta,-i);assert np.all(np.diff(theta)>1e-10),'Section is not injective in the chosen polar chart'
 assert theta[0]+2*np.pi-theta[-1]>1e-10
 return Q,NN,theta,{'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'plane_origin':C.tolist(),'plane_normal':N.tolist(),'count':len(Q),'perimeter_m':float(np.linalg.norm(np.roll(Q,-1,axis=0)-Q,axis=1).sum()),'area_centroid_world':ctr.tolist(),'world_center':ctr.tolist(),'max_interpolated_normal_spread_degrees':spread,'boundary_provenance':orig}

A,AN,at,ar=section(O/'components/plum_strip_cleanup085.glb',C)
B,BN,bt,br=section(O/'components/head_neck124.glb',C+height*N)
assert len(A)==129
alltheta=np.unique(np.r_[at,bt]);assert np.min(np.diff(alltheta))>1e-12

def cyclic(X,t,q):
 xp=np.r_[t[-1]-2*np.pi,t,t[0]+2*np.pi];yp=np.vstack([X[-1],X,X[0]]);return np.column_stack([np.interp(q,xp,yp[:,k])for k in range(X.shape[1])])
Aq=cyclic(A,at,alltheta);Bq=cyclic(B,bt,alltheta);Na=cyclic(AN,at,alltheta);Nb=cyclic(BN,bt,alltheta);Na/=np.linalg.norm(Na,axis=1)[:,None];Nb/=np.linalg.norm(Nb,axis=1)[:,None];D=Bq-Aq
Ta=D-Na*np.sum(D*Na,axis=1)[:,None];Tb=D-Nb*np.sum(D*Nb,axis=1)[:,None]
# No tangent may turn backward along the explicit join axis.
assert np.min(Ta@N)>0 and np.min(Tb@N)>0,'Source tangent would fold the join back through its endpoint plane'
rows=[A];params=[at]
for t in np.linspace(0,1,17)[1:-1]:
 h00=2*t**3-3*t**2+1;h10=t**3-2*t**2+t;h01=-2*t**3+3*t**2;h11=t**3-t**2
 rows.append(h00*Aq+h10*Ta+h01*Bq+h11*Tb);params.append(alltheta)
rows.append(B);params.append(bt);offset=np.r_[0,np.cumsum([len(x)for x in rows])];P=np.vstack(rows);F=[]
for layer in range(len(rows)-1):
 aa=params[layer];bb=params[layer+1];na=len(aa);nb=len(bb);i=k=0;fa=int(offset[layer]);fb=int(offset[layer+1]);count=0
 while i<na or k<nb:
  an=aa[(i+1)%na]+(2*np.pi if i+1>=na else 0)if i<na else float('inf');bn=bb[(k+1)%nb]+(2*np.pi if k+1>=nb else 0)if k<nb else float('inf')
  if an<=bn:F.append([fa+i%na,fa+(i+1)%na,fb+k%nb]);i+=1
  else:F.append([fa+i%na,fb+(k+1)%nb,fb+k%nb]);k+=1
  count+=1
 assert count==na+nb
F=np.array(F,np.int64);tri=P[F];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1)/2;GN=cross/np.maximum(2*area[:,None],1e-30);centerline=(A.mean(0)+B.mean(0))/2;rad=tri.mean(1)-centerline;rad-=np.outer(rad@N,N);rad/=np.linalg.norm(rad,axis=1)[:,None];rdot=(rad*GN).sum(1)
edges=collections.defaultdict(list)
for fi,f in enumerate(F):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append(fi)
bound=[e for e,fs in edges.items()if len(fs)==1];expected={tuple(sorted((int(offset[0]+i),int(offset[0]+(i+1)%len(A)))))for i in range(len(A))}|{tuple(sorted((int(offset[-2]+i),int(offset[-2]+(i+1)%len(B)))))for i in range(len(B))};assert set(bound)==expected;assert max(map(len,edges.values()))==2
pairs=np.array([fs for fs in edges.values()if len(fs)==2]);angles=np.degrees(np.arccos(np.clip((GN[pairs[:,0]]*GN[pairs[:,1]]).sum(1),-1,1)));norm=np.zeros_like(P)
for k in range(3):np.add.at(norm,F[:,k],cross)
norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-30);norm[:len(A)]=AN;norm[offset[-2]:]=BN
np.savez_compressed(O/'checks/neck_loft126.npz',positions=P,triangles=F,normals=norm,row_offsets=offset,source_ring=A,donor_ring=B,source_angles=at,donor_angles=bt)
r={'endpoints':[ar,br],'height_m':height,'triangle_count':len(F),'minimum_triangle_area_m2':float(area.min()),'minimum_outward_radial_normal_dot':float(rdot.min()),'max_adjacent_angle_degrees':float(angles.max()),'folds_over105':int((angles>105).sum()),'all_endpoint_edges_preserved_once':True,'max_edge_incidence':max(map(len,edges.values())),'boundary_count':len(bound),'source_and_donor_positions_unchanged':True,'scope':'Isolated unapproved join study. No source body cut. Requires all exact intersections, endpoint tangent/normal continuity, anatomical silhouette and actual lit/clay views before integration.'};(O/'checks/neck_loft126.json').write_text(json.dumps(r,indent=2));print('LOFT126',json.dumps({k:v for k,v in r.items()if k!='endpoints'}),flush=True)
