"""Read-only tiled full-area/edge support proof for inventory102, never a removal.
All candidate components are excluded from support. Pairwise shared attachment
conflicts are reported: individual incidence does not authorize a combined cut.
"""
from pathlib import Path
import sys,json,hashlib,argparse,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(R/'shared_helpers'));from projected_backing import prove_coverage
pa=argparse.ArgumentParser();pa.add_argument('--tile',type=int,required=True);pa.add_argument('--size',type=int,default=15);args=pa.parse_args();inventory=json.loads((O/'checks/backed_branch_inventory102.json').read_text());src=Path(inventory['source']);assert hashlib.sha256(src.read_bytes()).hexdigest()==inventory['source_sha256'];j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);T=P[F];G=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);G/=np.linalg.norm(G,axis=1)[:,None];SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];healthy=(G*SN).sum(1)>.3;lo=T.min(1);hi=T.max(1);groups=inventory['candidates'];excluded=sorted(set(fi for g in groups for fi in g['faces']));edgeowners=collections.defaultdict(set)
for g in groups:
 for e in g['boundary']:edgeowners[tuple(e['welded_edge'])].add(g['component_root'])
conflicts=collections.defaultdict(set)
for owners in edgeowners.values():
 if len(owners)>1:
  for k in owners:conflicts[k].update(owners-{k})
rows=[]
for gi in range(args.tile*args.size,min((args.tile+1)*args.size,len(groups))):
 group=groups[gi];AX,AY,D=np.array(group['chart_U_V_D']);proofs=[]
 for fi in group['faces']:
  subject=T[fi];near=np.all(hi>=subject.min(0)-.0031,axis=1)&np.all(lo<=subject.max(0)+.0031,axis=1)&healthy;ids=np.flatnonzero(near)
  try:proof=prove_coverage(subject,T[ids],ids,AX,AY,D,excluded_support_ids=excluded,maximum_ray_depth=.003,minimum_support_facing=.15)
  except (AssertionError,np.linalg.LinAlgError) as error:
   proof={'passed':False,'reason':'Conservative unresolved numeric support test; no threshold relaxation or removal approval','numerical_error':str(error)};print('NUMERICAL_HOLD104',gi,fi,str(error),flush=True)
  proofs.append({'face':fi,'coverage':proof})
 passed=all(x['coverage']['passed']for x in proofs);rows.append({'inventory_index':gi,'component_root':group['component_root'],'seed':group['seed'],'faces':group['faces'],'world_bounds':group['world_bounds'],'complete_component_backing_pass':passed,'other_components_sharing_attachment':sorted(conflicts[group['component_root']]),'proofs':proofs});print('INVENTORY104',gi,group['component_root'],passed,len(conflicts[group['component_root']]),flush=True)
r={'source_sha256':inventory['source_sha256'],'inventory_sha256':hashlib.sha256((O/'checks/backed_branch_inventory102.json').read_bytes()).hexdigest(),'tile':args.tile,'size':args.size,'complete_excluded_candidate_family':excluded,'support_stored_geometric_alignment_min':.3,'groups':rows,'scope':'Read-only support diagnosis only. Individual passing components are not a combined deletion list; mutual attachment conflicts, semantic ownership and actual matched appearance remain independent gates.'};(O/f'checks/branch_coverage104_{args.tile:02}.json').write_text(json.dumps(r,indent=2));print('TILE104_END',args.tile,len(rows),sum(r['complete_component_backing_pass']for r in rows),flush=True)
