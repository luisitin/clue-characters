"""Read-only inventory of small source patches with an opposed-normal face.
Complete2-face-connected components, not color/RGB selection. No edits, no
support/removal decision; surviving attachment incidence is checked explicitly.
"""
from pathlib import Path
import json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/plum_strip_cleanup085.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);tri=P[F];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1)/2;G=cross/(2*area[:,None]);SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];dot=(SN*G).sum(1);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list);parent=np.arange(len(F))
def root(k):
 while parent[k]!=k:parent[k]=parent[parent[k]];k=int(parent[k])
 return k
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
for family in edge.values():
 if len(family)==2:parent[root(family[1])]=root(family[0])
bins=collections.defaultdict(list)
for fi in range(len(F)):bins[root(fi)].append(fi)
seed=np.flatnonzero(dot<-.5);roots=sorted(set(root(int(fi))for fi in seed));candidates=[];rejected=[]
for rr in roots:
 ids=np.array(bins[rr]);xyz=tri[ids];lo=xyz.min((0,1));hi=xyz.max((0,1));extent=float(np.linalg.norm(hi-lo));reasons=[]
 if len(ids)>20:reasons.append('component_larger_than20_faces')
 if extent>.045:reasons.append('extent_larger_than45mm')
 if reasons:rejected.append({'component_root':rr,'faces':len(ids),'extent_m':extent,'reasons':reasons});continue
 group=set(map(int,ids));boundary={}
 for fi in ids:
  for aa,bb in zip(T[fi],np.roll(T[fi],-1)):
   key=tuple(sorted((int(aa),int(bb))));fam=edge[key]
   if len(fam)==1 or any(k not in group for k in fam):boundary[key]={'source_faces':fam,'retained_faces':[k for k in fam if k not in group]}
 if any(len(q['retained_faces'])not in(0,2)for q in boundary.values()):rejected.append({'component_root':rr,'faces':len(ids),'extent_m':extent,'reasons':['surviving_attachment_not_two_face']});continue
 opposed=ids[dot[ids]<-.5];key=int(opposed[np.argmax(area[opposed])]);D=SN[key];helper=np.eye(3)[np.argmin(abs(D))];AX=np.cross(helper,D);AX/=np.linalg.norm(AX);AY=np.cross(D,AX);assert np.allclose(np.array([AX,AY,D])@np.array([AX,AY,D]).T,np.eye(3));candidates.append({'component_root':rr,'seed':key,'faces':ids.tolist(),'opposed_faces':opposed.tolist(),'world_bounds':[lo.tolist(),hi.tolist()],'extent_m':extent,'surface_area_m2':float(area[ids].sum()),'normal_dot_stored_range':[float(dot[ids].min()),float(dot[ids].max())],'chart_U_V_D':np.array([AX,AY,D]).tolist(),'boundary':[{'welded_edge':list(k),**v}for k,v in boundary.items()]})
r={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'opposed_face_count':len(seed),'candidate_count':len(candidates),'candidate_face_count':sum(len(x['faces'])for x in candidates),'candidates':candidates,'rejected_components':rejected,'scope':'Read-only diagnosis only. Small complete components with geometric/stored-normal opposition and retained two-face attachment; not a deletion list. Every triangle/edge still needs retained backing and actual ownership/appearance checks.'};(O/'checks/backed_branch_inventory102.json').write_text(json.dumps(r,indent=2));print('INVENTORY102',r['opposed_face_count'],r['candidate_count'],r['candidate_face_count'],collections.Counter(v for x in rejected for v in x['reasons']),flush=True)
