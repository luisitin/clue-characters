"""Bounded cuff overlay trial retaining the finer native4-triangle disk.
The two disks have identical four oriented geometric boundary edges and held
boundary normals; they are not exact UV duplicates.120 records their different
UV charts but <=2/255 sampled base-color difference. Original inputs stay held.
"""
from pathlib import Path
import json,struct,hashlib,collections,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];src=O/'components/plum_strip_cleanup085.glb';proof=json.loads((O/'checks/cuff_overlay120.json').read_text());sha=hashlib.sha256(src.read_bytes()).hexdigest();assert proof['source_sha256']==sha;assert proof['same_four_directed_boundary_edges'] and proof['both_projected_disks_positive_orientation_and_euler_one'];assert proof['maximum_surface_separation_along_local_normal_m']<.0006;assert proof['max_sampled_RGB_channel_difference']<2.01/255
for q in proof['boundary_payload']:assert q['attributes']['POSITION']['exact_set_match'] and q['attributes']['NORMAL']['exact_set_match']
j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];F=a(pr['indices']).reshape(-1,3).astype(np.int64);remove=set(proof['coarse_patch_faces']);assert remove=={24148,76957};P=a(pr['attributes']['POSITION']);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
for key,fam in edge.items():
 if not any(fi in remove for fi,aa,bb in fam):continue
 remain=[r for r in fam if r[0]not in remove];assert len(remain)in(0,2)
 if remain:assert remain[0][1:]==remain[1][1:][::-1]
keep=np.ones(len(F),bool);keep[sorted(remove)]=False;new=F[keep].astype('<u4');payload=bytearray(b);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':new.nbytes,'target':34963});payload.extend(new.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':new.size,'type':'SCALAR','min':[int(new.min())],'max':[int(new.max())]});pr['indices']=ai;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/plum_cuff_sheet122.glb';dst.write_bytes(raw);jj,bb,aa=read_glb(dst);assert bb[:len(b)]==b;np.savez_compressed(O/'checks/cuff_sheet122_lineage.npz',new_to_085_face=np.flatnonzero(keep),removed_085_faces=np.array(sorted(remove)));r={'source_sha256':sha,'output_sha256':hashlib.sha256(raw).hexdigest(),'removed_085_faces':sorted(remove),'retained_finer_patch_085_faces':proof['fine_patch_faces'],'original_BIN_and_all_vertex_attributes_unchanged':True,'surviving_attachment_incidence_and_opposite_parity_pass':True,'cuff_overlay_proof_sha256':hashlib.sha256((O/'checks/cuff_overlay120.json').read_bytes()).hexdigest(),'scope':'Unapproved bounded alternate-tessellation cleanup. A2-triangle sheet is removed while the same-boundary native4-triangle surface remains. UV charts are not claimed identical; actual material/cuff section views are still required. This excludes the separate global121 trial.'};(O/'checks/cuff_sheet122.json').write_text(json.dumps(r,indent=2));print('CUFF122',r,flush=True)
