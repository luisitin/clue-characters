"""Read-only bounded reverse-branch support proof on source purple strip.
No color selection, no removal. Complete proposed candidate family is excluded
from every retained support test. Source exact positions define edge incidence.
"""
from pathlib import Path
import sys,json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(R/'shared_helpers'))
from projected_backing import prove_coverage
src=O/'components/plum_raw_cleanup003.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(p['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(p['indices']).reshape(-1,3).astype(np.int64);T=P[F];G=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);G/=np.linalg.norm(G,axis=1)[:,None];SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];cent=T.mean(1);dot=(G*SN).sum(1)
# Entire triangle must be inside the explicitly inspected garment-strip world box.
lo=np.array([.09,.12,.15]);hi=np.array([.19,.24,.40]);domain=((T>=lo).all((1,2)) & (T<=hi).all((1,2)))
candidates=np.flatnonzero(domain&(dot<-.5)&(G[:,1]<-.15));U,iv=np.unique(P,axis=0,return_inverse=True);FT=iv[F];edges=collections.defaultdict(list)
for fi,f in enumerate(FT):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append(fi)
groups=json.loads((O/'checks/source_back_branch082.json').read_text())['components'];eligible=[g for g in groups if g['within_inspected_domain'] and all(len(e['retained_family']) in (0,2)for e in g['boundary'])];excluded=sorted(set(fi for g in eligible for fi in g['faces']));rows=[]
for group in eligible:
 proofs=[]
 for fi in group['faces']:
  tri=T[fi];near=((T[:,:,0].max(1)>=tri[:,0].min()-1e-8)&(T[:,:,0].min(1)<=tri[:,0].max()+1e-8)&(T[:,:,2].max(1)>=tri[:,2].min()-1e-8)&(T[:,:,2].min(1)<=tri[:,2].max()+1e-8)&(T[:,:,1].max(1)>=tri[:,1].min()-.003)&(T[:,:,1].min(1)<=tri[:,1].max()+5e-6));ids=np.flatnonzero(near)
  proof=prove_coverage(tri,T[ids],ids,[1,0,0],[0,0,1],[0,1,0],excluded_support_ids=excluded,maximum_ray_depth=.003,minimum_support_facing=.15)
  proofs.append({'face':fi,'coverage':proof});print('GROUP083',group['seed'],fi,proof['passed'],flush=True)
 rows.append({'seed':group['seed'],'faces':group['faces'],'complete_component_pass':all(r['coverage']['passed']for r in proofs),'boundary':group['boundary'],'proofs':proofs})
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'complete_excluded_family':excluded,'groups':rows,'scope':'Complete bounded component coverage and surviving-edge incidence proof. Still requires explicit ownership and actual matched visual regression before any acceptance.'};(O/'checks/source_back_coverage083.json').write_text(json.dumps(r,indent=2))
