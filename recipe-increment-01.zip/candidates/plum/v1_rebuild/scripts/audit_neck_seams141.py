"""Read-only exact exported neck boundary, component and tangent audit."""
from pathlib import Path
import collections,json,hashlib,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];src=O/'components/neck_context127.glb';j,b,a=read_glb(src);Ps=[];Ns=[];Fs=[];groups=[];vo=fo=0;comp=[]
for mi,m in enumerate(j['meshes']):
 p=m['primitives'][0];P=a(p['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(np.int64);groups.append((fo,fo+len(F)));fo+=len(F);Ps.append(P);Ns.append(N);Fs.append(F+vo);vo+=len(P)
 # Physical face components use complete positional edge correspondence.
 U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];parent=np.arange(len(F));edge=collections.defaultdict(list)
 def root(k):
  while parent[k]!=k:parent[k]=parent[parent[k]];k=int(parent[k])
  return k
 for fi,f in enumerate(T):
  for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
 for fam in edge.values():
  for fi in fam[1:]:parent[root(fi)]=root(fam[0])
 bins=collections.defaultdict(list)
 for fi in range(len(F)):bins[root(fi)].append(fi)
 cr=[]
 for ids in sorted(bins.values(),key=len,reverse=True):
  xyz=P[F[ids]].reshape(-1,3);cr.append({'faces':len(ids),'bounds':[xyz.min(0).tolist(),xyz.max(0).tolist()],'source_triangle_ids':ids if len(ids)<1000 else None})
 comp.append({'mesh':mi,'name':m.get('name'),'components':cr,'physical_open_edges':sum(len(fs)==1 for fs in edge.values())})
P=np.vstack(Ps);N=np.vstack(Ns);F=np.vstack(Fs);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);G/=np.linalg.norm(G,axis=1)[:,None];edge=collections.defaultdict(list);gid=np.empty(len(F),int)
for k,(lo,hi)in enumerate(groups):gid[lo:hi]=k
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
seams=[]
for key,fam in edge.items():
 if len(set(gid[fam]))<2:continue
 assert len(fam)==2,('Joint incidence',key,fam);fa,fb=fam;assert 2 in gid[fam];dots=[]
 for vertex in key:
  na=N[F[fa][np.flatnonzero(T[fa]==vertex)[0]]];nb=N[F[fb][np.flatnonzero(T[fb]==vertex)[0]]];dots.append(float(na@nb/np.linalg.norm(na)/np.linalg.norm(nb)))
 seams.append({'edge':list(key),'groups':gid[fam].tolist(),'faces':fam,'geometric_angle_degrees':float(np.degrees(np.arccos(np.clip(G[fa]@G[fb],-1,1)))),'stored_normal_angle_max_degrees':float(np.degrees(np.arccos(np.clip(min(dots),-1,1))))})
lo,hi=groups[2];cornerdot=(G[lo:hi,None,:]*N[F[lo:hi]]).sum(2);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'components':comp,'joined_edges':len(seams),'joint_edge_groups':dict(collections.Counter(str(sorted(x['groups']))for x in seams)),'max_join_geometric_angle_degrees':max(s['geometric_angle_degrees']for s in seams),'max_join_stored_normal_angle_degrees':max(s['stored_normal_angle_max_degrees']for s in seams),'new_loft_min_corner_normal_dot':float(cornerdot.min()),'worst_seams':sorted(seams,key=lambda s:s['geometric_angle_degrees'],reverse=True)[:20],'scope':'Diagnostic-only export seam/component audit; open old hand stump and source defects remain. No shape acceptance.'};(O/'checks/neck_seams141.json').write_text(json.dumps(r,indent=2));print('NECK141',json.dumps({k:v for k,v in r.items()if k not in ['components','worst_seams']}),flush=True)
