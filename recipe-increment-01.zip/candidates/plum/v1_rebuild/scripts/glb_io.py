"""Minimal strict glTF2 GLB reader; immutable raw accessors retained for topology edits."""
import json,struct,pathlib,numpy as np
DT={5120:np.dtype('i1'),5121:np.dtype('u1'),5122:np.dtype('<i2'),5123:np.dtype('<u2'),5125:np.dtype('<u4'),5126:np.dtype('<f4')};NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT2':4,'MAT3':9,'MAT4':16}
def read_glb(path):
 raw=pathlib.Path(path).read_bytes();magic,ver,length=struct.unpack_from('<4sII',raw);assert magic==b'glTF'and ver==2 and length==len(raw);off=12;j=None;binary=None
 while off<len(raw):
  n,t=struct.unpack_from('<II',raw,off);off+=8;chunk=raw[off:off+n];off+=n
  if t==0x4e4f534a:j=json.loads(chunk)
  elif t==0x004e4942:binary=chunk
 assert j is not None and binary is not None
 def arr(index, decode_normalized=True):
  ac=j['accessors'][index];assert 'sparse'not in ac;v=j['bufferViews'][ac['bufferView']];dt=DT[ac['componentType']];nc=NC[ac['type']];stride=v.get('byteStride',dt.itemsize*nc);start=v.get('byteOffset',0)+ac.get('byteOffset',0);n=ac['count'];assert stride>=dt.itemsize*nc and start+max(0,n-1)*stride+dt.itemsize*nc<=len(binary);a=np.ndarray((n,nc),dtype=dt,buffer=binary,offset=start,strides=(stride,dt.itemsize)).copy()
  if decode_normalized and ac.get('normalized',False):
   assert dt.kind in 'iu';info=np.iinfo(dt);a=a.astype(np.float64)/info.max
   if dt.kind=='i':a=np.maximum(a,-1.)
  return a[:,0]if nc==1 else a
 return j,binary,arr

def node_matrix(node):
 if 'matrix'in node:return np.array(node['matrix'],float).reshape(4,4).T
 x,y,z,w=node.get('rotation',[0,0,0,1]);R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]);M=np.eye(4);M[:3,:3]=R@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);return M
