"""Read-only low-RAM view with complete immutable source/camera provenance."""
import bpy,math,pathlib,json,os,hashlib
from mathutils import Vector
src=pathlib.Path(os.environ['SOURCE']);out=pathlib.Path(os.environ['OUT']);out.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src));mode=os.environ.get('MODE','lit')
if mode=='clay':
 for mat in bpy.data.materials:
  mat.use_nodes=True;ns=mat.node_tree.nodes;ns.clear();o=ns.new('ShaderNodeOutputMaterial');d=ns.new('ShaderNodeBsdfDiffuse');d.inputs['Color'].default_value=(.5,.5,.5,1);d.inputs['Roughness'].default_value=.8;mat.node_tree.links.new(d.outputs[0],o.inputs['Surface'])
 for im in list(bpy.data.images):
  if im.users==0:bpy.data.images.remove(im)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=int(os.environ.get('SAMPLES','32'));scene.cycles.use_denoising=False;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.05;scene.cycles.adaptive_min_samples=8;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.render.resolution_x=int(os.environ.get('RES','720'));scene.render.resolution_y=scene.render.resolution_x;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.world=bpy.data.worlds.new('Neutral review studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.18,.18,.18,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.65;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
center=Vector(json.loads(os.environ.get('CENTER','[0,0,0]')));scale=float(os.environ.get('SCALE','2.2'));angle=float(os.environ.get('ANGLE','0'));elev=float(os.environ.get('ELEV','0'))
for label,loc,energy,size in [('Key',(-3,-4,4),180,4),('Fill',(4,-2,2),120,4),('Rear',(0,3,3),140,4)]:
 d=bpy.data.lights.new(label,'AREA');d.energy=energy;d.shape='DISK';d.size=size;o=bpy.data.objects.new(label,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;cam.data.type='ORTHO';scene.camera=cam;cam.location=center+Vector((math.sin(math.radians(angle))*5,-math.cos(math.radians(angle))*5,5*math.tan(math.radians(elev))));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=scale
name=f'{mode}_{int(angle):03}_{int(elev):+03}';scene.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'mode':mode,'center':list(center),'angle_degrees':angle,'elevation_degrees':elev,'ortho_scale':scale,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'samples':scene.cycles.samples,'denoising':False,'camera_world_matrix':[list(r)for r in cam.matrix_world],'camera_inverse_world_matrix':[list(r)for r in cam.matrix_world.inverted()],'projection_type':cam.data.type,'lens_mm':cam.data.lens,'sensor_width_mm':cam.data.sensor_width,'clip_range':[cam.data.clip_start,cam.data.clip_end],'pixel_center_convention':'x+0.5,y+0.5; image origin upper-left','geometry_unchanged':True,'clay_unused_texture_nodes_removed':mode=='clay'};(out/(name+'.json')).write_text(json.dumps(report,indent=2))
