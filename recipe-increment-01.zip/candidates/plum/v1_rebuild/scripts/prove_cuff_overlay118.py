"""Read-only proof of two same-boundary, same-oriented cuff patch tessellations.
This classifies a front-facing2-triangle/4-triangle overlay separately from
opposed-normal branches. No black-pixel or color-based removal decision.
"""
from pathlib import Path
import sys,json,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];sys.path.insert(0,str(O.parents[2]/'shared_helpers'));from projected_backing import intersection,area
src=O/'components/plum_strip_cleanup085.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);attrs={k:a(v)for k,v in pr['attributes'].items()};P=attrs['POSITION'].astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=attrs['NORMAL'].astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];A=np.array([24148,76957]);B=np.array([24149,47046,47047,76078]);allids=np.r_[A,B];tri=P[F];G=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);G/=np.linalg.norm(G,axis=1)[:,None];D=G[A].mean(0);D/=np.linalg.norm(D);u=np.cross(np.eye(3)[np.argmin(abs(D))],D);u/=np.linalg.norm(u);v=np.cross(D,u);AX=np.array([u,v,D]);center=tri[allids].mean((0,1));Q=(P-center)@AX.T;edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
def disk(ids):
 own=collections.defaultdict(list)
 for fi in ids:
  f=T[fi]
  for aa,bb in zip(f,np.roll(f,-1)):own[tuple(sorted((int(aa),int(bb))))].append((int(aa),int(bb)))
 assert max(map(len,own.values()))==2
 for rows in own.values():
  if len(rows)==2:assert rows[0]==rows[1][::-1]
 boundary=[rows[0]for rows in own.values()if len(rows)==1];nexts=dict(boundary);assert len(nexts)==len(boundary);loop=[min(nexts)]
 while nexts[loop[-1]]!=loop[0]:loop.append(nexts[loop[-1]]);assert len(loop)<=len(boundary)
 assert len(loop)==len(boundary);xyz=U[loop];xy=(xyz-center)@AX[:2].T;assert len(set(map(tuple,boundary)))==len(boundary);qt=Q[F[ids]];signed=np.cross(qt[:,1,:2]-qt[:,0,:2],qt[:,2,:2]-qt[:,0,:2]);assert np.all(signed>1e-15);ar=area(xy);assert abs(signed.sum()/2-ar)<1e-14;assert len(np.unique(T[ids]))-len(own)+len(ids)==1;return boundary,loop,ar
ba,la,aa=disk(A);bb,lb,ab=disk(B);assert set(ba)==set(bb);assert len(ba)==4
boundary_payload=[]
for vi in la:
 ia=sorted(set(int(i)for f in F[A]for i in f if iv[i]==vi));ib=sorted(set(int(i)for f in F[B]for i in f if iv[i]==vi));row={'welded_vertex':int(vi),'world':U[vi].tolist(),'attributes':{}}
 for k,val in attrs.items():
  va=val[ia];vb=val[ib];row['attributes'][k]={'exact_set_match':{tuple(np.atleast_1d(x))for x in va}=={tuple(np.atleast_1d(x))for x in vb}}
 boundary_payload.append(row)
intersections=[];maxdepth=0.;UVmax={k:0. for k in attrs if k.startswith('TEXCOORD_')}
for fa in A:
 qa=Q[F[fa]];da=np.linalg.solve(np.c_[qa[:,:2],np.ones(3)],qa[:,2]);covered=0.
 for fb in B:
  qb=Q[F[fb]];poly=intersection(qa[:,:2],qb[:,:2]);ar=area(poly)
  if ar<1e-18:continue
  covered+=ar;db=np.linalg.solve(np.c_[qb[:,:2],np.ones(3)],qb[:,2]);h=np.c_[poly,np.ones(len(poly))];dep=h@(da-db);maxdepth=max(maxdepth,float(abs(dep).max()));uvdiff={}
  for k in UVmax:
   ca=np.linalg.solve(np.c_[qa[:,:2],np.ones(3)],attrs[k][F[fa]]);cb=np.linalg.solve(np.c_[qb[:,:2],np.ones(3)],attrs[k][F[fb]]);difference=h@(ca-cb);mx=float(abs(difference).max());UVmax[k]=max(UVmax[k],mx);uvdiff[k]=mx
  intersections.append({'coarse_face':int(fa),'fine_face':int(fb),'projected_area_m2':ar,'signed_depth_range_m':[float(dep.min()),float(dep.max())],'UV_max_absolute_difference':uvdiff})
 assert abs(covered-area(qa[:,:2]))<1e-14
retained=[]
for e in ba:
 fam=edge[tuple(sorted(e))];remain=[r for r in fam if r[0]not in A];assert len(remain)==2;assert remain[0][1:]==remain[1][1:][::-1];retained.append({'edge':list(e),'before_faces':[r[0]for r in fam],'after_faces':[r[0]for r in remain]})
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'coarse_patch_faces':A.tolist(),'fine_patch_faces':B.tolist(),'same_four_directed_boundary_edges':True,'both_projected_disks_positive_orientation_and_euler_one':True,'projected_patch_area_m2':aa,'maximum_surface_separation_along_local_normal_m':maxdepth,'UV_field_max_absolute_difference':UVmax,'UV_field_max_difference_at4096_texels':{k:v*4096 for k,v in UVmax.items()},'boundary_payload':boundary_payload,'projected_intersections':intersections,'retained_edge_parity_if_coarse_removed':retained,'scope':'Read-only alternate-tessellation overlay proof. This is not an opposed-normal deletion. Inspect payload/depth tolerances and actual cuff appearance before selecting a retained sheet.'};(O/'checks/cuff_overlay118.json').write_text(json.dumps(r,indent=2));print('CUFF118',json.dumps({k:v for k,v in r.items()if k not in ['boundary_payload','projected_intersections','retained_edge_parity_if_coarse_removed']}),flush=True)
