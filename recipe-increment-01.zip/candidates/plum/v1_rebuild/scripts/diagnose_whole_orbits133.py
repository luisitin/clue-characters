"""Bounded TPS whole-orbit skin trial with exact physical apertures held.
Only projected-front, geodesically local skin may change. The desired smooth depth
field is constrained by every aperture vertex and healthy far-band skin samples;
C2 displacement fades retain the rim and outside tangents. No topology/UV change.
"""
from pathlib import Path
import json,struct,hashlib,collections,numpy as np
from scipy.interpolate import RBFInterpolator
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/head_corners065.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);assert np.allclose(M,np.eye(4));P=a(pr['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(pr['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
adj=collections.defaultdict(list)
for (aa,bb),fs in edge.items():
 if len(fs)==1:adj[aa].append(bb);adj[bb].append(aa)
assert all(len(v)==2 for v in adj.values());left=set(adj);loops=[]
while left:
 start=min(left);ring=[start];prev=None;cur=start
 while True:
  nxt=next(q for q in adj[cur]if q!=prev)
  if nxt==start:break
  assert nxt not in ring;ring.append(nxt);prev,cur=cur,nxt
 left-=set(ring);loops.append(np.array(ring,int))
EE=np.array(list(edge));length=np.linalg.norm(U[EE[:,0]]-U[EE[:,1]],axis=1);graph=coo_matrix((np.r_[length,length],(np.r_[EE[:,0],EE[:,1]],np.r_[EE[:,1],EE[:,0]])),shape=(len(U),len(U))).tocsr();UN=np.zeros_like(U);counts=np.zeros(len(U));np.add.at(UN,iv,N);np.add.at(counts,iv,1);UN/=counts[:,None];UN/=np.linalg.norm(UN,axis=1)[:,None];Q=U.copy();records=[];allfixed=[]
def smooth(t):
 t=np.clip(t,0,1);return t*t*t*(t*(t*6-15)+10)
for row in json.loads((O/'checks/regular_orbits033.json').read_text())['eyes']:
 target=np.array(row['boundary_target_world']).mean(0);ring=min(loops,key=lambda ids:np.linalg.norm(U[ids].mean(0)-target));assert len(ring)==128;C=U[ring].mean(0);X,Y,D=np.array(row['frame']);local=np.c_[(U-C)@X,(U-C)@Y,(U-C)@D];x,y,z=local.T;dist=dijkstra(graph,directed=False,indices=ring,min_only=True,limit=.030)
 healthy=np.flatnonzero((dist>=.022)&(dist<=.025)&(abs(x)<.041)&(abs(y)<.036)&(z>-.025)&((UN@D)>.35));assert len(healthy)>100
 # Thin the far-support row by a bounded planar grid, not a repeated NPZ lookup.
 cell=np.floor(local[healthy,:2]/.00075).astype(int);_,ix=np.unique(cell,axis=0,return_index=True);healthy=healthy[np.sort(ix)];fixed=np.r_[ring,healthy];XY=local[fixed,:2];depth=local[fixed,2];assert len(np.unique(XY,axis=0))==len(XY);smoothing=np.r_[np.zeros(len(ring)),np.full(len(healthy),.001)];rbf=RBFInterpolator(XY/.04,depth,kernel='thin_plate_spline',degree=1,smoothing=smoothing)
 lateral=x if row['side']=='positive'else -x
 gate=.85*smooth(dist/.004)*smooth((.022-dist)/.004)*smooth((lateral+.031)/.008)*smooth((.042-lateral)/.008)*smooth((.036-abs(y))/.004)*smooth((z+.017)/.006)*smooth((.035-z)/.006);gate[~np.isfinite(dist)]=0;gate[ring]=0;active=np.flatnonzero(gate>1e-12);desired=rbf(local[active,:2]/.04);delta=gate[active]*(desired-z[active]);Q[active]+=delta[:,None]*D;allfixed.extend(ring.tolist());records.append({'side':row['side'],'aperture_nodes':len(ring),'healthy_support_nodes':len(healthy),'active_vertices':len(active),'depth_offset_range_m':[float(delta.min()),float(delta.max())],'rim_rbf_error_m':float(abs(rbf(local[ring,:2]/.04)-z[ring]).max()),'aperture_held_exact':True,'geodesic_domain_max_m':.022,'inner_C2_fade_m':.004,'outer_C2_fade_m':.004,'intensity':.85,'domain_revision':'One whole external orbit band, with no mid-lid vertical fade endpoint. Medial31mm and lateral42mm support limits protect the nasal bridge and join healthy temporal skin; all physical rims stay exact.'});print('TPS133',records[-1],flush=True)
changed=np.flatnonzero(np.linalg.norm(Q-U,axis=1)>1e-10);assert np.array_equal(Q[allfixed],U[allfixed]);newP=Q[iv];affected=np.flatnonzero(np.isin(UF,changed).any(1));oldT=P[F];newT=newP[F];oldG=np.cross(oldT[:,1]-oldT[:,0],oldT[:,2]-oldT[:,0]);newG=np.cross(newT[:,1]-newT[:,0],newT[:,2]-newT[:,0]);ol=np.linalg.norm(oldG,axis=1);nl=np.linalg.norm(newG,axis=1);cos=np.einsum('ij,ij->i',oldG,newG)/(ol*nl);ng=newG/nl[:,None];pairs=np.array([fs for fs in edge.values()if len(fs)==2]);angles=np.degrees(np.arccos(np.clip((ng[pairs[:,0]]*ng[pairs[:,1]]).sum(1),-1,1)));affected_pair=np.isin(pairs,affected).any(1);normal_ids=np.unique(UF[affected]);sumN=np.zeros_like(U)
for k in range(3):np.add.at(sumN,UF[:,k],newG)
sumN/=np.maximum(np.linalg.norm(sumN,axis=1)[:,None],1e-30);newN=N.copy();mask=np.isin(iv,normal_ids);newN[mask]=sumN[iv[mask]];report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eyes':records,'changed_position_groups':len(changed),'changed_faces':len(affected),'maximum_displacement_m':float(np.linalg.norm(newP-P,axis=1).max()),'minimum_old_new_geometric_normal_dot':float(cos[affected].min()),'minimum_triangle_area_m2':float(nl.min()/2),'maximum_affected_adjacent_angle_degrees':float(angles[affected_pair].max()),'affected_folds_over105':int((angles[affected_pair]>105).sum()),'apertures_exact':True,'position_equivalence_groups_held_together':True,'all_UV_indices_and_original_BIN_held':True,'scope':'Unapproved lower-orbit shape trial; exact whole-eye intersections, actual matched views and likeness remain required.'};(O/'checks/whole_orbits133_failure.json').write_text(json.dumps(report,indent=2))
bad=np.flatnonzero(cos<0);badpairs=pairs[affected_pair & (angles>105)];normal_rows=[]
for fi in bad:
 normal_rows.append({'face':int(fi),'old_new_normal_dot':float(cos[fi]),'old_normal_dot_head_front':float(oldG[fi]@D/ol[fi]),'new_normal_dot_head_front':float(newG[fi]@D/nl[fi]),'old_triangle_world':oldT[fi].tolist(),'new_triangle_world':newT[fi].tolist()})
fold_rows=[]
for fa,fb in badpairs:
 vertices=np.unique(np.r_[F[fa],F[fb]]);fold_rows.append({'faces':[int(fa),int(fb)],'same_consecutive_quad_pair':int(fa)//2==int(fb)//2,'unique_vertices':vertices.tolist(),'new_positions':newP[vertices].tolist(),'old_positions':P[vertices].tolist(),'angle_degrees':float(np.degrees(np.arccos(np.clip(ng[fa]@ng[fb],-1,1))))})
report.update({'normal_rotations_beyond90_degrees':normal_rows,'fold_pairs':fold_rows,'scope':'Failed whole-orbit128 field diagnostics only. An old/new normal dot is a rotation gate, not by itself proof of winding inversion. No GLB emitted.'});(O/'checks/whole_orbits133_failure.json').write_text(json.dumps(report,indent=2));np.savez_compressed(O/'checks/whole_orbits133_failure.npz',positions=newP,normals=newN,triangles=F,old_positions=P,old_normals=N);print('FAILURE133',len(bad),fold_rows,flush=True)
