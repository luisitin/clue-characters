"""Bounded whole-orbit field strength study. No topology change.
A parallel-depth field preserves projected signed area. Large normal rotation is
reported separately; noncollapse is checked along the complete linear path.
"""
from pathlib import Path
import json,struct,hashlib,collections,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];src=O/'components/head_corners065.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];z=np.load(O/'checks/whole_orbits133_failure.npz');oldP=z['old_positions'];oldN=z['old_normals'];target=z['positions'];F=z['triangles'];z.close();D=np.array(json.loads((O/'checks/regular_orbits033.json').read_text())['eyes'][0]['frame'][2]);U,iv=np.unique(oldP,axis=0,return_inverse=True);UF=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
pairs=np.array([q for q in edge.values()if len(q)==2]);T=oldP[F];G0=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);records=[]
for factor in [.5,.65,.75,.8,.85,.9,1.0]:
 P=oldP+factor*(target-oldP);T=P[F];G=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);length=np.linalg.norm(G,axis=1);GN=G/length[:,None];angles=np.degrees(np.arccos(np.clip((GN[pairs[:,0]]*GN[pairs[:,1]]).sum(1),-1,1)));records.append({'factor_of_128':factor,'field_intensity':factor*.85,'maximum_adjacent_angle_degrees':float(angles.max()),'folds_over105':int((angles>105).sum())})
# Keep a conservative margin to the fold gate rather than optimize up to it.
factor=.8;P=oldP+factor*(target-oldP);T=P[F];G=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);length=np.linalg.norm(G,axis=1);GN=G/length[:,None];deltaG=G-G0;tstar=np.clip(-np.sum(G0*deltaG,axis=1)/np.maximum(np.sum(deltaG*deltaG,axis=1),1e-40),0,1);minimum_path_area=np.linalg.norm(G0+tstar[:,None]*deltaG,axis=1)/2;parallel_error=np.linalg.norm(np.cross(P-oldP,D),axis=1).max();projected_area_change=np.max(abs((G-G0)@D));assert parallel_error<1e-14 and projected_area_change<1e-16;assert minimum_path_area.min()>1e-16;angles=np.degrees(np.arccos(np.clip((GN[pairs[:,0]]*GN[pairs[:,1]]).sum(1),-1,1)));assert angles.max()<105
changed=np.flatnonzero(np.linalg.norm(P-oldP,axis=1)>1e-10);normal_groups=np.unique(UF[np.isin(F,changed).any(1)]);sumN=np.zeros_like(U)
for k in range(3):np.add.at(sumN,UF[:,k],G)
sumN/=np.maximum(np.linalg.norm(sumN,axis=1)[:,None],1e-30);N=oldN.copy();mask=np.isin(iv,normal_groups);N[mask]=sumN[iv[mask]]
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'failed_field_report_sha256':hashlib.sha256((O/'checks/whole_orbits133_failure.json').read_bytes()).hexdigest(),'strength_sweep':records,'chosen_factor':factor,'maximum_displacement_m':float(np.linalg.norm(P-oldP,axis=1).max()),'depth_displacement_parallel_error_m':float(parallel_error),'projected_signed_double_area_change_max_m2':float(projected_area_change),'minimum_triangle_area_along_linear_depth_path_m2':float(minimum_path_area.min()),'maximum_adjacent_angle_degrees':float(angles.max()),'folds_over105':int((angles>105).sum()),'apertures_indices_UVs_held':True,'scope':'Unapproved whole-orbit strength study. Projection and path-area checks replace the invalid assumption that normal rotation beyond90 degrees alone proves a fold. Exact intersections/contact and appearance remain required.'}
payload=bytearray(b)
for semantic,values in [('POSITION',P),('NORMAL',N)]:
 values=(values[:,[0,2,1]]*[1,1,-1]).astype('<f4');payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':values.nbytes,'target':34962});payload.extend(values.tobytes());ai=len(j['accessors']);row={'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC3'}
 if semantic=='POSITION':row.update(min=values.min(0).tolist(),max=values.max(0).tolist())
 j['accessors'].append(row);pr['attributes'][semantic]=ai
j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/head_orbits140.glb';dst.write_bytes(raw);report['output_sha256']=hashlib.sha256(raw).hexdigest();(O/'checks/orbit_strength140.json').write_text(json.dumps(report,indent=2));print('ORBIT140',report,flush=True)
