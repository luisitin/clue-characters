"""Bounded source trial from complete, conflict-free backed patch proofs104.
Additional oriented edge parity is mandatory. No source positions, normals, UVs,
materials or original BIN bytes change; all other faces remain held.
"""
from pathlib import Path
import json,struct,hashlib,collections,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/plum_strip_cleanup085.glb';j,b,a=read_glb(src);sha=hashlib.sha256(src.read_bytes()).hexdigest();rows=[];reports=[]
for path in sorted((O/'checks').glob('branch_coverage104_*.json')):
 report=json.loads(path.read_text());assert report['source_sha256']==sha;rows.extend(report['groups']);reports.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert len(rows)==85 and len({g['inventory_index']for g in rows})==85;proposals=[g for g in rows if g['complete_component_backing_pass']and not g['other_components_sharing_attachment']];pr=j['meshes'][0]['primitives'][0];F=a(pr['indices']).reshape(-1,3).astype(np.int64);P=a(pr['attributes']['POSITION']).astype(float);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
accepted=[];held=[]
for g in proposals:
 remove=set(g['faces']);bad=[]
 for fi in g['faces']:
  f=T[fi]
  for aa,bb in zip(f,np.roll(f,-1)):
   key=tuple(sorted((int(aa),int(bb))));remaining=[r for r in edge[key]if r[0]not in remove]
   if not remaining:continue
   if len(remaining)!=2 or remaining[0][1:]!=remaining[1][1:][::-1]:bad.append({'edge':list(key),'remaining_oriented_faces':[list(r)for r in remaining]})
 if bad:held.append({'component_root':g['component_root'],'faces':g['faces'],'reason':'Individual retained edge incidence/orientation not a coherent surface','edges':bad})
 else:accepted.append(g)
remove=set(fi for g in accepted for fi in g['faces']);assert remove;edgeproof=[]
for key,fam in edge.items():
 if not any(fi in remove for fi,aa,bb in fam):continue
 remain=[r for r in fam if r[0]not in remove];assert len(remain)in(0,2)
 if remain:assert remain[0][1:]==remain[1][1:][::-1]
 edgeproof.append({'edge':list(key),'before_faces':[r[0]for r in fam],'after_faces':[r[0]for r in remain]})
keep=np.ones(len(F),bool);keep[sorted(remove)]=False;newF=F[keep].astype('<u4');payload=bytearray(b);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':newF.nbytes,'target':34963});payload.extend(newF.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':newF.size,'type':'SCALAR','min':[int(newF.min())],'max':[int(newF.max())]});pr['indices']=ai;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/plum_branch_cleanup121.glb';dst.write_bytes(raw);jj,bb,aa=read_glb(dst);assert bb[:len(b)]==b;assert np.array_equal(aa(jj['meshes'][0]['primitives'][0]['indices']).reshape(-1,3),newF);np.savez_compressed(O/'checks/branch_cleanup121_lineage.npz',new_to_085_face=np.flatnonzero(keep),removed_085_faces=np.array(sorted(remove)));report={'source_sha256':sha,'output_sha256':hashlib.sha256(raw).hexdigest(),'proof_inputs':reports,'backed_individual_proposals':len(proposals),'accepted_components':[{'component_root':g['component_root'],'faces':g['faces'],'world_bounds':g['world_bounds']}for g in accepted],'held_for_orientation':held,'removed_faces':sorted(remove),'removed_face_count':len(remove),'remaining_triangles':len(newF),'all_original_vertex_attributes_and_BIN_unchanged':True,'all_retained_attachment_edges_two_face_and_opposed':True,'new_exposed_edges':0,'combined_edge_proof':edgeproof,'scope':'Unapproved whole-source trial. Only complete small backed components with coherent retained attachment were removed. Actual matched views for each changed region and all-angle regression still required. This does not repair failed-support or large/nonmanifold patches, source fusion or semantic paint.'};(O/'checks/branch_cleanup121.json').write_text(json.dumps(report,indent=2));print('TRIAL121',len(accepted),len(remove),len(held),report['output_sha256'],flush=True)
