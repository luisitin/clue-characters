# Peacock WIP face-paint and source-cleanup checkpoint178

This is an unfinished character candidate, not a complete head or owner-approved model. It combines the physical eyes/source-constrained cheeks from132, guarded opposite-side paint, an underside skin-color repair and two separately proven original-surface cleanups.

Exact GLB: checks/peacock_face_nosepaint178.glb, SHA-256 8934058dcb431f32066a60e3bd8b113028dca2cec32b460e55d404da0c945f66,203583 triangles. Editable inputs/face_nosepaint178.npz, SHA-256 d06ce3d75c4fe8884ccf930669bb9c9d99778978348f19e6553ffdf58ecc9dce. Use its material manifest and image dependencies for exact re-export.

## Replay after the retained132 source/component inputs

1. scripts/bake_opposite_atlas148.py uses inputs/face_opposite_plate140.png and the camera in renders/face_eyes132_albedo138/face_albedo_045_+00.json. It creates face_opposite148 with protected nose/lip regions.144 is rejected because its broader mask added a false nostril.
2. scripts/bake_chin_atlas161.py uses148, inputs/chin_paint_plate153.png and the camera in renders/chin_source149/face_albedo_000_-35.json. The world-space skin bounds prevent the projection from painting farther hair.157's earlier projection-only selection was insufficiently scoped.
3. scripts/prove_chin_branches166.py checks both proposed chin flap faces with all candidates excluded from support. It requires shared_helpers/projected_backing.py and source_clean1. Full area and every edge are supported in three directions within the unchanged -5micrometer to3mm depth bounds.
4. scripts/remove_verified_source_families173.py combines161 paint with the four nose-fan removals from the separately verified150 report and the two supported chin-flap removals. It leaves every position/normal/UV/image array untouched and checks all affected surviving edges have incidence2.
5. Export173 and run scripts/audit_glb_region174.py face_clean173 nose, chin, and eye_new separately. These actual exported-float32 regions report zero proper crossings, positive-area coplanar overlaps, exact copies and collapsed triangles. The105 sharp eye pairs remain closed-cap rims.
6. Render the registered unlit45-degree color field from161 with scripts/render_layered_glb53.py to renders/nose_paint_source170/face_albedo_045_+00.png, retaining its exact camera JSON. This PNG is a consumed bake input, so preserve its bytes or replay it with the recorded Blender4.3.2 renderer/settings.
7. scripts/bake_nose_material178.py uses173 and inputs/skin_material175.png. It fits the broad nasal skin color from13 measured healthy samples in the exact170 camera field; the generated feature-free material contributes only subtle mean-subtracted grain. It transfers no generated nostril or other facial landmark. The rejected_nose_plate172 image is not consumed.
8. Export178, then scripts/verify_geometry_identity180.py face_clean173 face_nosepaint178 verifies byte-equal actual-GLB oriented triangle-corner POSITION/NORMAL multisets. This propagates geometry checks only; new UV/material appearance still requires its own views.

Each bake uses unique padded per-triangle charts and records texel coverage.178 changes138 charts with4px padding and minimum66 covered texel centers. All model geometry and corner normals stay held during painting.

## Unique and consumed inputs added since132

- face_opposite_plate140.png, SHA-256 bad4b039331d4f464a5722cbfb73ad51f1537b387a0c457a8ca207d4d164a01b
- chin_paint_plate153.png, SHA-256 209c2c8aae5eb28c2333b1ece93559255581bf45fa3c022b6e9bbe16af18f737
- skin_material175.png, SHA-256 d6fd860e8ab75563483a29162aacdb797aefc9f28d485b569d6f1f52e2b8e6e5
- renders/nose_paint_source170/face_albedo_045_+00.png and its camera metadata, plus the earlier148/161 camera JSON files.

The first three are nondeterministic imagegen inputs with separate prompt/provenance files. The170 image is an exact registered model render, not an AI plate. Original source/reference licensing remains unchanged; no donor anatomy has been added to178.

## Evidence and remaining work

Independent saved-view review confirms148 repairs the large opposite temple/cheek gray patch without144's false nostril, and150 removes the thin nose scratch.173's actual under view removes the blue-gray chin blotch and the narrow source-flap line.Saved front/opposite/under/profile reviews now support the bounded178 nose/chin paint and source-cleanup improvements. This is not whole-character approval.

Far and near ears/lobes, the remaining lower-neck nub, fringe/hat/feather defects, neck/collar boundaries, mouth/whole-head close-ups and all body/anatomy/material work remain open. Source proper-contact and appearance gates are local, not whole-character clearance. Do not substitute any generated input image for an actual model render.
