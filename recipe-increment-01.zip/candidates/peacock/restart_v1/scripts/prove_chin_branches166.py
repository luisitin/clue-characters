"""Full-area and every-edge retained support proof for the diagnosed chin flap pair.
No geometry is edited. Both proposed faces are excluded from all support sets.
"""
from pathlib import Path
import numpy as np,json,sys,hashlib,math
R=Path(__file__).resolve().parents[1];sys.path.append(str(R.parents[2]/'shared_helpers'));from projected_backing import prove_coverage
path=R/'inputs/source_clean1.npz';a=np.load(path);P=a['pos'];T=a['tri'];a.close();q=P[T];drop=[117970,117971];center=q[drop].mean(axis=(0,1));pool=np.where(np.linalg.norm(q.mean(1)-center,axis=1)<.04)[0];views=[]
for az,el in [(0,-35),(315,-20),(45,-20)]:
 azr=math.radians(az);elr=math.radians(el);D=np.array([math.sin(azr)*math.cos(elr),-math.cos(azr)*math.cos(elr),math.sin(elr)]);U=np.array([math.cos(azr),math.sin(azr),0]);V=np.cross(D,U);rows=[]
 for fi in drop:rows.append({'source_clean_face':fi,'proof':prove_coverage(q[fi],q[pool],pool,U,V,D,excluded_support_ids=drop)})
 views.append({'azimuth_degrees':az,'elevation_degrees':el,'projection_axes':[U.tolist(),V.tolist(),D.tolist()],'faces':rows})
report={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'candidate_removal_ids':drop,'nearby_retained_pool_size':len(pool),'camera_directions_are_explicit_geometric_checks':True,'views':views,'all_passed':all(row['proof']['passed'] for v in views for row in v['faces']),'status':'Read-only coverage diagnostic; topology/attribute ownership and final matched appearance remain separate.'};(R/'checks/chin_branches166.json').write_text(json.dumps(report,indent=2));print(json.dumps({'all_passed':report['all_passed'],'views':[{'angle':[v['azimuth_degrees'],v['elevation_degrees']],'faces':[{'id':r['source_clean_face'],'passed':r['proof']['passed'],'uncovered_area':r['proof'].get('uncovered_projected_area_m2'),'edge_gaps':r['proof'].get('uncovered_edge_lengths_m'),'support_ids':[q['retained_face'] for q in r['proof'].get('support_records',[])]} for r in v['faces']]} for v in views]},indent=2))
