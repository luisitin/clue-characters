"""Exact saved-camera source/current ray provenance for the newly visible underside chin marks.
No geometry or material changes. Ray hits include orientation and corner data.
"""
from pathlib import Path
import json,hashlib
import numpy as np
R=Path(__file__).resolve().parents[1]
meta=json.loads((R/'renders/face_chin157_export/face_paint_000_-35.json').read_text());C=np.array(meta['camera_world_matrix']);W,H=meta['image_dimensions'];scale=meta['ortho_scale'];ray=-C[:3,2]
spots=[(522,542),(531,541),(537,541),(545,541),(569,565),(584,573),(536,584)]
report={'camera_metadata':'renders/face_chin157_export/face_paint_000_-35.json','camera_world_matrix':meta['camera_world_matrix'],'spots_xy':spots,'datasets':{}}
for name in ['source_world','face_chin157']:
 path=R/f'inputs/{name}.npz';a=np.load(path);P=a['pos'];T=a['tri'];N=a['normal'];U=a['uv'];M=a['material'] if 'material' in a.files else np.zeros(len(T),int);a.close();q=P[T];e1=q[:,1]-q[:,0];e2=q[:,2]-q[:,0];h=np.cross(np.broadcast_to(ray,e2.shape),e2);det=np.einsum('ij,ij->i',e1,h);valid=abs(det)>1e-14;inv=np.zeros(len(det));inv[valid]=1/det[valid];geom=np.cross(e1,e2);geom/=np.maximum(np.linalg.norm(geom,axis=1)[:,None],1e-30);rows=[]
 for x,y in spots:
  origin=C[:3,3]+C[:3,0]*((x+.5)/W-.5)*scale+C[:3,1]*(.5-(y+.5)/H)*scale;s=origin-q[:,0];u=inv*np.einsum('ij,ij->i',s,h);z=np.cross(s,e1);v=inv*(z@ray);t=inv*np.einsum('ij,ij->i',e2,z);ids=np.where(valid&(u>=-1e-9)&(v>=-1e-9)&(u+v<=1+1e-9)&(t>=0))[0];ids=ids[np.argsort(t[ids])];hits=[]
  for fi in ids[:12]:
   bary=np.array([1-u[fi]-v[fi],u[fi],v[fi]]);norm=bary@N[T[fi]];norm/=np.linalg.norm(norm);hits.append({'triangle':int(fi),'material':int(M[fi]),'ray_t':float(t[fi]),'behind_first_mm':float((t[fi]-t[ids[0]])*1000),'world':(origin+t[fi]*ray).tolist(),'geom_dot_ray':float(geom[fi]@ray),'authored_dot_ray':float(norm@ray),'barycentric':bary.tolist(),'uv':(bary@U[T[fi]]).tolist(),'corner_positions':q[fi].tolist(),'corner_uv':U[T[fi]].tolist()})
  rows.append({'pixel_xy':[x,y],'hits':hits})
 report['datasets'][name]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'triangles':len(T),'rays':rows}
(R/'checks/chin_slit_rays160.json').write_text(json.dumps(report,indent=2));print(json.dumps({name:[{'xy':r['pixel_xy'],'hits':[{k:v for k,v in h.items() if k in ['triangle','material','behind_first_mm','geom_dot_ray','authored_dot_ray']} for h in r['hits'][:4]]} for r in data['rays']] for name,data in report['datasets'].items()},indent=2))
