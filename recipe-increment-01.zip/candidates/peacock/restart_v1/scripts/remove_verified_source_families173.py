"""Integrate two independently diagnosed source-family cleanups with guarded face paint.
Only six existing faces are removed. Every retained corner array and texture stays exact.
"""
from pathlib import Path
from collections import Counter
import json,hashlib,shutil
import numpy as np
R=Path(__file__).resolve().parents[1];src=R/'inputs/source_clean1.npz';a=np.load(src);SP=a['pos'];ST=a['tri'];a.close();nose=json.loads((R/'checks/face_nose150.json').read_text());chin=json.loads((R/'checks/chin_branches166.json').read_text());assert chin['all_passed'] and chin['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();drop=nose['original_removed_faces']+chin['candidate_removal_ids'];held=set(nose['original_retained_faces'])
for view in chin['views']:
 for row in view['faces']:
  assert row['proof']['passed'];held.update(r['retained_face'] for r in row['proof']['support_records'])
assert not set(drop)&held;ids=drop+sorted(held);base=R/'inputs/face_chin161.npz';a=np.load(base);D={k:a[k] for k in a.files};a.close();P=D['pos'];T=D['tri'];keys={tuple(sorted(tuple(row) for row in SP[ST[fi]])):fi for fi in ids};hits={fi:[] for fi in ids};q=P[T]
for ii,tr in enumerate(q):
 key=tuple(sorted(tuple(row) for row in tr))
 if key in keys:hits[keys[key]].append(ii)
assert all(len(v)==1 for v in hits.values()),hits;removed=[hits[i][0] for i in drop];_,G=np.unique(P,axis=0,return_inverse=True);GT=G[T];keep=np.ones(len(T),bool);keep[removed]=False;edges=set(tuple(sorted((int(a),int(b)))) for tr in GT[removed] for a,b in zip(tr,np.roll(tr,-1)));before=Counter();after=Counter()
for ii,tr in enumerate(GT):
 for a,b in zip(tr,np.roll(tr,-1)):
  edge=tuple(sorted((int(a),int(b))))
  if edge in edges:
   before[edge]+=1
   if keep[ii]:after[edge]+=1
assert all(after[e] in (0,2) for e in edges),[(e,before[e],after[e]) for e in edges];D['tri']=T[keep];D['material']=D['material'][keep];out=R/'inputs/face_clean173.npz';np.savez_compressed(out,**D);shutil.copyfile(R/'inputs/face_chin161_materials.json',R/'inputs/face_clean173_materials.json');report={'source_component_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles_before':len(T),'triangles_after':len(D['tri']),'source_clean_removed_ids':drop,'current_removed_ids':removed,'verified_retained_source_ids':sorted(held),'retained_positions_normals_uvs_images_all_exact':True,'affected_edges_after_incidence_zero_or_two':True,'edge_counts':[{'edge_position_groups':list(e),'before':before[e],'after':after[e]} for e in sorted(edges)],'proofs':['face_nose150.json','chin_branches166.json'],'status':'Integrated guarded paint plus six proven source-face removals; actual exported contacts and matched appearance pending'};(R/'checks/face_clean173.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
