"""Trace the source overlap family exposed by repaired underside diffuse paint."""
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1];a=np.load(R/'inputs/source_world.npz');rawT=a['tri'];a.close();p=R/'inputs/source_clean1.npz';a=np.load(p);P=a['pos'];T=a['tri'];N=a['normal'];U=a['uv'];a.close();q=P[T];points,G=np.unique(P,axis=0,return_inverse=True);GT=G[T];E=defaultdict(list)
for fi,tr in enumerate(GT):
 for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append(fi)
seeds={}
for raw in [118078,118079,70692,118081]:
 ids=np.where(np.all(T==rawT[raw],axis=1))[0];assert len(ids)==1;seeds[raw]=int(ids[0])
center=np.mean(q[list(seeds.values())],axis=(0,1));family=set(seeds.values());iterations=[]
for step in range(20):
 extra=set()
 for fi in family:
  for a,b in zip(GT[fi],np.roll(GT[fi],-1)):
   edge=tuple(sorted((int(a),int(b))))
   if len(E[edge])>2:extra.update(E[edge])
 extra-=family
 if not extra:break
 if len(family|extra)>100 or np.linalg.norm(q[list(extra)].mean(1)-center,axis=1).max()>.025:break
 family.update(extra);iterations.append({'step':step,'added_faces':sorted(extra)})
rows=[];fn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);fn/=np.maximum(np.linalg.norm(fn,axis=1)[:,None],1e-30)
for fi in sorted(family):
 inc=[]
 for a,b in zip(GT[fi],np.roll(GT[fi],-1)):
  edge=tuple(sorted((int(a),int(b))));inc.append({'edge':list(edge),'incidents':E[edge]})
 rows.append({'face':fi,'position_groups':GT[fi].tolist(),'world':q[fi].tolist(),'uv':U[T[fi]].tolist(),'normal':N[T[fi]].tolist(),'authored_geometric_dot':float(fn[fi]@N[T[fi]].mean(0)),'edges':inc})
counts=Counter(tuple(sorted((int(a),int(b)))) for fi in family for a,b in zip(GT[fi],np.roll(GT[fi],-1)));report={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_to_clean_seed_ids':seeds,'nonmanifold_edge_family':sorted(family),'iterations':iterations,'family_boundary_edges':[list(e) for e,n in counts.items() if n==1],'faces':rows,'status':'Read-only branch incidence. No deletion or backing claim.'};(R/'checks/chin_family165.json').write_text(json.dumps(report,indent=2));print(json.dumps({'raw_to_clean_seed_ids':seeds,'family':sorted(family),'boundary':[list(e) for e,n in counts.items() if n==1],'rows':[(r['face'],r['position_groups'],r['authored_geometric_dot']) for r in rows]},indent=2))
