"""Bounded camera-registered far cheek paint on unchanged actual geometry.
Unique padded per-triangle charts preserve current colors at the blend boundary.
The two physical eyes, their skin/walls/caps and every position/normal stay held.
"""
from pathlib import Path
import numpy as np,json,hashlib
from PIL import Image,ImageDraw,ImageFilter
from scipy.interpolate import RBFInterpolator
from scipy.ndimage import map_coordinates
R=Path(__file__).resolve().parents[1];name='face_eyes132';a=np.load(R/f'inputs/{name}.npz');D={k:a[k] for k in a.files};a.close();P=D['pos'];N=D['normal'];T=D['tri'];U=D['uv'];M=D['material'];materials=json.loads((R/f'inputs/{name}_materials.json').read_text());meta=json.loads((R/'renders/face_eyes132_albedo138/face_albedo_045_+00.json').read_text());C=np.array(meta['camera_world_matrix']);scale=meta['ortho_scale'];size=800
src=np.array([[286,269],[350,301],[302,282],[403,314],[475,345],[425,327],[446,405],[419,418],[474,435],[343,453],[477,496],[431,478],[432,505],[435,620],[350,575],[536,589],[610,526],[646,458],[601,407],[547,352],[502,330],[269,248],[247,345],[282,427],[285,682],[649,620],[100,100],[700,100],[100,700],[700,700]],float)
dst=np.array([[307,269],[365,301],[316,280],[424,314],[492,342],[444,325],[477,406],[450,419],[495,433],[360,451],[500,497],[454,475],[454,502],[453,601],[366,575],[542,573],[625,496],[661,447],[621,406],[570,357],[522,333],[285,246],[261,345],[297,426],[303,679],[650,621],[100,100],[700,100],[100,700],[700,700]],float)
warp=RBFInterpolator(src,dst-src,kernel='thin_plate_spline',smoothing=.3)
mask=Image.new('L',(800,800));dr=ImageDraw.Draw(mask)
# Explicit anatomical projection domain, not a color-based face selection.
poly=[(486,336),(525,340),(573,359),(614,384),(643,419),(648,482),(619,526),(588,548),(551,588),(508,614),(432,625),(397,608),(410,568),(431,540),(459,516),(470,503),(481,490),(478,469),(465,445),(463,408),(474,378)]
dr.polygon(poly,fill=255);dr.polygon([(330,442),(380,451),(441,470),(475,487),(480,503),(447,516),(393,490),(345,467)],fill=0);dr.polygon([(399,365),(473,365),(500,397),(501,438),(489,457),(449,459),(404,432)],fill=0);mask=np.asarray(mask.filter(ImageFilter.GaussianBlur(7)),dtype=np.float32)/255
plate=np.asarray(Image.open(R/'inputs/face_opposite_plate140.png').convert('RGB'));old={}
for m in [0,1]:
 for key in ['base_path','orm_path']:
  path=materials[m][key]
  if path not in old:old[path]=np.asarray(Image.open(path).convert('RGB'))
def sample(im,uv):
 xy=uv*np.array([im.shape[1],im.shape[0]])-.5;ij=np.floor(xy).astype(int);f=xy-ij;x=np.clip(ij[:,0],0,im.shape[1]-1);y=np.clip(ij[:,1],0,im.shape[0]-1);x1=np.minimum(x+1,im.shape[1]-1);y1=np.minimum(y+1,im.shape[0]-1);fx=f[:,0,None];fy=f[:,1,None]
 return im[y,x]*(1-fx)*(1-fy)+im[y,x1]*fx*(1-fy)+im[y1,x]*(1-fx)*fy+im[y1,x1]*fx*fy
def project(p):
 rel=p-C[:3,3];return np.column_stack([(.5+rel@C[:3,0]/scale)*size-.5,(.5-rel@C[:3,1]/scale)*size-.5,-rel@C[:3,2]])
Q=project(P);q=Q[T];lo=np.maximum(np.ceil(q[:,:,:2].min(1)).astype(int),0);hi=np.minimum(np.floor(q[:,:,:2].max(1)).astype(int),size-1);depth=np.full((size,size),np.inf);owner=np.full((size,size),-1,np.int32)
for fi in np.where(np.all(hi>=lo,axis=1))[0]:
 tri=q[fi];b=tri[1,:2]-tri[0,:2];c=tri[2,:2]-tri[0,:2];den=b[0]*c[1]-b[1]*c[0]
 if abs(den)<1e-12:continue
 xx,yy=np.meshgrid(np.arange(lo[fi,0],hi[fi,0]+1),np.arange(lo[fi,1],hi[fi,1]+1));dx=xx-tri[0,0];dy=yy-tri[0,1];u=(dx*c[1]-dy*c[0])/den;v=(b[0]*dy-b[1]*dx)/den;zz=tri[0,2]+u*(tri[1,2]-tri[0,2])+v*(tri[2,2]-tri[0,2]);take=(u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8)&(zz<depth[yy,xx]-1e-9);depth[yy[take],xx[take]]=zz[take];owner[yy[take],xx[take]]=fi
cent=q.mean(1);weight=map_coordinates(mask,[cent[:,1],cent[:,0]],order=1,mode='constant',cval=0);ij=np.clip(np.rint(cent[:,:2]).astype(int),0,799);near=abs(cent[:,2]-depth[ij[:,1],ij[:,0]])<.0008;selected=(weight>1e-5)&near&(M<2);visible=np.unique(owner[(mask>1e-5)&(owner>=0)]);selected[visible[M[visible]<2]]=True
ids=np.where(selected)[0];assert len(ids)>100;projected=q[ids,:,:2];span=np.maximum(8,np.ceil(np.max(np.linalg.norm(projected-np.roll(projected,1,axis=1),axis=2),axis=1)*2)).astype(int);pad=4;cells=span+2*pad+1;order=np.argsort(-cells);atlas=2**int(np.ceil(np.log2(np.sqrt(np.sum(cells*cells)*1.4))))
while True:
 x=y=rowh=0;placements={}
 for kk in order:
  cell=int(cells[kk])
  if x+cell>atlas:x=0;y+=rowh;rowh=0
  placements[int(kk)]=(x,y);x+=cell;rowh=max(rowh,cell)
 if y+rowh<=atlas:break
 atlas*=2
assert atlas<=4096;rgb=np.zeros((atlas,atlas,3),np.uint8);orm=np.zeros_like(rgb);newP=P.tolist();newN=N.tolist();newU=U.tolist();newT=T.copy();newM=M.copy();coverage=[];maxmove=0;minimum_det=1e9
for kk,fi in enumerate(ids):
 cell=int(cells[kk]);sp=int(span[kk]);xx,yy=np.meshgrid(np.arange(cell),np.arange(cell));b=(xx-pad)/sp;c=(yy-pad)/sp;bar=np.stack([1-b-c,b,c],-1);inside=(bar>=-1e-8).all(2);bar=np.maximum(bar,0);bar/=bar.sum(2,keepdims=True);bar=bar.reshape(-1,3);uv=bar@U[T[fi]];p=bar@P[T[fi]];pix=project(p)[:,:2];weight=map_coordinates(mask,[pix[:,1],pix[:,0]],order=1,mode='constant',cval=0);delta=warp(pix);mapped=pix+delta;maxmove=max(maxmove,float(np.linalg.norm(delta,axis=1)[weight>1e-6].max(initial=0)));eps=.05;gx=(warp(pix+[eps,0])-warp(pix-[eps,0]))/(2*eps);gy=(warp(pix+[0,eps])-warp(pix-[0,eps]))/(2*eps);det=(1+gx[:,0])*(1+gy[:,1])-gx[:,1]*gy[:,0];minimum_det=min(minimum_det,float(det[weight>1e-6].min(initial=1)));assert det.min()>.1
 oldrgb=sample(old[materials[M[fi]]['base_path']],uv);paint=sample(plate,(mapped+.5)/800);color=np.clip(np.rint(oldrgb*(1-weight[:,None])+paint*weight[:,None]),0,255).astype(np.uint8);aux=np.clip(np.rint(sample(old[materials[M[fi]]['orm_path']],uv)),0,255).astype(np.uint8)
 x,y=placements[kk];rgb[y:y+cell,x:x+cell]=color.reshape(cell,cell,3);orm[y:y+cell,x:x+cell]=aux.reshape(cell,cell,3);chart=(np.array([[x+pad,y+pad],[x+pad+sp,y+pad],[x+pad,y+pad+sp]],float)+.5)/atlas;start=len(newP);newP.extend(P[T[fi]].tolist());newN.extend(N[T[fi]].tolist());newU.extend(chart.tolist());newT[fi]=np.arange(start,start+3);newM[fi]=len(materials);coverage.append(int(inside.sum()))
 if kk%500==0:print('CHART',kk,'/',len(ids),flush=True)
P2=np.array(newP);N2=np.array(newN);U2=np.array(newU);assert np.array_equal(P2[newT],P[T]) and np.array_equal(N2[newT],N[T]);target=R/'inputs/face_opposite148.npz';np.savez_compressed(target,pos=P2,normal=N2,uv=U2,tri=newT,material=newM);base=R/'inputs/opposite148_basecolor.png';aux=R/'inputs/opposite148_ORM.png';Image.fromarray(rgb).save(base);Image.fromarray(orm).save(aux);materials.append({'name':'Registered opposite cheek repair','base_path':str(base),'orm_path':str(aux),'occlusion_strength':0});(R/'inputs/face_opposite148_materials.json').write_text(json.dumps(materials,indent=2));report={'source_component_sha256':hashlib.sha256((R/f'inputs/{name}.npz').read_bytes()).hexdigest(),'component_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'plate_sha256':hashlib.sha256((R/'inputs/face_opposite_plate140.png').read_bytes()).hexdigest(),'triangles':len(T),'selected_triangles':len(ids),'source_face_ids':ids.tolist(),'all_corner_positions_normals_held_exact':True,'eye_materials_2_3_4_held_exact':True,'atlas_size':[atlas,atlas],'chart_padding_px':pad,'chart_overlap_count_by_disjoint_cell_construction':0,'minimum_triangle_texel_centers':min(coverage),'registration_source_landmarks800':src.tolist(),'registration_plate_landmarks800':dst.tolist(),'anatomical_camera_polygon800':poly,'max_registration_displacement_px':maxmove,'sampled_registration_jacobian_min':minimum_det,'nose_and_lip_protection':'Explicit camera45 polygons exclude the existing nose and lip feature footprint before feathering','status':'Bounded paint trial; actual exported opposite/front/under appearance pending'};(R/'checks/face_opposite148.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='source_face_ids'},indent=2))
