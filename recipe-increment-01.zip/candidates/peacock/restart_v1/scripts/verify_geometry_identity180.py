"""Compare exact exported corner POSITION/NORMAL multisets, preserving triangle winding.
UV/material ordering may differ. No geometric tolerance or vertex snapping is used.
"""
from pathlib import Path
import numpy as np,json,hashlib,sys
from glb_io import GLB
R=Path(__file__).resolve().parents[1];a,b=sys.argv[1:3]
def signature(name):
 g=GLB(R/f'checks/peacock_{name}.glb');assert g.j['nodes'][0].get('scale',[1,1,1])==[1,1,1] and not any(k in g.j['nodes'][0] for k in ('matrix','rotation','translation'));prs=g.j['meshes'][0]['primitives'];at=prs[0]['attributes'];assert all(pr['attributes']==at for pr in prs);P=g.read(at['POSITION']);N=g.read(at['NORMAL']);T=np.concatenate([g.read(pr['indices']).reshape(-1,3) for pr in prs]);assert np.isfinite(P).all() and np.isfinite(N).all();q=P[T];r=np.lexsort((q[:,:,2],q[:,:,1],q[:,:,0]),axis=1)[:,0];corners=np.concatenate([q,N[T]],axis=2);canon=corners[np.arange(len(T))[:,None],(r[:,None]+np.arange(3))%3].reshape(len(T),18).copy();order=np.lexsort(tuple(canon[:,i] for i in reversed(range(18))));canon=canon[order];return {'candidate_glb_sha256':g.sha256,'triangles':len(T),'oriented_corner_position_normal_sha256':hashlib.sha256(canon.tobytes()).hexdigest()},canon
ra,A=signature(a);rb,B=signature(b);equal=A.shape==B.shape and A.tobytes()==B.tobytes();report={'models':{a:ra,b:rb},'exact_oriented_geometry_and_corner_normals_equal':equal,'scope':'Actual GLB float32 oriented triangle-corner POSITION/NORMAL multiset, independent of UV/material partitioning. This transfers geometry-only checks; appearance and new UV/material checks remain separate.'};(R/f'checks/geometry_identity180_{a}_{b}.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert equal
