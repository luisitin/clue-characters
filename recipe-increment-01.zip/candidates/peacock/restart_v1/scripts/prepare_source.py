"""Exact source unpacking; no geometry or paint edits. Run under external flock."""
import json,struct,hashlib,io
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[1]; source=R.parents[2]/'sources/prelod-cd4c20d/sus-peacock.glb'
b=source.read_bytes(); jlen=struct.unpack_from('<I',b,12)[0]; g=json.loads(b[20:20+jlen]); off=20+jlen; blen,typ=struct.unpack_from('<II',b,off); blob=memoryview(b)[off+8:off+8+blen]
D={5126:'<f4',5125:'<u4',5123:'<u2',5122:'<i2',5121:'u1',5120:'i1'}; W={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def acc(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];n=W[a['type']];dt=np.dtype(D[a['componentType']]);o=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',n*dt.itemsize)
 arr=np.ndarray((a['count'],n),dtype=dt,buffer=blob,offset=o,strides=(stride,dt.itemsize)).copy()
 if a.get('normalized'):
  arr=arr.astype('float64')/np.iinfo(dt).max
  if dt.kind=='i': arr=np.maximum(arr,-1)
 return arr
p=g['meshes'][0]['primitives'][0]; P=acc(p['attributes']['POSITION']).astype('float64');N=acc(p['attributes']['NORMAL']);U=acc(p['attributes']['TEXCOORD_0']);T=acc(p['indices']).reshape(-1,3).astype('int32');node=g['nodes'][0]
assert 'rotation' not in node and 'matrix' not in node
P=P*np.array(node.get('scale',[1,1,1]))+np.array(node.get('translation',[0,0,0]));P=P[:,[0,2,1]];P[:,1]*=-1;N=N[:,[0,2,1]];N[:,1]*=-1
np.savez_compressed(R/'inputs/source_world.npz',pos=P,tri=T,normal=N,uv=U)
images=[]
for i,im in enumerate(g['images']):
 v=g['bufferViews'][im['bufferView']];data=blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']].tobytes();path=R/f'inputs/source_image_{i}.webp';path.write_bytes(data);picture=Image.open(io.BytesIO(data));picture.save(R/f'inputs/source_image_{i}.png');images.append({'index':i,'name':im['name'],'size':picture.size,'encoded_sha256':hashlib.sha256(data).hexdigest(),'decoded_mode':picture.mode})
a=P[T[:,1]]-P[T[:,0]];c=P[T[:,2]]-P[T[:,0]];areas=np.linalg.norm(np.cross(a,c),axis=1)*.5
report={'source':str(source),'source_sha256':hashlib.sha256(b).hexdigest(),'source_commit':'cd4c20dcfbf0e59cc64e916746048ed5b49fb627','triangles':len(T),'vertices':len(P),'bounds':[P.min(0).tolist(),P.max(0).tolist()],'zero_area_triangles':int((areas<1e-14).sum()),'images':images,'status':'untouched recovered source; lost v4 work is not restored','geometry_conversion':'glTF node scale/translation followed by x,y,z -> x,-z,y'}
(R/'checks/source_manifest.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
