"""Reimport the declared GLB and save exact camera, source hash and diagnostic mode."""
import bpy,os,pathlib,json,hashlib,math,sys
from mathutils import Vector,Matrix
sys.path.insert(0,str(pathlib.Path(__file__).parent));from glb_io import read_glb,write_glb
previous=json.loads(pathlib.Path(os.environ['CAMERA_META']).read_text()) if os.environ.get('CAMERA_META') else None
src=pathlib.Path(os.environ['GLB']);out=pathlib.Path(os.environ['OUT']);out.parent.mkdir(parents=True,exist_ok=True);mode=os.environ.get('MODE','pbr');digest=hashlib.sha256(src.read_bytes()).hexdigest();bpy.ops.wm.read_factory_settings(use_empty=True)
if mode=='clay':
 j,b,a=read_glb(src);j.pop('images',None);j.pop('textures',None);j.pop('samplers',None);j['materials']=[{'name':'Diagnostic neutral clay','pbrMetallicRoughness':{'baseColorFactor':[.5,.5,.5,1],'roughnessFactor':.8,'metallicFactor':0},'doubleSided':True}]
 for m in j['meshes']:
  for p in m['primitives']:p['material']=0
 j['extensionsUsed']=[x for x in j.get('extensionsUsed',[])if x!='EXT_texture_webp'];j['extensionsRequired']=[x for x in j.get('extensionsRequired',[])if x!='EXT_texture_webp'];temp=out.with_suffix('.temporary.glb');write_glb(temp,j,b);bpy.ops.import_scene.gltf(filepath=str(temp));temp.unlink();del j,b,a
else:bpy.ops.import_scene.gltf(filepath=str(src))
if mode=='unlit':
 for m in bpy.data.materials:
  if not m.use_nodes:continue
  ns=m.node_tree.nodes;links=m.node_tree.links;bs=next((q for q in ns if q.type=='BSDF_PRINCIPLED'),None);output=next((q for q in ns if q.type=='OUTPUT_MATERIAL'),None)
  if bs is None or output is None:continue
  em=ns.new('ShaderNodeEmission');em.inputs['Strength'].default_value=1
  if bs.inputs['Base Color'].is_linked:links.new(bs.inputs['Base Color'].links[0].from_socket,em.inputs['Color'])
  else:em.inputs['Color'].default_value=bs.inputs['Base Color'].default_value
  links.new(em.outputs[0],output.inputs['Surface'])
for m in list(bpy.data.materials):
 if m.users==0:bpy.data.materials.remove(m)
for im in list(bpy.data.images):
 if im.users==0:bpy.data.images.remove(im)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=int(os.environ.get('SAMPLES','16'));scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=2;scene.render.resolution_x=int(os.environ.get('RES',str(previous['render_dimensions'][0] if previous else 640)));scene.render.resolution_y=scene.render.resolution_x;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs['Color'].default_value=(.16,.16,.16,1);scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
environment_record=None
if os.environ.get('WORLD_ENV'):
 environment_path=pathlib.Path(os.environ['WORLD_ENV']);environment_strength=float(os.environ.get('WORLD_STRENGTH','.45'));ns=scene.world.node_tree.nodes;links=scene.world.node_tree.links;output=next(n for n in ns if n.type=='OUTPUT_WORLD');original_bg=next(n for n in ns if n.type=='BACKGROUND');env=ns.new('ShaderNodeTexEnvironment');env.image=bpy.data.images.load(str(environment_path),check_existing=True);env_bg=ns.new('ShaderNodeBackground');env_bg.inputs['Strength'].default_value=environment_strength;links.new(env.outputs['Color'],env_bg.inputs['Color']);light_path=ns.new('ShaderNodeLightPath');mix=ns.new('ShaderNodeMixShader');links.new(light_path.outputs['Is Camera Ray'],mix.inputs[0]);links.new(env_bg.outputs[0],mix.inputs[1]);links.new(original_bg.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],output.inputs['Surface']);environment_record={'path':str(environment_path),'sha256':hashlib.sha256(environment_path.read_bytes()).hexdigest(),'strength':environment_strength,'camera_background':'Original neutral background retained for camera rays; environment affects lighting and reflections.'}
center=Vector(previous['target'] if previous else json.loads(os.environ['TARGET']));scale=float(previous['camera_ortho_scale'] if previous else os.environ['SCALE']);angle=float(previous['angle'] if previous else os.environ.get('ANGLE','0'));elev=float(previous['elevation'] if previous else os.environ.get('ELEV','0'))
for label,offset,power in [('Key',(-3,-4,4),280),('Fill',(4,-1,1),80),('Rim',(0,4,3),200)]:
 d=bpy.data.lights.new(label,'AREA');d.energy=power;d.shape='DISK';d.size=3;o=bpy.data.objects.new(label,d);scene.collection.objects.link(o);o.location=center+Vector(offset);o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=scale;cam.location=center+Vector((5*math.sin(math.radians(angle)),-5*math.cos(math.radians(angle)),elev));cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
if os.environ.get('CAMERA_META'):
 assert previous['render_dimensions']==[scene.render.resolution_x]*2;cam.matrix_world=Matrix(previous['camera_world_matrix_blender']);cam.data.ortho_scale=previous['camera_ortho_scale']
diagnostic_camera_fill=None
if os.environ.get('CAMERA_FILL'):
 d=bpy.data.lights.new('DiagnosticCameraFill','AREA');d.energy=float(os.environ['CAMERA_FILL']);d.shape='DISK';d.size=2;o=bpy.data.objects.new('DiagnosticCameraFill',d);scene.collection.objects.link(o);o.location=center+(cam.location-center).normalized()*3;o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler();diagnostic_camera_fill={'power':d.energy,'size':d.size,'location':list(o.location)}
scene.render.filepath=str(out);bpy.ops.render.render(write_still=True);count=sum(len(o.data.polygons)for o in scene.objects if o.type=='MESH');q={'source':str(src),'sha256':digest,'actual_glb_reimport':True,'mode':mode,'imported_polygon_count':count,'target':list(center),'elevation_semantics':'world Z camera offset in metres','angle':angle,'elevation':elev,'camera_world_matrix_blender':[list(v)for v in cam.matrix_world],'camera_projection_type':'ORTHO','camera_ortho_scale':cam.data.ortho_scale,'camera_lens_mm':cam.data.lens,'camera_sensor_width_mm':cam.data.sensor_width,'render_dimensions':[scene.render.resolution_x,scene.render.resolution_y],'samples':scene.cycles.samples,'world_environment':environment_record,'diagnostic_camera_fill':diagnostic_camera_fill,'reused_camera_metadata':os.environ.get('CAMERA_META'),'status':'Internal actual-model diagnostic, not user review or whole-character clearance'};out.with_suffix('.json').write_text(json.dumps(q,indent=2));print(q,flush=True)
