"""Reversible one-face source overlap trial, supported from three measured observers."""
import pathlib,json,hashlib,copy,collections,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_07_far_eye_geometry_diagnostic.glb'
proof=json.loads((r/'checks/scarlett61_raw23453_support.json').read_text())
assert hashlib.sha256(src.read_bytes()).hexdigest()==proof['sha256']
assert proof['jointly_excluded_raw_faces']==[23453]
for q in proof['observations']:
    assert q['counts']['all']['first_hit_front_with_ties']==q['counts']['all']['n']==3321
    assert q['counts']['all']['front_backing_within_5mm']==3321
j,b,a=read_glb(src);sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0]
raw=np.load(r/'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids'];SF=sa(sp['indices']).reshape(-1,3);target=SF[np.flatnonzero(raw==23453)[0]]
sourceP=sa(sp['attributes']['POSITION'])*sj['nodes'][0]['scale']+sj['nodes'][0]['translation'];W,iv=np.unique(sourceP,axis=0,return_inverse=True)
allF=[];removed=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
    if p['attributes']['POSITION']!=sp['attributes']['POSITION']:continue
    F=a(p['indices']).reshape(-1,3);allF.extend(F.tolist());keep=~np.all(F==target,axis=1)
    if not keep.all():
        removed.extend([[pi,int(k)] for k in np.flatnonzero(~keep)])
        p['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
assert len(removed)==1
counts=collections.Counter(tuple(sorted((int(u),int(v))))for f in iv[np.array(allF)]for u,v in zip(f,np.roll(f,-1)))
edge_report=[{'position_ids':[int(u),int(v)],'before':counts[tuple(sorted((int(u),int(v))))],'after':counts[tuple(sorted((int(u),int(v))))]-1}for u,v in zip(iv[target],np.roll(iv[target],-1))]
out=r/'models/scarlett_08_backface_overlap_trial.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out)
report={'source':str(src),'source_sha256':proof['sha256'],'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_raw_face':23453,'removed_primitive_face':removed,'triangles':sum(len(aa(p['indices']))//3 for p in jj['meshes'][0]['primitives']),'attributes_materials_images_held':True,'source_edge_incidence':edge_report,'support_report':'checks/scarlett61_raw23453_support.json','status':'One supported reversed source sheet removed in an internal trial. Exact appearance and independent review pending; no whole-model clearance.'}
(r/'checks/scarlett_08_backface_overlap_trial.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
