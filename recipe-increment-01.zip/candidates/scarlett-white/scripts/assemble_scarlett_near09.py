"""Internal near-eye trial with a conforming retained-source perimeter."""
import pathlib,json,copy,hashlib,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_08_backface_overlap_trial.glb';j,b,a=read_glb(src)
path=r/'checks/scarlett_near_patch72.npz';z=np.load(path);D={k:z[k]for k in z.files};z.close();proof=json.loads((r/'checks/scarlett_near_patch72_v4_audit.json').read_text());assert proof['sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
assert not any(proof[k]for k in ['proper_crossings','positive_area_coplanar_pairs','new_full_face_copies','new_zero_area_faces'])
sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];SF=sa(sp['indices']).reshape(-1,3);lookup={tuple(map(int,f)):i for i,f in enumerate(SF)};selected=set(map(int,D['near_source_face_ids']));split=set(map(int,D['source_split_replaced_source01_faces']));remove=selected|split;found=[];materials={};components=[];prims=[]
oldlabels=json.loads((r/'checks/scarlett_07_far_eye_geometry_diagnostic.json').read_text())['components']
for pi,p in enumerate(j['meshes'][0]['primitives']):
    q=copy.deepcopy(p)
    if p['attributes']['POSITION']==sp['attributes']['POSITION']:
        F=a(p['indices']).reshape(-1,3);ids=np.array([lookup[tuple(map(int,f))]for f in F]);keep=~np.isin(ids,list(remove));found.extend(ids[~keep].tolist())
        for fi in ids:materials[int(fi)]=p['material']
        q['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
    prims.append(q);components.append({'kind':'held_'+oldlabels[pi]['kind'],'source08_primitive':pi})
assert len(found)==len(remove)and set(found)==remove
payload=(r/'renders/scarlett_06_eyes_front_unlit.png').read_bytes();b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(payload)});b+=payload;ii=len(j['images']);j['images'].append({'name':'Internal near-eye original unlit color probe800px','bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});mats={}
for name,rough in [('skin',.62),('cap',.24),('contact',.62)]:
    mat={'name':'Scarlett internal near-eye '+name,'pbrMetallicRoughness':{'baseColorTexture':{'index':ti},'roughnessFactor':rough,'metallicFactor':0},'doubleSided':False}
    if name=='cap':mat['extensions']={'KHR_materials_clearcoat':{'clearcoatFactor':.8,'clearcoatRoughnessFactor':.06},'KHR_materials_ior':{'ior':1.38}}
    mats[name]=len(j['materials']);j['materials'].append(mat)
sc=np.array(j['nodes'][0]['scale']);tr=np.array(j['nodes'][0]['translation'])
def add(P,N,UV,T,mat,label):
    global b
    used,iv=np.unique(T,return_inverse=True);P=P[used];N=N[used];UV=UV[used];T=iv.reshape(-1,3);attrs={}
    for key,arr,kind in [('POSITION',((P-tr)/sc).astype(np.float32),'VEC3'),('NORMAL',N.astype(np.float32),'VEC3'),('TEXCOORD_0',UV.astype(np.float32),'VEC2')]:attrs[key],b=append_accessor(j,b,arr,kind,34962)
    ix,b=append_accessor(j,b,T.astype(np.uint32),'SCALAR',34963);prims.append({'attributes':attrs,'indices':ix,'mode':4,'material':mat});components.append({'kind':label,'triangles':len(T),'position_sha256':hashlib.sha256(P.tobytes()).hexdigest()})
for name in ['skin','cap','contact']:
    P=D['near_positions']if name=='skin'else D['near_'+name+'_positions'];T=D['near_'+name+'_triangles'];N=D['near_'+name+'_normals']if name!='contact'else None
    if name=='contact':P=P[T].reshape(-1,3);N=np.repeat(D['near_contact_face_normals'],3,axis=0);T=np.arange(len(P)).reshape(-1,3)
    UV=np.c_[.5+(P[:,0]+.07)/.23,.5-(P[:,1]-.816)/.23];add(P,N,UV,T,mats[name],'near_'+name)
source_faces=D['source_split_source01_faces'];source_mats=np.array([materials[int(fi)]for fi in source_faces])
for mat in np.unique(source_mats):
    add(D['source_split_positions'],D['source_split_normals'],D['source_split_uv'],D['source_split_triangles'][source_mats==mat],int(mat),'source_planar_subdivision')
j['meshes'][0]['primitives']=prims;out=r/'models/scarlett_09_near_eye_geometry_trial.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'component_array_sha256':proof['sha256'],'removed_for_eye_source01_faces':sorted(selected),'subdivided_retained_source01_faces':sorted(split),'components':components,'triangles':sum(len(aa(p['indices']))//3 for p in jj['meshes'][0]['primitives']),'paint_provenance':'Temporary800px unlit source color probe. Source eye pigment/baked glints remain diagnostic input, not final neutral eye painting.','status':'INTERNAL TRIAL. Exact-model intersections, source subdivision seams and front/profile/under appearance pending.'};(r/'checks/scarlett_09_near_eye_geometry_trial.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k not in ['components','removed_for_eye_source01_faces','subdivided_retained_source01_faces']},flush=True)
