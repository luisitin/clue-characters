"""Small lossless GLB reader/writer with normalized and interleaved accessors."""
import pathlib,struct,json,numpy as np
DT={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def read_glb(path):
 raw=pathlib.Path(path).read_bytes();assert raw[:4]==b'glTF'and struct.unpack_from('<I',raw,4)[0]==2;j=None;b=None;offset=12
 while offset<len(raw):
  n,t=struct.unpack_from('<II',raw,offset);chunk=raw[offset+8:offset+8+n];offset+=8+n
  if t==0x4e4f534a:j=json.loads(chunk)
  elif t==0x004e4942:b=chunk
 assert j is not None and b is not None
 def accessor(i,normalized=True):
  q=j['accessors'][i];assert 'sparse'not in q;v=j['bufferViews'][q['bufferView']];dtype=np.dtype(DT[q['componentType']]);n=NC[q['type']];stride=v.get('byteStride',dtype.itemsize*n);off=v.get('byteOffset',0)+q.get('byteOffset',0);a=np.ndarray((q['count'],n),dtype=dtype,buffer=b,offset=off,strides=(stride,dtype.itemsize)).copy()
  if normalized and q.get('normalized'):
   info=np.iinfo(dtype);a=a.astype(np.float64)/info.max
   if info.min<0:a=np.maximum(a,-1)
  return a[:,0]if n==1 else a
 return j,b,accessor
def append_accessor(j,b,array,kind,target=None):
 a=np.ascontiguousarray(array)
 if kind=='SCALAR':a=a.reshape(-1)
 types={np.dtype('float32'):5126,np.dtype('uint32'):5125,np.dtype('uint16'):5123};ct=types[a.dtype];b+=b'\0'*((-len(b))%4);v={'buffer':0,'byteOffset':len(b),'byteLength':a.nbytes}
 if target is not None:v['target']=target
 vi=len(j['bufferViews']);j['bufferViews'].append(v);q={'bufferView':vi,'componentType':ct,'count':len(a),'type':kind}
 if kind!='SCALAR':q.update(min=a.min(0).astype(float).tolist(),max=a.max(0).astype(float).tolist())
 ai=len(j['accessors']);j['accessors'].append(q);return ai,b+a.tobytes()
def write_glb(path,j,b):
 j['buffers']=[{'byteLength':len(b)}];raw=json.dumps(j,separators=(',',':')).encode();raw+=b' '*((-len(raw))%4);b+=b'\0'*((-len(b))%4);pathlib.Path(path).write_bytes(struct.pack('<4sII',b'glTF',2,28+len(raw)+len(b))+struct.pack('<II',len(raw),0x4e4f534a)+raw+struct.pack('<II',len(b),0x004e4942)+b)
