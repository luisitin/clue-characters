"""Internal exact-model diagnostic of the cleared component45 intersection domain.
The retained-source tangent risk remains open. This is not an approved character.
"""
import pathlib,json,numpy as np,hashlib,copy,io
from PIL import Image
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_06_lip_corner_softness.glb';j,b,a=read_glb(src);sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];SF=sa(sp['indices']).reshape(-1,3);d=np.load(r/'checks/scarlett_far_patch45.npz');D={k:d[k]for k in d.files};d.close();proof=json.loads((r/'checks/scarlett_far_patch45_v4_audit.json').read_text());assert not proof['proper_crossings']and not proof['positive_area_coplanar_pairs']and not proof['new_full_face_copies']and not proof['new_zero_area_faces'];assert proof['sha256']==hashlib.sha256((r/'checks/scarlett_far_patch45.npz').read_bytes()).hexdigest();scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);lookup={tuple(map(int,f)):i for i,f in enumerate(SF)};selected=set(map(int,D['source01_faces_to_replace']));removed=[];new=[];components=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 q=copy.deepcopy(p)
 if p['attributes']['POSITION']==sp['attributes']['POSITION']:
  assert np.array_equal(a(p['attributes']['POSITION'],False),sa(sp['attributes']['POSITION'],False));F=a(p['indices']).reshape(-1,3);ids=np.array([lookup[tuple(map(int,f))]for f in F]);keep=~np.isin(ids,list(selected));removed.extend(ids[~keep].tolist());q['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
 new.append(q);components.append({'kind':'held_base','source_primitive':pi,'attribute_accessors':q['attributes'].copy()})
assert len(removed)==len(selected)and set(removed)==selected
probe=r/'renders/scarlett_06_eyes_front_unlit.png';skin_bytes=probe.read_bytes();atlas=np.array(Image.open(probe).convert('RGB'));H,W=atlas.shape[:2];assert(H,W)==(800,800);pc=np.array(json.loads((r/'checks/scarlett_physical_aperture27.json').read_text())['source_pupil_target_pixels']);ic=pc+[3,4];yy,xx=np.meshgrid(np.arange(H)+.5,np.arange(W)+.5,indexing='ij');dx=xx-ic[0];dy=yy-ic[1];theta=.18;c=np.cos(theta);s=np.sin(theta);u=c*dx+s*dy;v=-s*dx+c*dy;rr=np.sqrt((u/19)**2+(v/23)**2);phi=np.arctan2(v/23,u/19);fiber=(np.sin(phi*47+rr*8)+.4*np.sin(phi*93-rr*7))/1.4;factor=(.80+.18*np.exp(-((rr-.55)/.25)**2))*(.42+.58*np.clip((1-rr)/.12,0,1))*(1+.08*fiber);iris=np.clip(np.array([42.,132.,158.])[None,None,:]*factor[:,:,None],0,255);pup=np.sqrt(((xx-pc[0])/7.5)**2+((yy-pc[1])/12.0)**2);pa=np.clip((1.05-pup)/.12,0,1);iris=iris*(1-pa[:,:,None])+np.array([3,8,11])[None,None,:]*pa[:,:,None];ia=np.clip((1.035-rr)/.065,0,1);globe=np.broadcast_to(np.array([224.,226.,217.]),(H,W,3))*(1-ia[:,:,None])+iris*ia[:,:,None];buf=io.BytesIO();Image.fromarray(np.rint(globe).astype(np.uint8)).save(buf,format='PNG');globe_bytes=buf.getvalue()
def texture(payload,name):
 global b
 b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(payload)});b+=payload;ii=len(j['images']);j['images'].append({'name':name,'bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});return ti
skintex=texture(skin_bytes,'Temporary original source unlit color probe800px');eyetex=texture(globe_bytes,'Temporary far-eye registered procedural pigment800px; no baked glint');mats={}
for name,ti,rough in [('skin',skintex,.62),('cap',eyetex,.24),('contact',skintex,.62)]:
 m={'name':'Scarlett internal far-eye diagnostic '+name,'pbrMetallicRoughness':{'baseColorTexture':{'index':ti},'metallicFactor':0,'roughnessFactor':rough},'doubleSided':False}
 if name=='cap':m['extensions']={'KHR_materials_clearcoat':{'clearcoatFactor':.8,'clearcoatRoughnessFactor':.06},'KHR_materials_ior':{'ior':1.38}}
 mats[name]=len(j['materials']);j['materials'].append(m)
j['extensionsUsed']=list(dict.fromkeys(j.get('extensionsUsed',[])+['KHR_materials_clearcoat','KHR_materials_ior']))
for name in ['skin','cap','contact']:
 P=D[name+'_positions_world'];T=D[name+'_triangles'];N=D[name+'_normals_world']if name!='contact'else None
 if name=='contact':P=P[T].reshape(-1,3);N=np.repeat(D['contact_face_normals_world'],3,axis=0);T=np.arange(len(P)).reshape(-1,3)
 else:used,iv=np.unique(T,return_inverse=True);P=P[used];N=N[used];T=iv.reshape(-1,3)
 uv=np.c_[.5+(P[:,0]+.07)/.23,.5-(P[:,1]-.816)/.23];attrs={}
 for key,arr,kind in [('POSITION',((P-translation)/scale).astype(np.float32),'VEC3'),('NORMAL',N.astype(np.float32),'VEC3'),('TEXCOORD_0',uv.astype(np.float32),'VEC2')]:attrs[key],b=append_accessor(j,b,arr,kind,34962)
 ix,b=append_accessor(j,b,T.astype(np.uint32),'SCALAR',34963);new.append({'attributes':attrs,'indices':ix,'mode':4,'material':mats[name]});components.append({'kind':name,'triangles':len(T),'position_sha256':hashlib.sha256(P.tobytes()).hexdigest(),'triangle_sha256':hashlib.sha256(T.tobytes()).hexdigest()})
j['meshes'][0]['primitives']=new;out=r/'models/scarlett_07_far_eye_geometry_diagnostic.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'component_array_sha256':proof['sha256'],'replaced_source01_faces':sorted(selected),'triangles':sum(len(aa(p['indices']))//3 for p in jj['meshes'][0]['primitives']),'held_base_attribute_bytes':True,'components':components,'paint_provenance':'Temporary800px direct source-color probe plus deterministic procedural far-eye pigment; no AI raster or external artist asset. Not final HD painting.','known_open_gate':'Retained-source geometric tangent mismatch reaches72.6deg. Exact front/profile/under debug views must locate it; no source/character approval inferred from the clean intersection audit.','status':'INTERNAL DIAGNOSTIC ONLY, NOT USER REVIEW OR PROMOTED CHECKPOINT.'};(r/'checks/scarlett_07_far_eye_geometry_diagnostic.json').write_text(json.dumps(report,indent=2));print({k:report[k]for k in ['sha256','triangles','known_open_gate']},flush=True)
