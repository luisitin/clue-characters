"""Continuous physical neck chart with bounded harmonic skin-color restoration.
Protect the measured bead surface; reproject source material before inpainting.
"""
import pathlib,json,numpy as np,hashlib,copy,io
from PIL import Image
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from scipy.ndimage import distance_transform_edt
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_22_forehead_family_cleanup.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION'])*j['nodes'][0]['scale']+j['nodes'][0]['translation'];N=a(p['attributes']['NORMAL']);N/=np.linalg.norm(N,axis=1)[:,None];UV=a(p['attributes']['TEXCOORD_0']);F=a(p['indices']).reshape(-1,3);mat=j['materials'][p['material']];fit=json.loads((r/'checks/white_bead23_landmarks.json').read_text());C=np.array(fit['sphere_fit_center_gltf']);R=fit['sphere_fit_radius_m'];S=2048

def load(ti):
 tx=j['textures'][ti];ii=tx.get('source',tx.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];return np.array(Image.open(io.BytesIO(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB'))
base=load(mat['pbrMetallicRoughness']['baseColorTexture']['index']);orm=load(mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index'])
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def region(q,n):
 rad=q-C;dd=np.linalg.norm(rad,axis=-1);align=np.sum(n*rad,axis=-1)/np.maximum(dd,1e-10);bead=(align>.80)&(dd<R*1.35);w=smooth((q[...,0]-.060)/.015)*smooth((.137-q[...,0])/.015)*smooth((q[...,1]-.694)/.008)*smooth((.742-q[...,1])/.006)*smooth((q[...,2]+.001)/.006)*smooth((.047-q[...,2])/.008)*smooth((n[...,0]-.35)/.25);w*=1-smooth((align-.65)/.15);return w,bead
cent=P[F].mean(1);nn=N[F].mean(1);nn/=np.linalg.norm(nn,axis=1)[:,None];weights,_=region(cent,nn);vw,_=region(P,N);selected=np.flatnonzero((weights>.001)|(vw[F].max(1)>.001));# Restrict the chart to the measured neck side, never hidden opposite-head sheets.
selected=selected[np.all(P[F[selected],0]>.05,axis=1)&(nn[selected,0]>.25)];assert 5<len(selected)<1000;chosen=np.unique(F[selected]);yz=P[chosen][:,1:];low=yz.min(0)-.004;high=yz.max(0)+.004;span=high-low
# PNG u increases toward posterior -Z; v increases toward lower Y.
def chart(q):return np.c_[(high[1]-q[:,2])/span[1],(high[0]-q[:,1])/span[0]]
project=chart(P)*S;tri=project[F];lo=tri.min(1);hi=tri.max(1);candidates=np.flatnonzero(np.all(hi>=0,axis=1)&np.all(lo<S,axis=1)&(P[F,0].max(1)>.05));color=np.zeros((S,S,3),np.uint8);rough=np.zeros_like(color);depth=np.full((S,S),-np.inf,np.float32);normal=np.zeros((S,S,3),np.float32)
def sample(im,uv):
 h,w=im.shape[:2];x=uv[:,0]*w-.5;y=uv[:,1]*h-.5;ix=np.floor(x).astype(int);iy=np.floor(y).astype(int);fx=(x-ix)[:,None];fy=(y-iy)[:,None];return im[iy%h,ix%w]*(1-fx)*(1-fy)+im[iy%h,(ix+1)%w]*fx*(1-fy)+im[(iy+1)%h,ix%w]*(1-fx)*fy+im[(iy+1)%h,(ix+1)%w]*fx*fy
for fi in candidates:
 f=F[fi];q=project[f];mn=np.maximum(np.floor(q.min(0)).astype(int),0);mx=np.minimum(np.ceil(q.max(0)).astype(int),S-1);aa,bb,cc=q;den=(bb[1]-cc[1])*(aa[0]-cc[0])+(cc[0]-bb[0])*(aa[1]-cc[1])
 if abs(den)<1e-12:continue
 for y0 in range(mn[1],mx[1]+1,64):
  for x0 in range(mn[0],mx[0]+1,512):
   yy,xx=np.meshgrid(np.arange(y0,min(y0+64,mx[1]+1)),np.arange(x0,min(x0+512,mx[0]+1)),indexing='ij');px=xx+.5;py=yy+.5;w0=((bb[1]-cc[1])*(px-cc[0])+(cc[0]-bb[0])*(py-cc[1]))/den;w1=((cc[1]-aa[1])*(px-cc[0])+(aa[0]-cc[0])*(py-cc[1]))/den;w2=1-w0-w1;ok=(w0>=0)&(w1>=0)&(w2>=0)
   if not ok.any():continue
   yv,xv=yy[ok],xx[ok];bc=np.c_[w0[ok],w1[ok],w2[ok]];x=bc@P[f,0];near=x>depth[yv,xv]+1e-9
   if not near.any():continue
   yv,xv,bc,x=yv[near],xv[near],bc[near],x[near];uv=bc@UV[f];color[yv,xv]=np.rint(sample(base,uv)).astype(np.uint8);rough[yv,xv]=np.rint(sample(orm,uv)).astype(np.uint8);n=bc@N[f];n/=np.linalg.norm(n,axis=1)[:,None];normal[yv,xv]=n;depth[yv,xv]=x
valid=np.isfinite(depth);alpha=np.zeros((S,S),np.float32);protected=np.zeros((S,S),bool)
for y0 in range(0,S,128):
 yy,xx=np.meshgrid(np.arange(y0,min(y0+128,S)),np.arange(S),indexing='ij');q=np.stack([np.where(valid[yy,xx],depth[yy,xx],0),high[0]-(yy+.5)/S*span[0],high[1]-(xx+.5)/S*span[1]],-1);w,bead=region(q,normal[yy,xx]);alpha[yy,xx]=w*valid[yy,xx];protected[yy,xx]=bead&valid[yy,xx]
# Solve the low-frequency color field on a256 grid. Bead and absent surfaces are
# no-flux boundaries, so turquoise cannot diffuse into the restored skin.
small=256;c=np.array(Image.fromarray(color).resize((small,small),Image.Resampling.BILINEAR),float);aa=np.array(Image.fromarray(alpha).resize((small,small),Image.Resampling.BILINEAR));vv=np.array(Image.fromarray(valid).resize((small,small),Image.Resampling.NEAREST));pp=np.array(Image.fromarray(protected).resize((small,small),Image.Resampling.NEAREST));unknown=(aa>.015)&vv&~pp;ids=np.full((small,small),-1,int);ids[unknown]=np.arange(unknown.sum());rows=[];cols=[];vals=[];rhs=np.zeros((unknown.sum(),3));ys,xs=np.nonzero(unknown)
for idx,(y,x)in enumerate(zip(ys,xs)):
 degree=0
 for dy,dx in[(1,0),(-1,0),(0,1),(0,-1)]:
  yy,xx=y+dy,x+dx
  if not(0<=yy<small and 0<=xx<small)or not vv[yy,xx]or pp[yy,xx]:continue
  if not unknown[yy,xx] and not(c[yy,xx,0]>c[yy,xx,1]*1.08 and c[yy,xx,0]>c[yy,xx,2]*1.15 and c[yy,xx,0]>60):continue
  degree+=1
  if unknown[yy,xx]:rows.append(idx);cols.append(ids[yy,xx]);vals.append(-1.)
  else:rhs[idx]+=c[yy,xx]
 assert degree>0;rows.append(idx);cols.append(idx);vals.append(float(degree))
L=coo_matrix((vals,(rows,cols)),shape=(len(ys),len(ys))).tocsr();solution=spsolve(L,rhs);assert np.isfinite(solution).all();filled=c.copy();filled[unknown]=solution;field=np.array(Image.fromarray(np.rint(np.clip(filled,0,255)).astype(np.uint8)).resize((S,S),Image.Resampling.BILINEAR),float);paint=np.rint(color*(1-alpha[:,:,None])+field*alpha[:,:,None]).astype(np.uint8);neworm=rough.copy();neworm[:,:,1]=np.rint(rough[:,:,1]*(1-alpha)+.63*255*alpha).astype(np.uint8);neworm[:,:,2]=np.rint(rough[:,:,2]*(1-alpha)).astype(np.uint8)
# A full positional chart covers selected faces without original UV-island seams.
# Pad only absent exterior texels to keep bilinear filtering off black background.
if not valid.all():
 _,nearest=distance_transform_edt(~valid,return_indices=True);paint[~valid]=paint[nearest[0][~valid],nearest[1][~valid]];neworm[~valid]=neworm[nearest[0][~valid],nearest[1][~valid]]
textures=[]
for data,label in[(paint,'albedo'),(neworm,'ORM')]:
 buf=io.BytesIO();Image.fromarray(data).save(buf,format='PNG');payload=buf.getvalue();(r/'checks'/f'white25_neck_chart_{label}.png').write_bytes(payload);b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(payload)});b+=payload;ii=len(j['images']);j['images'].append({'name':'White continuous neck skin chart25 '+label,'bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});textures.append(ti)
newmat=copy.deepcopy(mat);newmat['name']='White continuous physical neck skin chart25';newmat['pbrMetallicRoughness']['baseColorTexture']['index']=textures[0];newmat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=textures[1]
if 'occlusionTexture'in newmat:newmat['occlusionTexture']['index']=textures[1]
mi=len(j['materials']);j['materials'].append(newmat);mask=np.ones(len(F),bool);mask[selected]=False;held=copy.deepcopy(p);held['indices'],b=append_accessor(j,b,F[mask].astype(np.uint32),'SCALAR',34963);fresh=copy.deepcopy(p);fresh['attributes']=copy.deepcopy(p['attributes']);fresh['attributes']['TEXCOORD_0'],b=append_accessor(j,b,chart(P).astype(np.float32),'VEC2',34962);fresh['attributes'].pop('TANGENT',None);fresh['indices'],b=append_accessor(j,b,F[selected].astype(np.uint32),'SCALAR',34963);fresh['material']=mi;j['meshes'][0]['primitives']=[held]+j['meshes'][0]['primitives'][1:]+[fresh];out=r/'models/white_25_continuous_neck_paint_trial.glb';write_glb(out,j,b);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'selected_source22_primitive0_faces':selected.tolist(),'geometry_normal_attributes_and_face_multiset_held':True,'new_chart_dimensions':[S,S],'restored_skin_texels':int((alpha>.01).sum()),'protected_physical_bead_texels':int(protected.sum()),'harmonic_unknowns':len(ys),'harmonic_bead_boundary':'Neumann/no flux for protected bead, invalid surfaces and non-skin-colored known neighbors. Mixed turquoise border pixels cannot donate color.','source_albedo_and_ORM_projected_before_restoration':True,'chart_bounds_world_YZ':[low.tolist(),high.tolist()],'status':'Unapproved material-only trial. Exact profile/unlit and other-angle boundaries must be inspected; no geometry cleanup or whole-head approval.'};(r/'checks/white_25_continuous_neck_paint_trial.json').write_text(json.dumps(report,indent=2));print({k:report[k]for k in ['sha256','restored_skin_texels','protected_physical_bead_texels','harmonic_unknowns']},flush=True)
