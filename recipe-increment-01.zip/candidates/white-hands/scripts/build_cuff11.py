"""Independent rounded rectangular closed fabric cuff shell with explicit UV chart."""
import pathlib,sys,numpy as np,json,hashlib,math,collections
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import append_accessor,write_glb
binding=json.load((r/'checks/fist_seed10.json').open());j={'asset':{'version':'2.0','generator':'White independent anatomical cuff11'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0,'name':'White cuff geometry study11'}],'meshes':[{'primitives':[]}],'buffers':[],'bufferViews':[],'accessors':[],'materials':[{'name':'White tailored cuff trial','pbrMetallicRoughness':{'baseColorFactor':[.81,.785,.735,1],'roughnessFactor':.76,'metallicFactor':0}},{'name':'Dark horn cuff stud trial','pbrMetallicRoughness':{'baseColorFactor':[.019,.014,.01,1],'roughnessFactor':.36,'metallicFactor':0}}]};b=b'';report={};allP=[];allT=[]
def append(P,T,UV,material):
 global b
 # Welded area normals are shared across UV seam copies.
 un,iv=np.unique(P,axis=0,return_inverse=True);q=P[T];fn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);N=np.zeros_like(un)
 for k in range(3):np.add.at(N,iv[T[:,k]],fn)
 N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-15);N=N[iv];gp=P[:,[0,2,1]]*[1,1,-1];gn=N[:,[0,2,1]]*[1,1,-1];attrs={}
 for name,a,kind in [('POSITION',gp,'VEC3'),('NORMAL',gn,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],b=append_accessor(j,b,a.astype(np.float32),kind,34962)
 ix,b=append_accessor(j,b,T.astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':material,'mode':4});off=sum(len(a)for a in allP);allP.append(P);allT.append(T+off);return N
for side,q in binding['hands'].items():
 O=np.array(q['anchor']);F=np.array(q['forward']);S=np.array(q['thumbward']);D=np.array(q['anatomical_dorsal']);theta=np.linspace(0,2*np.pi,97);theta[-1]=0;u=np.linspace(0,1,9);# longitudinal-radial closed cross-section with small fabric edge bevels
 cross=[(-.078,-.0007),(-.0773,0),(.0063,.002),(.007,.0013),(.007,-.0008),(.0063,-.0015),(-.0773,-.0025),(-.078,-.0018),(-.078,-.0007)];P=[];UV=[]
 for h,(x,offset)in enumerate(cross):
  for k,t in enumerate(theta):
   cs=np.sign(np.cos(t))*abs(np.cos(t))**(2/3.0);sn=np.sign(np.sin(t))*abs(np.sin(t))**(2/3.0);P.append(O+F*x+S*cs*(.043+offset)+D*sn*(.036+offset));UV.append([.025+k/96*.95,.025+h/8*.95])
 P=np.array(P);P[-97:]=P[:97];# exact seam coherence in both periodic directions
 for h in range(9):P[h*97+96]=P[h*97]
 T=[]
 for h in range(8):
  for k in range(96):
   a=h*97+k;c=(h+1)*97+k;T.extend([[a,c,a+1],[a+1,c,c+1]])
 T=np.array(T);volume=np.sum(P[T[:,0]]*np.cross(P[T[:,1]],P[T[:,2]]))/6
 if volume<0:T=T[:,[0,2,1]];volume=-volume
 N=append(P,T,np.array(UV),0);np.savez_compressed(r/'checks'/f'cuff11_{side}.npz',P=P,T=T,UV=np.array(UV),N=N,anchor=O,axis=F,thumbward=S,dorsal=D)
 # Low-profile horn button on the dorsal cuff plane; capsule profile avoids a sharp rim.
 B=O-F*.034+D*.039-S*.013;n=64;angles=np.linspace(0,2*np.pi,n+1);angles[-1]=0;bp=[];bu=[];profiles=[(-.0011,.0048),(-.0007,.0057),(.0007,.0058),(.0016,.0048),(.0019,.0030)];
 for h,(depth,radius)in enumerate(profiles):
  for k,a in enumerate(angles):bp.append(B+D*depth+radius*(F*np.cos(a)+S*np.sin(a)));bu.append([.025+.95*k/n,.025+.4*h/4])
 bp=np.array(bp);bt=[]
 for h in range(len(profiles)-1):
  for k in range(n):a=h*(n+1)+k;c=(h+1)*(n+1)+k;bt.extend([[a,c,a+1],[a+1,c,c+1]])
 # Two cap fans use their own planar UV regions in a separate atlas domain.
 for h,sign in [(0,-1),(len(profiles)-1,1)]:
  base=len(bp);ring=bp[h*(n+1):h*(n+1)+n].copy();center=B+D*profiles[h][0];bp=np.vstack([bp,center,ring]);uvcenter=np.array([.25 if h==0 else .75,.75]);bu.extend([uvcenter.tolist()]+[(uvcenter+.20*np.array([np.cos(a),np.sin(a)])).tolist()for a in angles[:n]])
  for k in range(n):bt.append([base,base+1+k,base+1+(k+1)%n])
 bt=np.array(bt);# orient each face outward relative to button center by local radial position
 fc=bp[bt].mean(1);fn=np.cross(bp[bt[:,1]]-bp[bt[:,0]],bp[bt[:,2]]-bp[bt[:,0]]);flip=np.sum(fn*(fc-B),axis=1)<0;bt[flip]=bt[flip][:,[0,2,1]];append(bp,bt,np.array(bu),1);report[side]={'fabric_triangles':len(T),'signed_volume':float(volume),'nominal_proximal_distal_thickness_m':[.0025,.0035],'circumference_sections':96,'button_triangles':len(bt),'scope':'Standalone cuff fitting study; source sleeve contact and button/contact appearance are pending.'}
write_glb(r/'models/cuff11.glb',j,b);np.savez_compressed(r/'checks/cuff11_all.npz',P=np.concatenate(allP),T=np.concatenate(allT));(r/'checks/cuff11.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
