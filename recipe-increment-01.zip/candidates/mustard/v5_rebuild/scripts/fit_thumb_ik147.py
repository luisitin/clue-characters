"""Length-preserving thumb opposition IK against the held shaft, with bounded CMC angles."""
import bpy,json,hashlib,time,math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
D=Path(__file__).resolve().parents[1];src=D/'native/grip132.blend';bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH');r=json.loads((D/'audit/grip132.json').read_text());A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);R=r['shaft_radius_m'];radial=np.array([0.,1.,0]);radial-=radial@A*A;radial/=np.linalg.norm(radial);target=C+.035*A+.0252*radial;names=['finger1-1.R','finger1-2.R','finger1-3.R'];pb=[arm.pose.bones[n] for n in names];before={n:[list(row) for row in p.matrix] for n,p in arm.pose.bones.items() if not n.startswith('finger1-')};old=np.array([math.degrees(v) for v in pb[0].rotation_euler]+[math.degrees(pb[1].rotation_euler.x),math.degrees(pb[2].rotation_euler.x)]);start=time.time();calls=0

def pose(x):
 for p in pb:p.rotation_mode='XYZ'
 pb[0].rotation_euler=tuple(np.radians(x[:3]));pb[1].rotation_euler.x=math.radians(x[3]);pb[2].rotation_euler.x=math.radians(x[4]);bpy.context.view_layer.update();return np.array([list(p.head) for p in pb]+[list(pb[-1].tail)])

def residual(x):
 global calls
 calls+=1;p=pose(x);samples=np.concatenate([p[k][None,:]+np.linspace(0,1,9)[:,None]*(p[k+1]-p[k]) for k in range(3)]);q=samples-C;rr=np.linalg.norm(q-(q@A)[:,None]*A,axis=1);res=np.r_[(p[-1]-target)*3,np.maximum(R+.0112-rr,0)*2,(x-old)*.000006]
 if calls%25==0:print('IK',calls,'tip_error_mm',np.linalg.norm(p[-1]-target)*1000,'minimum_bone_radial_mm',rr.min()*1000,flush=True)
 return res
lo=np.array([-45.,-75.,-10.,-85.,-75.]);hi=np.array([45.,75.,25.,10.,10.])
def jacobian(x):
    columns=[]
    for k in range(len(x)):
        xp=x.copy();xm=x.copy();xp[k]=min(hi[k],x[k]+.20);xm[k]=max(lo[k],x[k]-.20);columns.append((residual(xp)-residual(xm))/(xp[k]-xm[k]))
    return np.column_stack(columns)
fit=least_squares(residual,old,bounds=(lo,hi),jac=jacobian,x_scale=20,max_nfev=150,ftol=1e-9,xtol=1e-9,gtol=1e-9);p=pose(fit.x);r['thumb_IK']={'target':target.tolist(),'target_radial_direction':radial.tolist(),'angles_baseXYZ_MCPX_IPX_degrees':fit.x.tolist(),'old_angles_degrees':old.tolist(),'tip_target_error_m':float(np.linalg.norm(p[-1]-target)),'solver_status':int(fit.status),'solver_message':fit.message,'Jacobian':'Bounded central finite differences with absolute0.20 degree steps; relative steps at zero were below Blender float32 pose resolution in rejected138.','evaluations':calls,'seconds':time.time()-start};r['non_thumb_bone_matrices_exactly_held']=all(before[n]==[list(row) for row in arm.pose.bones[n].matrix] for n in before);assert r['non_thumb_bone_matrices_exactly_held'];r['posed_bones']={n:{'head':list(p.head),'tail':list(p.tail),'matrix':[list(row) for row in p.matrix]} for n,p in arm.pose.bones.items() if n.endswith('.R') and any(q in n for q in ('finger','wrist','metacarpal'))};r['pose_degrees_local_x'].update({names[0]:float(fit.x[0]),names[1]:float(fit.x[3]),names[2]:float(fit.x[4]),names[0]+' local_y':float(fit.x[1]),names[0]+' local_z':float(fit.x[2])});ob.name='Mustard thumb opposed shaft study147';bpy.ops.wm.save_as_mainfile(filepath=str(D/'native/grip147.blend'));bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
out=D/'inputs/grip_thumb147.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True);r.update(source_native_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),scope='Thumb CMC opposition and hinge-flexion trial only, using actual parent-aware rigid bone matrices. Held four-finger/shaft fit. Skin self/cylinder/fold and actual appearance checks are mandatory; tip IK alone is not contact proof.');(D/'audit/grip147.json').write_text(json.dumps(r,indent=2));print(r['thumb_IK'],flush=True)
