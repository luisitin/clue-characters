"""First recovered anatomical hand trial. Native topology/UV, official normalized weights, fixed rest winding."""
import bpy,sys,json,math,hashlib,os
from pathlib import Path
import numpy as np
from mathutils import Vector,Matrix
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2]
TAG=os.environ.get('POINT_TAG','03');SUBDIV=int(os.environ.get('SUBDIV','3'));SIDE=os.environ.get('HAND_SIDE','R');FLEX=-1 if SIDE=='R' else 1
assert SIDE in ('R','L')
sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'))
from load_donor import load_donor
a=load_donor();V=a['positions'];UV=a['uv'];J=a['joint_positions'];bones=a['rig']['bones']
wrist=J[f'wrist.{SIDE}____head'];forward=J[f'finger3-1.{SIDE}____head']-wrist;forward/=np.linalg.norm(forward)
side=J[f'finger2-1.{SIDE}____head']-J[f'finger5-1.{SIDE}____head'];side-=side@forward*forward;side/=np.linalg.norm(side)
dorsal=np.cross(forward,side);dorsal/=np.linalg.norm(dorsal)
F=np.array([float(x) for x in os.environ.get('HAND_FORWARD','.6,-.8,.25').split(',')]);F/=np.linalg.norm(F);S=np.array([0.,0.,1.]);S-=S@F*F;S/=np.linalg.norm(S);N=np.cross(F,S)
R=np.column_stack([F,S,N])@np.column_stack([forward,side,dorsal]).T
assert np.linalg.det(R)>.999999
scale=.11833381983148004;anchor=np.array([-.290,-.130,.398])
def world(p):return (np.asarray(p)-wrist)@R.T*scale+anchor
proj=(V-wrist)@forward;dist=np.linalg.norm(V-wrist,axis=1)
chosen=[]
for i in a['body_face_ids']:
    face=a['faces'][i]
    if all(proj[x]>-.20 and dist[x]<2.05 and ((V[x,0]<-3.8) if SIDE=='R' else (V[x,0]>3.8)) for x in face):chosen.append(int(i))
ids=np.unique(np.concatenate([a['faces'][i] for i in chosen]));lookup={int(v):i for i,v in enumerate(ids)}
faces=[[lookup[v] for v in a['faces'][i]] for i in chosen]
pv=world(V[ids]);edges={}
for face in faces:
    for x,y in zip(face,face[1:]+face[:1]):edges.setdefault(tuple(sorted((x,y))),[]).append((x,y))
boundary=[q[0] for q in edges.values() if len(q)==1]
assert all(len(q)<=2 for q in edges.values())
degrees={}
for x,y in boundary:degrees[x]=degrees.get(x,0)+1;degrees[y]=degrees.get(y,0)+1
assert set(degrees.values())=={2},degrees
# A cap only for the winding test; never exported as hand skin.
c=pv[list(degrees)].mean(axis=0);volume=0.
for face in faces:
    for k in range(1,len(face)-1):volume+=np.dot(pv[face[0]],np.cross(pv[face[k]],pv[face[k+1]]))/6
for x,y in boundary:volume+=np.dot(c,np.cross(pv[y],pv[x]))/6
assert volume>0,('Unexpected rest winding; inspect before fitting',volume)
bpy.ops.wm.read_factory_settings(use_empty=True)
mesh=bpy.data.meshes.new('Official right hand rest UV');mesh.from_pydata(pv.tolist(),[],faces);mesh.update()
ob=bpy.data.objects.new(f'Mustard anatomical pointing hand{TAG} {SIDE}',mesh);bpy.context.collection.objects.link(ob)
uvlayer=mesh.uv_layers.new(name='NativeHandUV')
for poly,sourceface in zip(mesh.polygons,chosen):
    for loopid,uvi in zip(poly.loop_indices,a['face_uv'][sourceface]):uvlayer.data[loopid].uv=UV[uvi]
    poly.use_smooth=True
armdata=bpy.data.armatures.new('Official hand articulation');arm=bpy.data.objects.new('Official hand articulation',armdata);bpy.context.collection.objects.link(arm)
bpy.context.view_layer.objects.active=arm;arm.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for name,b in bones.items():
    e=armdata.edit_bones.new(name);e.head=world(J[b['head']]);e.tail=world(J[b['tail']])
    if (e.tail-e.head).length<1e-6:e.tail=e.head+Vector((0,0,1e-4))
    e.align_roll(Vector(N))
for name,b in bones.items():
    if b.get('parent'):armdata.edit_bones[name].parent=armdata.edit_bones[b['parent']]
bpy.ops.object.mode_set(mode='OBJECT');arm.select_set(False)
weights=a['weights_normalized'][ids]
for k,name in enumerate(a['bone_names']):
    active=np.flatnonzero(weights[:,k]>0)
    if len(active):
        group=ob.vertex_groups.new(name=name)
        for i in active:group.add([int(i)],float(weights[i,k]),'REPLACE')
mod=ob.modifiers.new('Official weighted preserve-volume articulation','ARMATURE');mod.object=arm;mod.use_deform_preserve_volume=True
angles={}
for digit in (3,4,5):
    for seg,degrees_ in enumerate([float(v) for v in os.environ.get('CURL','45,60,50').split(',')],1):
        name=f'finger{digit}-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
for seg,degrees_ in enumerate([float(v) for v in os.environ.get('CURL','60,55,40').split(',')],1):
    name=f'finger2-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
if os.environ.get('STRAIGHT_INDEX','0')=='1':
    # Set every index segment to the target direction through the actual parent pose.
    # No edited vertex or bone length is inferred from a post-subdivision array order.
    for seg in (1,2,3):
        name=f'finger2-{seg}.{SIDE}';pb=arm.pose.bones[name];bpy.context.view_layer.update()
        parent=pb.parent;rest=pb.bone.matrix_local.copy()
        base=(parent.matrix @ parent.bone.matrix_local.inverted() @ rest) if parent else rest
        desiredY=Vector(F);desiredZ=Vector(N);desiredX=desiredY.cross(desiredZ).normalized();desiredZ=desiredX.cross(desiredY).normalized()
        desired=Matrix((desiredX,desiredY,desiredZ)).transposed()
        pb.rotation_mode='QUATERNION';pb.rotation_quaternion=(base.to_3x3().inverted()@desired).to_quaternion()
    bpy.context.view_layer.update()
for seg,degrees_ in enumerate([15.,30.,20.],1):
    name=f'finger1-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
thumb_angle=float(os.environ.get('THUMB_ABDUCT','0'))
if thumb_angle:
    pb=arm.pose.bones[f'finger1-1.{SIDE}'];pb.rotation_mode='XYZ';pb.rotation_euler.z=math.radians(thumb_angle)
    angles[f'finger1-1.{SIDE} local_z']=thumb_angle
# Thumb opposition is assessed from actual views.
sub=ob.modifiers.new('Anatomical surface subdivision','SUBSURF');sub.levels=SUBDIV;sub.render_levels=SUBDIV
mat=bpy.data.materials.new('Neutral skin trial');mat.diffuse_color=(.61,.36,.23,1);mat.use_nodes=True
mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.61,.36,.23,1)
mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.55;ob.data.materials.append(mat)
bpy.context.view_layer.update()
posed_bones={name:{'head':list(pb.head),'tail':list(pb.tail),'matrix':[list(row) for row in pb.matrix]} for name,pb in arm.pose.bones.items() if name.endswith('.'+SIDE) and any(q in name for q in ('finger','wrist','metacarpal'))}
rest_report={'posed_bones':posed_bones,'source_manifest_sha256':hashlib.sha256((ROOT/'shared_sources/makehuman/provenance/manifest.json').read_bytes()).hexdigest(),'source_body_faces':chosen,'source_vertices':ids.tolist(),'rest_quads':len(faces),'rest_vertices':len(pv),'boundary_edges':len(boundary),'boundary_degree_two':True,'rest_cap_volume':float(volume),'fixed_original_OBJ_winding':True,'raw_weight_sum_range':[float(a['weight_sums_raw'][ids].min()),float(a['weight_sums_raw'][ids].max())],'normalized_weight_max_error':float(np.abs(weights.sum(axis=1)-1).max()),'world_forward':F.tolist(),'index_straightened':os.environ.get('STRAIGHT_INDEX','0')=='1','world_anchor':anchor.tolist(),'scale':scale,'native_forward':forward.tolist(),'native_thumbward':side.tolist(),'donor_side':SIDE,'native_basis_normal':dorsal.tolist(),'native_anatomical_dorsal':(-FLEX*dorsal).tolist(),'world_anatomical_dorsal':(-FLEX*N).tolist(),'pose_degrees_local_x':angles,'scope':'Provisional gripping-hand study from source landmarks. No prop/skin contact or gesture approval; no body cut. Diagonal leather belt remains protected separately from the baton.'}
bpy.context.view_layer.update();bpy.ops.wm.save_as_mainfile(filepath=str(D/f'native/pointing_hand{TAG}.blend'))
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for modifier in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=modifier.name)
ob.data.calc_loop_triangles();rest_report['evaluated_triangles']=len(ob.data.loop_triangles)
out=D/f'inputs/pointing_hand{TAG}.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
rest_report['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(D/f'audit/pointing_hand{TAG}.json').write_text(json.dumps(rest_report,indent=2));print(json.dumps({k:v for k,v in rest_report.items() if k not in ('source_body_faces','source_vertices')},indent=2),flush=True)
