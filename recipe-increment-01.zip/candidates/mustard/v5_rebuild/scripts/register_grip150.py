"""Rigidly register the clean hand/shaft to original front/back cap ray brackets.
No hand deformation or source-body removal. Registration is a visual/context trial.
"""
from pathlib import Path
import numpy as np,json,hashlib,copy
from glb_io import GLB
from merge_glbs import merge
D=Path(__file__).resolve().parents[1];r=json.loads((D/'audit/grip147.json').read_text());probes=json.loads((D/'audit/prop112_landmarks.json').read_text());caps=[];evidence=[]
for role in ['baton top gold cap','baton bottom gold cap']:
 row=next(x for x in probes['landmarks'] if x['reference_role']==role);hit=row['hits'][:2];assert hit[0]['camera_facing_GN']>0 and hit[1]['camera_facing_GN']<0;center=np.mean([h['point'] for h in hit],axis=0);caps.append(center);evidence.append({'role':role,'pixel':row['pixel'],'front_back_raw_faces':[h['raw_face'] for h in hit],'front_back_points':[h['point'] for h in hit],'ray_bracket_midpoint':center.tolist()})
top,bottom=caps;At=(top-bottom)/np.linalg.norm(top-bottom);A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);H=np.array(r['world_anchor']);cross=np.cross(A,At);sin=np.linalg.norm(cross);cos=A@At;K=np.array([[0,-cross[2],cross[1]],[cross[2],0,-cross[0]],[-cross[1],cross[0],0]]);R=np.eye(3)+K+K@K*((1-cos)/(sin*sin));assert np.max(np.abs(R.T@R-np.eye(3)))<1e-12 and np.linalg.det(R)>.999999999;Cr=H+(C-H)@R.T;Ct=bottom+At*((Cr-bottom)@At);delta=Ct-Cr;translation=H-H@R.T+delta;M=np.eye(4);M[:3,:3]=R;M[:3,3]=translation;reports=[]
for stem,outstem in [('grip_thumb147','grip_registered150'),('grip_shaft133','shaft_registered150')]:
 g=GLB(D/f'inputs/{stem}.glb');node=g.j['nodes'][0];assert not any(k in node for k in ('scale','rotation','translation','matrix'));p=g.primitive();oldp=p['attributes'].copy();rawP=g.read(oldp['POSITION'],False);rawN=g.read(oldp['NORMAL'],False);P=rawP.astype('f8')[:,[0,2,1]]*[1,-1,1];N=rawN.astype('f8')[:,[0,2,1]]*[1,-1,1];newP=P@R.T+translation;newN=N@R.T;p['attributes']['POSITION']=g.append((newP[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962);p['attributes']['NORMAL']=g.append((newN[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962)
 if 'TANGENT' in oldp:
  oldt=g.read(oldp['TANGENT'],False).copy();nt=oldt[:,:3].astype('f8')[:,[0,2,1]]*[1,-1,1];nt=nt@R.T;oldt[:,:3]=(nt[:,[0,2,1]]*[1,1,-1]).astype('f4');p['attributes']['TANGENT']=g.append(oldt,'VEC4',5126,34962)
 node['name']=outstem;out=D/f'inputs/{outstem}.glb';sha=g.save(out);check=GLB(out);CP,CT,CN,CUV=check.native();err=np.linalg.norm(CP-newP,axis=1);_,group=np.unique(P,axis=0,return_inverse=True);divergent=[]
 for label in np.unique(group):
  idx=np.flatnonzero(group==label)
  if len(idx)>1 and not np.all(CP[idx]==CP[idx[0]]):divergent.append(int(label))
 assert not divergent;assert np.array_equal(check.read(check.primitive()['indices']),g.read(p['indices']));reports.append({'source_sha256':GLB(D/f'inputs/{stem}.glb').sha256,'output':out.name,'sha256':sha,'maximum_float32_rigid_position_roundoff_m':float(err.max()),'preexisting_position_groups_divergent':divergent,'triangle_indices_UV_materials_held':True})
rout=copy.deepcopy(r);rout['registration_matrix_world']=M.tolist();rout['world_anchor']=(H+delta).tolist();rout['world_forward']=(R@np.array(r['world_forward'])).tolist();rout['world_anatomical_dorsal']=(R@np.array(r['world_anatomical_dorsal'])).tolist();rout['shaft_axis']=At.tolist();rout['shaft_center']=Ct.tolist()
for n,b in rout['posed_bones'].items():
 old=r['posed_bones'][n];b['head']=(R@np.array(old['head'])+translation).tolist();b['tail']=(R@np.array(old['tail'])+translation).tolist();b['matrix']=(M@np.array(old['matrix'])).tolist()
rout.update(output_sha256=reports[0]['sha256'],source_canonical_hand_sha256=reports[0]['source_sha256'],cap_ray_brackets=evidence,source_original_sha256=probes['sha256'],rotation_degrees=float(np.degrees(np.arccos(np.clip(cos,-1,1)))),wrist_translation_m=delta.tolist(),cap_midpoint_span_m=float(np.linalg.norm(top-bottom)),component_reports=reports,scope='Rigid registration trial from original prop cap front/back ray brackets. The original body, old hand, old prop and belt are untouched. Canonical native pose and material binding remain147; apply this matrix after canonical painting rather than pretending the canonical native file has moved. Actual body/reference fit and garment interface remain open.');(D/'audit/grip150_registration.json').write_text(json.dumps(rout,indent=2));merged=merge([D/'inputs/grip_registered150.glb',D/'inputs/shaft_registered150.glb'],D/'inputs/grip_registered_context150.glb');print({'rotation_degrees':rout['rotation_degrees'],'wrist_translation_m':rout['wrist_translation_m'],'world_anchor':rout['world_anchor'],'cap_midpoint_span_m':rout['cap_midpoint_span_m'],'components':reports,'assembly_sha256':merged['sha256']},flush=True)
