"""Bounded official-rig fit around a 28mm shaft. No skin sculpting or bone-length edits.
Low-resolution optimization is provisional; final evaluated triangle checks are mandatory.
"""
import bpy,sys,json,math,time,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
D=Path(__file__).resolve().parents[1];src=D/'native/grip124.blend';bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH');sub=next(m for m in ob.modifiers if m.type=='SUBSURF');heldlevel=sub.levels;sub.levels=1;sub.render_levels=1
r=json.loads((D/'audit/grip_axis127.json').read_text());C0=np.array(r['line_center']);A=np.array(r['line_axis_thumbward']);U=np.array([1.,0,0]);U-=U@A*A;U/=np.linalg.norm(U);V=np.cross(A,U);names=[f'finger{d}-{s}.R' for d in (2,3,4,5) for s in (1,2,3)];old=np.array([-math.degrees(arm.pose.bones[n].rotation_euler.x) for n in names]);start=time.time();calls=0;radius=.014;clearance=.0008
before={n:[list(row) for row in p.matrix] for n,p in arm.pose.bones.items() if n.startswith('finger1-')};lengths={n:float((p.tail-p.head).length) for n,p in arm.pose.bones.items()}

def positions(x):
 global calls
 calls+=1
 for name,a in zip(names,x[:12]):arm.pose.bones[name].rotation_euler.x=-math.radians(a)
 bpy.context.view_layer.update();ev=ob.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();p=np.empty((len(m.vertices),3),'f4');m.vertices.foreach_get('co',p.ravel());ev.to_mesh_clear();return p.astype('f8')

def residual(x):
 p=positions(x);C=C0+U*x[12]*.001+V*x[13]*.001;q=p-C;rad=np.linalg.norm(q-(q@A)[:,None]*A,axis=1);penetration=np.maximum(radius+clearance-rad,0);out=np.r_[penetration,(x[:12]-old)*.000005,x[12:]*.00005]
 if calls%25==0:print('FIT',calls,'elapsed',round(time.time()-start,2),'max_radial_intrusion_mm',float(penetration.max()*1000),'inside_count',int(np.count_nonzero(penetration)),flush=True)
 return out
x0=np.r_[old,0.,0.];lo=np.r_[np.tile([35.,35.,10.],4),-12.,-12.];hi=np.r_[np.tile([80.,80.,65.],4),12.,12.];result=least_squares(residual,x0,bounds=(lo,hi),diff_step=.002,x_scale=np.r_[np.full(12,10.),np.full(2,2.)],max_nfev=100,ftol=1e-7,xtol=1e-7,gtol=1e-7);x=result.x;positions(x);C=C0+U*x[12]*.001+V*x[13]*.001;sub.levels=heldlevel;sub.render_levels=heldlevel;bpy.context.view_layer.update();ob.name='Mustard grip official-rig shaft fit132';outnative=D/'native/grip132.blend';bpy.ops.wm.save_as_mainfile(filepath=str(outnative));report=json.loads((D/'audit/grip124.json').read_text());report['pose_degrees_local_x'].update({n:float(-a) for n,a in zip(names,x[:12])});report['posed_bones']={n:{'head':list(p.head),'tail':list(p.tail),'matrix':[list(row) for row in p.matrix]} for n,p in arm.pose.bones.items() if n.endswith('.R') and any(q in n for q in ('finger','wrist','metacarpal'))};report['thumb_matrices_exactly_held']=all(before[n]==[list(row) for row in arm.pose.bones[n].matrix] for n in before);assert report['thumb_matrices_exactly_held'];report['max_bone_length_delta_m']=max(abs(float((p.tail-p.head).length)-lengths[n]) for n,p in arm.pose.bones.items());bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
ob.data.calc_loop_triangles();P=np.empty((len(ob.data.vertices),3),'f4');ob.data.vertices.foreach_get('co',P.ravel());q=P-C;rr=np.linalg.norm(q-(q@A)[:,None]*A,axis=1);out=D/'inputs/grip_fit132.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True);report.update(source_native_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),shaft_axis=A.tolist(),shaft_center=C.tolist(),shaft_radius_m=radius,optimization_clearance_m=clearance,initial_angles_degrees=old.tolist(),fitted_angles_degrees=x[:12].tolist(),center_offset_mm=x[12:].tolist(),optimization_status=int(result.status),optimization_message=result.message,optimization_evaluations=calls,seconds=time.time()-start,full_subdivision_min_vertex_radial_distance_m=float(rr.min()),scope='Bounded official-rig fit; no skin sculpting or changed bone lengths. Low-resolution radial vertex optimization is provisional. Full final triangle-cylinder contact, full-hand intersections and actual gesture/context are required.');(D/'audit/grip132.json').write_text(json.dumps(report,indent=2));print({k:report[k] for k in ['output_sha256','fitted_angles_degrees','center_offset_mm','full_subdivision_min_vertex_radial_distance_m','seconds']},flush=True)
