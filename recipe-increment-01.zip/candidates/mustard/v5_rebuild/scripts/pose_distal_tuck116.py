"""Small MCP adduction study, using the held weighted rig rather than skin reshaping."""
import bpy,json,hashlib,sys
from pathlib import Path
import numpy as np
from mathutils import Vector
D=Path(__file__).resolve().parents[1];src=D/'native/pointing_hand09.blend';source_sha=hashlib.sha256(src.read_bytes()).hexdigest();bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH');assert np.max(np.abs(np.array(ob.matrix_world)-np.eye(4)))<1e-12
pose=json.loads((D/'audit/pointing_hand09.json').read_text());H=Vector(pose['world_anchor']);scale=.11833381983148004;factor=scale/pose['scale']
for v in ob.data.vertices:v.co=H+factor*(v.co-H)
bpy.ops.object.select_all(action='DESELECT');arm.select_set(True);bpy.context.view_layer.objects.active=arm;bpy.ops.object.mode_set(mode='EDIT')
for bone in arm.data.edit_bones:bone.head=H+factor*(bone.head-H);bone.tail=H+factor*(bone.tail-H)
bpy.ops.object.mode_set(mode='OBJECT');arm.select_set(False)
for digit in (3,4,5):
 for seg,degrees in [(2,70.),(3,55.)]:
  pb=arm.pose.bones[f'finger{digit}-{seg}.L'];assert pb.rotation_mode=='XYZ';pb.rotation_euler.x=np.radians(degrees);pose['pose_degrees_local_x'][f'finger{digit}-{seg}.L']=degrees
ob.name='Mustard pointing distal tuck116 L';bpy.context.view_layer.update();bpy.ops.wm.save_as_mainfile(filepath=str(D/'native/pointing_hand116.blend'));bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
ob.data.calc_loop_triangles();out=D/'inputs/pointing_hand116.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
pose['posed_bones']={name:{'head':list(pb.head),'tail':list(pb.tail),'matrix':[list(row) for row in pb.matrix]} for name,pb in arm.pose.bones.items() if name.endswith('.L') and any(q in name for q in ('finger','wrist','metacarpal'))}
pose.update(source_native_sha256=source_sha,output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),scale=scale,source_scale=pose['scale'],distal_tuck_local_x_degrees={'PIP':70,'DIP':55,'MCP_held':65},scope='Unpainted modest distal-tuck study. Index, thumb and MCP angles held; PIP+10deg and DIP+5deg only. Official weights/rest UVs held. Whole-hand and cuff/contact/appearance gates pending.')
(D/'audit/pointing_hand116.json').write_text(json.dumps(pose,indent=2));print(json.dumps({k:v for k,v in pose.items() if k not in ['source_body_faces','source_vertices','posed_bones']},indent=2))
