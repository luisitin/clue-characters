"""Correct the measured ring/little shaft intrusion using only small distal hinge rotations.
The fitted MCP stack, index/middle and thumb bones remain held.
"""
import bpy,json,math,hashlib,time
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
D=Path(__file__).resolve().parents[1];src=D/'native/grip_stack176.blend';bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH');r=json.loads((D/'audit/grip_stack176.json').read_text());A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);radius=r['shaft_radius_m'];names=[f'finger{d}-{s}.R' for d in (4,5) for s in (2,3)];old=np.array([math.degrees(arm.pose.bones[n].rotation_euler.x) for n in names]);before={n:[list(row) for row in p.matrix] for n,p in arm.pose.bones.items()};lengths={n:float((p.tail-p.head).length) for n,p in arm.pose.bones.items()};lo=old-5;hi=old+5;start=time.time();calls=0

def pose(x):
 global calls
 calls+=1
 for n,a in zip(names,x):p=arm.pose.bones[n];assert p.rotation_mode=='XYZ';p.rotation_euler.x=math.radians(a)
 bpy.context.view_layer.update();ev=ob.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();P=np.empty((len(m.vertices),3),'f4');m.vertices.foreach_get('co',P.ravel());ev.to_mesh_clear();return P.astype('f8')

def residual(x):
 P=pose(x);q=P-C;rr=np.linalg.norm(q-(q@A)[:,None]*A,axis=1);bad=np.maximum(radius+.00032-rr,0);res=np.r_[bad,(x-old)*.000003]
 if calls%25==0:print('CONTACT_FIT',calls,'seconds',round(time.time()-start,2),'max_intrusion_mm',float(bad.max()*1000),'count',int(np.count_nonzero(bad)),flush=True)
 return res

def jac(x):
 cols=[]
 for k in range(len(x)):
  xp=x.copy();xm=x.copy();xp[k]=min(hi[k],x[k]+.20);xm[k]=max(lo[k],x[k]-.20);cols.append((residual(xp)-residual(xm))/(xp[k]-xm[k]))
 return np.column_stack(cols)
fit=least_squares(residual,old,jac=jac,bounds=(lo,hi),x_scale=2,max_nfev=70,ftol=1e-9,xtol=1e-9,gtol=1e-9);P=pose(fit.x);q=P-C;rr=np.linalg.norm(q-(q@A)[:,None]*A,axis=1);held=all(before[n]==[list(row) for row in p.matrix] for n,p in arm.pose.bones.items() if n not in names);assert held;r['contact_correction']={'changed_joints':names,'old_local_X_degrees':old.tolist(),'new_local_X_degrees':fit.x.tolist(),'maximum_allowed_change_degrees':5,'full_evaluated_min_vertex_axis_distance_m':float(rr.min()),'target_surface_clearance_m':.00032,'all_other_bone_matrices_exactly_held':held,'evaluations':calls,'seconds':time.time()-start,'solver_message':fit.message};r['max_bone_length_delta_m']=max(abs(float((p.tail-p.head).length)-lengths[n]) for n,p in arm.pose.bones.items());r['stack_fit_before_contact_correction']=r.pop('stack_fit');r['final_digit_landmarks']={str(d):[list(arm.pose.bones[f'finger{d}-{s}.R'].tail) for s in (1,2,3)] for d in (2,3,4,5)};r['pose_degrees_local_x'].update({n:float(a) for n,a in zip(names,fit.x)});r['posed_bones']={n:{'head':list(p.head),'tail':list(p.tail),'matrix':[list(row) for row in p.matrix]} for n,p in arm.pose.bones.items() if n.endswith('.R') and any(q in n for q in ('finger','wrist','metacarpal'))};ob.name='Mustard contact-corrected compact grip179';bpy.ops.wm.save_as_mainfile(filepath=str(D/'native/grip179.blend'));bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
out=D/'inputs/grip179.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True);r.update(source_native_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),scope='Only four distal hinge rotations changed within5 degrees to clear the measured shaft conflict. No MCP, thumb or bone-length edits. Exact exported triangle-cylinder distance, whole-hand self-test and actual views must be repeated.');(D/'audit/grip179.json').write_text(json.dumps(r,indent=2));print(r['contact_correction'],flush=True)
