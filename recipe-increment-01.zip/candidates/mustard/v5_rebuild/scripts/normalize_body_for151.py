"""Normalize inherited quantized/dequantized normal lengths, without changing any
normal direction, geometry, topology, UV, material, transform or attribute index order.
"""
from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];reports=[]
for source,outname in [('body_pointing_cut33.glb','body_cut_unit104.glb')]:
 g=GLB(D/'inputs'/source);pr=g.primitive();attrs=pr['attributes'].copy();N=g.read(attrs['NORMAL'],False);assert N.dtype==np.dtype('float32');ids=np.unique(g.read(pr['indices']));old=N[ids].astype('f8');length=np.linalg.norm(old,axis=1);assert length.min()>.99 and length.max()<1.01;new=N.copy();new[ids]=(old/length[:,None]).astype('f4');after=new[ids].astype('f8');after/=np.linalg.norm(after,axis=1,keepdims=True);before=old/length[:,None];dot=np.sum(before*after,axis=1);angular=np.degrees(np.arccos(np.clip(dot,-1,1)));assert angular.max()<.00001
 pr['attributes']['NORMAL']=g.append(new,'VEC3',5126,34962);assert {k:v for k,v in pr['attributes'].items() if k!='NORMAL'}=={k:v for k,v in attrs.items() if k!='NORMAL'};sha=g.save(D/'inputs'/outname)
 reports.append({'source':source,'source_sha256':GLB(D/'inputs'/source).sha256,'output':outname,'output_sha256':sha,'referenced_normals':len(ids),'before_length_range':[float(length.min()),float(length.max())],'after_max_unit_error':float(np.abs(np.linalg.norm(new[ids].astype('f8'),axis=1)-1).max()),'maximum_direction_change_degrees':float(angular.max()),'position_indices_UV_material_transform_bytes_held':True,'normal_rows_and_corner_correspondence_held':True,'source_BIN_prefix_held':True,'scope':'Direction-preserving normalization of legacy normal lengths only; not a shape/appearance repair or a general geometry pass.'})
(D/'audit/body_normals151_replay.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2))
