"""Fit PIP/DIP/tip lateral spacing using explicit palm-axis rotation plus posed phalanx-axis twist.
This avoids assuming an Euler sign moves every part of an already-curled digit in one direction.
"""
import bpy,os,json,math,time,hashlib
from pathlib import Path
import numpy as np
from mathutils import Matrix,Vector
from scipy.optimize import least_squares
D=Path(__file__).resolve().parents[1];native=os.environ['NATIVE'];reportname=os.environ['SOURCE_REPORT'];side=os.environ['SIDE'];tag=os.environ['OUTPUT'];ratio=float(os.environ.get('STACK_RATIO','.80'));src=D/f'native/{native}.blend';bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH');r=json.loads((D/f'audit/{reportname}.json').read_text());F=np.array(r['world_forward']);S=np.array([0.,0,1.]);S-=S@F*F;S/=np.linalg.norm(S);DN=np.array(r['world_anatomical_dorsal']);DN/=np.linalg.norm(DN)
if side=='L':
 for digit in (3,4):
  for seg,deg in [(2,74.),(3,61.)]:
   p=arm.pose.bones[f'finger{digit}-{seg}.{side}'];p.rotation_euler.x=math.radians(deg);r['pose_degrees_local_x'][p.name]=deg
bpy.context.view_layer.update();baseline={n:[list(row) for row in p.matrix] for n,p in arm.pose.bones.items()};lengths={n:float((p.tail-p.head).length) for n,p in arm.pose.bones.items()};digits=[4,5] if side=='L' else [2,4,5];base={d:np.array([list(arm.pose.bones[f'finger{d}-{s}.{side}'].tail) for s in (1,2,3)]) for d in (2,3,4,5)};solutions=[];start=time.time()
for digit in digits:
 pb=arm.pose.bones[f'finger{digit}-1.{side}'];M0=pb.matrix.copy();H=M0.translation.copy();Hmat=Matrix.Translation(H);Hinv=Matrix.Translation(-H);old=base[digit];targetS=(old@S-base[3]@S)*ratio+base[3]@S;calls=[0]
 def pose(x):
  calls[0]+=1;palmar=Matrix.Rotation(math.radians(float(x[0])),4,Vector(DN));axial=Matrix.Rotation(math.radians(float(x[1])),4,'Y');pb.matrix=Hmat@palmar@Hinv@M0@axial;bpy.context.view_layer.update();return np.array([list(arm.pose.bones[f'finger{digit}-{s}.{side}'].tail) for s in (1,2,3)])
 def residual(x):
  pts=pose(x);delta=pts-old;return np.r_[pts@S-targetS,.15*(delta@F),.15*(delta@DN),x*.000005]
 def jac(x):
  columns=[]
  for k in range(2):
   xp=x.copy();xm=x.copy();xp[k]=min(25.,x[k]+.20);xm[k]=max(-25.,x[k]-.20);columns.append((residual(xp)-residual(xm))/(xp[k]-xm[k]))
  return np.column_stack(columns)
 fit=least_squares(residual,np.zeros(2),jac=jac,bounds=(-25,25),x_scale=10,max_nfev=80,ftol=1e-9,xtol=1e-9,gtol=1e-9);pts=pose(fit.x);solutions.append({'digit':digit,'palm_axis_rotation_degrees':float(fit.x[0]),'posed_phalanx_axis_twist_degrees':float(fit.x[1]),'landmarks':['PIP joint','DIP joint','distal bone tip'],'baseline_positions':old.tolist(),'target_S':targetS.tolist(),'actual_positions':pts.tolist(),'actual_S_error_m':(pts@S-targetS).tolist(),'actual_S_displacement_m':((pts-old)@S).tolist(),'actual_F_displacement_m':((pts-old)@F).tolist(),'actual_D_displacement_m':((pts-old)@DN).tolist(),'evaluations':calls[0],'status':int(fit.status),'MCP_head_error_m':float((pb.head-H).length)})
 print('SOLVED',solutions[-1],flush=True)
r['stack_fit']={'ratio':ratio,'palm_normal_axis':DN.tolist(),'lateral_axis':S.tolist(),'control_definition':'First rotate around fixed world/armature palm-normal axis through MCP head, then twist around the resulting posed proximal phalanx localY. Actual landmark directions are measured.','solutions':solutions,'seconds':time.time()-start};r['all_non_target_bone_matrices_exactly_held_after_distal_setup']=all(baseline[n]==[list(row) for row in p.matrix] for n,p in arm.pose.bones.items() if not any(n.startswith(f'finger{d}-') for d in digits));assert r['all_non_target_bone_matrices_exactly_held_after_distal_setup'];r['max_bone_length_delta_m']=max(abs(float((p.tail-p.head).length)-lengths[n]) for n,p in arm.pose.bones.items());r['posed_bones']={n:{'head':list(p.head),'tail':list(p.tail),'matrix':[list(row) for row in p.matrix]} for n,p in arm.pose.bones.items() if n.endswith('.'+side) and any(q in n for q in ('finger','wrist','metacarpal'))};ob.name='Mustard '+tag;bpy.ops.wm.save_as_mainfile(filepath=str(D/f'native/{tag}.blend'));bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
out=D/f'inputs/{tag}.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True);r.update(source_native_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),scope='Measured knuckle-and-tip spacing trial using rigid bone rotations only. Bone-target success is not skin clearance or gesture approval; full self/prop/cuff and actual views remain mandatory.');(D/f'audit/{tag}.json').write_text(json.dumps(r,indent=2));print(r['output_sha256'],flush=True)
