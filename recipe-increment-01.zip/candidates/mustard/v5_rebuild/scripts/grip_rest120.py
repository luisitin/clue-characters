"""Neutral pose ablation, preserving the exact donor extraction and original rest winding."""
import bpy,json,hashlib
from pathlib import Path
from mathutils import Matrix
D=Path(__file__).resolve().parents[1];src=D/'native/pointing_hand114.blend';bpy.ops.wm.open_mainfile(filepath=str(src));arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');ob=next(o for o in bpy.data.objects if o.type=='MESH')
for pb in arm.pose.bones:pb.matrix_basis=Matrix.Identity(4)
bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for mod in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
out=D/'inputs/grip_rest120.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
r={'source_native_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'scope':'Rest-pose diagnostic. All pose bone matrix_basis values are identity. Source extraction, weights, original rest winding and subdivision are unchanged.'};(D/'audit/grip_rest120.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
