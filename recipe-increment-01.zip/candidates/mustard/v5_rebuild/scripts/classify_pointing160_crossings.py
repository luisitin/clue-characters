"""Trace failed deeper flexion to native anatomy; no geometry changes."""
from pathlib import Path
import numpy as np,json,sys,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2];sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'));from load_donor import load_donor
g=GLB(D/'inputs/pointing_tuck160.glb');P,T,N,UV=g.native();u=g.read(g.primitive()['attributes']['TEXCOORD_0']);z=np.load(D/'inputs/pointing09_paint_binding13.npz');a={k:z[k] for k in z.files};mapping={}
for i,uv in enumerate(a['UV']):
 key=uv.tobytes()
 if key in mapping:assert np.array_equal(a['REST'][mapping[key]],a['REST'][i])
 else:mapping[key]=i
assert all(v.tobytes() in mapping for v in u);RP=a['REST'][[mapping[v.tobytes()] for v in u]];don=load_donor();bones=[]
for name,b in don['rig']['bones'].items():
 if name.endswith('.L') and ('finger' in name or 'metacarpal' in name or 'wrist' in name):bones.append((name,don['joint_positions'][b['head']],don['joint_positions'][b['tail']]))
centers=RP[T].mean(1);cost=[]
for name,a,b in bones:
 d=b-a;t=np.clip(((centers-a)@d)/(d@d),0,1);cost.append(np.linalg.norm(centers-a-t[:,None]*d,axis=1))
labels=np.argmin(cost,axis=0);raw=json.loads((D/'audit/pointing160_v4.json').read_text());pairs=[];counts=collections.Counter()
for pair in raw['proper_crossings']:
 fs=pair['faces'];names=[bones[labels[i]][0] for i in fs];counts['/'.join(sorted(names))]+=1;pairs.append({**pair,'rest_nearest_bones':names,'rest_centroids_native':centers[fs].tolist()})
folds=[]
for fs in raw['manifold_edge_folds_over_105_degrees']:folds.append({'faces':fs,'rest_nearest_bones':[bones[labels[i]][0] for i in fs],'posed_centers':P[T[fs]].mean(1).tolist()})
out={'sha256':g.sha256,'proper_crossing_count':len(pairs),'rest_bone_pair_counts':dict(counts),'pairs':pairs,'adjacent_fold_pairs':folds,'scope':'Exact native-UV rest attribution of failed160. This trial is rejected; no valid155 geometry is altered to conceal these intersections.'};(D/'audit/pointing160_crossing_attribution.json').write_text(json.dumps(out,indent=2));print({'counts':dict(counts),'folds':folds},flush=True)
