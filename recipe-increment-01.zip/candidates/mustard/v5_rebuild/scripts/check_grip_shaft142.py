"""Exact projected-triangle shaft clearance and rest-anatomy attribution."""
from pathlib import Path
import numpy as np,json,sys,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2];sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'));from load_donor import load_donor
r=json.loads((D/'audit/grip141.json').read_text());g=GLB(D/'inputs/grip_thumb141.glb');P,T,N,UV=g.native();rest=GLB(D/'inputs/grip_rest120.glb');RP,RT,RN,RUV=rest.native();u=g.read(g.primitive()['attributes']['TEXCOORD_0']);ru=rest.read(rest.primitive()['attributes']['TEXCOORD_0']);lookup={}
for i,uv in enumerate(ru):
 key=uv.tobytes()
 if key in lookup:assert np.array_equal(RP[lookup[key]],RP[i])
 else:lookup[key]=i
assert set(lookup)==set(uv.tobytes() for uv in u)
rest_index=np.array([lookup[uv.tobytes()] for uv in u]);ordered_equal=np.array_equal(u[T],ru[RT]);mapped_RP=RP[rest_index];A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);U=np.array([1.,0,0]);U-=U@A*A;U/=np.linalg.norm(U);V=np.cross(A,U);Q=(P-C)@np.column_stack((U,V));q=Q[T];cross=lambda a,b:a[:,0]*b[:,1]-a[:,1]*b[:,0];area=cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);sign=np.stack([cross(q[:,k],q[:,(k+1)%3]) for k in range(3)],axis=1);inside=(np.abs(area)>1e-16)&(np.all(sign>=-1e-16,axis=1)|np.all(sign<=1e-16,axis=1));ds=[]
for k in range(3):
 a=q[:,k];e=q[:,(k+1)%3]-a;t=np.clip(-np.sum(a*e,axis=1)/np.maximum(np.sum(e*e,axis=1),1e-30),0,1);ds.append(np.linalg.norm(a+t[:,None]*e,axis=1))
dist=np.min(ds,axis=0);dist[inside]=0;rad=r['shaft_radius_m'];bad=np.flatnonzero(dist<rad);don=load_donor();old=json.loads((D/'audit/pointing_hand114.json').read_text());F=np.array(old['world_forward']);S=np.array([0.,0.,1.]);S-=S@F*F;S/=np.linalg.norm(S);NN=np.cross(F,S);R=np.column_stack([F,S,NN])@np.column_stack([old['native_forward'],old['native_thumbward'],old['native_basis_normal']]).T;wrist=don['joint_positions']['wrist.R____head'];H=np.array(old['world_anchor']);world=lambda p:(np.asarray(p)-wrist)@R.T*old['scale']+H;bones=[]
for name,b in don['rig']['bones'].items():
 if name.endswith('.R') and ('finger' in name or 'wrist' in name or 'metacarpal' in name):bones.append((name,world(don['joint_positions'][b['head']]),world(don['joint_positions'][b['tail']])))
centers=mapped_RP[T[bad]].mean(1);cost=[]
for name,a,b in bones:
 d=b-a;t=np.clip(((centers-a)@d)/(d@d),0,1);cost.append(np.linalg.norm(centers-a-t[:,None]*d,axis=1))
labels=[bones[k][0] for k in np.argmin(cost,axis=0)];counts=collections.Counter(labels);rr={'hand_sha256':g.sha256,'rest_sha256':rest.sha256,'ordered_native_UV_corners_equal':bool(ordered_equal),'rest_binding':'Exact native-UV vertex keys with unique neutral positions; triangle orientation/diagonal changes do not invalidate per-vertex rest attribution.','shaft_radius_m':rad,'shaft_axis':A.tolist(),'shaft_center':C.tolist(),'minimum_axis_to_triangle_distance_m':float(dist.min()),'minimum_triangle_id':int(np.argmin(dist)),'axis_hits_skin_projection_triangles':np.flatnonzero(inside).tolist(),'triangles_within_shaft_radius':bad.tolist(),'rest_bone_counts':dict(counts),'worst_per_rest_bone':{name:float(dist[bad][np.array(labels)==name].min()) for name in counts},'scope':'Distance to an infinite shaft axis over every projected triangle, including triangle interior and all edges. Radius minus this distance is a solid-cylinder conflict, separate from exact surface crossing and external appearance.'};(D/'audit/grip142_clearance.json').write_text(json.dumps(rr,indent=2));print({k:(len(v) if isinstance(v,list) else v) for k,v in rr.items()},flush=True)
