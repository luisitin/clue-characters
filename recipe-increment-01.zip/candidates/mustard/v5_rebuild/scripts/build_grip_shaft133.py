"""Untextured explicit 28mm straight-shaft diagnostic, not final prop materials or caps."""
from pathlib import Path
import json,numpy as np
from glb_io import GLB
from merge_glbs import merge
D=Path(__file__).resolve().parents[1];r=json.loads((D/'audit/grip132.json').read_text());A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);radius=r['shaft_radius_m'];U=np.array([1.,0,0]);U-=U@A*A;U/=np.linalg.norm(U);V=np.cross(A,U);M=96;angles=np.arange(M+1)*2*np.pi/M;radial=np.cos(angles)[:,None]*U+np.sin(angles)[:,None]*V;radial[-1]=radial[0];ts=np.linspace(-.18,.36,55);P=[];N=[];UV=[];T=[]
for t in ts:P.extend(C+t*A+radius*radial);N.extend(radial);UV.extend(np.column_stack((np.linspace(0,1,M+1),np.full(M+1,(t+.18)/.54))))
for j in range(len(ts)-1):
 for k in range(M):
  a=j*(M+1)+k;b=a+1;c=a+(M+1);d=c+1;T.extend([[a,b,d],[a,d,c]])
for end,sign in [(0,-1),(-1,1)]:
 t=ts[end];off=len(P);ring=C+t*A+radius*radial[:-1];P.extend(ring);N.extend(np.tile(sign*A,(M,1)));UV.extend(np.column_stack((.5+.5*np.cos(angles[:-1]),.5+.5*np.sin(angles[:-1]))));center=len(P);P.append(C+t*A);N.append(sign*A);UV.append([.5,.5])
 for k in range(M):
  face=[center,off+k,off+(k+1)%M]
  if sign<0:face=face[::-1]
  T.append(face)
P=np.array(P);N=np.array(N);UV=np.array(UV);T=np.array(T);gn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);assert np.min(np.sum(gn*N[T].mean(1),axis=1))>0
G=object.__new__(GLB);G.bin=bytearray();G.j={'asset':{'version':'2.0','generator':'Mustard explicit shaft contact diagnostic133'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'materials':[{'name':'Diagnostic shaft solid','pbrMetallicRoughness':{'baseColorFactor':[.15,.07,.035,1],'roughnessFactor':.5,'metallicFactor':0},'doubleSided':False}],'nodes':[{'mesh':0,'name':'Straight diagnostic shaft133'}],'meshes':[],'scenes':[{'nodes':[0]}],'scene':0};attr={'POSITION':G.append((P[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962),'NORMAL':G.append((N[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962),'TEXCOORD_0':G.append(UV.astype('f4'),'VEC2',5126,34962)};G.j['meshes']=[{'primitives':[{'attributes':attr,'indices':G.append(T.ravel(),'SCALAR',5125,34963),'material':0,'mode':4}]}];out=D/'inputs/grip_shaft133.glb';sha=G.save(out);report=merge([D/'inputs/grip_fit132.glb',out],D/'inputs/grip_shaft_context133.glb');report['scope']='Unseated anatomical hand and explicit straight cylinder only. Body/cuff registration, thumb fit, final caps/materials and whole-character gates remain open.';report['shaft_radius_m']=radius;report['shaft_axis']=A.tolist();report['shaft_center']=C.tolist();(D/'audit/grip_shaft133.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
