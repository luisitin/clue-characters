import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/fair_sleeve74.py').read_text().replace('sleeve69','sleeve227').replace('sleeve74','sleeve228');exec(compile(code,'fair_sleeve228','exec'))
code=(R/'scripts/add_recessed_lining75.py').read_text().replace('sleeve69','sleeve227').replace('sleeve74','sleeve228').replace('sleeve75','sleeve229');exec(compile(code,'lining229','exec'))
