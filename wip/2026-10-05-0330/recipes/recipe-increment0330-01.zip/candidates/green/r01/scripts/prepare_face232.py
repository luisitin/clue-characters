"""Bind generated head albedo plates to exact saved cameras and held scene depth."""
import pathlib,json,hashlib,numpy as np
from PIL import Image
from scipy.spatial.transform import Rotation
from scipy.ndimage import distance_transform_edt
from glb_source import read_glb
from uv_raster import samples
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_head211.glb';j,b,A=read_glb(src)
def world(node):
 if 'matrix'in node:return np.array(node['matrix']).reshape(4,4).T
 M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);return M
triangles=[];targets={}
specs={(0,10):('head',4096),(0,1):('forehead',2048),(34,0):('eye0',2048),(34,3):('eye1',2048)}
for ni,node in enumerate(j['nodes']):
 if 'mesh'not in node:continue
 M=world(node)
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  P=A(pr['attributes']['POSITION']).astype('float32').astype(float);F=A(pr['indices']).astype(np.int64).reshape(-1,3);W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];keep=np.max(W[F][:,:,2],axis=1)>.62;triangles.append(W[F[keep]])
  if (ni,pi)in specs:
   key,res=specs[ni,pi];N=A(pr['attributes']['NORMAL'])@np.linalg.inv(M[:3,:3]);N=N[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];UV=A(pr['attributes']['TEXCOORD_0']);targets[key]={'P':W[F],'N':N[F],'UV':UV[F],'resolution':res,'node':ni,'primitive':pi,'material':pr['material']}
T=np.concatenate(triangles);plates=[('front','renders/eyes60/head_angle_0_unlit.json'),('profile270','renders/full_head211/head_angle_270_unlit.json'),('profile90','renders/full_head211/head_angle_90_unlit.json'),('under','renders/full_head211/head_under_unlit.json'),('rear','renders/full_head211/head_angle_180_unlit.json')];cameras=[];scales=[];depths=[];images=[];guards=[];provenance=[]
for name,metafile in plates:
 meta=json.loads((R/metafile).read_text());C=np.array(meta['camera_world_matrix']);s=meta['ortho_scale'];pc=(T-C[:3,3])@C[:3,:3];uv=np.stack([pc[:,:,0]/s+.5,.5-pc[:,:,1]/s],axis=-1);depth=np.full((1024,1024),np.inf,np.float32)
 for fi,y,x,bc in samples(uv,1024):
  d=bc@(-pc[fi,:,2]);depth[y,x]=np.minimum(depth[y,x],d)
 path=R/'textures/painting_plates/face224'/f'{name}.png';im=np.array(Image.open(path).convert('RGB').resize((1024,1024),Image.Resampling.LANCZOS));mask=(im.max(2).astype(int)-im.min(2)>12);guard=np.minimum(distance_transform_edt(mask),distance_transform_edt(np.isfinite(depth)));cameras.append(C);scales.append(s);depths.append(depth);images.append(im);guards.append(guard.astype('float32'));provenance.append({'plate':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'native_resolution':Image.open(path).size,'camera':metafile,'source_geometry_sha256':meta['source_sha256']});print(name,int(np.isfinite(depth).sum()),flush=True)
np.savez_compressed(R/'audit/face232_projection.npz',cameras=cameras,scales=scales,depths=depths,images=images,guards=guards)
info={}
for key,d in targets.items():
 np.savez_compressed(R/'audit'/f'face232_{key}.npz',P=d['P'],N=d['N'],UV=d['UV']);info[key]={k:v for k,v in d.items()if k not in ['P','N','UV']};info[key]['faces']=len(d['P'])
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'plates':provenance,'targets':info,'status':'Five-view albedo reprojection inputs. Generated plates are painting inputs, not evidence of actual model quality. Preserved source geometry and physical eyes require rendered regression.'};(R/'audit/face232.json').write_text(json.dumps(report,indent=2));print(info,flush=True)
