"""Classify the pearl's shallow intentional lobe contact and exclude other hits.
The analytic sphere bounds the inscribed mesh conservatively; V4 checks actual
triangles. A clean attachment requires native-ear ownership and a buried cap.
"""
from pathlib import Path
from collections import Counter
import numpy as np,json,hashlib
from audit_intersections_v4 import audit
R=Path(__file__).resolve().parents[1];info=json.loads((R/'checks/pearl_stud257.json').read_text());a=np.load(R/'inputs/face_pearl257.npz');P,T,M=a['pos'],a['tri'],a['material'];a.close();c=np.asarray(info['pearl_center_world']);anchor=np.asarray(info['anchor_world']);axis=np.asarray(info['seating_axis_world']);radius=info['radius_mm']/1000;bead=M==info['new_material'];q=P[T];lo=q.min(1);hi=q.max(1);bounds=np.r_[c-radius-.001,c+radius+.001];potential=np.all(hi>=bounds[:3],axis=1)&np.all(lo<=bounds[3:],axis=1);ids=np.where(potential)[0];source_ids=ids[~bead[ids]];Q=q[source_ids];A=Q[:,0];e=Q[:,1]-A;f=Q[:,2]-A;r=c-A;ee=np.sum(e*e,axis=1);ef=np.sum(e*f,axis=1);ff=np.sum(f*f,axis=1);re=np.sum(r*e,axis=1);rf=np.sum(r*f,axis=1);det=ee*ff-ef*ef;assert (det>1e-24).all();u=(ff*re-ef*rf)/det;v=(ee*rf-ef*re)/det;inside=(u>=0)&(v>=0)&(u+v<=1);closest=A+u[:,None]*e+v[:,None]*f;d2=np.sum((closest-c)**2,axis=1);d2[~inside]=np.inf
for j in range(3):
 a,b=Q[:,j],Q[:,(j+1)%3];ed=b-a;tt=np.clip(np.sum((c-a)*ed,axis=1)/np.sum(ed*ed,axis=1),0,1);point=a+tt[:,None]*ed;dd=np.sum((point-c)**2,axis=1);use=dd<d2;d2[use]=dd[use];closest[use]=point[use]
distance=np.sqrt(d2);contact=distance<radius;maxdepth=float(np.max(radius-distance));assert np.all(M[source_ids[contact]]==8),Counter(M[source_ids[contact]]);assert 0<maxdepth<.0008,maxdepth;other=distance[M[source_ids]!=8];other_min=float(other.min(initial=np.inf));assert other_min>radius+.0001,(other_min,radius);contact_extent=float(np.linalg.norm(closest[contact]-anchor,axis=1).max());assert contact_extent<.0035,contact_extent
used,inv=np.unique(T[ids],return_inverse=True);print(json.dumps({'stage':'COMPACT_READY','triangles':len(ids),'analytic_lobe_contact_triangles':int(contact.sum()),'maximum_analytic_penetration_mm':maxdepth*1000,'contact_extent_from_anchor_mm':contact_extent*1000}),flush=True);report=audit(P[used],inv.reshape(-1,3),bounds=bounds.tolist())
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in report[key]:row['faces']=[int(ids[i]) for i in row['faces']]
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:report[key]=[[int(ids[i]) for i in row] for row in report[key]]
report['zero_area_faces']=[int(ids[i]) for i in report['zero_area_faces']];ownership=Counter();cap_dots=[]
for row in report['proper_crossings']:
 pair=row['faces'];owners=tuple(sorted(map(int,M[pair])));ownership[owners]+=1;assert owners==(8,info['new_material']),owners;face=next(i for i in pair if bead[i]);n=(q[face].mean(0)-c)/radius;cap_dots.append(float(n@axis))
assert len(cap_dots)>0 and max(cap_dots)<-.75,cap_dots
assert not any(report[k] for k in ['positive_area_coplanar_pairs','position_triangle_copy_groups','zero_area_faces','manifold_edge_folds_over_105_degrees'])
report.update(component_sha256=hashlib.sha256((R/'inputs/face_pearl257.npz').read_bytes()).hexdigest(),proper_crossing_material_ownership={','.join(map(str,k)):v for k,v in ownership.items()},intentional_contacts_only=True,maximum_analytic_sphere_penetration_mm=maxdepth*1000,contact_extent_from_anchor_mm=contact_extent*1000,minimum_other_material_center_distance_mm=None if not np.isfinite(other_min) else other_min*1000,maximum_contact_bead_normal_dot_seating_axis=max(cap_dots),scope='The only triangle intersections are the pearl back cap seated into the verified native lobe. Contact depth is below0.8mm and all other materials are clear. Actual exported/all-angle appearance still required; this is not a zero-intersection or whole-character claim.');(R/'checks/pearl_contact258.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report.items()},indent=2))
