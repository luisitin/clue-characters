"""Conforming source-preserving garment flow study; no skin/pose changes.
Fixed physical support from162 holds unrelated torso and lower-sleeve faces.
Chord80um, angle8degrees, determinant and160K-face bounds are unchanged.
All physical split edges propagate through every incident source face while UV
and normal corner layers remain separate. Only after dense chord/Jacobian checks
pass is a new GLB written. Original construction body144 remains held.
"""
from pathlib import Path
import collections,hashlib,json,struct,numpy as np
from glb_io import read_glb
from cuff_flow_field162 import flow,zeroY
from retessellate_source_faces173 import retessellate
O=Path(__file__).resolve().parents[1];src=O/'components/source_body144.glb';tj=json.loads((O/'checks/cuff_tjunctions167.json').read_text());assert not tj['near_collinear_candidates'],'Source near-collinear edge candidates need explicit chain classification first';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];attrs={k:a(ai).astype(float)for k,ai in pr['attributes'].items()};assert set(attrs)=={'POSITION','NORMAL','TEXCOORD_0'}
for key in ['POSITION','NORMAL']:attrs[key]=attrs[key][:,[0,2,1]]*[1,-1,1]
baseP=attrs['POSITION'].copy();baseN=attrs['NORMAL'].copy();baseUV=attrs['TEXCOORD_0'].copy();F=a(pr['indices']).reshape(-1,3).astype(np.int64);baseF=F.copy();lineage=np.arange(len(F));history=[];original_triangles=len(F);original_vertices=len(baseP)
def metrics(A,F):
 P=A['POSITION'];Q,J=flow(P,32);shift=np.linalg.norm(Q-P,axis=1);active=np.flatnonzero(np.any(shift[F]>1e-10,axis=1));U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];badkeys=set();maxchord=0.;maxangle=0.;mindet=float(np.linalg.det(J).min());badfaces=0;worst=[]
 for start in range(0,len(active),500):
  ids=active[start:start+500];T=P[F[ids]];TQ=Q[F[ids]];cent=T.mean(1);mid=(T+np.roll(T,-1,axis=1))/2;test=np.concatenate([cent,mid.reshape(-1,3)]);Y,JJ=flow(test,32);mindet=min(mindet,float(np.linalg.det(JJ).min()));edgeerr=np.linalg.norm(Y[len(cent):].reshape(mid.shape)-(TQ+np.roll(TQ,-1,axis=1))/2,axis=2);g0=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);g1=np.cross(TQ[:,1]-TQ[:,0],TQ[:,2]-TQ[:,0]);assert np.linalg.norm(g0,axis=1).min()>1e-18 and np.linalg.norm(g1,axis=1).min()>1e-18;g0/=np.linalg.norm(g0,axis=1)[:,None];g1/=np.linalg.norm(g1,axis=1)[:,None];expected=np.linalg.solve(JJ[:len(cent)].transpose(0,2,1),g0[...,None])[...,0];expected/=np.linalg.norm(expected,axis=1)[:,None];ang=np.degrees(np.arccos(np.clip(np.sum(expected*g1,axis=1),-1,1)));maxchord=max(maxchord,float(edgeerr.max()));maxangle=max(maxangle,float(ang.max()));badfaces+=int(((edgeerr.max(1)>.00008)|(ang>8)).sum())
  for kk in np.argsort(ang)[-3:]:
   if ang[kk]>8:worst.append({'angle_degrees':float(ang[kk]),'triangle':int(ids[kk]),'body144_parent_face':int(lineage[ids[kk]]),'prewarp_triangle_world':T[kk].tolist(),'postwarp_triangle_world':TQ[kk].tolist(),'chord_error_m':float(edgeerr[kk].max())})
  for k,fi in enumerate(ids):
   for z in range(3):
    if edgeerr[k,z]>.00008 or ang[k]>8:badkeys.add(tuple(sorted((int(UF[fi,z]),int(UF[fi,(z+1)%3])))))
 return Q,J,U,iv,UF,badkeys,{'triangles':len(F),'vertices':len(P),'active_faces':len(active),'maximum_chord_error_m':maxchord,'maximum_geometry_normal_error_degrees':maxangle,'minimum_vertex_edge_centroid_jacobian_determinant':mindet,'bad_faces':badfaces,'split_physical_edges':len(badkeys),'worst_faces':sorted(worst,key=lambda x:x['angle_degrees'],reverse=True)[:12]}
for iteration in range(17):
 Q,J,U,iv,UF,badkeys,row=metrics(attrs,F);row['iteration']=iteration;history.append(row);print('REFINE174',{k:v for k,v in row.items()if k!='worst_faces'},flush=True);(O/'checks/cuff_refine174_progress.json').write_text(json.dumps(history,indent=2));assert row['minimum_vertex_edge_centroid_jacobian_determinant']>.05
 if not badkeys:break
 assert iteration<16 and len(F)<160000,'Refinement limit exceeded; no output permitted'
 lists={k:v.tolist()for k,v in attrs.items()};cache={};geocache={};newF=[];newL=[]
 def midpoint(aa,bb):
  key=tuple(sorted((int(aa),int(bb))))
  if key in cache:return cache[key]
  gk=tuple(sorted((int(iv[aa]),int(iv[bb]))))
  if gk not in geocache:geocache[gk]=(U[gk[0]]+U[gk[1]])/2
  values={k:(v[aa]+v[bb])/2 for k,v in attrs.items()};values['POSITION']=geocache[gk];values['NORMAL']/=np.linalg.norm(values['NORMAL']);ix=len(lists['POSITION'])
  for k,v in values.items():lists[k].append(v.tolist())
  cache[key]=ix;return ix
 for fi,f in enumerate(F):
  chosen=[k for k in range(3)if tuple(sorted((int(UF[fi,k]),int(UF[fi,(k+1)%3]))))in badkeys]
  if not chosen:newF.append(f.tolist());newL.append(int(lineage[fi]));continue
  if len(chosen)==1:
   k=chosen[0];aa,bb,cc=map(int,[f[k],f[(k+1)%3],f[(k+2)%3]]);mm=midpoint(aa,bb);newF.extend([[aa,mm,cc],[mm,bb,cc]]);newL.extend([int(lineage[fi])]*2);continue
  if len(chosen)==3:
   aa,bb,cc=map(int,f);ab=midpoint(aa,bb);bc=midpoint(bb,cc);ca=midpoint(cc,aa);tris=[[aa,ab,ca],[ab,bb,bc],[ca,bc,cc],[ab,bc,ca]]
  else:
   # Two split edges meet at the central corner bb. Keep its small triangle,
   # then choose the better of two legal diagonals in the remaining quad.
   unsplit=next(k for k in range(3)if k not in chosen);aa=int(f[(unsplit+1)%3]);bb=int(f[(unsplit+2)%3]);cc=int(f[unsplit]);ab=midpoint(aa,bb);bc=midpoint(bb,cc);small=[bb,bc,ab]
   options=[[[aa,ab,bc],[aa,bc,cc]],[[aa,ab,cc],[ab,bc,cc]]]
   def quality(tris):
    xyz=np.array([[lists['POSITION'][v]for v in tri]for tri in tris]);edge=xyz-np.roll(xyz,-1,axis=1);area2=np.linalg.norm(np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]),axis=1);return float(np.min(area2/np.sum(edge*edge,axis=(1,2))))
   tris=[small]+max(options,key=quality)
  for tri in tris:newF.append(tri);newL.append(int(lineage[fi]))
 attrs={k:np.array(v)for k,v in lists.items()};F=np.array(newF,np.int64);lineage=np.array(newL,np.int64);F,lineage,retopo=retessellate(attrs['POSITION'],F,lineage,baseP,baseF);print('RETESSELLATE174',retopo,flush=True)
else:raise AssertionError('No converged surface')
assert np.array_equal(attrs['POSITION'][:original_vertices],baseP) and np.array_equal(attrs['NORMAL'][:original_vertices],baseN) and np.array_equal(attrs['TEXCOORD_0'][:original_vertices],baseUV)
# Transport authored corner normals through the actual integrated deformation.
N=attrs['NORMAL'];newN=np.linalg.solve(J.transpose(0,2,1),N[...,None])[...,0];newN/=np.linalg.norm(newN,axis=1)[:,None];held=np.all(Q==attrs['POSITION'],axis=1);newN[held]=N[held];assert np.isfinite(Q).all() and np.isfinite(newN).all();protected=attrs['POSITION'][:,1]>=zeroY;assert np.array_equal(Q[protected],attrs['POSITION'][protected]);values={'POSITION':Q,'NORMAL':newN,'TEXCOORD_0':attrs['TEXCOORD_0']};Q32=Q.astype('<f4').astype(float);G=np.cross(Q32[F[:,1]]-Q32[F[:,0]],Q32[F[:,2]]-Q32[F[:,0]]);assert np.linalg.norm(G,axis=1).min()>0;payload=bytearray(b);newattrs={}
for semantic,value in values.items():
 if semantic in ['POSITION','NORMAL']:value=value[:,[0,2,1]]*[1,1,-1]
 value=value.astype('<f4');payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':value.nbytes,'target':34962});payload.extend(value.tobytes());ai=len(j['accessors']);ar={'bufferView':vi,'componentType':5126,'count':len(value),'type':'VEC'+str(value.shape[1])}
 if semantic=='POSITION':ar.update(min=value.min(0).tolist(),max=value.max(0).tolist())
 j['accessors'].append(ar);newattrs[semantic]=ai
indices=F.astype('<u4').ravel();payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':indices.nbytes,'target':34963});payload.extend(indices.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':len(indices),'type':'SCALAR','min':[int(indices.min())],'max':[int(indices.max())]});pr['attributes']=newattrs;pr['indices']=ai;j['nodes'][0]['name']='Plum source cloth cuff flow174, unapproved';j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_cuff_flow174.glb';dst.write_bytes(raw)
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'flow_report163_sha256':hashlib.sha256((O/'checks/cuff_flow163.json').read_bytes()).hexdigest(),'source_tjunction_inventory167_sha256':hashlib.sha256((O/'checks/cuff_tjunctions167.json').read_bytes()).hexdigest(),'iterations':history,'triangles':len(F),'vertices':len(Q),'original_triangles':original_triangles,'original_vertices':original_vertices,'all_old_corner_UVs_and_prewarp_positions_normals_exactly_held':True,'normal_transport':'Integrated velocity-flow Jacobian inverse transpose; authored corner splits retained.','minimum_export_float32_triangle_area_m2':float(np.linalg.norm(G,axis=1).min()/2),'Y_at_or_above_8mm_held_exact':True,'scope':'Unapproved garment-end shape study. Original paint is preserved through corner interpolation but is semantically unfinished. No skin, hand pose, knitted cuff or lining is added. Full exact crossing/copy/seam checks and actual views remain mandatory.'};(O/'checks/cuff_refine174.json').write_text(json.dumps(r,indent=2));np.savez_compressed(O/'checks/cuff_refine174_binding.npz',prewarp_positions=attrs['POSITION'],prewarp_normals=attrs['NORMAL'],triangles=F,body144_parent_face=lineage);print('CUFF174',r,flush=True)
