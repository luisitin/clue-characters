"""Read-only moving-support cuff flow feasibility.
The direct blended displacement152 folded near its support fade and is rejected.
A smooth bounded velocity flow instead integrates both positions and the exact
spatial Jacobian; the held cuff ring follows the requested affine isotopy while
all background points at Y>=11mm remain fixed. This is not a model export.
"""
from pathlib import Path
import json,hashlib,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];r=json.loads((O/'checks/cuff_field152.json').read_text());CS=np.array(r['source_area_centroid']);A=np.array(r['affine_A']);t=np.array(r['translation_at_source_centroid']);F0=np.array(r['source_frame']);NC=F0[2];I=np.eye(3);src=O/'components/source_body144.glb';br=json.loads((O/'checks/source_body144.json').read_text());ring=np.array(next(x for x in br['explicit_boundaries']if x['label']=='cuff_construction')['ordered_world_points']);target=CS+(ring-CS)@A.T+t;fullY0=ring[:,1].max()+.0002;fullY1=target[:,1].max()+.0002;zeroY=.008;fullY=max(fullY0,fullY1);fullY0=fullY1=fullY;assert fullY<zeroY-.003

def smooth_derivative(u):
 x=np.clip(u,0,1);return x*x*x*(x*(x*6-15)+10),30*x*x*(x-1)**2

def velocity(P,time):
 At=I+time*(A-I);Atinv=np.linalg.inv(At);L=(P-CS)@F0.T;q=L[:,2];rad=np.linalg.norm(L[:,:2],axis=1);aa,da=smooth_derivative((q+.080)/.050);bb,db=smooth_derivative((.055-q)/.040);g,dg=smooth_derivative((.130-rad)/.040);f=aa*bb;fq=da/.050*bb-aa*db/.040;fg=f*g;fg_grad=(fq*g)[:,None]*NC+(-f*dg/.040)[:,None]*((L[:,0,None]*F0[0]+L[:,1,None]*F0[1])/np.maximum(rad[:,None],1e-20));hy,dy=smooth_derivative((zeroY-P[:,1])/(zeroY-fullY));hx,dx=smooth_derivative((-.065-P[:,0])/.025);w=fg*hy*hx;grad=fg_grad*(hy*hx)[:,None]+(-fg*dy*hx/(zeroY-fullY))[:,None]*np.array([0.,1.,0.])+(-fg*hy*dx/.025)[:,None]*np.array([1.,0.,0.]);B=(A-I)@Atinv;v=(P-CS-time*t)@B.T+t;dv=w[:,None,None]*B[None]+np.einsum('ni,nj->nij',v,grad);return w[:,None]*v,dv

def flow(P,steps=32):
 X=P.copy();J=np.repeat(I[None],len(P),axis=0);dt=1/steps
 for k in range(steps):
  tt=k*dt;k1,L=velocity(X,tt);j1=L@J;k2,L=velocity(X+dt*k1/2,tt+dt/2);j2=L@(J+dt*j1/2);k3,L=velocity(X+dt*k2/2,tt+dt/2);j3=L@(J+dt*j2/2);k4,L=velocity(X+dt*k3,tt+dt);j4=L@(J+dt*j3);X+=dt*(k1+2*k2+2*k3+k4)/6;J+=dt*(j1+2*j2+2*j3+j4)/6
 return X,J

# Pure field helper: no model, render or report is written by importing this module.

# The entire explicit affine ring path lies in the fixed full-strength region.
for points in [ring,target]:
 local=(points-CS)@F0.T
 assert local[:,2].min()>-.030 and local[:,2].max()<.015
 assert np.linalg.norm(local[:,:2],axis=1).max()<.090
 assert points[:,0].max()<-.090 and points[:,1].max()<fullY
