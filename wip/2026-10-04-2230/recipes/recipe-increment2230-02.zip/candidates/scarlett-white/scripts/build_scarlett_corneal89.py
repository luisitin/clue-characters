"""Optical-shape study: a small corneal rise, with shared eye/lid contact preserved.
Every projected coordinate and outer source perimeter stays fixed. This is a trial.
"""
import pathlib,json,numpy as np,hashlib
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_13_paired_eye_albedo_trial.glb';j,b,a=read_glb(src);node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);m=json.loads((r/'checks/scarlett_13_paired_eye_albedo_trial.json').read_text());far=np.load(r/'checks/scarlett_far_patch45.npz');near=np.load(r/'checks/scarlett_near_patch72.npz');outer_map={'far':far['skin_positions_world'][far['outer_vertex_ids'],:2],'near':near['near_positions'][near['near_outer_vertex_ids'],:2]};far.close();near.close();reports={}

for name,pis in [('near',[8,9,10]),('far',[5,6,7])]:
 info=m['eyes'][name];center=np.array(info['iris_center_pixels']);axes=np.array(info['iris_axes_pixels']);theta=info['iris_rotation_radians'];R=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]);outer=outer_map[name];amplitude=.0012 if name=='near'else .0008
 def bump(Q):
  pixels=np.c_[400+(Q[:,0]+.07)*800/.23,400-(Q[:,1]-.816)*800/.23];q=(pixels-center)@R/axes;rho2=np.sum(q*q,axis=1)/(1.20**2);height=amplitude*np.maximum(1-rho2,0)**3;dist=np.full(len(Q),np.inf)
  for aa,bb in zip(outer,np.roll(outer,-1,axis=0)):
   v=bb-aa;t=np.clip((Q[:,:2]-aa)@v/(v@v),0,1);dist=np.minimum(dist,np.linalg.norm(Q[:,:2]-aa-t[:,None]*v,axis=1))
  fade=np.clip(dist/.0025,0,1);fade=fade*fade*(3-2*fade);return height*fade
 rows=[]
 for pi in pis:
  p=j['meshes'][0]['primitives'][pi];P=a(p['attributes']['POSITION'])*scale+translation;N=a(p['attributes']['NORMAL']);delta=bump(P);grad=np.zeros_like(P);h=1e-6
  for axis in [0,1]:
   shift=np.zeros(3);shift[axis]=h;grad[:,axis]=(bump(P+shift)-bump(P-shift))/(2*h)
  Q=P.copy();Q[:,2]+=delta;NN=N-grad*N[:,2,None];NN/=np.linalg.norm(NN,axis=1)[:,None];F=a(p['indices']).reshape(-1,3);oldCross=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);newCross=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]]);dot=np.sum(oldCross*newCross,axis=1)/(np.linalg.norm(oldCross,axis=1)*np.linalg.norm(newCross,axis=1));assert dot.min()>.5;assert np.array_equal(Q[:,:2],P[:,:2]);assert delta.max()<=amplitude+1e-12
  for key,val in [('POSITION',((Q-translation)/scale).astype(np.float32)),('NORMAL',NN.astype(np.float32))]:p['attributes'][key],b=append_accessor(j,b,val,'VEC3',34962)
  rows.append({'primitive':pi,'max_rise_m':float(delta.max()),'moved_vertices':int((delta>1e-8).sum()),'minimum_old_new_geometric_normal_dot':float(dot.min())})
 reports[name]=rows
out=r/'models/scarlett_15_corneal_curvature_trial.glb';write_glb(out,j,b);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'amplitude_limits_m':{'near':.0012,'far':.0008},'eyes':reports,'method':'Compact iris-centered corneal rise, faded to zero over2.5mm at the held outer skin perimeter. The same global-Z scalar field is applied to globe, skin and contact strips; XY contours/gaze/UVs remain fixed and contact separation is preserved. Normals use the exact displacement Jacobian.','all_topology_UVs_materials_maps_and_rest_of_character_held':True,'status':'Unapproved optical-shape trial. Fresh source/eye crossings and exact front/profile/under PBR/clay contact checks required. This is not a claimed anatomical cornea baseline.'};(r/'checks/scarlett_15_corneal_curvature_trial.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
