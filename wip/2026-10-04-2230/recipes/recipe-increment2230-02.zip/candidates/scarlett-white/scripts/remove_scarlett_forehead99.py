"""Bounded three-face forehead overlap trial after joint dense backing checks."""
import pathlib,json,hashlib,collections,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_10_native4k_orbital_albedo.glb';sha=hashlib.sha256(src.read_bytes()).hexdigest();targets=[85184,51820,51821];proofs=[]
for rawid in targets:
 path=r/'checks'/f'scarlett94_raw{rawid}_support.json';q=json.loads(path.read_text());assert q['sha256']==sha and q['candidate_raw_face']==rawid and q['jointly_excluded_raw_faces']==targets
 for o in q['observations']:
  c=o['counts']['all'];assert c['n']==c['first_hit_front_with_ties']==c['front_backing_within_5mm']==3321 and c['foreground_occluded']==0
  assert all(v['raw_face']>=0 and v['raw_face']not in targets for v in o['backing_faces'])
 proofs.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'maximum_backing_mm':max(o['nearest_front_backing_min_median_max_mm'][-1]for o in q['observations'])})
j,b,a=read_glb(src);sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];SF=sa(sp['indices']).reshape(-1,3);raw=np.load(r/'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids'];lookup={tuple(map(int,f)):int(raw[i])for i,f in enumerate(SF)};sourceP=sa(sp['attributes']['POSITION']);W,iv=np.unique(sourceP,axis=0,return_inverse=True);before=[];after=[];removed=[];removedfaces=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 if p['attributes']['POSITION']!=sp['attributes']['POSITION']:continue
 F=a(p['indices']).reshape(-1,3);ids=np.array([lookup.get(tuple(map(int,f)),-1)for f in F]);keep=~np.isin(ids,targets);before.extend(F.tolist());after.extend(F[keep].tolist())
 if not keep.all():
  removed.extend([{'raw_face':int(ids[k]),'primitive':pi,'face':int(k)}for k in np.flatnonzero(~keep)]);removedfaces.extend(F[~keep].tolist());p['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
assert sorted(q['raw_face']for q in removed)==sorted(targets)
def incidence(faces):return collections.Counter(tuple(sorted((int(u),int(v))))for f in iv[np.array(faces)]for u,v in zip(f,np.roll(f,-1)))
oldcount,newcount=incidence(before),incidence(after);touched={tuple(sorted((int(u),int(v))))for f in iv[np.array(removedfaces)]for u,v in zip(f,np.roll(f,-1))};edges=[{'position_ids':list(e),'before':oldcount[e],'after':newcount[e]}for e in sorted(touched)]
out=r/'models/scarlett_17_forehead_overlap_trial.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);report={'source':str(src),'source_sha256':sha,'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_faces':removed,'triangles':sum(len(aa(p['indices']))//3 for p in jj['meshes'][0]['primitives']),'attributes_materials_images_held':True,'source_edge_incidence':edges,'joint_support_reports':proofs,'status':'Internal supported three-face overlap trial. Actual matched forehead/head and alternate-angle appearance pending; no whole-character clearance.'};(r/'checks/scarlett_17_forehead_overlap_trial.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
