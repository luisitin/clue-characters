"""Actual GLB audit of both optical fields against all retained nearby surfaces."""
import pathlib,json,hashlib,sys,numpy as np
from scipy.spatial import cKDTree
from glb_io import read_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_16_optical_axis_trial.glb';old=r/'models/scarlett_15_corneal_curvature_trial.glb';j,b,a=read_glb(src);oj,ob,oa=read_glb(old);changed={8,9,10};pr=j['meshes'][0]['primitives'];sc=np.array(j['nodes'][0]['scale']);tr=np.array(j['nodes'][0]['translation']);P=[];F=[]
assert j['materials']==oj['materials']and j['images']==oj['images']
for k,p in enumerate(pr):
    P.append(a(p['attributes']['POSITION'])*sc+tr);F.append(a(p['indices']).reshape(-1,3));op=oj['meshes'][0]['primitives'][k];assert np.array_equal(a(p['indices']),oa(op['indices']))
    for key,ai in p['attributes'].items():
        if k not in changed or key not in ['POSITION','NORMAL']:assert np.array_equal(a(ai),oa(op['attributes'][key]))
patch=np.concatenate([P[k][F[k]]for k in sorted(changed)]);lo=patch.min((0,1))-1e-6;hi=patch.max((0,1))+1e-6;parts=[];provenance=[]
for k in range(len(pr)):
    if k in changed:continue
    T=P[k][F[k]];ids=np.flatnonzero(np.all(T.max(1)>=lo,axis=1)&np.all(T.min(1)<=hi,axis=1));parts.append(T[ids]);provenance.extend([[k,int(i)]for i in ids])
source_count=sum(len(q)for q in parts)
for k in sorted(changed):parts.append(P[k][F[k]]);provenance.extend([[k,int(i)]for i in range(len(F[k]))])
alltri=np.concatenate(parts);W,iv=np.unique(alltri.reshape(-1,3),axis=0,return_inverse=True);T=iv.reshape(-1,3);original=W.copy();parent=np.arange(len(W))
def root(i):
    while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
    return i
for u,v in cKDTree(W).query_pairs(2e-7,output_type='ndarray'):
    u,v=root(int(u)),root(int(v));parent[max(u,v)]=min(u,v)
for i in range(len(W)):parent[i]=root(i)
W=W[parent];snap=float(np.linalg.norm(W-original,axis=1).max());assert snap<2.01e-7;contacts={}
for name,(skin,cap,wall)in {'far':(5,6,7),'near':(8,9,10)}.items():
    gap=cKDTree(np.vstack([P[skin],P[cap]])).query(P[wall])[0];assert gap.max()<2e-7;contacts[name]=float(gap.max())
helper=r.parent/'mustard/v5_rebuild/scripts/audit_intersections_v4.py';dep=helper.parent/'exact_triangle_pair.py';sys.path.append(str(helper.parent));code=helper.read_text().replace('from glb_io import GLB\n','').replace('selected=np.arange(len(T))','selected=np.arange(SOURCE_COUNT,len(T))');ns={'__name__':'scarlett16_optics_audit','__file__':str(helper),'SOURCE_COUNT':source_count};exec(compile(code,str(helper),'exec'),ns);print({'source_faces':source_count,'changed_faces':len(patch),'audit_only_snap_m':snap},flush=True);result=ns['audit'](W,T,tol=1e-8);report={'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'baseline_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'changed_primitives':sorted(changed),'source_region_triangles':source_count,'changed_triangles':len(patch),'audit_only_max_snap_m':snap,'contact_vertex_gaps_m':contacts,'topology_UVs_materials_images_and_other_attributes_held':True,'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'exact_predicate_sha256':hashlib.sha256(dep.read_bytes()).hexdigest(),'proper_crossings':result['proper_crossings'],'positive_area_coplanar_pairs':result['positive_area_coplanar_pairs'],'new_full_face_copies':[q for q in result['position_triangle_copy_groups']if max(q)>=source_count],'new_zero_area_faces':[q for q in result['zero_area_faces']if q>=source_count],'status':'Actual-file optical geometry audit only; exact lighting/profile/under appearance remains required.'};(r/'checks/scarlett_16_optics_v4.json').write_text(json.dumps(report,indent=2));(r/'checks/scarlett_16_optics_v4_full.json').write_text(json.dumps(result,indent=2));np.savez_compressed(r/'checks/scarlett_16_optics_v4_geometry.npz',P=W,T=T,provenance=provenance,source_count=source_count);print({k:len(report[k])for k in ['proper_crossings','positive_area_coplanar_pairs','new_full_face_copies','new_zero_area_faces']},flush=True)
