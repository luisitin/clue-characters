"""Bounded optical-axis study derived from the registered pupil offset.
The gaze proxy uses an orthographic forward eye axis and fitted effective radius;
it is an artistic fitting hypothesis, not a claimed anatomical reconstruction.
"""
import pathlib,json,hashlib,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_15_corneal_curvature_trial.glb';j,b,a=read_glb(src);m=json.loads((r/'checks/scarlett_13_paired_eye_albedo_trial.json').read_text());far=np.load(r/'checks/scarlett_far_patch45.npz');near=np.load(r/'checks/scarlett_near_patch72.npz');outer_map={'far':far['skin_positions_world'][far['outer_vertex_ids'],:2],'near':near['near_positions'][near['near_outer_vertex_ids'],:2]};center_map={'far':far['cap_positions_world'][far['aperture_vertex_ids'],:2].mean(0),'near':near['near_cap_positions'][near['near_aperture_vertex_ids'],:2].mean(0)};far.close();near.close();sc=np.array(j['nodes'][0]['scale']);tr=np.array(j['nodes'][0]['translation']);reports={}
for name,pis,radius in [('near',[8,9,10],.03129444177)]:
    info=m['eyes'][name];pc=np.array(info['pupil_center_pixels']);pcw=np.array([-.07+(pc[0]-400)*.23/800,.816-(pc[1]-400)*.23/800]);axes=np.array(info['iris_axes_pixels']);theta=info['iris_rotation_radians'];R=np.array([[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]);outer=outer_map[name];cap=j['meshes'][0]['primitives'][pis[1]];P=a(cap['attributes']['POSITION'])*sc+tr;N=a(cap['attributes']['NORMAL']);F=a(cap['indices']).reshape(-1,3);T=P[F];v1=T[:,1,:2]-T[:,0,:2];v2=T[:,2,:2]-T[:,0,:2];den=v1[:,0]*v2[:,1]-v1[:,1]*v2[:,0];h=pcw-T[:,0,:2];u=np.divide(h[:,0]*v2[:,1]-h[:,1]*v2[:,0],den,out=np.full(len(F),-1.),where=abs(den)>1e-15);v=np.divide(v1[:,0]*h[:,1]-v1[:,1]*h[:,0],den,out=np.full(len(F),-1.),where=abs(den)>1e-15);ids=np.flatnonzero((u>=-1e-8)&(v>=-1e-8)&(u+v<=1+1e-8));assert len(ids);fi=int(ids[0]);normal=np.array([1-u[fi]-v[fi],u[fi],v[fi]])@N[F[fi]];normal/=np.linalg.norm(normal);assert normal[2]>.2;xy=(pcw-center_map[name])/radius;assert xy@xy<.8;desired=np.r_[xy,np.sqrt(1-xy@xy)];gradient=(-desired[:2]/desired[2])-(-normal[:2]/normal[2]);assert np.linalg.norm(gradient)<.6,(name,'Gaze-proxy tilt exceeds bounded study',gradient)
    def field(Q):
        pix=np.c_[400+(Q[:,0]+.07)*800/.23,400-(Q[:,1]-.816)*800/.23];local=(pix-pc)@R/axes/1.2;window=np.maximum(1-np.sum(local*local,axis=1),0)**3;distance=np.full(len(Q),np.inf)
        for aa,bb in zip(outer,np.roll(outer,-1,axis=0)):
            d=bb-aa;t=np.clip((Q[:,:2]-aa)@d/(d@d),0,1);distance=np.minimum(distance,np.linalg.norm(Q[:,:2]-aa-t[:,None]*d,axis=1))
        fade=np.clip(distance/.0025,0,1);fade=fade*fade*(3-2*fade);return ((Q[:,:2]-pcw)@gradient)*window*fade
    rows=[]
    for pi in pis:
        p=j['meshes'][0]['primitives'][pi];P=a(p['attributes']['POSITION'])*sc+tr;N=a(p['attributes']['NORMAL']);delta=field(P);grad=np.zeros_like(P)
        for axis in [0,1]:
            step=np.zeros(3);step[axis]=1e-6;grad[:,axis]=(field(P+step)-field(P-step))/2e-6
        Q=P.copy();Q[:,2]+=delta;NN=N-grad*N[:,2,None];NN/=np.linalg.norm(NN,axis=1)[:,None];F=a(p['indices']).reshape(-1,3);oc=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);nc=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]]);dot=np.sum(oc*nc,axis=1)/(np.linalg.norm(oc,axis=1)*np.linalg.norm(nc,axis=1));assert dot.min()>.5 and abs(delta).max()<.002;assert np.array_equal(Q[:,:2],P[:,:2])
        for key,val in [('POSITION',((Q-tr)/sc).astype(np.float32)),('NORMAL',NN.astype(np.float32))]:p['attributes'][key],b=append_accessor(j,b,val,'VEC3',34962)
        rows.append({'primitive':pi,'depth_delta_min_max_m':[float(delta.min()),float(delta.max())],'minimum_old_new_geometric_normal_dot':float(dot.min())})
    reports[name]={'pupil_world_xy':pcw.tolist(),'effective_radius_m':radius,'old_pupil_normal':normal.tolist(),'gaze_proxy_normal':desired.tolist(),'added_depth_gradient':gradient.tolist(),'components':rows}
out=r/'models/scarlett_16_optical_axis_trial.glb';write_glb(out,j,b);rep={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'eyes':reports,'all_XY_contours_UVs_materials_and_outer_source_perimeters_held':True,'rejected_prior_hypothesis':'Combined96 stopped before export because the far-eye gaze proxy required gradient0.867, above the0.6 bound. This97 trial changes only the near eye within the original bound.','status':'Unapproved near-only optical-axis fitting hypothesis. Fresh exact crossings and actual image/profile checks required; no character clearance.'};(r/'checks/scarlett_16_optical_axis_trial.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
