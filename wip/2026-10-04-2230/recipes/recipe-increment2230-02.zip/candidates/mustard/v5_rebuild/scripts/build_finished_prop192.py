"""Held14mm contact shaft with explicit turned brass ends and baked walnut material.
Canonical grip coordinates; no changes to the held hand or body. End placement uses
original cap ray-bracket centers through the measured rigid registration150.
"""
from pathlib import Path
import numpy as np,json,hashlib
from scipy.interpolate import PchipInterpolator
from scipy.ndimage import gaussian_filter
from PIL import Image
from glb_io import GLB
D=Path(__file__).resolve().parents[1];r=json.loads((D/'audit/grip179.json').read_text());reg=json.loads((D/'audit/grip150_registration.json').read_text());A=np.array(r['shaft_axis']);C=np.array(r['shaft_center']);Areg=np.array(reg['shaft_axis']);Creg=np.array(reg['shaft_center']);caps={x['role']:float((np.array(x['ray_bracket_midpoint'])-Creg)@Areg) for x in reg['cap_ray_brackets']};bottom=caps['baton bottom gold cap'];top=caps['baton top gold cap'];woodlo=bottom+.015;woodhi=top-.017;radius=.014;assert woodhi-woodlo>.40
U=np.array([1.,0,0]);U-=U@A*A;U/=np.linalg.norm(U);V=np.cross(A,U);M=128
# Profiles advance outwards from each neck. Dense sampling preserves the small turned details.
xT=np.array([0,.002,.005,.007,.010,.013,.017,.022,.027,.031]);rT=np.array([.014,.0148,.0148,.019,.0202,.0202,.0195,.017,.011,0]);
xB=np.array([0,.002,.005,.008,.012,.016,.020,.023]);rB=np.array([.014,.0155,.0155,.0175,.0182,.0182,.014,0]);
fT=PchipInterpolator(xT,rT);fB=PchipInterpolator(xB,rB);bt=np.unique(np.r_[np.linspace(0,xB[-1],49),xB]);tt=np.unique(np.r_[np.linspace(0,xT[-1],65),xT]);wood=np.linspace(woodlo,woodhi,81)
# (axial position, radius, dr/dt, region). Pole endpoints have explicit axial normals.
profile=[(woodlo-x,float(fB(x)),float(-fB.derivative()(x)),1) for x in bt[::-1]]+[(float(t),radius,0.,0) for t in wood[1:-1]]+[(woodhi+x,float(fT(x)),float(fT.derivative()(x)),1) for x in tt]
angles=np.arange(M+1)*2*np.pi/M;rad=np.cos(angles)[:,None]*U+np.sin(angles)[:,None]*V;rad[-1]=rad[0];circ=-np.sin(angles)[:,None]*U+np.cos(angles)[:,None]*V;circ[-1]=circ[0];P=[];N=[];UV=[];TAN=[];rings=[]
for i,(t,rr,dr,region) in enumerate(profile):
 if i in (0,len(profile)-1):
  assert abs(rr)<1e-12;rings.append([len(P)]);P.append(C+t*A);N.append((-1 if i==0 else 1)*A);UV.append([.5,0 if i==0 else 1]);TAN.append([*U,1]);continue
 normal=rad-dr*A;normal/=np.linalg.norm(normal,axis=1,keepdims=True);ring=list(range(len(P),len(P)+M+1));rings.append(ring);P.extend(C+t*A+rr*rad);N.extend(normal);UV.extend(np.column_stack((np.linspace(0,1,M+1),np.full(M+1,(t-woodlo)/(woodhi-woodlo)))));TAN.extend(np.column_stack((circ,-np.ones(M+1))))
triangles=[];mats=[]
for i in range(len(rings)-1):
 a,b=rings[i],rings[i+1];mid=(profile[i][0]+profile[i+1][0])/2;material=0 if woodlo<=mid<=woodhi else 1
 if len(a)==1:
  for k in range(M):triangles.append([a[0],b[k+1],b[k]]);mats.append(material)
 elif len(b)==1:
  for k in range(M):triangles.append([a[k],a[k+1],b[0]]);mats.append(material)
 else:
  for k in range(M):triangles.extend([[a[k],a[k+1],b[k+1]],[a[k],b[k+1],b[k]]]);mats.extend([material,material])
P=np.array(P);N=np.array(N);UV=np.array(UV);TAN=np.array(TAN);T=np.array(triangles,'u4');mats=np.array(mats);gn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);area=np.linalg.norm(gn,axis=1);dot=np.sum(gn*N[T].mean(1),axis=1);assert area.min()>1e-14 and dot.min()>0,(area.min(),dot.min());assert np.abs(np.sum(N*TAN[:,:3],axis=1)).max()<1e-12
# Bake the generated wood input into a periodic circumferential field. Sampling is
# mirrored, so the analytic field is continuous at both U seam ends. No baked light.
source=D/'textures/Mustard_Walnut_Albedo_Source_v1.png';image=np.asarray(Image.open(source).convert('RGB'),dtype='f8')/255;res=2048;h,w=image.shape[:2];u=(np.arange(res)+.5)/res;v=(np.arange(res)+.5)/res
su=1-np.abs(2*u-1);sv=1-np.abs(2*(v*.63+.10)%2-1);xx=su*(w-1);yy=sv*(h-1);x0=np.floor(xx).astype(int);y0=np.floor(yy).astype(int);x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1);fx=xx-x0;fy=yy-y0
rgb=(image[y0[:,None],x0[None,:]]*(1-fx)[None,:,None]+image[y0[:,None],x1[None,:]]*fx[None,:,None])*(1-fy)[:,None,None]+(image[y1[:,None],x0[None,:]]*(1-fx)[None,:,None]+image[y1[:,None],x1[None,:]]*fx[None,:,None])*fy[:,None,None]
lum=rgb@np.array([.2126,.7152,.0722]);grain=gaussian_filter(lum,1)-gaussian_filter(lum,8);height=grain*.000035;dy,dx=np.gradient(height,(woodhi-woodlo)/res,2*np.pi*radius/res);normal=np.stack((-dx,+dy,np.ones_like(dx)),axis=2);normal/=np.linalg.norm(normal,axis=2,keepdims=True);rough=np.clip(.34+grain*.7,.27,.42);orm=np.stack((np.ones_like(rough),rough,np.zeros_like(rough)),axis=2);maps={}
for name,array in [('base',rgb),('normal',normal*.5+.5),('orm',orm)]:
 p=D/f'textures/Mustard_Walnut_{name}_2048_v192.png';Image.fromarray(np.rint(np.clip(array,0,1)*255).astype('u1')).save(p);maps[name]=p
G=object.__new__(GLB);G.bin=bytearray();G.j={'asset':{'version':'2.0','generator':'Mustard turned contact-preserving prop192'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'images':[],'textures':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':33071}],'materials':[],'nodes':[{'mesh':0,'name':'Mustard walnut baton with turned brass ends192'}],'meshes':[],'scenes':[{'nodes':[0]}],'scene':0};textures={}
for name,p in maps.items():
 data=p.read_bytes();G.bin.extend(b'\0'*((-len(G.bin))%4));offset=len(G.bin);G.bin.extend(data);vi=len(G.j['bufferViews']);G.j['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(data)});ii=len(G.j['images']);G.j['images'].append({'name':p.stem,'bufferView':vi,'mimeType':'image/png'});ti=len(G.j['textures']);G.j['textures'].append({'source':ii,'sampler':0});textures[name]=ti
G.j['materials']=[{'name':'Axial walnut varnish192','pbrMetallicRoughness':{'baseColorTexture':{'index':textures['base']},'metallicFactor':0,'roughnessFactor':1,'metallicRoughnessTexture':{'index':textures['orm']}},'normalTexture':{'index':textures['normal'],'scale':1},'occlusionTexture':{'index':textures['orm']},'doubleSided':False},{'name':'Turned warm brass192','pbrMetallicRoughness':{'baseColorFactor':[.74,.43,.13,1],'metallicFactor':1,'roughnessFactor':.29},'doubleSided':False}]
rawP=(P[:,[0,2,1]]*[1,1,-1]).astype('f4');rawN=(N[:,[0,2,1]]*[1,1,-1]).astype('f4');rawT=TAN.astype('f4');rawT[:,:3]=(TAN[:,:3][:,[0,2,1]]*[1,1,-1]).astype('f4');attr={'POSITION':G.append(rawP,'VEC3',5126,34962),'NORMAL':G.append(rawN,'VEC3',5126,34962),'TEXCOORD_0':G.append(UV.astype('f4'),'VEC2',5126,34962),'TANGENT':G.append(rawT,'VEC4',5126,34962)};G.j['meshes']=[{'primitives':[{'attributes':attr,'indices':G.append(T[mats==i].ravel(),'SCALAR',5125,34963),'material':i,'mode':4} for i in (0,1)]}];out=D/'inputs/finished_prop192.glb';sha=G.save(out)
hand=GLB(D/'inputs/grip179.glb');HP,HT,HN,HU=hand.native();handt=(HP-C)@A;caps_gap=min(float(handt.min()-woodlo),float(woodhi-handt.max()));assert caps_gap>.04
report={'output_sha256':sha,'held_contact_hand_sha256':hand.sha256,'contact_radius_m':radius,'wood_axial_range':[woodlo,woodhi],'hand_axial_range':[float(handt.min()),float(handt.max())],'caps_axial_separation_from_entire_hand_m':caps_gap,'cap_center_parameters':caps,'triangles':len(T),'wood_triangles':int((mats==0).sum()),'brass_triangles':int((mats==1).sum()),'minimum_double_area':float(area.min()),'normal_tangent_dot_max':float(np.abs(np.sum(N*TAN[:,:3],axis=1)).max()),'source_albedo_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'map_hashes':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in maps.items()},'normal_basis':'Native tangent points circumferentially; native bitangent is -axis because raw glTF UV V increases along axis. PNG row derivative therefore contributes +Y in the tangent normal map.','scope':'First material/turned-cap candidate.14mm contact cylinder retained; end caps are axially separated from the entire hand. Exact exported topology/self, physical contact and actual macro/all-angle appearance remain mandatory.'};(D/'audit/finished_prop192.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
