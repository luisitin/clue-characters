import argparse,json,hashlib,time
from pathlib import Path
import numpy as np
from PIL import Image
from uv_raster import samples
from hand_skin_fields28 import SkinFields
D=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['base','aux'],required=True);ap.add_argument('--row',type=int,required=True);args=ap.parse_args();res=4096 if args.mode=='base' else 2048;row0=args.row;row1=min(row0+1024,res)
z=np.load(D/'inputs/grip179_paint_binding185.npz');a={k:z[k] for k in z.files};zt=np.load(D/'inputs/grip179_tangent_basis186.npz');basis={k:zt[k] for k in zt.files};T=a['T'];tr=a['UV_CORNER_PACKED'].astype('f8');Rtri=a['REST'][T];RNtri=a['REST_N'][T];Ptri=a['P'][T];Ntri=a['N'][T];TB=basis['T_NATIVE'];SB=basis['SIGN_NATIVE'];assert np.all(SB==SB[:,0,None])
E=(Ptri[:,1:]-Ptri[:,:1]).transpose(0,2,1);ER=(Rtri[:,1:]-Rtri[:,:1]).transpose(0,2,1);gram=np.einsum('nji,njk->nik',E,E);J=ER@np.linalg.inv(gram)@E.transpose(0,2,1)
fields=SkinFields(json.loads((D/'audit/grip179.json').read_text()));valid=np.zeros((row1-row0,res),'u1');out=np.zeros((row1-row0,res,3),'u1');orm=np.zeros_like(out) if args.mode=='aux' else None;start=time.time();buffers=[];count=0;nail_pixels=0
def flush():
    global buffers,count,nail_pixels
    if not buffers:return
    fi=np.concatenate([b[0] for b in buffers]);y=np.concatenate([b[1] for b in buffers]);x=np.concatenate([b[2] for b in buffers]);bary=np.concatenate([b[3] for b in buffers]);R=np.einsum('ni,nij->nj',bary,Rtri[fi]);RN=np.einsum('ni,nij->nj',bary,RNtri[fi]);RN/=np.linalg.norm(RN,axis=1,keepdims=True)
    C,H,rough,nail=fields.material(R,RN,color=args.mode=='base');nail_pixels+=int(np.count_nonzero(nail>.5))
    if args.mode=='base':out[y,x]=np.rint(C*255).astype('u1')
    else:
        PN=np.einsum('ni,nij->nj',bary,Ntri[fi]);PN/=np.linalg.norm(PN,axis=1,keepdims=True);tt=np.einsum('ni,nij->nj',bary,TB[fi]);tt-=np.sum(tt*PN,axis=1,keepdims=True)*PN;tt/=np.linalg.norm(tt,axis=1,keepdims=True);bb=np.cross(PN,tt)*SB[fi,0,None]
        grad=np.empty_like(R);eps=.0007
        for axis in range(3):
            delta=np.zeros(3);delta[axis]=eps;hp=fields.material(R+delta,RN,color=False)[1];hm=fields.material(R-delta,RN,color=False)[1];grad[:,axis]=(hp-hm)/(2*eps)
        gp=np.einsum('ni,nij->nj',grad,J[fi]);nx=-np.sum(gp*tt,axis=1);ny=-np.sum(gp*bb,axis=1);nn=np.column_stack((nx,ny,np.ones(len(nx))));nn/=np.linalg.norm(nn,axis=1,keepdims=True);out[y,x]=np.rint(np.clip(nn*.5+.5,0,1)*255).astype('u1')
        orm[y,x,0]=255;orm[y,x,1]=np.rint(rough*255).astype('u1');orm[y,x,2]=0
    assert not np.any(valid[y,x]);valid[y,x]=1;buffers=[];count=0
for fi,y,x,bary in samples(tr,res,row0,row1):
    buffers.append((np.full(len(y),fi,'i4'),y,x,bary));count+=len(y)
    if count>=32768:flush()
flush();folder=D/'textures/grip187_tiles';folder.mkdir(exist_ok=True)
outputs={}
for key,array in [('base' if args.mode=='base' else 'normal',out),('orm',orm),('valid_'+args.mode,valid*255)]:
    if array is None:continue
    path=folder/f'{key}_{row0}.png';Image.fromarray(array).save(path);outputs[key]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
report={'mode':args.mode,'row0':row0,'row1':row1,'resolution':res,'occupied':int(valid.sum()),'nail_pixels_over_half':nail_pixels,'outputs':outputs,'seconds':time.time()-start,'normal_basis':'Native Blender Mikk tangent+signed bitangent on held posed surface; scalar rest-height gradient pulled through each exact triangle Jacobian.'}
(folder/f'{args.mode}_{row0}.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
