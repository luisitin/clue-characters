"""Bind unchanged actual09 GLB vertices to the same modifier stack in rest pose."""
import bpy,sys,json,hashlib
from pathlib import Path
from mathutils import Matrix
import numpy as np
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2];sys.path.insert(0,str(D/'scripts'))
from glb_io import GLB
sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'));from load_donor import load_donor
g=GLB(D/'inputs/grip179.glb');P,T,N,UVnative=g.native();UV=g.read(g.primitive()['attributes']['TEXCOORD_0']).astype('f4')
bpy.ops.wm.open_mainfile(filepath=str(D/'native/grip179.blend'))
ob=next(o for o in bpy.data.objects if o.type=='MESH');arm=next(o for o in bpy.data.objects if o.type=='ARMATURE')
def evaluate():
    bpy.context.view_layer.update();dg=bpy.context.evaluated_depsgraph_get();ev=ob.evaluated_get(dg);m=ev.to_mesh();m.calc_loop_triangles()
    p=np.empty((len(m.vertices),3),'f4');m.vertices.foreach_get('co',p.ravel())
    li=np.empty(len(m.loops),'i4');m.loops.foreach_get('vertex_index',li)
    uv=np.empty((len(m.loops),2),'f4');m.uv_layers.active.data.foreach_get('uv',uv.ravel())
    cn=np.array([x.vector[:] for x in m.corner_normals],dtype='f4')
    tri=np.array([x.vertices[:] for x in m.loop_triangles]);out=(p,li,uv,cn,tri);ev.to_mesh_clear();return out
posed,li,uv,cn,tri=evaluate()
for pb in arm.pose.bones:pb.matrix_basis=Matrix.Identity(4)
arm.update_tag(refresh={'OBJECT'});rest,rli,ruv,rcn,rtri=evaluate()
rest_pose_delta=np.linalg.norm(rest-posed,axis=1);assert rest_pose_delta.max()>.05,rest_pose_delta.max()
assert np.array_equal(li,rli) and np.array_equal(uv,ruv)
uvexport=uv.copy();uvexport[:,1]=1-uvexport[:,1]
lookup={};ambiguous=0
for k,vi in enumerate(li):
    key=posed[vi].tobytes()+uvexport[k].tobytes()
    if key in lookup:
        old=lookup[key];assert np.array_equal(rest[li[old]],rest[vi]);ambiguous+=1
    else:lookup[key]=k
binding=[];fallback_errors=[]
keys=np.column_stack((posed[li],uvexport))
for i,(p,u) in enumerate(zip(P.astype('f4'),UV)):
    key=p.tobytes()+u.tobytes();k=lookup.get(key)
    if k is None:
        error=np.abs(keys-np.r_[p,u]);cost=error.max(axis=1);k=int(np.argmin(cost));assert cost[k]<1.2e-7,(i,float(cost[k]));fallback_errors.append(float(cost[k]))
    binding.append(k)
binding=np.array(binding);restworld=rest[li[binding]].astype('f8');restNworld=rcn[binding].astype('f8')
report09=json.loads((D/'audit/grip179.json').read_text());a=load_donor();side=report09['donor_side'];wrist=a['joint_positions'][f'wrist.{side}____head']
F=np.array(report09['world_forward']);S=np.array([0.,0.,1.]);S-=S@F*F;S/=np.linalg.norm(S);BN=np.cross(F,S)
R=np.column_stack((F,S,BN))@np.column_stack((report09['native_forward'],report09['native_thumbward'],report09['native_basis_normal'])).T
restnative=(restworld-report09['world_anchor'])@R/report09['scale']+wrist
restNnative=restNworld@R;restNnative/=np.linalg.norm(restNnative,axis=1,keepdims=True)
uv_unique,uv_inv=np.unique(UV,axis=0,return_inverse=True);parent=np.arange(len(uv_unique))
def find(x):
    while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
    return x
for tr in uv_inv[T]:
    root=find(tr[0])
    for x in tr[1:]:parent[find(x)]=root
labels=np.array([find(x) for x in uv_inv]);roots,labels=np.unique(labels,return_inverse=True)
islands=[]
for label in range(len(roots)):
    mask=labels==label;ts=np.all(mask[T],axis=1);assert not np.any(np.any(mask[T],axis=1)^ts)
    islands.append({'id':label,'vertices':int(mask.sum()),'triangles':int(ts.sum()),'uv_min':UV[mask].min(axis=0).astype(float).tolist(),'uv_max':UV[mask].max(axis=0).astype(float).tolist(),'rest_min':restnative[mask].min(axis=0).tolist(),'rest_max':restnative[mask].max(axis=0).tolist()})
np.savez_compressed(D/'inputs/grip179_paint_binding183.npz',P=P,T=T,N=N,UV=UV,REST=restnative,REST_N=restNnative,ISLAND=labels)
report={'rest_pose_delta_quantiles_m':np.quantile(rest_pose_delta,[0,.5,.95,1]).tolist(),'all_bone_basis_identity_after_reset':all(np.max(np.abs(np.array(pb.matrix_basis)-np.eye(4)))<1e-7 for pb in arm.pose.bones),'source_sha256':g.sha256,'donor_side':side,'polygon_loop_indices_and_native_corner_UV_same_between_pose_and_rest':True,'triangulation_same_between_pose_and_rest':bool(np.array_equal(tri,rtri)),'exported_vertices':len(P),'triangles':len(T),'exact_position_UV_keys':len(P)-len(fallback_errors),'sub_float32_roundoff_fallback_count':len(fallback_errors),'max_fallback_component_error':max(fallback_errors,default=0),'repeated_corner_keys_with_exact_same_rest_position':ambiguous,'islands':islands,'scope':'Paint binding only. Held179 GLB is unchanged; atlas overlap/texel coverage still pending.'}
(D/'audit/grip179_paint_binding183.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
