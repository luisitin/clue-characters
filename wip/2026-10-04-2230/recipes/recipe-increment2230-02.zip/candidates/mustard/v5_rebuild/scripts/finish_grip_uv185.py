"""Only unsampled faces receive small, individually padded charts in empty atlas space."""
from pathlib import Path
import numpy as np,json
from uv_raster import audit
D=Path(__file__).resolve().parents[1];z=np.load(D/'inputs/grip179_paint_binding184.npz');a={k:z[k] for k in z.files};T=a['T'];tr=a['UV_PACKED'][T].astype('f8')
old2=json.loads((D/'audit/grip179_uv184.json').read_text());old4,counts=audit(tr,4096)
missing=sorted(set(old2['faces_without_strict_interior_texel_center']+old4['missing_faces']))
assert len(missing)<=620,len(missing)
for k,fi in enumerate(missing):
    col=k%4;row=k//4;origin=np.array([1972+col*14,20+row*14]);tr[fi]=(origin+np.array([[3.,3.],[11.,3.],[3.,11.]]))/2048
assert tr.max()<1 and tr.min()>0
new2,f2=audit(tr,2048);new4,f4=audit(tr,4096)
assert new2['multiply_covered_texels']==new4['multiply_covered_texels']==0
assert len(new2['missing_faces'])==len(new4['missing_faces'])==0,(new2['missing_faces'],new4['missing_faces'])
a['UV_CORNER_PACKED']=tr.astype('f4');a['MICRO_CHART_FACES']=np.array(missing,'i4');np.savez_compressed(D/'inputs/grip179_paint_binding185.npz',**a)
report={'source_hand':'grip179.glb','source_pack':'grip179_paint_binding184.npz','initial_4K':old4,'isolated_source_faces':missing,'new_2K':new2,'new_4K':new4,'held_geometry_pose_normals':True,'held_native_rest_coordinates':True,'note':'Only tiny faces lacking sample centers at2K or4K moved into explicitly empty right-margin cells. Native charts for all other faces are affine-held.'}
(D/'audit/grip179_uv185.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
