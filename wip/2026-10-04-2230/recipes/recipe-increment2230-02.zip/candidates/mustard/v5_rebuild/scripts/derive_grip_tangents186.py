"""Explicit native Mikk basis, checked against original Blender-exported tangent signs."""
import bpy,sys,json
from pathlib import Path
import numpy as np
D=Path(__file__).resolve().parents[1];sys.path.insert(0,str(D/'scripts'));from glb_io import GLB
g=GLB(D/'inputs/grip179.glb');P,T,N,UV=g.native();rawT=g.read(g.primitive()['attributes']['TANGENT']);oldTB=rawT[:,:3][:,[0,2,1]]*[1,-1,1]
z=np.load(D/'inputs/grip179_paint_binding185.npz');a={k:z[k] for k in z.files};packed=a['UV_CORNER_PACKED'].astype('f8');packed[:,:,1]=1-packed[:,:,1]
bpy.ops.wm.read_factory_settings(use_empty=True);m=bpy.data.meshes.new('Held hand tangent derivation');m.from_pydata(P.tolist(),[],T.tolist());m.update()
m.polygons.foreach_set('use_smooth',np.ones(len(T),bool));m.normals_split_custom_set(N[T].reshape(-1,3).tolist())
layer=m.uv_layers.new(name='ProofUV')
def basis(uv):
    m.uv_layers['ProofUV'].data.foreach_set('uv',(uv[T] if uv.ndim==2 else uv).reshape(-1).astype('f4'));m.update();m.calc_tangents(uvmap='ProofUV')
    tb=np.empty((len(m.loops),3),'f4');sg=np.empty(len(m.loops),'f4');m.loops.foreach_get('tangent',tb.ravel());m.loops.foreach_get('bitangent_sign',sg)
    return tb.reshape(-1,3,3).astype('f8'),sg.reshape(-1,3)
print('BASIS old',flush=True);oldT,oldS=basis(UV);target=oldTB[T];cos=np.sum(oldT*target,axis=2)/np.maximum(np.linalg.norm(oldT,axis=2)*np.linalg.norm(target,axis=2),1e-30)
ratios,ratio_counts=np.unique(rawT[T,3]/oldS,return_counts=True)
print('BASIS packed',flush=True);newT,newS=basis(packed);CN=N[T];newT-=np.sum(newT*CN,axis=2,keepdims=True)*CN
length=np.linalg.norm(newT,axis=2,keepdims=True);assert length.min()>1e-7;newT/=length
# Determine native->glTF tangent sign on an unambiguous unit plane.
print('BASIS canonical plane',flush=True);plane=bpy.data.meshes.new('Canonical tangent convention plane');plane.from_pydata([(0,0,0),(1,0,0),(1,1,0),(0,1,0)],[],[(0,1,2,3)]);plane.update()
puv=plane.uv_layers.new(name='Canonical UV')
for k,val in enumerate([(0,0),(1,0),(1,1),(0,1)]):puv.data[k].uv=val
plane.calc_tangents(uvmap='Canonical UV');native_plane_sign=[x.bitangent_sign for x in plane.loops];native_plane_t=[list(x.tangent) for x in plane.loops]
po=bpy.data.objects.new('Canonical plane',plane);bpy.context.collection.objects.link(po);po.select_set(True);bpy.context.view_layer.objects.active=po
plane_path=D/'audit/canonical_tangent_plane186.glb'
bpy.ops.export_scene.gltf(filepath=str(plane_path),export_format='GLB',use_selection=True,export_normals=True,export_texcoords=True,export_tangents=True)
pg=GLB(plane_path);pt=pg.read(pg.primitive()['attributes']['TANGENT']);factor=float(pt[0,3]/native_plane_sign[0]);assert factor in (-1,1)
assert np.all(pt[:,3]==native_plane_sign[0]*factor);assert np.max(np.abs(pt[:,:3]-[1,0,0]))<1e-7
np.savez_compressed(D/'inputs/grip179_tangent_basis186.npz',T_NATIVE=newT,SIGN_NATIVE=newS,TANGENT_W_GLTF_FACTOR=np.array([factor]))
report={'source_sha256':g.sha256,'canonical_plane_native_to_glTF_w_factor':factor,'old_hand_w_ratios':ratios.tolist(),'old_hand_w_ratio_counts':ratio_counts.tolist(),'canonical_plane_native_T':native_plane_t,'canonical_plane_native_sign':native_plane_sign,'source_Mikk_vs_export_angle_degrees_quantiles':np.degrees(np.arccos(np.clip(np.quantile(cos,[0,.01,.5,1]),-1,1))).tolist(),'new_native_T_dot_N_max':float(np.abs(np.sum(newT*CN,axis=2)).max()),'new_native_T_length_error':float(np.abs(np.linalg.norm(newT,axis=2)-1).max()),'scope':'Packed chart native Blender tangent basis. Sign conversion is measured on the canonical plane; old hand tangent deviations are reported rather than copied into new chart tangents.'}
(D/'audit/grip179_tangent_basis186.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
