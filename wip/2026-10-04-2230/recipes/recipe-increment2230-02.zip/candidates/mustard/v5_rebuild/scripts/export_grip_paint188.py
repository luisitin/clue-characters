"""Assemble deterministic PBR tiles and replace only atlas/material/tangents of held hand09."""
import json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
from glb_io import GLB
D=Path(__file__).resolve().parents[1];folder=D/'textures/grip187_tiles';maps={};summaries={}
for name,res,validname in [('base',4096,'base'),('normal',2048,'aux'),('orm',2048,'aux')]:
    rows=list(range(0,res,1024));array=np.concatenate([np.asarray(Image.open(folder/f'{name}_{row}.png')) for row in rows]);valid=np.concatenate([np.asarray(Image.open(folder/f'valid_{validname}_{row}.png'))>0 for row in rows]);assert array.shape==(res,res,3)
    indices=distance_transform_edt(~valid,return_distances=False,return_indices=True);array[~valid]=array[indices[0][~valid],indices[1][~valid]];del indices
    path=D/f'textures/Mustard_Grip_{name}_{res}_v188.png';Image.fromarray(array).save(path);maps[name]=path;summaries[name]={'resolution':res,'occupied':int(valid.sum()),'padded':int((~valid).sum()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    del array,valid
g=GLB(D/'inputs/grip179.glb');pr=g.primitive();oldat=pr['attributes'];oldT=g.read(pr['indices']).reshape(-1,3);oldP=g.read(oldat['POSITION'],False);oldN=g.read(oldat['NORMAL'],False);oldbin=bytes(g.bin)
z=np.load(D/'inputs/grip179_paint_binding185.npz');UV=z['UV_CORNER_PACKED'];zt=np.load(D/'inputs/grip179_tangent_basis186.npz');TB=zt['T_NATIVE'];sign=zt['SIGN_NATIVE']*float(zt['TANGENT_W_GLTF_FACTOR'][0]);tg=TB[:,:,[0,2,1]]*[1,1,-1]
tg4=np.concatenate((tg,sign[:,:,None]),axis=2).astype('f4');records=np.concatenate((oldP[oldT],oldN[oldT],UV,tg4),axis=2).reshape(-1,12).astype('f4');keys=records.view('V48').ravel();_,first,inv=np.unique(keys,return_index=True,return_inverse=True);r=records[first]
pr['attributes']={'POSITION':g.append(r[:,:3],'VEC3',5126,34962),'NORMAL':g.append(r[:,3:6],'VEC3',5126,34962),'TEXCOORD_0':g.append(r[:,6:8],'VEC2',5126,34962),'TANGENT':g.append(r[:,8:12],'VEC4',5126,34962)};pr['indices']=g.append(inv.astype('u4'),'SCALAR',5125,34963)
g.j.setdefault('images',[]);g.j.setdefault('textures',[]);g.j.setdefault('samplers',[]);sampler=len(g.j['samplers']);g.j['samplers'].append({'magFilter':9729,'minFilter':9987,'wrapS':33071,'wrapT':33071});textures={}
for name,path in maps.items():
    data=path.read_bytes();g.bin.extend(b'\0'*((-len(g.bin))%4));offset=len(g.bin);g.bin.extend(data);vi=len(g.j['bufferViews']);g.j['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(data)});ii=len(g.j['images']);g.j['images'].append({'name':path.stem,'bufferView':vi,'mimeType':'image/png'});ti=len(g.j['textures']);g.j['textures'].append({'source':ii,'sampler':sampler});textures[name]=ti
material={'name':'Mustard mature skin and seated native nail beds188','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'baseColorTexture':{'index':textures['base']},'metallicFactor':0,'roughnessFactor':1,'metallicRoughnessTexture':{'index':textures['orm']}},'normalTexture':{'index':textures['normal'],'scale':1},'occlusionTexture':{'index':textures['orm'],'strength':1},'doubleSided':False};mi=len(g.j['materials']);g.j['materials'].append(material);pr['material']=mi
output=D/'inputs/grip_painted188.glb';sha=g.save(output);v=GLB(output);vp=v.primitive();vt=v.read(vp['indices']).reshape(-1,3)
assert np.array_equal(v.read(vp['attributes']['POSITION'],False)[vt],oldP[oldT]);assert np.array_equal(v.read(vp['attributes']['NORMAL'],False)[vt],oldN[oldT]);assert np.array_equal(v.read(vp['attributes']['TEXCOORD_0'],False)[vt],UV)
assert bytes(g.bin[:len(oldbin)])==oldbin
N=v.read(vp['attributes']['NORMAL']);TT=v.read(vp['attributes']['TANGENT']);unit=np.linalg.norm(TT[:,:3],axis=1);dot=np.sum(N*TT[:,:3],axis=1);assert np.max(np.abs(unit-1))<2e-6 and np.max(np.abs(dot))<2e-6;assert set(TT[:,3])<=set([-1.,1.])
report={'source_hand_sha256':GLB(D/'inputs/grip179.glb').sha256,'output_sha256':sha,'triangles':len(oldT),'exported_vertices':len(r),'geometry_and_normals_exact_by_ordered_triangle_corner':True,'packed_UV_exact_by_ordered_triangle_corner':True,'source_BIN_prefix_byte_identical':True,'tangent_max_unit_error':float(np.max(np.abs(unit-1))),'tangent_max_dot_N':float(np.max(np.abs(dot))),'maps':summaries,'normal_basis':'Native Mikk on posed surface, native-rest scalar material fields; canonical exporter w factor+1.','nails':'Albedo/roughness and shallow height on existing distal skin nail beds; no added plate meshes.','scope':'First material candidate. Actual unlit/PBR/top/under and cuff/complete assembly gates pending.'}
(D/'audit/grip_painted188.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
