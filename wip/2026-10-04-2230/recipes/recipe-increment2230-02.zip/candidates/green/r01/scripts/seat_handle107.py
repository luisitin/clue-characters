"""Seat the rigid handle under gravity using complete mesh distance with a positive safety gap."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_grip_clearance106.py').read_text();prefix=code[:code.index('assert len(objects)==2')];exec(compile(prefix,'load_exact_grip105','exec'));body=code[code.index('assert len(objects)==2'):code.index("rep={'source_sha256'")];exec('def measure(objects):\n'+''.join(' '+line+'\n'for line in body.splitlines())+' return best,where,vf,tested\n')
from glb_source import write_glb
base=[tuple(x.copy()for x in item)for item in objects];d,where,_,_=measure(base);shift=0.;rows=[{'shift_down_m':shift,'minimum_clearance_m':d}];target=.000152
for step in range(20):
 if d<=.00017:break
 move=min(.6*d,d-target);assert move>0 and move<d-1e-6;oldD=d;shift+=move;assert shift<.005
 posed=[base[0],(base[1][0]-np.array([0.,0.,shift]),base[1][1],base[1][2])];d,where,vf,tested=measure(posed);assert d>=oldD-move-2e-7;rows.append({'shift_down_m':shift,'minimum_clearance_m':d});print({'step':step+1,**rows[-1]},flush=True)
assert target-2e-7<=d<=.00017,(shift,d)
path=R/'Green_handle103.glb';hj,hb,H=read_glb(path);node=next(n for n in hj['nodes']if'mesh'in n);assert not node.get('matrix')and not node.get('translation');node['translation']=[0.,-shift,0.];out=R/'Green_handle107_seated.glb';write_glb(out,hj,hb);report={'source_assembly_sha256':sha,'source_handle_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'candidate_handle_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'rigid_blender_world_translation':[0.,0.,-shift],'all_handle_local_attributes_indices_UV_materials_exact':True,'minimum_clearance_m':d,'steps':rows,'closest_feature':where,'disjoint_path_argument':'Every translation step is strictly shorter than the preceding complete mesh clearance, preserving disjointness along the rigid path. A fresh exact merged V4 and actual view follow.','status':'Unadopted gravity seating; case/character placement remains separate.'};(R/'audit/handle107_seating.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
