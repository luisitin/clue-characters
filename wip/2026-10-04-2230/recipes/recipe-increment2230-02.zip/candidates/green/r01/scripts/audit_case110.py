"""Audit every newly constructed case part with exact raw transforms and ownership labels."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
from glb_source import read_glb
from intersection_kernel_v4 import audit
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_case108.glb';j,b,A=read_glb(src);P=[];F=[];N=[];owners=[];names=[];offset=0;volumes=[]
for ni,node in enumerate(j['nodes']):
 assert not node.get('children'),'Flat node transform audit only'
 if'mesh'not in node:continue
 names.append(node.get('name',str(ni)));M=np.eye(4)
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 volume=0
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  p=A(pr['attributes']['POSITION']).astype('float32').astype(float);p=(p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];n=A(pr['attributes']['NORMAL']).astype(float);n=n@np.linalg.inv(M[:3,:3]);n=n[:,[0,2,1]]*[1,-1,1];f=A(pr['indices']).reshape(-1,3);used=np.unique(f);assert np.isfinite(n[used]).all();N.append(n[used]);P.append(p);F.append(f+offset);offset+=len(p);owners.extend([node.get('name',str(ni))]*len(f));volume+=np.sum(p[f[:,0]]*np.cross(p[f[:,1]],p[f[:,2]]))/6
 volumes.append({'name':node.get('name',str(ni)),'signed_volume_m3':float(volume)})
P=np.vstack(P);F=np.vstack(F);N=np.vstack(N);owners=np.array(owners);report=audit(P,F)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in report[key]:row['parts']=owners[row['faces']].tolist()
report.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),part_volumes=volumes,referenced_zero_normals=int((np.linalg.norm(N,axis=1)<1e-6).sum()),referenced_max_normal_unit_error=float(abs(np.linalg.norm(N,axis=1)-1).max()),scope='Whole constructed case, all parts and their exact transforms. Hardware contact/appearance and hand/handle assembly remain separate.');(R/'audit/case110_surface_v4.json').write_text(json.dumps(report,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in report.items()},flush=True)
