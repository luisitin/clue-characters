"""Reproduce only the native rig to measure joint centers; no mesh is rebuilt or edited."""
import bpy,pathlib,sys,json,numpy as np,math
from mathutils import Vector,Quaternion
R=pathlib.Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
D=load_donor();V=D['positions'];F=D['faces'];G=D['face_group'];J={g:V[np.unique(np.concatenate([F[i]for i in np.flatnonzero(G==g)]))].mean(0)for g in np.unique(G)if g.startswith('joint-l-')};z=np.load(R/'audit/grip88_binding.npz');B=z['native_basis'];OB=z['world_basis'];scale=z['scale'];anchor=z['anchor'];rep=json.loads((R/'audit/grip88.json').read_text());angles={int(k):v for k,v in rep['angles_degrees'].items()};wrist=J['joint-l-hand'];bpy.ops.wm.read_factory_settings(use_empty=True);rd=bpy.data.armatures.new('Diagnostic rig');rig=bpy.data.objects.new('Diagnostic rig',rd);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT');palm=rd.edit_bones.new('palm');palm.head=(0,0,0);palm.tail=(.95,0,0)
for fi in range(1,6):
 parent=palm
 for k in range(1,4):
  bn=rd.edit_bones.new(f'finger{fi}_{k}');bn.head=Vector(B@(J[f'joint-l-finger-{fi}-{k}']-wrist));bn.tail=Vector(B@(J[f'joint-l-finger-{fi}-{k+1}']-wrist));bn.parent=parent;bn.use_connect=k>1;parent=bn
bpy.ops.object.mode_set(mode='OBJECT')
for fi in range(1,6):
 for k,degree in enumerate(angles[fi],1):
  pb=rig.pose.bones[f'finger{fi}_{k}'];rest=rd.bones[pb.name];axis=(rest.tail_local-rest.head_local).normalized().cross(Vector((0,1,0))).normalized();pb.rotation_mode='QUATERNION';pb.rotation_quaternion=Quaternion(rest.matrix_local.to_3x3().inverted()@axis,math.radians(degree));assert tuple(pb.scale)==(1.,1.,1.)
bpy.context.view_layer.update();points={};circles=[]
for fi in range(1,6):
 q=np.array([rig.pose.bones[f'finger{fi}_1'].head[:]]+[rig.pose.bones[f'finger{fi}_{k}'].tail[:]for k in range(1,4)]);world=anchor+(q*scale)@OB.T;points[str(fi)]=world.tolist()
 if fi>1:
  x=world[0:3][:,[0,2]];coef=np.linalg.solve(np.column_stack([2*x,np.ones(3)]),np.sum(x*x,axis=1));center=coef[:2];rad=np.sqrt(coef[2]+center@center);circles.append({'finger':fi,'center_world_xz':center.tolist(),'radius_m':float(rad)})
out={'source_hand':'Green_grip88.glb','angles_degrees':angles,'finger_joint_world_positions':points,'three_joint_circle_fits_xz':circles,'scope':'Exact reconstruction of the documented unit-scale FK bone matrices. Circle centers are handle-fit initial guesses, not a collision or contact proof.'};(R/'audit/grip_fk89.json').write_text(json.dumps(out,indent=2));print(out,flush=True)
