"""Structured two-shell leather attache, seated handle plates and articulated catches."""
import bpy,pathlib,json,math,hashlib,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];bpy.ops.wm.read_factory_settings(use_empty=True)
seat=json.loads((R/'audit/handle107_seating.json').read_text());shift=-seat['rigid_blender_world_translation'][2];top=-.285-shift-.003;xc=.375;split=xc-.025;yc=.065;w=.42;h=.29;zc=top-h/2;objects=[]
def mat(name,col,rough,metal=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*col,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal;return m
leather=mat('Black leather shell study',(.014,.013,.012),.44);trim=mat('Sewn leather piping study',(.021,.019,.017),.38);steel=mat('Satin nickel hardware study',(.47,.46,.43),.27,.85);rubber=mat('Dark underside feet',(.008,.008,.007),.7)
def mesh(name,V,F,material,smoothFaces=None,UV=None,Normals=None):
 me=bpy.data.meshes.new(name);me.from_pydata(np.asarray(V).tolist(),[],F);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);me.materials.append(material)
 if smoothFaces is not None:
  for p,s in zip(me.polygons,smoothFaces):p.use_smooth=bool(s)
 if UV is not None:
  layer=me.uv_layers.new(name='Construction UV')
  for p,coords in zip(me.polygons,UV):
   for li,q in zip(p.loop_indices,coords):layer.data[li].uv=q
 if Normals is not None:me.normals_split_custom_set(np.asarray(Normals)[[l.vertex_index for l in me.loops]].tolist())
 objects.append(o);return o
def outline(ww,hh,r,steps=16):
 coords=[];normals=[]
 for cy,cz,a in [(ww/2-r,hh/2-r,0),(-ww/2+r,hh/2-r,np.pi/2),(-ww/2+r,-hh/2+r,np.pi),(ww/2-r,-hh/2+r,3*np.pi/2)]:
  for t in np.linspace(a,a+np.pi/2,steps+1):coords.append([cy+r*np.cos(t),cz+r*np.sin(t)]);normals.append([np.cos(t),np.sin(t)])
 return np.array(coords),np.array(normals)
def shell(name,x0,x1,mirror=False):
 r=.013;prof=[(x0,.003),(x0+.000228,.001852),(x0+.000879,.000879),(x0+.001852,.000228),(x0+.003,0),(x1-.001,0),(x1-.000617,.000076),(x1-.000293,.000293),(x1-.000076,.000617),(x1,.001)];V=[];F=[];S=[];U=[];Normals=[];n=68
 phi=np.linspace(0,np.pi/2,5);normalProfile=[(-np.cos(t),np.sin(t))for t in phi]+[(np.sin(t),np.cos(t))for t in phi]
 if mirror:normalProfile=[(-a,b)for a,b in reversed(normalProfile)]
 if mirror:prof=[(x0+x1-xx,off)for xx,off in reversed(prof)]
 for (xx,inset),(nx,nr) in zip(prof,normalProfile):
  q,norm=outline(w-2*inset,h-2*inset,r-inset);V.extend(np.column_stack([np.full(n,xx),q[:,0]+yc,q[:,1]+zc]));Normals.extend(np.column_stack([np.full(n,nx),norm[:,0]*nr,norm[:,1]*nr]))
 for row in range(len(prof)-1):
  for k in range(n):a=row*n+k;b=row*n+(k+1)%n;c=(row+1)*n+(k+1)%n;d=(row+1)*n+k;F.extend([[a,b,c],[a,c,d]]);S.extend([True,True]);U.extend([[[k/n,row/20],[(k+1)/n,row/20],[(k+1)/n,(row+1)/20]],[[k/n,row/20],[(k+1)/n,(row+1)/20],[k/n,(row+1)/20]]])
 for end in [0,1]:
  row=0 if end==0 else len(prof)-1;base=len(V);ring=np.array(V[row*n:(row+1)*n]);V.extend(ring);Normals.extend([[(-1 if end==0 else 1),0,0]]*n);center=len(V);V.append([prof[row][0],yc,zc]);Normals.append([(-1 if end==0 else 1),0,0]);uvring=np.column_stack([.02+.44*(ring[:,1]-yc+w/2)/w,.52+.46*(ring[:,2]-zc+h/2)/h]);uvring[:,0]+=.50*end
  for k in range(n):
   order=[(k+1)%n,k]if end==0 else[k,(k+1)%n];F.append([center,base+order[0],base+order[1]]);S.append(False);U.append([[.24+.5*end,.75],uvring[order[0]].tolist(),uvring[order[1]].tolist()])
 return mesh(name,V,F,leather,S,U,Normals)
# A narrow physical seam separates the rigid shells.
shell('Front opening shell',xc-.05,split-.00035);shell('Rear opening shell',split+.00035,xc+.05,mirror=True)
# Separate rounded piping stays just outside the leather face, without clipping it.
for side in [-1,1]:
 q,norm=outline(w-.010,h-.010,.008);rr=.00095;xx=xc+side*(.05+rr+.00008);V=[];F=[];Normals=[];nu=16
 for (y,z),(ny,nz)in zip(q,norm):
  for k in range(nu):t=2*np.pi*k/nu;V.append([xx+rr*np.cos(t),yc+y+rr*np.sin(t)*ny,zc+z+rr*np.sin(t)*nz]);Normals.append([np.cos(t),np.sin(t)*ny,np.sin(t)*nz])
 for i in range(len(q)):
  for k in range(nu):a=i*nu+k;b=i*nu+(k+1)%nu;c=((i+1)%len(q))*nu+(k+1)%nu;d=((i+1)%len(q))*nu+k;F.extend([[a,b,c],[a,c,d]])
 mesh(('Front'if side<0 else'Rear')+' stitched piping',V,F,trim,[True]*len(F),Normals=Normals)
def box(name,center,dimensions,material,bevel=.0006):
 bpy.ops.mesh.primitive_cube_add(size=1,location=center);o=bpy.context.object;o.name=name;o.dimensions=dimensions;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
 if bevel:
  b=o.modifiers.new('Small physical edge rounding','BEVEL');b.width=bevel;b.segments=4;b.harden_normals=True;bpy.ops.object.modifier_apply(modifier=b.name)
 for p in o.data.polygons:p.use_smooth=True
 wn=o.modifiers.new('Weighted metal panel normals','WEIGHTED_NORMAL');wn.keep_sharp=True;wn.weight=50;bpy.ops.object.modifier_apply(modifier=wn.name);objects.append(o);return o
def pin(name,center,radius,length,axis='Z'):
 bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=radius,depth=length,location=center);o=bpy.context.object;o.name=name
 if axis=='Y':o.rotation_euler[0]=np.pi/2
 o.data.materials.append(steel)
 for p in o.data.polygons:p.use_smooth=len(p.vertices)==4
 objects.append(o);return o
for i,y in enumerate([-.025,.155]):
 box(f'Handle mounting plate {i+1}',[xc,y,top+.0015],[.019,.025,.0028],steel,.001)
 for s in [-1,1]:pin(f'Handle plate screw {i+1} {s}',[xc,y+s*.009,top+.0035],.0016,.001)
for i,y in enumerate([yc-.153,yc+.153]):
 for label,x in [('lid',split-.0105),('base',split+.0105)]:box(f'Catch {i+1} {label} seat',[x,y,top+.0009],[.019,.024,.0016],steel,.0005)
 pin(f'Catch {i+1} hinge axle',[split-.009,y,top+.0034],.0015,.019,'Y')
 box(f'Catch {i+1} bridge lever',[split+.00379,y,top+.0038],[.02242,.014,.0018],steel,.0005)
 box(f'Catch {i+1} locking toe',[split+.0135,y,top+.0023],[.006,.010,.0011],steel,.0003)
# Two restrained hinges on the lower seam provide the counterpart to the catches.
for i,y in enumerate([yc-.125,yc+.125]):
 box(f'Bottom hinge lid leaf {i+1}',[split-.0105,y,top-h-.0009],[.020,.025,.0016],steel,.0005)
 box(f'Bottom hinge base leaf {i+1}',[split+.0105,y,top-h-.0009],[.020,.025,.0016],steel,.0005)
 pin(f'Bottom hinge axle {i+1}',[split,y,top-h-.0028],.001,.028,'Y')
for i,y in enumerate([yc-.155,yc+.155]):
 for side in [-1,1]:box(f'Protective case foot {i+1} {side}',[xc+side*.033,y,top-h-.0025],[.023,.030,.0046],rubber,.0015)
bpy.ops.object.select_all(action='SELECT');bpy.context.view_layer.update();triangles=0
for o in objects:o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles)
out=R/'Green_case108.glb';assert not out.exists(),'Immutable case108 target exists';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',export_yup=True,export_tangents=False,export_animations=False,export_cameras=False,export_lights=False);report={'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles_native':triangles,'objects':len(objects),'case_dimensions_xyz_m':[.100,.420,.290],'shell_opening_gap_m':.0007,'opening_plane_x_m':split,'handle_mounts_on_single_rear_shell':True,'handle_mount_top_m':top+.0029,'held_handle_foot_height_m':-.285-shift,'handle_foot_to_plate_gap_m':.0001,'status':'Unadopted case construction study. Leather/fabric maps, local hardware intersections, actual front/back/top/under and reference placement remain pending.'};(R/'audit/case108.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
