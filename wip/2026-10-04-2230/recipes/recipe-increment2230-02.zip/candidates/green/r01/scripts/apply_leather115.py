"""Apply intentional repeating leather PBR with physically scaled UVs and native Mikk tangents."""
import bpy,pathlib,sys,json,hashlib,copy,numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
args=sys.argv[sys.argv.index('--')+1:];mode=args[0];src=R/('Green_case108.glb'if mode=='case'else'Green_handle107_seated.glb');out=R/('Green_case115_pbr.glb'if mode=='case'else'Green_handle115_pbr.glb');j,buf,A=read_glb(src);old=copy.deepcopy(j);oldbuf=bytes(buf);j.setdefault('images',[]);j.setdefault('textures',[]);j.setdefault('samplers',[]);sampler=len(j['samplers']);j['samplers'].append({'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':10497});tex={}
for kind in ['BaseColor','Normal','ORM']:
 p=R/'textures'/f'Green_Leather114_{kind}_2K.png';data=p.read_bytes();buf=bytes(buf)+b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(data)});buf+=data;ii=len(j['images']);j['images'].append({'name':p.name,'mimeType':'image/png','bufferView':vi});ti=len(j['textures']);j['textures'].append({'source':ii,'sampler':sampler});tex[kind]=ti
leatherMats=[]
for mi,mat in enumerate(j['materials']):
 if'leather'not in mat.get('name','').lower():continue
 leatherMats.append(mi);piping='piping'in mat['name'].lower();factor=1. if piping else(.8 if mode=='handle'else .85);rough=.94 if piping else(.9 if mode=='handle'else 1.);mat['name']=mat['name'].replace('study','PBR115');mat['pbrMetallicRoughness']={'baseColorFactor':[factor]*3+[1.],'baseColorTexture':{'index':tex['BaseColor']},'metallicFactor':0.,'roughnessFactor':rough,'metallicRoughnessTexture':{'index':tex['ORM']}};mat['normalTexture']={'index':tex['Normal'],'scale':.1 if piping else(.35 if mode=='handle'else .55)};mat['occlusionTexture']={'index':tex['ORM']}
def outline(ww,hh,r):
 q=[];nn=[]
 for cy,cz,a in [(ww/2-r,hh/2-r,0),(-ww/2+r,hh/2-r,np.pi/2),(-ww/2+r,-hh/2+r,np.pi),(ww/2-r,-hh/2+r,3*np.pi/2)]:
  for t in np.linspace(a,a+np.pi/2,17):q.append([cy+r*np.cos(t),cz+r*np.sin(t)]);nn.append([np.cos(t),np.sin(t)])
 return np.array(q),np.array(nn)
q,nq=outline(.42,.29,.013);arc=np.r_[0,np.cumsum(np.linalg.norm(np.roll(q,-1,axis=0)-q,axis=1))];cycles=round(arc[-1]/.04);top=json.loads((R/'audit/case108.json').read_text())['held_handle_foot_height_m']-.003;zc=top-.145;pipeq,pipen=outline(.41,.28,.008);pa=np.r_[0,np.cumsum(np.linalg.norm(np.roll(pipeq,-1,axis=0)-pipeq,axis=1))];pipeCycles=round(pa[-1]/.04);records=[]
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 assert not node.get('children');M=np.eye(4)
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  if pr['material']not in leatherMats:continue
  P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']).astype('float32');F=A(pr['indices']).reshape(-1,3);CP=P[F];CN=N[F];W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];name=node.get('name','');uv=np.empty((len(F),3,2),float)
  if mode=='handle':
   oldUV=A(pr['attributes']['TEXCOORD_0'])[F];side=oldUV[:,:,1].mean(1)<.82;curve=np.load(R/'audit/handle103_binding.npz')['centerline_world'];count=round(np.linalg.norm(np.diff(curve,axis=0),axis=1).sum()/.04);uv[side,:,0]=(oldUV[side,:,0]-.02)/.96;uv[side,:,1]=(oldUV[side,:,1]-.02)/.78*count;uv[~side]=np.stack([W[F[~side],0]/.04,-W[F[~side],1]/.04],axis=2)
  elif'piping'in name:
   side=-1 if name.startswith('Front')else 1;xx=.375+side*(.05+.00095+.00008);pv=[];pu=[]
   for i,((y,z),(ny,nz))in enumerate(zip(pipeq,pipen)):
    for k in range(16):t=2*np.pi*k/16;pv.append([xx+.00095*np.cos(t),.065+y+.00095*np.sin(t)*ny,zc+z+.00095*np.sin(t)*nz]);pu.append([pa[i]/pa[-1]*pipeCycles,k/16])
   dist,ix=cKDTree(np.array(pv,dtype='float32')).query(W);assert dist.max()<2e-7;uv=np.array(pu)[ix][F]
   for axis,period in [(0,pipeCycles),(1,1)]:
    wrap=np.ptp(uv[:,:,axis],axis=1)>period/2;vv=uv[wrap,:,axis];vv[vv<period/2]+=period;uv[wrap,:,axis]=vv
  else:
   oldUV=A(pr['attributes']['TEXCOORD_0'])[F];cap=oldUV[:,:,1].mean(1)<.5;uv[cap]=np.stack([W[F[cap],1]/.04,-W[F[cap],2]/.04],axis=2);kk=np.rint(oldUV[~cap,:,0]*68).astype(int);assert np.max(abs(kk-oldUV[~cap,:,0]*68))<1e-4;uv[~cap,:,0]=arc[kk]/arc[-1]*cycles;uv[~cap,:,1]=-W[F[~cap],0]/.04
  uv=uv.astype('float32');area=np.cross(uv[:,1]-uv[:,0],uv[:,2]-uv[:,0]);assert np.min(abs(area))>1e-12
  raw=np.concatenate([CP,CN,uv],axis=2).reshape(-1,8);_,first,inv=np.unique(np.ascontiguousarray(raw).view('V32').ravel(),return_index=True,return_inverse=True);rec=raw[first];ff=inv.reshape(-1,3);PB=rec[:,:3][:,[0,2,1]]*[1,-1,1];NB=rec[:,3:6][:,[0,2,1]]*[1,-1,1];UB=rec[:,6:8].copy();UB[:,1]=1-UB[:,1];me=bpy.data.meshes.new('PBR115 tangent mesh');me.from_pydata(PB.tolist(),[],ff.tolist());me.update();me.polygons.foreach_set('use_smooth',np.ones(len(ff),bool));me.normals_split_custom_set(NB[ff].reshape(-1,3).tolist());layer=me.uv_layers.new(name='Physical leather UV');layer.data.foreach_set('uv',UB[ff].ravel());me.calc_tangents(uvmap=layer.name);T=np.empty((len(me.loops),3),'float32');sg=np.empty(len(me.loops),'float32');me.loops.foreach_get('tangent',T.ravel());me.loops.foreach_get('bitangent_sign',sg);T=T.astype(float);nn=NB[ff].reshape(-1,3).astype(float);T-=nn*np.sum(T*nn,axis=1)[:,None];ln=np.linalg.norm(T,axis=1);assert ln.min()>1e-7;T/=ln[:,None];TG=T[:,[0,2,1]]*[1,1,-1];allrec=np.concatenate([CP.reshape(-1,3),CN.reshape(-1,3),uv.reshape(-1,2),TG,sg[:,None]],axis=1).astype('float32');_,first,inv=np.unique(np.ascontiguousarray(allrec).view('V48').ravel(),return_index=True,return_inverse=True);rr=allrec[first];attrs={}
  for key,sl,kind in [('POSITION',slice(0,3),'VEC3'),('NORMAL',slice(3,6),'VEC3'),('TEXCOORD_0',slice(6,8),'VEC2'),('TANGENT',slice(8,12),'VEC4')]:attrs[key],buf=append_accessor(j,buf,rr[:,sl],kind,34962)
  idx,buf=append_accessor(j,buf,inv.astype('uint32'),'SCALAR',34963);pr['attributes']=attrs;pr['indices']=idx;records.append({'node':ni,'primitive':pi,'name':name,'triangles':len(F),'minimum_uv_double_area':float(abs(area).min()),'tangent_unit_error':float(abs(np.linalg.norm(rr[:,8:11],axis=1)-1).max()),'tangent_dot_normal':float(abs(np.sum(rr[:,8:11]*rr[:,3:6],axis=1)).max())});bpy.data.meshes.remove(me)
write_glb(out,j,buf);jj,bb,B=read_glb(out)
for m0,m1 in zip(old['meshes'],jj['meshes']):
 for p0,p1 in zip(m0['primitives'],m1['primitives']):
  f0=A(p0['indices']).reshape(-1,3);f1=B(p1['indices']).reshape(-1,3)
  for key in ['POSITION','NORMAL']:assert np.array_equal(A(p0['attributes'][key])[f0],B(p1['attributes'][key])[f1])
assert old['nodes']==jj['nodes'];report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_ordered_triangle_POSITION_NORMAL_corners_exact':True,'all_node_transforms_exact':True,'only_leather_UV_tangent_material_bindings_changed':True,'intentional_repeating_material_not_unique_skin_atlas':True,'nominal_tile_size_m':.04,'primitives':records,'status':'PBR material study. Actual seam/scale/normal-basis views are required; geometry contact results carry only through the exact corner/transform proof.'};(R/'audit'/(mode+'115_pbr.json')).write_text(json.dumps(report,indent=2));print(report,flush=True)
