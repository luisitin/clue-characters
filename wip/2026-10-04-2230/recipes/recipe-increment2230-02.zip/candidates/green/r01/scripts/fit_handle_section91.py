"""Measure a smooth finite grip corridor in exact hand sections before constructing a handle."""
import pathlib,json,hashlib,numpy as np
from scipy.optimize import differential_evolution
from scipy.spatial.transform import Rotation
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip88.glb';j,b,A=read_glb(src);node=next(n for n in j['nodes']if'mesh'in n);M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);pr=j['meshes'][node['mesh']]['primitives'][0];P=A(pr['attributes']['POSITION']);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];F=A(pr['indices']).reshape(-1,3);T=P[F];fk=json.loads((R/'audit/grip_fk89.json').read_text());ys=np.array([np.mean(np.array(fk['finger_joint_world_positions'][str(i)])[:3,1])for i in range(2,6)]);cc=np.array([x['center_world_xz']for x in fk['three_joint_circle_fits_xz']]);centerY=float(ys.mean());span=float(np.ptp(ys)/2);xpoly=np.polyfit((ys-centerY)/span,cc[:,0],2);zpoly=np.polyfit((ys-centerY)/span,cc[:,1],2);samplesY=np.linspace(float(ys.min()-.01037),float(ys.max()+.00719),41);tn=(samplesY-centerY)/span;base=np.column_stack([np.polyval(xpoly,tn),np.polyval(zpoly,tn)]);segments=[];owners=[]
for iy,y in enumerate(samplesY):
 d=T[:,:,1]-y;ids=np.flatnonzero((d.min(1)<0)&(d.max(1)>0));count=0
 for fi in ids:
  hits=[]
  for a,b0 in zip(range(3),[1,2,0]):
   if d[fi,a]*d[fi,b0]<0:hits.append(T[fi,a]+d[fi,a]/(d[fi,a]-d[fi,b0])*(T[fi,b0]-T[fi,a]))
  if len(hits)==2:segments.append(np.array(hits)[:,[0,2]]);owners.append(iy);count+=1
 assert count>10
segments=np.array(segments);owners=np.array(owners);aa=segments[:,0];ee=segments[:,1]-aa;ee2=np.sum(ee*ee,axis=1);valid=ee2>1e-20;aa=aa[valid];ee=ee[valid];ee2=ee2[valid];owners=owners[valid]
def centers(v):return base+np.column_stack([v[0]+v[1]*tn,v[2]+v[3]*tn+v[4]*tn*tn])
def clearance(v,details=False):
 c=centers(v);q=c[owners]-aa;t=np.clip(np.sum(q*ee,axis=1)/ee2,0,1);d=np.linalg.norm(q-t[:,None]*ee,axis=1);out=np.full(len(samplesY),np.inf);np.minimum.at(out,owners,d);cross=((aa[:,1]>c[owners,1])!=((aa[:,1]+ee[:,1])>c[owners,1]));ix=aa[:,0]+(c[owners,1]-aa[:,1])*ee[:,0]/np.where(abs(ee[:,1])<1e-20,1.,ee[:,1]);inside=np.bincount(owners,weights=(cross&(ix>c[owners,0])),minlength=len(samplesY)).astype(int)%2;out[inside.astype(bool)]*=-1
 return out if details else-float(out.min())
bounds=[(-.007,.007),(-.003,.003),(-.007,.007),(-.004,.004),(-.003,.003)];res=differential_evolution(clearance,bounds,seed=91,popsize=8,maxiter=55,tol=.0001,polish=True,workers=1);distance=clearance(res.x,True);C=np.column_stack([centers(res.x)[:,0],samplesY,centers(res.x)[:,1]]);np.savez_compressed(R/'audit/handle91_sections.npz',section_y=samplesY,segments_start=aa,segments_delta=ee,segment_section=owners,base_centers=base,t_normalized=tn,parameters=res.x,centerline_world=C)
report={'hand_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'section_count':len(samplesY),'plane_cut_segments':len(aa),'minimum_measured_circle_clearance_m':float(distance.min()),'median_measured_circle_clearance_m':float(np.median(distance)),'circle_clearances_m':distance.tolist(),'centerline_world':C.tolist(),'base_center_y':centerY,'polynomial_y_scale':span,'parameters_m':res.x.tolist(),'evaluations':res.nfev,'status':'Bounded smooth centerline fit against41 exact skin plane sections. This is a handle initial fit, not a continuous 3D tube collision/contact clearance.'};(R/'audit/handle91.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k not in ['centerline_world','circle_clearances_m']},flush=True)
