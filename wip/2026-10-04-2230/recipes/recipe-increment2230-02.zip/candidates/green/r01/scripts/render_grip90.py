import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/render_exact.py').read_text()
code=code.replace("target,scale,angle,elev=regions[tag];","regions['grip_front80']=((.39,.055,-.20),.28,-11,.02)\nregions['grip_palm90']=((.39,.055,-.20),.28,259,.02)\nregions['grip_side80']=((.39,.055,-.20),.28,79,.02)\nregions['grip_opposite80']=((.39,.055,-.20),.28,169,.02)\nregions['grip_under80']=((.39,.055,-.20),.28,-11,-5)\ntarget,scale,angle,elev=regions[tag];")
exec(compile(code,'render_grip80','exec'))
