"""Whole triangle-mesh minimum clearance using vertex/face and edge/edge minima."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_grip_handle105.glb';sha=hashlib.sha256(src.read_bytes()).hexdigest();pre=json.loads((R/'audit/grip_handle105_v4.json').read_text());assert pre['source_sha256']==sha and pre['handle_proper']==0 and pre['handle_coplanar']==0
j,b,A=read_glb(src);objects=[]
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 M=np.eye(4)
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 ps=[];fs=[];off=0
 for pr in j['meshes'][node['mesh']]['primitives']:
  p=A(pr['attributes']['POSITION']).astype('float32').astype(float);p=(p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];ps.append(p);fs.append(A(pr['indices']).reshape(-1,3)+off);off+=len(p)
 p=np.vstack(ps);f=np.vstack(fs);u,g=np.unique(p,axis=0,return_inverse=True);f=g[f];edges=np.unique(np.sort(np.vstack([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1),axis=0);objects.append((u,f,edges))
assert len(objects)==2;best=np.inf;where={};vf=[]
for who in [0,1]:
 p,f,e=objects[who];op,of,oe=objects[1-who];tree=BVHTree.FromPolygons(op.tolist(),of.tolist(),all_triangles=True);ds=[]
 for vi,v in enumerate(p):
  hit,n,fi,d=tree.find_nearest(Vector(v));ds.append(d)
  if d<best:best=float(d);where={'type':'vertex_face','vertex_object':who,'vertex':vi,'face_object':1-who,'face':int(fi),'points':[v.tolist(),list(hit)]}
 vf.append({'object':who,'vertices':len(p),'minimum_m':float(min(ds))})
p0,f0,e0=objects[0];p1,f1,e1=objects[1];a=p0[e0[:,0]];u=p0[e0[:,1]]-a;b0=p1[e1[:,0]];v=p1[e1[:,1]]-b0;c0=a+u/2;c1=b0+v/2;h0=np.linalg.norm(u,axis=1)/2;h1=np.linalg.norm(v,axis=1)/2;tree=cKDTree(c0);tested=0
for i in range(len(e1)):
 ids=np.array(tree.query_ball_point(c1[i],h1[i]+h0.max()+best+1e-10),int)
 if not len(ids):continue
 ids=ids[np.linalg.norm(c0[ids]-c1[i],axis=1)<=h0[ids]+h1[i]+best+1e-10]
 if not len(ids):continue
 aa=a[ids];uu=u[ids];bb=b0[i];vv=v[i];ww=aa-bb;A0=np.sum(uu*uu,axis=1);B0=uu@vv;C0=float(vv@vv);D0=np.sum(uu*ww,axis=1);E0=ww@vv;den=A0*C0-B0*B0;d2=np.full(len(ids),np.inf);param=np.zeros((len(ids),2))
 for s,t in [(np.zeros(len(ids)),np.clip(E0/C0,0,1)),(np.ones(len(ids)),np.clip((E0+B0)/C0,0,1)),(np.clip(-D0/A0,0,1),np.zeros(len(ids))),(np.clip((B0-D0)/A0,0,1),np.ones(len(ids)))]:
  delta=ww+s[:,None]*uu-t[:,None]*vv;dd=np.sum(delta*delta,axis=1);take=dd<d2;d2[take]=dd[take];param[take]=np.column_stack([s,t])[take]
 valid=den>1e-30;s=np.zeros(len(ids));t=np.zeros(len(ids));s[valid]=(B0[valid]*E0[valid]-C0*D0[valid])/den[valid];t[valid]=(A0[valid]*E0[valid]-B0[valid]*D0[valid])/den[valid];valid&=(s>=0)&(s<=1)&(t>=0)&(t<=1);delta=ww+s[:,None]*uu-t[:,None]*vv;dd=np.sum(delta*delta,axis=1);take=valid&(dd<d2);d2[take]=dd[take];param[take]=np.column_stack([s,t])[take];k=int(np.argmin(d2));tested+=len(ids)
 if d2[k]<best*best:best=float(np.sqrt(d2[k]));idx=int(ids[k]);where={'type':'edge_edge','hand_edge':e0[idx].tolist(),'handle_edge':e1[i].tolist(),'points':[(a[idx]+param[k,0]*u[idx]).tolist(),(b0[i]+param[k,1]*v[i]).tolist()]}
rep={'source_sha256':sha,'minimum_mesh_boundary_clearance_m':best,'vertex_face_checks':vf,'candidate_edge_edge_pairs_tested':tested,'closest_feature':where,'scope':'Complete vertex/triangle minima in both directions and all possibly closer finite edge/edge pairs under conservative center-radius pruning. Float64 segment arithmetic and BVH float32 nearest-face distance; V4 separately establishes no crossing. Does not establish perceptual grip or case placement.'};(R/'audit/grip_clearance106.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
