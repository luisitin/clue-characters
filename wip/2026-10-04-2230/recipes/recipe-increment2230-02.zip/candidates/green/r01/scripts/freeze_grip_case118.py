"""Freeze the reproducible grip/case component chain and its unique leather input."""
import pathlib,json,hashlib,ast,datetime
R=pathlib.Path(__file__).resolve().parents[1];ROOT=R.parents[2];out=ROOT/'component_snapshots/green-grip-case-20261004-2210';out.mkdir(parents=True,exist_ok=True)
scripts=['glb_source.py','merge_exact_components.py','run_heavy_stage.sh','build_grip84_neutral.py','build_grip88.py','build_openhand_rest96.py','prepare_grip_paint97.py','export_grip_paint98.py','measure_grip_fk89.py','fit_handle_section91.py','build_handle103.py','audit_grip_handle105.py','audit_grip_clearance106.py','seat_handle107.py','build_case108.py','audit_grip_handle109.py','audit_case110.py','render_exact.py','render_grip90.py','render_case112.py','audit_component_surfaces_v4.py','intersection_kernel_v4.py','intersection_kernel_v4_selected.py','exact_triangle_pair.py','audit_uv_texels.py','audit_grip_transfer104.py','bake_leather_tile114.py','apply_leather115.py','audit_grip_case117.py','freeze_grip_case118.py']
reports=['grip84_neutral.json','grip88.json','openhand_rest96.json','Green_grip88_surface_audit_v4.json','Green_grip88_paint97.json','Green_grip88_paint98.json','Green_grip88_painted98_surface_audit_v4.json','Green_grip88_painted98_uv_2048.json','Green_grip88_painted98_uv_4096.json','grip_fk89.json','handle91.json','handle103.json','grip_handle105_v4.json','grip_clearance106.json','handle107_seating.json','grip_handle107_v4.json','case108.json','case110_surface_v4.json','Green_grip_case111_components.json','leather114_maps.json']
selected=[R/'scripts'/n for n in scripts]+[R/'audit'/n for n in reports]
selected += [R/'textures/painting_plates/Green_case_leather_master113.png',R/'textures/painting_plates/Green_case_leather_master113.json']
for folder,tag in [('grip98','grip_front80_paint'),('grip98','grip_palm90_paint'),('case111','case_context112_paint')]:
 for ext in ['.png','.json']:selected.append(R/'renders'/folder/(tag+ext))
records=[]
for p in selected:
 assert p.is_file(),p
 if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
 rel=p.relative_to(ROOT);dst=out/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes()
 if dst.exists():assert dst.read_bytes()==data
 else:dst.write_bytes(data)
 records.append({'relative_path':str(rel),'snapshot_path':str(dst),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
build=[
 'Restore pinned source, official CC0 MakeHuman donor, and previous green-combined-recipes-20261004-1830 with its1833 build order/camera. The held Green_openhand_thumb3 and Green_openhand_closed27 plus hand_thumb3_uv_islands.npz are required from that chain.',
 'Under one external flock per process, run Blender build_grip84_neutral.py, build_grip88.py and build_openhand_rest96.py independently. These preserve native corner UVs and explicit normalized weights.',
 'Run Python prepare_grip_paint97.py Green_grip88; then Blender export_grip_paint98.py -- Green_grip88. This maps held donor-rest topology and source packed chart corners onto the posed mirrored hand. The source pose vertex set is exact but diagonals change, so run audit_component_surfaces_v4.py Green_grip88_painted98 hand and audit_uv_texels.py at2048 and4096.',
 'Run Blender measure_grip_fk89.py; Python fit_handle_section91.py; Python build_handle103.py. Fit91 is bounded stochastic optimization with its fixed seed. Its saved exact report is included as a replay input if version-dependent optimization differs.',
 'Run Python merge_exact_components.py Green_grip_handle105 Green_grip88_painted98 Green_handle103 using bare stems. Run Python audit_grip_handle105.py and Blender audit_grip_clearance106.py. Then Blender seat_handle107.py computes a bounded disjoint gravity translation.',
 'Run Python merge_exact_components.py Green_grip_handle107 Green_grip88_painted98 Green_handle107_seated; Python audit_grip_handle109.py; Blender build_case108.py; Python audit_case110.py. Then merge_exact_components.py Green_grip_case111 Green_grip88_painted98 Green_handle107_seated Green_case108.',
 'New unique master113 is1254x1254, despite the request for2K; preserve it unchanged. Python bake_leather_tile114.py derives periodic2K maps. Blender apply_leather115.py -- case and -- handle are pending material studies at snapshot time; do not claim their actual appearance or completeness from111.',
 'Every heavy stage uses run_heavy_stage.sh before launch, with OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1, releasing the lock between stages and views.'
]
j={'scope':'Public-safe reproducible Green WIP component increment, separate from current complete character. No approval or full rebuild claim.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'depends_on':['green-combined-recipes-20261004-1830','green_recipe_build_order_20261004_1833.json'],'build_order':build,'component_candidate':{'path':str(R/'Green_grip_case111.glb'),'sha256':'452f00c245e4a92c901e63635eb8dd64e5939d3dfe5b0984d2a88b9bf36a74f4','triangles':81414,'status':'Local component study. Not fitted or integrated to original body. New leather PBR, hardware views, inter-component case contacts, wrist paint seam and complete character finish remain pending.'},'files':records,'total_bytes':sum(x['bytes']for x in records),'verification':'Exact file copies and SHA256, Python AST checks. No clean-room full rebuild performed.'};(out/'MANIFEST.json').write_text(json.dumps(j,indent=2));print(out/'MANIFEST.json');print(len(records),j['total_bytes'])
