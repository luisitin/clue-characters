"""Bind the held skin atlas to a mirrored donor pose through neutral anatomy; no new paint."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial import cKDTree
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];stem=sys.argv[1]if len(sys.argv)>1 else'Green_grip88';DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
D=load_donor();wrist=D['positions'][np.unique(np.concatenate([D['faces'][i]for i in np.flatnonzero(D['face_group']=='joint-l-hand')]))].mean(0)
def obj(name):
 j,b,A=read_glb(R/(name+'.glb'));ps=[];ns=[];us=[];fs=[];off=0
 for pr in j['meshes'][0]['primitives']:
  p=A(pr['attributes']['POSITION']);ps.append(p);ns.append(A(pr['attributes']['NORMAL']));us.append(A(pr['attributes']['TEXCOORD_0']));fs.append(A(pr['indices']).reshape(-1,3)+off);off+=len(p)
 return j,np.vstack(ps),np.vstack(ns),np.vstack(us),np.vstack(fs)
def neutral(name,binding):
 j,p,n,u,f=obj(name);z=np.load(R/'audit'/binding);W=p[:,[0,2,1]]*[1,-1,1];q=(W-z['anchor'])@z['world_basis']/z['scale'];rest=q@z['native_basis']+wrist;mapping={}
 for i,v in enumerate(u.astype('float32')):
  key=v.tobytes()
  if key in mapping:assert np.linalg.norm(rest[mapping[key]]-rest[i])<1e-8
  else:mapping[key]=i
 return u,rest,mapping
ou,oldrest,oldmap=neutral('Green_openhand_rest96','openhand_rest96_binding.npz');nu,newrest,newmap=neutral('Green_grip84_neutral','grip84_neutral_binding.npz');oldJ,oldP,oldN,oldUV,oldF=obj('Green_openhand_thumb3');newJ,newP,newN,newUV,newF=obj(stem);paintJ,paintP,paintN,paintUV,paintF=obj('Green_openhand_closed27')
# Exact point-bound native UVs identify the neutral coordinates on each posed mesh.
oldMissing=[i for i,u in enumerate(oldUV)if u.astype('float32').tobytes()not in oldmap];newMissing=[i for i,u in enumerate(newUV)if u.astype('float32').tobytes()not in newmap];assert not oldMissing and not newMissing,(len(oldMissing),len(newMissing));OR=oldrest[[oldmap[u.astype('float32').tobytes()]for u in oldUV]];NR=newrest[[newmap[u.astype('float32').tobytes()]for u in newUV]]
# Coincident seam records are distinguished using their native UV coordinates.
tree=cKDTree(NR);dist,cand=tree.query(OR,k=64);chosen=[];errors=[];uvErrors=[]
for i,(dd,ids)in enumerate(zip(dist,cand)):
 near=ids[dd<max(float(dd[0])+2e-6,3e-6)];assert len(near)>0
 q=near[np.argmin(np.linalg.norm(newUV[near]-oldUV[i],axis=1))];chosen.append(int(q));errors.append(float(np.linalg.norm(NR[q]-OR[i])));uvErrors.append(float(np.linalg.norm(newUV[q]-oldUV[i])))
chosen=np.array(chosen);print({'rest_error_max':max(errors),'uv_error_percentiles':np.percentile(uvErrors,[50,95,99,100]).tolist(),'worst':[(int(i),oldUV[i].tolist(),newUV[chosen[i]].tolist(),errors[i])for i in np.argsort(uvErrors)[-8:]]},flush=True);assert max(errors)<1e-5,('Rest correspondence exceeds1.1um at this scale',max(errors));labels=np.load(R/'audit/hand_thumb3_uv_islands.npz')['labels'];capLabel=next(k for k in np.unique(labels)if np.sum(labels==k)==78);bodyUV=np.zeros(len(oldUV),bool);bodyUV[np.unique(oldF[labels!=capLabel])]=True;assert np.max(np.array(uvErrors)[bodyUV])<2e-6
# Exact old painted triangle positions preserve microchart corner identity.
def key(points):return tuple(sorted(p.astype('float32').tobytes()for p in points))
table={}
for fi,t in enumerate(paintF):
 k=key(paintP[t]);assert k not in table;table[k]=fi
packed=[]
for t in oldF:
 k=key(oldP[t]);assert k in table;f=paintF[table[k]];lookup={p.astype('float32').tobytes():uv for p,uv in zip(paintP[f],paintUV[f])};packed.append([lookup[p.astype('float32').tobytes()]for p in oldP[t]])
packed=np.array(packed,dtype='float32');cp=newP[chosen[oldF]];cn=newN[chosen[oldF]];gn=np.cross(cp[:,1]-cp[:,0],cp[:,2]-cp[:,0]);dots=np.sum(gn*cn.mean(1),axis=1);flip=bool(np.median(dots)<0)
if flip:cp=cp[:,[0,2,1]];cn=cn[:,[0,2,1]];packed=packed[:,[0,2,1]];dots=-dots
assert (dots<=0).sum()==0,('Oriented triangle disagreement',(dots<=0).sum());oldPoints=np.unique(newP[newF].reshape(-1,3),axis=0);mappedPoints=np.unique(cp.reshape(-1,3),axis=0);assert np.array_equal(oldPoints,mappedPoints),'Pose vertex set changed';np.savez_compressed(R/'audit'/(stem+'_paint97_binding.npz'),corner_positions=cp,corner_normals=cn,corner_uv=packed)
rep={'geometry_source':stem,'geometry_sha256':hashlib.sha256((R/(stem+'.glb')).read_bytes()).hexdigest(),'paint_source_sha256':hashlib.sha256((R/'Green_openhand_closed27.glb').read_bytes()).hexdigest(),'source_native_sha256':hashlib.sha256((R/'Green_openhand_thumb3.glb').read_bytes()).hexdigest(),'triangles':len(cp),'maximum_rest_correspondence_error_native':max(errors),'maximum_visible_native_UV_error':float(np.max(np.array(uvErrors)[bodyUV])),'pose_vertex_POSITION_set_exact':True,'mapped_NORMAL_corners_from_current_pose_exact':True,'painted_packed_UV_corners_exact':True,'fixed_mirror_winding_reversed':flip,'scope':'Reuses the held source triangulation and microchart corners on the exact current pose vertex set; triangle diagonals can differ from the current native export. Exact surface/V4 and painted-view regression are still required.'};(R/'audit'/(stem+'_paint97.json')).write_text(json.dumps(rep,indent=2));print(rep,flush=True)
