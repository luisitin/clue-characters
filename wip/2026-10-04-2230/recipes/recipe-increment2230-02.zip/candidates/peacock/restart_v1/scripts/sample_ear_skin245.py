"""Read healthy nearby skin colors from exact178 geometry and its material UVs.
These are material anchors only. They do not select, delete or classify geometry.
"""
from pathlib import Path
import numpy as np,json,hashlib
from PIL import Image
R=Path(__file__).resolve().parents[1]
def sample(im,uv):
 xy=uv*np.array([im.shape[1],im.shape[0]])-.5;ij=np.floor(xy).astype(int);f=xy-ij;x=np.clip(ij[:,0],0,im.shape[1]-1);y=np.clip(ij[:,1],0,im.shape[0]-1);x1=np.minimum(x+1,im.shape[1]-1);y1=np.minimum(y+1,im.shape[0]-1);fx=f[:,0,None];fy=f[:,1,None]
 return im[y,x]*(1-fx)*(1-fy)+im[y,x1]*fx*(1-fy)+im[y1,x]*(1-fx)*fy+im[y1,x1]*fx*fy
a=np.load(R/'inputs/face_nosepaint178.npz');P,T,U,M=a['pos'],a['tri'],a['uv'],a['material'];a.close();m=json.loads((R/'inputs/face_nosepaint178_materials.json').read_text());q=P[T];xz=q[:,:,[0,2]];e=xz[:,1]-xz[:,0];f=xz[:,2]-xz[:,0];den=e[:,0]*f[:,1]-e[:,1]*f[:,0];valid=den>1e-12;images={};rows=[]
for x,z in [(-.066,.753),(-.056,.738),(-.064,.718),(-.078,.704),(-.092,.704),(-.075,.682)]:
 r=np.array([x,z])-xz[:,0];b=np.zeros(len(T));c=b.copy();b[valid]=(r[valid,0]*f[valid,1]-r[valid,1]*f[valid,0])/den[valid];c[valid]=(e[valid,0]*r[valid,1]-e[valid,1]*r[valid,0])/den[valid];bar=np.column_stack([1-b-c,b,c]);ids=np.where(valid&(bar.min(1)>=-1e-9))[0];yy=np.einsum('ni,ni->n',bar[ids],q[ids,:,1]);fi=int(ids[np.argmin(yy)]);uv=bar[fi]@U[T[fi]];mat=int(M[fi]);colors={}
 for key in ['base_path','orm_path']:
  p=m[mat][key]
  if p not in images:images[p]=np.asarray(Image.open(p).convert('RGB'))
  colors[key]=sample(images[p],uv[None])[0].tolist()
 rows.append({'world_xz':[x,z],'world':(bar[fi]@q[fi]).tolist(),'triangle':fi,'material':mat,'barycentric':bar[fi].tolist(),'uv_png':uv.tolist(),'base_srgb255':colors['base_path'],'orm255':colors['orm_path']})
report={'source_component_sha256':hashlib.sha256((R/'inputs/face_nosepaint178.npz').read_bytes()).hexdigest(),'anchors':rows,'scope':'Exact front-facing source sheet material samples at named nearby skin locations; no geometry mutation or classification.'};(R/'checks/ear_skin_anchors245.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
