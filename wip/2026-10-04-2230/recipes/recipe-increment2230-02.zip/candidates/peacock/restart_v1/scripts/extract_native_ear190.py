"""Topology study of the pinned CC0 ear morph's affected rest-surface domain.
The morph displacement is not applied. A target vertex set is only an anatomical hint.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1];S=R.parents[2]/'shared_sources/makehuman';a=np.load(S/'checks/native_donor.npz');V=a['positions'];U=a['uv'];allF=a['polygon_indices'].reshape(-1,4);allFU=a['polygon_uv_indices'].reshape(-1,4);bodyids=a['body_face_ids'];a.close();target=R/'inputs/sources/l-ear-scale-incr189.target';rows=[x.split() for x in target.read_text().splitlines() if x.strip() and not x.startswith('#')];affected=np.array([int(x[0]) for x in rows]);assert len(set(affected))==len(affected);F=allF[bodyids];FU=allFU[bodyids];valid=np.zeros(len(V),bool);valid[affected]=True;attempts=[];chosen=None
for mode in ['all','any']:
 selected=np.where(np.all(valid[F],axis=1) if mode=='all' else np.any(valid[F],axis=1))[0];quads=F[selected];counts=Counter(tuple(sorted((int(a),int(b)))) for q in quads for a,b in zip(q,np.roll(q,-1)));boundary=[e for e,c in counts.items() if c==1];adj=defaultdict(list)
 for a,b in boundary:adj[a].append(b);adj[b].append(a)
 loops=[];remaining=set(adj)
 while remaining:
  start=min(remaining);loop=[start];previous=None;current=start
  for _ in range(len(adj)+2):
   if len(adj[current])!=2:break
   nxt=adj[current][0] if adj[current][0]!=previous else adj[current][1]
   if nxt==start:break
   if nxt in loop:break
   loop.append(nxt);previous,current=current,nxt
  remaining-=set(loop);loops.append(loop)
 verts=np.unique(quads);chi=len(verts)-len(counts)+len(quads);row={'mode':mode,'quads':len(quads),'vertices':len(verts),'euler_characteristic':chi,'boundary_loops':list(map(len,loops)),'bad_boundary_degree_count':sum(len(v)!=2 for v in adj.values()),'nonmanifold_edges':sum(c>2 for c in counts.values()),'bounds_native':[V[verts].min(0).tolist(),V[verts].max(0).tolist()]};attempts.append(row)
 if chosen is None and len(loops)==1 and row['bad_boundary_degree_count']==0 and row['nonmanifold_edges']==0 and chi==1:chosen=(selected,np.array(loops[0]))
report={'base_obj_sha256':hashlib.sha256((S/'raw/base.obj').read_bytes()).hexdigest(),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'affected_target_vertices':len(affected),'attempts':attempts,'healthy_disk_found':chosen is not None,'status':'Native topology study only. No Peacock extraction, fit, pose, shading, local folds or intersection clearance.'}
if chosen:
 selected,boundary=chosen;nativeq=F[selected];nativeuv=FU[selected];np.savez_compressed(R/'inputs/native_ear_domain190.npz',native_pos=V,native_uv=U,native_quads=nativeq,native_corner_uv=nativeuv,native_source_face_ids=bodyids[selected],native_boundary_vertex_ids=boundary);report['saved_domain_quads']=len(selected);report['boundary_vertex_ids']=boundary.tolist();report['ear_center_native']=V[np.unique(nativeq)].mean(0).tolist()
(R/'checks/native_ear_domain190.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
