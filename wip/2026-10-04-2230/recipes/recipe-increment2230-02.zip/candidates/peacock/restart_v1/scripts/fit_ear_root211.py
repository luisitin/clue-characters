"""Shrink only the plain root into the healthy source domain.

Choose the first bounded root scale with1.5mm chart clearance, then extend its
small displacement using a positive graph Laplacian while holding the ear core
at least8mm geodesically from the cut. This is still an isolated study.
"""
from pathlib import Path
import numpy as np,json,hashlib
from scipy.sparse import coo_matrix,diags
from scipy.sparse.csgraph import dijkstra
from scipy.sparse.linalg import spsolve
from subdivide_pose_ear208 import inside_distance,crossings
R=Path(__file__).resolve().parents[1]
a=np.load(R/'inputs/posed_ear208.npz');D={k:a[k] for k in a.files};a.close();P=D['pos'];T=D['tri'];ring=D['boundary_vertex_ids'];a=np.load(R/'inputs/host_ear_domain205.npz');outer=a['boundary_world'][:,[0,2]];a.close();original=P.copy();root=P[ring][:,[0,2]];center=np.array([-.105,.760]);attempts=[];chosen=None
for scale in [1.,.98,.96,.94,.92,.90,.88,.86,.84,.82,.80]:
    target=center+(root-center)*scale
    samples=np.concatenate([(1-t)*target+t*np.roll(target,-1,axis=0) for t in np.linspace(0,1,33)]);margin=inside_distance(samples,outer).min();attempts.append({'scale':scale,'minimum_sampled_margin_mm':float(margin*1000)})
    if margin>.0015 and not crossings(target):chosen=target;break
assert chosen is not None,attempts
ed=np.unique(np.sort(np.vstack([T[:,[0,1]],T[:,[1,2]],T[:,[2,0]]]),axis=1),axis=0);length=np.linalg.norm(P[ed[:,0]]-P[ed[:,1]],axis=1);A=coo_matrix((np.r_[length,length],(np.r_[ed[:,0],ed[:,1]],np.r_[ed[:,1],ed[:,0]])),shape=(len(P),len(P))).tocsr();distance=dijkstra(A,directed=False,indices=ring,min_only=True);core=distance>=.008;fixed=core.copy();fixed[ring]=True
W=coo_matrix((np.r_[1/length,1/length],(np.r_[ed[:,0],ed[:,1]],np.r_[ed[:,1],ed[:,0]])),shape=(len(P),len(P))).tocsr();L=diags(np.asarray(W.sum(1)).ravel())-W;free=np.where(~fixed)[0];hold=np.where(fixed)[0];motion=np.zeros_like(P);motion[ring[:,None],[0,2]]=chosen-root;motion[free]=spsolve(L[free][:,free].tocsc(),-L[free][:,hold]@motion[hold]);P=P+motion
assert np.array_equal(P[core],original[core]);q=P[T];fn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);old=np.cross(original[T[:,1]]-original[T[:,0]],original[T[:,2]]-original[T[:,0]]);cos=np.sum(fn*old,axis=1)/(np.linalg.norm(fn,axis=1)*np.linalg.norm(old,axis=1));ar=np.linalg.norm(fn,axis=1)/np.linalg.norm(old,axis=1);assert cos.min()>0 and ar.min()>.05
N=np.zeros_like(P)
for k in range(3):np.add.at(N,T[:,k],fn)
N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30);D.update(pos=P,normal=N,pre_root_fit_pos=original,held_anatomical_core=core,root_geodesic_distance=distance)
out=R/'inputs/posed_ear211.npz';np.savez_compressed(out,**D);report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256((R/'inputs/posed_ear208.npz').read_bytes()).hexdigest(),'attempts':attempts,'root_scale':scale,'core_geodesic_threshold_mm':8,'held_core_vertices':int(core.sum()),'core_max_motion_mm':float(np.linalg.norm(motion[core],axis=1).max()*1000),'max_attachment_motion_mm':float(np.linalg.norm(motion,axis=1).max()*1000),'fixed_parent_triangle_min_normal_cosine':float(cos.min()),'fixed_parent_triangle_area_ratio_minmax':[float(ar.min()),float(ar.max())],'inner_root_chart_crossings':crossings(P[ring][:,[0,2]]),'status':'Isolated root-fit study. Global surface intersections, actual join geometry/materials, retained head identity and all-angle appearance remain open.'};(R/'checks/posed_ear211.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
