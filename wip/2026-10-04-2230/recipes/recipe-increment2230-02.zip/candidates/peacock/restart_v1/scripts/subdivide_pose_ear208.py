"""Subdivide the pinned native ear and bound only its plain upper attachment.

This produces an isolated component, not a source-character replacement. Native
anatomy is subdivided before a monotone upper-root compression. All topology,
corner UVs and original quad provenance are carried through the subdivision.
"""
from pathlib import Path
from collections import defaultdict, Counter
import numpy as np, json, hashlib

R=Path(__file__).resolve().parents[1]

def subdivide(P,Q,UV,owner):
    E=defaultdict(list); VF=defaultdict(list); VE=defaultdict(list)
    for fi,face in enumerate(Q):
        for v in face: VF[int(v)].append(fi)
        for a,b in zip(face,np.roll(face,-1)):
            E[tuple(sorted((int(a),int(b))))].append(fi)
    edgekeys=sorted(E); edgeid={e:len(P)+i for i,e in enumerate(edgekeys)}
    for e in edgekeys:
        for v in e:VE[v].append(e)
    FP=P[Q].mean(1); newP=[]
    for i,p in enumerate(P):
        be=[e for e in VE[i] if len(E[e])==1]
        if be:
            assert len(be)==2
            neighbor=[e[0] if e[1]==i else e[1] for e in be]
            newP.append((6*p+P[neighbor].sum(0))/8)
        else:
            n=len(VE[i]); midpoint=np.array([P[list(e)].mean(0) for e in VE[i]])
            newP.append((FP[VF[i]].mean(0)+2*midpoint.mean(0)+(n-3)*p)/n)
    for e in edgekeys:
        fs=E[e]
        assert len(fs) in (1,2)
        newP.append(P[list(e)].mean(0) if len(fs)==1 else (P[list(e)].sum(0)+FP[fs].sum(0))/4)
    offset=len(newP); newP.extend(FP); newQ=[]; newUV=[]; newowner=[]
    for fi,face in enumerate(Q):
        uv=UV[fi]; center=uv.mean(0)
        for k,v in enumerate(face):
            nextv=face[(k+1)%4]; prevv=face[(k-1)%4]
            newQ.append([v,edgeid[tuple(sorted((int(v),int(nextv))))],offset+fi,edgeid[tuple(sorted((int(prevv),int(v))))]])
            newUV.append([uv[k],(uv[k]+uv[(k+1)%4])/2,center,(uv[(k-1)%4]+uv[k])/2])
            newowner.append(owner[fi])
    return np.asarray(newP),np.asarray(newQ),np.asarray(newUV),np.asarray(newowner)

def boundary(Q):
    E=Counter(tuple(sorted((int(a),int(b)))) for f in Q for a,b in zip(f,np.roll(f,-1)))
    adj=defaultdict(list)
    for (a,b),n in E.items():
        assert n in (1,2)
        if n==1:adj[a].append(b);adj[b].append(a)
    assert all(len(x)==2 for x in adj.values())
    start=min(adj);ring=[start];prev=None;cur=start
    while True:
        nxt=adj[cur][0] if adj[cur][0]!=prev else adj[cur][1]
        if nxt==start:break
        assert nxt not in ring
        ring.append(nxt);prev,cur=cur,nxt
    assert len(ring)==len(adj)
    return np.array(ring),E

def inside_distance(query,poly):
    edge=np.roll(poly,-1,axis=0)-poly; rel=query[:,None,:]-poly[None,:,:]
    t=np.clip(np.sum(rel*edge,axis=2)/np.sum(edge*edge,axis=1),0,1)
    dist=np.linalg.norm(rel-t[:,:,None]*edge,axis=2).min(1)
    inside=np.zeros(len(query),bool)
    for a,b in zip(poly,np.roll(poly,-1,axis=0)):
        if abs(b[1]-a[1])<1e-16:continue
        hit=((a[1]>query[:,1])!=(b[1]>query[:,1]))&(query[:,0]<(b[0]-a[0])*(query[:,1]-a[1])/(b[1]-a[1])+a[0])
        inside^=hit
    return np.where(inside,dist,-dist)

def crossings(poly):
    out=[]
    def cross(a,b):return a[0]*b[1]-a[1]*b[0]
    for i,(a,b) in enumerate(zip(poly,np.roll(poly,-1,axis=0))):
        for j in range(i+2,len(poly)):
            if i==0 and j==len(poly)-1:continue
            c,d=poly[j],poly[(j+1)%len(poly)]
            if cross(b-a,c-a)*cross(b-a,d-a)<-1e-22 and cross(d-c,a-c)*cross(d-c,b-c)<-1e-22:out.append([i,j])
    return out

def main():
    a=np.load(R/'inputs/posed_ear203.npz');D={k:a[k] for k in a.files};a.close()
    P=D['pos'];Q=D['quads'];UV=D['native_uv'][D['native_corner_uv']];owner=D['native_source_face_ids']
    for _ in range(2):P,Q,UV,owner=subdivide(P,Q,UV,owner)
    rest=P.copy(); z0=.7915; P[:,2]=np.where(P[:,2]>z0,z0+.28*(P[:,2]-z0),P[:,2])
    ring,E=boundary(Q);T=np.vstack([Q[:,[0,1,2]],Q[:,[0,2,3]]]);q=P[T];rn=np.cross(rest[T[:,1]]-rest[T[:,0]],rest[T[:,2]]-rest[T[:,0]]);fn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);area=np.linalg.norm(fn,axis=1);N=np.zeros_like(P)
    for k in range(3):np.add.at(N,T[:,k],fn)
    N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30)
    cos=np.sum(rn*fn,axis=1)/(np.linalg.norm(rn,axis=1)*area)
    h=np.load(R/'inputs/host_ear_domain205.npz');host=h['boundary_world'][:,[0,2]];h.close();inner=P[ring][:,[0,2]]
    # Dense edge sampling plus the exact noncrossing polygon gate. Positive
    # sampled margin is supplemented by explicit contour intersection checks.
    samples=np.concatenate([(1-t)*inner+t*np.roll(inner,-1,axis=0) for t in np.linspace(0,1,17)])
    margin=inside_distance(samples,host);cr=crossings(inner)
    assert np.min(area)>1e-14 and np.min(cos)>0
    out=R/'inputs/posed_ear208.npz';np.savez_compressed(out,pos=P,normal=N,tri=T,quads=Q,rest_pos=rest,corner_uv=UV,source_quad_ids=owner,boundary_vertex_ids=ring)
    report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256((R/'inputs/posed_ear203.npz').read_bytes()).hexdigest(),'vertices':len(P),'quads':len(Q),'triangles':len(T),'euler':len(P)-len(E)+len(Q),'boundary_vertices':len(ring),'upper_attachment_only_monotone_z_map':{'start_z':z0,'derivative_above':.28},'minimum_triangle_area2':float(area.min()),'minimum_fixed_rest_normal_cosine':float(cos.min()),'maximum_motion_mm':float(np.linalg.norm(P-rest,axis=1).max()*1000),'inner_root_chart_crossings':cr,'host_margin_sample_min_mm':float(margin.min()*1000),'root_bounds':[P[ring].min(0).tolist(),P[ring].max(0).tolist()],'scope':'Isolated attachment fit study. Source205 remains intact. No fitted annulus, root tangency, whole-ear intersection audit, source-volume proof or assembled appearance clearance yet.'}
    (R/'checks/posed_ear208.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
