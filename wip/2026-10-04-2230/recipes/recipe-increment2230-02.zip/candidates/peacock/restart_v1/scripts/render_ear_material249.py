"""Raw source/NPZ render; native texture bytes decoded losslessly. Clay skips image loading."""
import bpy,numpy as np,sys,json,math,hashlib,os,struct
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:];mode=args[0];view=args[1];angle=float(args[2]);elev=float(args[3]) if len(args)>3 else 0
src=Path(args[4]) if len(args)>4 else R/'inputs/source_world.npz'
label=args[5] if len(args)>5 else 'baseline'
materials=json.loads(src.with_name(src.stem+'_materials.json').read_text())
glb_path=os.environ.get('PEACOCK_GLB');verified_glb_sha=None
if glb_path:
 raw=Path(glb_path).read_bytes();verified_glb_sha=hashlib.sha256(raw).hexdigest();jlen=struct.unpack_from('<I',raw,12)[0];g=json.loads(raw[20:20+jlen]);boff=28+jlen
 assert g['nodes'][0].get('scale',[1,1,1])==[1,1,1] and 'rotation' not in g['nodes'][0] and 'matrix' not in g['nodes'][0] and 'translation' not in g['nodes'][0]
 def ga(i):
  a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];width={'VEC2':2,'VEC3':3,'SCALAR':1}[a['type']];dtype={5126:'<f4',5125:'<u4'}[a['componentType']];return np.frombuffer(raw,dtype=dtype,count=a['count']*width,offset=boff+v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,width).copy()
 prs=g['meshes'][0]['primitives'];at=prs[0]['attributes'];P=ga(at['POSITION'])[:,[0,2,1]];P[:,1]*=-1;N=ga(at['NORMAL'])[:,[0,2,1]];N[:,1]*=-1;U=ga(at['TEXCOORD_0']);T=np.concatenate([ga(pr['indices']).reshape(-1,3) for pr in prs]);part=np.concatenate([np.full(g['accessors'][pr['indices']]['count']//3,pr['material'],int) for pr in prs])
 for i,path in enumerate([Path(m[key]) for m in materials for key in ['base_path','orm_path']]):
  v=g['bufferViews'][g['images'][i]['bufferView']];data=raw[boff+v['byteOffset']:boff+v['byteOffset']+v['byteLength']];assert hashlib.sha256(data).digest()==hashlib.sha256(path.read_bytes()).digest()
 for i,m in enumerate(materials):assert g['materials'][i]['occlusionTexture']['strength']==m['occlusion_strength']
else:
 a=np.load(src);P=a['pos'];T=a['tri'];N=a['normal'];U=a['uv'];part=a['material'] if 'material' in a.files else np.zeros(len(T),int);a.close()
bpy.ops.wm.read_factory_settings(use_empty=True)
me=bpy.data.meshes.new('Peacock exact source geometry');me.from_pydata(P.tolist(),[],T.tolist());me.update()
ob=bpy.data.objects.new('Peacock recovered source',me);bpy.context.collection.objects.link(ob)
for poly in me.polygons: poly.use_smooth=True
me.normals_split_custom_set_from_vertices(N.tolist())
uv=me.uv_layers.new(name='SourceUV');q=U[T.ravel()].copy();q[:,1]=1-q[:,1];uv.data.foreach_set('uv',q.astype('float32').ravel())
def material(name,base,ormpath):
 mat=bpy.data.materials.new(name);mat.use_nodes=True;nd=mat.node_tree.nodes;lk=mat.node_tree.links;bs=nd.get('Principled BSDF');bs.inputs['Roughness'].default_value=.68
 if mode in ('paint','albedo'):
  tex=nd.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(base),check_existing=True);tex.extension='EXTEND';lk.new(tex.outputs['Color'],bs.inputs['Base Color'])
  if mode=='paint':
   orm=nd.new('ShaderNodeTexImage');orm.image=bpy.data.images.load(str(ormpath),check_existing=True);orm.extension='EXTEND';orm.image.colorspace_settings.name='Non-Color';sep=nd.new('ShaderNodeSeparateColor');lk.new(orm.outputs['Color'],sep.inputs['Color']);lk.new(sep.outputs['Green'],bs.inputs['Roughness']);lk.new(sep.outputs['Blue'],bs.inputs['Metallic'])
  else:
   emit=nd.new('ShaderNodeEmission');lk.new(tex.outputs['Color'],emit.inputs['Color']);lk.new(emit.outputs[0],nd.get('Material Output').inputs['Surface'])
 else:bs.inputs['Base Color'].default_value=(.24,.24,.24,1) if os.environ.get('PEACOCK_STUDIO')=='neutral' else (.45,.45,.45,1)
 return mat
for m in materials:
 me.materials.append(material(m['name'],m.get('base_render_path',m['base_path']),m.get('orm_render_path',m['orm_path'])))
me.polygons.foreach_set('material_index',part.astype('int32'))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.14,.14,.14,1)
for name,loc,power,size in [('Key',(-3,-4,5),650,4),('Fill',(3,-2,2),350,3),('Rim',(1,3,4),700,3)]:
 ld=bpy.data.lights.new(name,'AREA');ld.energy=power*(.4 if os.environ.get('PEACOCK_STUDIO')=='neutral' else 1);ld.shape='DISK';ld.size=size;lo=bpy.data.objects.new(name,ld);scene.collection.objects.link(lo);lo.location=loc;lo.rotation_euler=(Vector((0,0,.2))-lo.location).to_track_quat('-Z','Y').to_euler()
centers={'ear':(-.099,-.078,.755),'full':(0,0,0),'head':(-.06,-.025,.725),'face':(-.06,-.045,.725),'eye_left':(-.0296,-.128,.7754)};scales={'ear':.14,'full':2.15,'head':.65,'face':.34,'eye_left':.125};center=Vector(centers[view]);scale=scales[view]
az=math.radians(angle);el=math.radians(elev);direction=Vector((math.sin(az)*math.cos(el),-math.cos(az)*math.cos(el),math.sin(el)))
ca=bpy.data.cameras.new('Exact orthographic camera');co=bpy.data.objects.new('Camera',ca);scene.collection.objects.link(co);co.location=center+direction*4;co.rotation_euler=(center-co.location).to_track_quat('-Z','Y').to_euler();ca.type='ORTHO';ca.ortho_scale=scale;scene.camera=co
scene.render.resolution_x=800;scene.render.resolution_y=scene.render.resolution_x;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
out=R/'renders'/label;out.mkdir(parents=True,exist_ok=True);name=f'{view}_{mode}_{int(angle):03d}_{int(elev):+03d}';scene.render.filepath=str(out/(name+'.png'))
bpy.context.view_layer.update()
meta={'geometry_npz':str(src),'geometry_npz_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_glb_sha256':'22faf1e82334f5b5d19775a080448c8b2cc8edbdc6f4858fdae5e7c47961f39c','triangles':len(T),'material_mode':mode,'clay_overrides_materials_only':mode=='clay','camera_world_matrix':[list(row) for row in co.matrix_world],'projection':'ORTHO','ortho_scale':scale,'image_dimensions':[scene.render.resolution_x,scene.render.resolution_y],'angle_degrees':angle,'elevation_degrees':elev,'camera_target':list(center),'source_AO':'Disabled in the actual exported material' if all(m['occlusion_strength']==0 for m in materials) else 'Active AO is not rendered','omitted_active_material_inputs':[] if all(m['occlusion_strength']==0 for m in materials) else ['occlusion'], 'texture_wrap':'CLAMP_TO_EDGE, matched by EXTEND nodes','basecolor_override':os.environ.get('PEACOCK_BASECOLOR'),'candidate_glb_sha256':verified_glb_sha,'actual_glb_geometry_and_image_bytes_read':bool(glb_path),'studio':os.environ.get('PEACOCK_STUDIO','baseline'),'quality':'800px64sample exact exported material study','face_material_triangles':int((part==1).sum())}
(out/(name+'.json')).write_text(json.dumps(meta,indent=2));bpy.ops.render.render(write_still=True);print(json.dumps(meta))
