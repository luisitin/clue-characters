"""Raw source/NPZ render; native texture bytes decoded losslessly. Clay skips image loading."""
import bpy,numpy as np,sys,json,math,hashlib,os
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:];mode=args[0];view=args[1];angle=float(args[2]);elev=float(args[3]) if len(args)>3 else 0
src=Path(args[4]) if len(args)>4 else R/'inputs/source_world.npz'
label=args[5] if len(args)>5 else 'baseline'
a=np.load(src);P=a['pos'];T=a['tri'];N=a['normal'];U=a['uv'] if 'uv' in a.files else np.zeros((len(P),2));a.close()
bpy.ops.wm.read_factory_settings(use_empty=True)
me=bpy.data.meshes.new('Peacock exact source geometry');me.from_pydata(P.tolist(),[],T.tolist());me.update()
ob=bpy.data.objects.new('Peacock recovered source',me);bpy.context.collection.objects.link(ob)
for poly in me.polygons: poly.use_smooth=True
me.normals_split_custom_set_from_vertices(N.tolist())
uv=me.uv_layers.new(name='SourceUV');q=U[T.ravel()].copy();q[:,1]=1-q[:,1];uv.data.foreach_set('uv',q.astype('float32').ravel())
mat=bpy.data.materials.new('Source painted PBR' if mode=='paint' else 'Clay diagnostic override');mat.use_nodes=True;nd=mat.node_tree.nodes;lk=mat.node_tree.links;bs=nd.get('Principled BSDF');bs.inputs['Roughness'].default_value=.68
if mode in ('paint','albedo'):
 tex=nd.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(os.environ.get('PEACOCK_BASECOLOR',str(R/'inputs/source_image_0.png')));lk.new(tex.outputs['Color'],bs.inputs['Base Color'])
 orm=nd.new('ShaderNodeTexImage');orm.image=bpy.data.images.load(str(R/'inputs/source_image_1.png'));orm.image.colorspace_settings.name='Non-Color';sep=nd.new('ShaderNodeSeparateColor');lk.new(orm.outputs['Color'],sep.inputs['Color']);lk.new(sep.outputs['Green'],bs.inputs['Roughness']);lk.new(sep.outputs['Blue'],bs.inputs['Metallic'])
else: bs.inputs['Base Color'].default_value=(.25,.25,.25,1)
if mode=='albedo':
 emit=nd.new('ShaderNodeEmission');lk.new(tex.outputs['Color'],emit.inputs['Color']);lk.new(emit.outputs[0],nd.get('Material Output').inputs['Surface'])
me.materials.append(mat)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=2
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.14,.14,.14,1)
for name,loc,power,size in [('Key',(-3,-4,5),260,4),('Fill',(3,-2,2),140,3),('Rim',(1,3,4),280,3)]:
 ld=bpy.data.lights.new(name,'AREA');ld.energy=power;ld.shape='DISK';ld.size=size;lo=bpy.data.objects.new(name,ld);scene.collection.objects.link(lo);lo.location=loc;lo.rotation_euler=(Vector((0,0,.2))-lo.location).to_track_quat('-Z','Y').to_euler()
centers={'full':(0,0,0),'head':(-.06,-.025,.725),'face':(-.06,-.045,.725),'ear':(-.099,-.078,.755)};scales={'full':2.15,'head':.65,'face':.34,'ear':.14};center=Vector(centers[view]);scale=scales[view]
az=math.radians(angle);el=math.radians(elev);direction=Vector((math.sin(az)*math.cos(el),-math.cos(az)*math.cos(el),math.sin(el)))
ca=bpy.data.cameras.new('Exact orthographic camera');co=bpy.data.objects.new('Camera',ca);scene.collection.objects.link(co);co.location=center+direction*4;co.rotation_euler=(center-co.location).to_track_quat('-Z','Y').to_euler();ca.type='ORTHO';ca.ortho_scale=scale;scene.camera=co
scene.render.resolution_x=640;scene.render.resolution_y=scene.render.resolution_x;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
out=R/'renders'/label;out.mkdir(parents=True,exist_ok=True);name=f'{view}_{mode}_{int(angle):03d}_{int(elev):+03d}';scene.render.filepath=str(out/(name+'.png'))
bpy.context.view_layer.update()
meta={'geometry_npz':str(src),'geometry_npz_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_glb_sha256':'22faf1e82334f5b5d19775a080448c8b2cc8edbdc6f4858fdae5e7c47961f39c','triangles':len(T),'material_mode':mode,'clay_overrides_materials_only':mode=='clay','camera_world_matrix':[list(row) for row in co.matrix_world],'projection':'ORTHO','ortho_scale':scale,'image_dimensions':[scene.render.resolution_x,scene.render.resolution_y],'angle_degrees':angle,'elevation_degrees':elev,'camera_target':list(center),'scope':'Exact NPZ geometry study with material-only clay override; not an exported GLB appearance pass','basecolor_override':os.environ.get('PEACOCK_BASECOLOR'),'candidate_glb_sha256':os.environ.get('PEACOCK_GLB_SHA256')}
(out/(name+'.json')).write_text(json.dumps(meta,indent=2));bpy.ops.render.render(write_still=True);print(json.dumps(meta))
