"""Bounded source-to-native-ear attachment study with exact two boundary loops.

The source scalp/cheek field returns away from the diagnosed old ear and lower
fold. Only an isolated component is saved. Actual joined-character appearance,
local folds, contacts, UVs, and material authorship remain explicit later gates.
"""
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np,json,sys,hashlib
from scipy.interpolate import RBFInterpolator
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
from subdivide_pose_ear208 import inside_distance,crossings
R=Path(__file__).resolve().parents[1]
sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle

def load(name):
    a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
def area(poly):return np.sum(poly[:,0]*np.roll(poly[:,1],-1)-poly[:,1]*np.roll(poly[:,0],-1))/2
def edge_distance(q,poly):
    e=np.roll(poly,-1,axis=0)-poly;r=q[:,None,:]-poly[None,:,:];t=np.clip(np.sum(r*e,axis=2)/np.sum(e*e,axis=1),0,1)
    return np.linalg.norm(r-t[:,:,None]*e,axis=2).min(1)
def cross2(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
def edges(T):
    E=defaultdict(list)
    for fi,tr in enumerate(T):
        for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append(fi)
    return E
def smooth(x):x=np.clip(x,0,1);return x*x*x*(10-15*x+6*x*x)

S=load('source_clean1');H=load('host_ear_domain205');D=load('posed_ear211')
SP,ST,SN=S['pos'],S['tri'],S['normal'];DP,DT,DN=D['pos'],D['tri'],D['normal']
outerP=H['boundary_world'].copy();innerids=D['boundary_vertex_ids'].copy()
if area(outerP[:,[0,2]])<0:outerP=outerP[::-1].copy()
if area(DP[innerids][:,[0,2]])<0:innerids=innerids[::-1].copy()
innerP=DP[innerids];outer,inner=outerP[:,[0,2]],innerP[:,[0,2]]
assert not crossings(outer) and not crossings(inner)
assert inside_distance(inner,outer).min()>.0008,inside_distance(inner,outer).min()
old=set(map(int,H['source_faces']));groupsP,G=np.unique(SP,axis=0,return_inverse=True);SG=G[ST];SE=edges(SG);DE=edges(DT);lookup={tuple(p):i for i,p in enumerate(groupsP)};outergroups=np.array([lookup[tuple(p)] for p in outerP]);no,ni=len(outer),len(inner)

# A short explicit triangle at each boundary continues the actual adjacent
# retained face plane. The annulus lies left of the CCW outer curve and right
# of the CCW inner curve; the donor's detailed core remains entirely held.
guides=[];gy=[];planes=[];guide_faces=[];guide_kind=[];outside_controls=[]
for kind,loop,ids,world,F,E in [('source',outer,outergroups,groupsP,SG,SE),('donor',inner,innerids,DP,DT,DE)]:
    for k,(a,b) in enumerate(zip(ids,np.roll(ids,-1))):
        fs=E[tuple(sorted((int(a),int(b))))]
        if kind=='source':fs=[i for i in fs if i not in old]
        assert len(fs)==1,(kind,k,fs)
        fi=int(fs[0]);pts=world[F[fi]];basis=np.column_stack([pts[:,0],pts[:,2],np.ones(3)]);assert abs(np.linalg.det(basis))>1e-12
        plane=np.linalg.solve(basis,pts[:,1]);e=loop[(k+1)%len(loop)]-loop[k];left=np.array([-e[1],e[0]])/np.linalg.norm(e);direction=left if kind=='source' else -left
        width=min(.00015,np.linalg.norm(e)*.10)
        for _ in range(10):
            guide=(loop[k]+loop[(k+1)%len(loop)])*.5+direction*width
            if inside_distance(guide[None],outer)[0]>0 and inside_distance(guide[None],inner)[0]<0:break
            width*=.5
        assert width>1e-6,(kind,k)
        guides.append(guide);gy.append(float(np.r_[guide,1]@plane));planes.append(plane);guide_faces.append(fi);guide_kind.append(kind)
        if kind=='source':outside_controls.extend(pts.tolist())
guides=np.array(guides);gy=np.array(gy);planes=np.array(planes)

loopseg=np.vstack([np.column_stack([np.arange(no),np.roll(np.arange(no),-1)]),np.column_stack([no+np.arange(ni),no+np.roll(np.arange(ni),-1)])])
gids=no+ni+np.arange(no+ni);wedgeseg=np.vstack([np.column_stack([loopseg[:,0],gids]),np.column_stack([gids,loopseg[:,1]])]);seg=np.vstack([loopseg,wedgeseg])
xx,zz=np.meshgrid(np.arange(outer[:,0].min(),outer[:,0].max(),.0015),np.arange(outer[:,1].min(),outer[:,1].max(),.0015));seeds=np.column_stack([xx.ravel(),zz.ravel()]);seeds=seeds[(inside_distance(seeds,outer)>.00035)&(inside_distance(seeds,inner)<-.00035)]
# Exclude seeds close to either side of the constrained tangent wedges.
for ia,ib in wedgeseg:
    vv=np.vstack([outer,inner,guides]);a,b=vv[ia],vv[ib];e=b-a;t=np.clip(((seeds-a)@e)/(e@e),0,1);seeds=seeds[np.linalg.norm(seeds-a-t[:,None]*e,axis=1)>.00018]
res=triangle.triangulate({'vertices':np.vstack([outer,inner,guides,seeds]),'segments':seg,'holes':[inner.mean(0)]},'pYq24Q');V=res['vertices'];F=res['triangles'];q=V[F];signed=cross2(q[:,1]-q[:,0],q[:,2]-q[:,0]);assert signed.min()>0
assert np.array_equal(V[:no],outer) and np.array_equal(V[no:no+ni],inner)
EC=Counter(tuple(sorted((int(a),int(b)))) for tr in F for a,b in zip(tr,np.roll(tr,-1)))
assert {e for e,n in EC.items() if n==1}=={tuple(sorted(map(int,e))) for e in loopseg}
assert max(EC.values())==2

# Initial height uses the two exact boundaries and actual neighboring planes.
ctrl=np.vstack([outerP,innerP,np.column_stack([guides[:,0],gy,guides[:,1]]),outside_controls]);xz,ix=np.unique(ctrl[:,[0,2]],axis=0,return_index=True);ctrl=ctrl[ix]
fit=RBFInterpolator(xz,ctrl[:,1],kernel='thin_plate_spline',smoothing=1e-14);Y=fit(V)
fixed=np.zeros(len(V),bool);fixed[:no+ni]=True;Y[:no]=outerP[:,1];Y[no:no+ni]=innerP[:,1];members=[]
for k,(ia,ib) in enumerate(loopseg):
    p=np.array([V[ia],V[ib],guides[k]]);a,b=p[1]-p[0],p[2]-p[0];den=cross2(a,b);r=V-p[0];s=cross2(r,b)/den;t=cross2(a,r)/den;take=(s>=-1e-8)&(t>=-1e-8)&(s+t<=1+1e-8)
    Y[take]=np.column_stack([V[take],np.ones(take.sum())])@planes[k];fixed[take]=True;members.append(np.where(take)[0])
Y[:no]=outerP[:,1];Y[no:no+ni]=innerP[:,1]

# Smooth the bounded interval; fixed source and native tangent wedges control
# derivatives at both ends. This does not assert that the interpolated volume
# matches the original scalp away from the old ear, so that is enforced next.
X=(V-V.mean(0))/.05;rr=[];cc=[];ww=[];mass=np.zeros(len(V))
for tr in F:
    p=X[tr];ar=abs(cross2(p[1]-p[0],p[2]-p[0]));mass[tr]+=ar/6
    for j in range(3):
        a,b=tr[(j+1)%3],tr[(j+2)%3];w=.5*((p[(j+1)%3]-p[j])@(p[(j+2)%3]-p[j]))/ar;rr.extend([a,b]);cc.extend([b,a]);ww.extend([w,w])
W=coo_matrix((ww,(rr,cc)),shape=(len(V),len(V))).tocsr();L=diags(np.asarray(W.sum(1)).ravel())-W;K=(L.T@diags(1/np.maximum(mass,1e-20))@L).tocsr();free=np.where(~fixed)[0];hold=np.where(fixed)[0];Y[free]=spsolve(K[free][:,free].tocsc(),-K[free][:,hold]@Y[hold]);smoothY=Y.copy();assert np.isfinite(Y).all()

# Exact front-facing source sheet sampling in this chart. No RGB criteria are
# used for geometry. Source points outside the old-ear/fold reconstruction mask
# return to their original depth; a C2 fade approaches the new attachment.
sourceY=np.full(len(V),np.inf);sourceN=np.zeros((len(V),3));sourceID=np.full(len(V),-1)
for fi in H['source_faces']:
    p=SP[ST[fi]];xz=p[:,[0,2]];a,b=xz[1]-xz[0],xz[2]-xz[0];den=cross2(a,b)
    if den<=1e-12:continue
    lo=xz.min(0)-1e-10;hi=xz.max(0)+1e-10;ids=np.where(((V>=lo)&(V<=hi)).all(1))[0]
    if not len(ids):continue
    r=V[ids]-xz[0];u=cross2(r,b)/den;v=cross2(a,r)/den;bar=np.column_stack([1-u-v,u,v]);ok=(bar.min(1)>=-1e-8);ids=ids[ok];bar=bar[ok];yy=bar@p[:,1];ok=yy<sourceY[ids];ids=ids[ok];bar=bar[ok];sourceY[ids]=yy[ok];sourceN[ids]=bar@SN[ST[fi]];sourceID[ids]=fi
old_ear=np.sqrt(((V[:,0]+.108)/.024)**2+((V[:,1]-.765)/.039)**2)
old_fold=np.sqrt(((V[:,0]+.083)/.014)**2+((V[:,1]-.716)/.014)**2)
old_lobe=np.sqrt(((V[:,0]+.102)/.021)**2+((V[:,1]-.731)/.026)**2)
return_weight=smooth((old_ear-1)/.25)*smooth((old_fold-1)/.25)*smooth((old_lobe-1)/.25)*smooth((edge_distance(V,inner)-.0015)/.004)
return_weight[~np.isfinite(sourceY)]=0;return_weight[fixed]=0
take=return_weight>0;Y[take]=(1-return_weight[take])*Y[take]+return_weight[take]*sourceY[take]
P=np.column_stack([V[:,0],Y,V[:,1]]);P[:no]=outerP;P[no:no+ni]=innerP
fn=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);N=np.zeros_like(P)
for k in range(3):np.add.at(N,F[:,k],fn)
N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30)

# Geometry join dihedrals and fixed boundaries are measured before rendering.
FE=edges(F);join=[]
for k,(ia,ib) in enumerate(loopseg):
    fs=FE[tuple(sorted((int(ia),int(ib))))];assert len(fs)==1;ff=fn[fs[0]];ff/=np.linalg.norm(ff)
    if k<no:pp=groupsP[SG[guide_faces[k]]]
    else:pp=DP[DT[guide_faces[k]]]
    nn=np.cross(pp[1]-pp[0],pp[2]-pp[0]);nn/=np.linalg.norm(nn);join.append(float(np.degrees(np.arccos(np.clip(ff@nn,-1,1)))))
out=R/'inputs/ear_annulus216.npz';np.savez_compressed(out,pos=P,normal=N,tri=F,outer_boundary_count=no,inner_boundary_count=ni,inner_native_vertex_ids=innerids,source_face_ids=H['source_faces'],source_return_weight=return_weight,source_sample_ids=sourceID)
report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'donor_component_sha256':hashlib.sha256((R/'inputs/posed_ear211.npz').read_bytes()).hexdigest(),'triangles':len(F),'vertices':len(P),'outer_boundary_vertices':no,'inner_boundary_vertices':ni,'minimum_projected_area2':float(signed.min()),'exact_outer_boundary_held':bool(np.array_equal(P[:no],outerP)),'exact_native_inner_boundary_held':bool(np.array_equal(P[no:no+ni],innerP)),'max_source_join_dihedral_degrees':max(join[:no]),'max_native_join_dihedral_degrees':max(join[no:]),'join_dihedral_degrees':join,'source_return_full_vertices':int((return_weight==1).sum()),'source_return_partial_vertices':int(((return_weight>0)&(return_weight<1)).sum()),'source_return_max_correction_mm':float(np.max(np.abs(Y-smoothY))*1000),'source_field_misses':int((sourceID<0).sum()),'old_lobe_source_return_exclusion':{'center_xz':[-.102,.731],'radii_xz':[.021,.026],'basis':'The exact215 fold centroids and original198 lobe/earring footprint show the obsolete source form is still sampled in212. This exclusion changes interpolation only inside the already-selected205 domain.'},'height_bounds':[float(Y.min()),float(Y.max())],'status':'Isolated annular attachment study only. No source cut/export. True contact/local fold checks, retained form, normals, paint and actual joined appearance remain open.'}
(R/'checks/ear_annulus216.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='join_dihedral_degrees'},indent=2))
