"""Registered, visibility-bounded ear/scalp albedo cleanup on unchanged246 mesh.
The native pinna pigment is protected; the plate repairs the obsolete painted
ear outline and the new attachment's skin/hair transition. Actual views follow.
"""
from pathlib import Path
import numpy as np,json,hashlib,os
from PIL import Image
from scipy.ndimage import map_coordinates,distance_transform_edt
from subdivide_pose_ear208 import inside_distance
from glb_io import GLB
R=Path(__file__).resolve().parents[1];W=2048;size=800
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
def smooth(x):x=np.clip(x,0,1);return x*x*x*(10-15*x+6*x*x)
def linear(c):return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)
def srgb(c):return np.where(c<=.0031308,c*12.92,1.055*np.maximum(c,0)**(1/2.4)-.055)
def sample(im,uv):
 xy=uv*np.array([im.shape[1],im.shape[0]])-.5;ij=np.floor(xy).astype(int);f=xy-ij;x=np.clip(ij[:,0],0,im.shape[1]-1);y=np.clip(ij[:,1],0,im.shape[0]-1);x1=np.minimum(x+1,im.shape[1]-1);y1=np.minimum(y+1,im.shape[0]-1);fx=f[:,0,None];fy=f[:,1,None]
 return im[y,x]*(1-fx)*(1-fy)+im[y,x1]*fx*(1-fy)+im[y1,x]*(1-fx)*fy+im[y1,x1]*fx*fy
def texels(q):
 q=q*W;lo=np.maximum(np.floor(q.min(0)).astype(int),0);hi=np.minimum(np.ceil(q.max(0)).astype(int),W-1)
 if np.any(hi<lo):return np.empty(0,int),np.empty(0,int),np.empty((0,3))
 xx,yy=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));p=np.column_stack([xx.ravel()+.5,yy.ravel()+.5]);e=q[1]-q[0];f=q[2]-q[0];r=p-q[0];den=e[0]*f[1]-e[1]*f[0];b=(r[:,0]*f[1]-r[:,1]*f[0])/den;c=(e[0]*r[:,1]-e[1]*r[:,0])/den;bar=np.column_stack([1-b-c,b,c]);take=bar.min(1)>=-1e-9;return yy.ravel()[take],xx.ravel()[take],bar[take]
D=load('face_ear246');E=load('posed_ear239');A=load('ear_annulus240');H=load('host_ear_domain205');P,T,N,U,M=D['pos'],D['tri'],D['normal'],D['uv'],D['material'];materials=json.loads((R/'inputs/face_ear246_materials.json').read_text());platepath=R/'inputs/ear_albedo_plate251.png';plate=np.asarray(Image.open(platepath).convert('RGB'));reg=json.loads((R/'checks/ear_plate_registration252.json').read_text());assert reg['plate_png_sha256']==hashlib.sha256(platepath.read_bytes()).hexdigest() and reg['inliers']>=8 and reg['mapping_determinant']>.8;warp=np.asarray(reg['source_pixels_to_plate_800_pixels_matrix']);meta=json.loads((R/'renders/ear_albedo250/ear_albedo_315_+00.json').read_text());C=np.asarray(meta['camera_world_matrix']);scale=meta['ortho_scale']
def project(p):
 rel=p-C[:3,3];return np.column_stack([(.5+rel@C[:3,0]/scale)*size-.5,(.5-rel@C[:3,1]/scale)*size-.5,-rel@C[:3,2]])
# Read the exact exported float32 geometry for the camera visibility field.
g=GLB(R/'checks/peacock_face_ear246.glb');prs=g.j['meshes'][0]['primitives'];at=prs[0]['attributes'];GP=g.read(at['POSITION']).astype(float)[:,[0,2,1]];GP[:,1]*=-1;GT=np.concatenate([g.read(pr['indices']).reshape(-1,3) for pr in prs]);Q=project(GP);q=Q[GT];lo=np.maximum(np.ceil(q[:,:,:2].min(1)).astype(int),0);hi=np.minimum(np.floor(q[:,:,:2].max(1)).astype(int),size-1);depth=np.full((size,size),np.inf)
for fi in np.where(np.all(hi>=lo,axis=1))[0]:
 tr=q[fi];e=tr[1,:2]-tr[0,:2];f=tr[2,:2]-tr[0,:2];den=e[0]*f[1]-e[1]*f[0]
 if abs(den)<1e-12:continue
 xx,yy=np.meshgrid(np.arange(lo[fi,0],hi[fi,0]+1),np.arange(lo[fi,1],hi[fi,1]+1));r=np.column_stack([xx.ravel(),yy.ravel()])-tr[0,:2];b=(r[:,0]*f[1]-r[:,1]*f[0])/den;c=(e[0]*r[:,1]-e[1]*r[:,0])/den;bar=np.column_stack([1-b-c,b,c]);z=bar@tr[:,2];x=xx.ravel();y=yy.ravel();take=(bar.min(1)>=-1e-9)&(z<depth[y,x]);depth[y[take],x[take]]=z[take]
depth[~np.isfinite(depth)]=1e6;del GP,GT,Q,q
pose=json.loads((R/'checks/posed_ear203.json').read_text());transform=np.asarray(pose['native_to_world_matrix']);native=(E['rest_pos']-np.asarray(pose['target_center']))@np.linalg.inv(transform).T+np.asarray(pose['native_anchor']);nx,ny,nz=native.T;ellipse=np.sqrt(((ny-7.105)/.29)**2+((nz-.52)/.18)**2);pinna=np.maximum(smooth((-.735-nx)/.03),1-smooth((ellipse-.8)/.3));pinna*=smooth(E['root_geodesic_distance']/.004);outer=H['boundary_world'][:,[0,2]];stats={}
for name,mi,component,protect in [('native',8,E,pinna),('attachment',9,A,np.zeros(len(A['pos'])))]:
 ids=np.where(M==mi)[0];assert np.array_equal(P[T[ids]],component['pos'][component['tri']]);dist=inside_distance(component['pos'][:,[0,2]],outer);old=np.asarray(Image.open(materials[mi]['base_path']).convert('RGB'));rgb=old.copy();valid=np.zeros((W,W),bool);alphamap=np.zeros((W,W),np.uint8);coverage=[];applied=full=0;max_change=0
 for k,fi in enumerate(ids):
  yy,xx,bar=texels(U[T[fi]]);coverage.append(len(yy))
  if not len(yy):continue
  p=bar@P[T[fi]];normal=bar@N[T[fi]];normal/=np.linalg.norm(normal,axis=1)[:,None];v=project(p);z=map_coordinates(depth,[v[:,1],v[:,0]],order=1,mode='constant',cval=1e6);visible=smooth((.0008-abs(v[:,2]-z))/.0004);facing=smooth((normal@C[:3,2]-.05)/.3);ct=component['tri'][k];alpha=visible*facing*smooth((bar@dist[ct])/.0012)*(1-bar@protect[ct]);mapped=np.column_stack([v[:,:2],np.ones(len(v))])@warp;inside=(mapped.min(1)>=0)&(mapped.max(1)<size);alpha*=inside;paint=sample(plate,(mapped+.5)/size);color=np.clip(np.rint(srgb(linear(old[yy,xx]/255)*(1-alpha[:,None])+linear(paint/255)*alpha[:,None])*255),0,255).astype(np.uint8);color[alpha==0]=old[yy[alpha==0],xx[alpha==0]];rgb[yy,xx]=color;alphamap[yy,xx]=np.maximum(alphamap[yy,xx],np.rint(alpha*255).astype(np.uint8));valid[yy,xx]=True;applied+=int((alpha>1e-5).sum());full+=int((alpha>.999).sum());max_change=max(max_change,int(np.max(np.abs(color.astype(int)-old[yy,xx].astype(int)))))
  if k%3000==0:print('REGISTERED_BAKE',name,k,'/',len(ids),flush=True)
 assert min(coverage)>0
 distances,ind=distance_transform_edt(~valid,return_indices=True);pad=(~valid)&(distances<=8);rgb[pad]=rgb[ind[0][pad],ind[1][pad]];del distances,ind
 out=R/f'inputs/ear253_{name}_basecolor.png';Image.fromarray(rgb).save(out);Image.fromarray(alphamap).save(R/f'checks/ear253_{name}_plate_alpha.png');materials[mi]['base_path']=str(out);materials[mi]['name']+=' with registered scalp albedo repair';stats[name]={'texture_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'minimum_face_texel_centers':min(coverage),'painted_texel_samples':applied,'full_weight_texel_samples':full,'maximum_srgb_channel_change':max_change,'pinna_pigment_protected':mi==8,'padding_pixels':8}
# Identical immutable mesh bytes are linked, avoiding another full array copy.
target=R/'inputs/face_ear253.npz';assert not target.exists();os.link(R/'inputs/face_ear246.npz',target);(R/'inputs/face_ear253_materials.json').write_text(json.dumps(materials,indent=2));report={'mesh_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source_actual_glb_sha256':g.sha256,'plate_sha256':hashlib.sha256(platepath.read_bytes()).hexdigest(),'all_positions_normals_UVs_topology_material_indices_held_byte_equal':True,'all_ORM_images_held_byte_equal':True,'registration_inlier_RMS_pixels':reg['inlier_RMS_pixels'],'registration_mapping_determinant':reg['mapping_determinant'],'visibility_depth_tolerance_m':.0008,'outer_color_return_band_m':.0012,'charts':stats,'status':'Registered albedo trial. Exact exported PBR/unlit/front/profile/under regressions remain required; no geometry or character clearance.'};(R/'checks/face_ear253.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
