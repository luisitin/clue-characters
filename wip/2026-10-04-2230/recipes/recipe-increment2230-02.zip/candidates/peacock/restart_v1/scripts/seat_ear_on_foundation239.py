"""Seat the anatomical ear against a bounded source-constrained depth study.

The target is an interpolation, not observed hidden skull. A determinant-one
depth shear holds the front X/Z landmark projection. Remaining root correction
is limited by fixed-rest orientation and area gates before any assembled trial.
"""
from pathlib import Path
import numpy as np,json,hashlib
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
R=Path(__file__).resolve().parents[1]
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
D=load('posed_ear211');B=load('ear_foundation224');original=D['pos'].copy();P=original.copy();T=D['tri'];ring=D['boundary_vertex_ids'];root=P[ring];target=B['root_target_y'];X=np.column_stack([root[:,0]+.105,root[:,2]-.760,np.ones(len(root))]);beta=np.linalg.lstsq(X,target-root[:,1],rcond=None)[0];P[:,1]+=np.column_stack([P[:,0]+.105,P[:,2]-.760,np.ones(len(P))])@beta;posed=P.copy();J=np.array([[1.,0,0],[beta[0],1,beta[1]],[0,0,1]]);assert np.linalg.det(J)==1
edges=np.unique(np.sort(np.vstack([T[:,[0,1]],T[:,[1,2]],T[:,[2,0]]]),axis=1),axis=0);length=np.linalg.norm(P[edges[:,0]]-P[edges[:,1]],axis=1);W=coo_matrix((np.r_[1/length,1/length],(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(P),len(P))).tocsr();L=diags(np.asarray(W.sum(1)).ravel())-W;core=D['held_anatomical_core'];fixed=core.copy();fixed[ring]=True;free=np.where(~fixed)[0];hold=np.where(fixed)[0];dy=np.zeros(len(P));dy[ring]=target-P[ring,1];dy[free]=spsolve(L[free][:,free].tocsc(),-L[free][:,hold]@dy[hold]);restfn=np.cross(posed[T[:,1]]-posed[T[:,0]],posed[T[:,2]]-posed[T[:,0]]);restarea=np.linalg.norm(restfn,axis=1);attempts=[];chosen=None
for fraction in [1.,.75,.5,.25,0.]:
 trial=posed.copy();trial[:,1]+=fraction*dy;fn=np.cross(trial[T[:,1]]-trial[T[:,0]],trial[T[:,2]]-trial[T[:,0]]);area=np.linalg.norm(fn,axis=1);cos=np.sum(fn*restfn,axis=1)/(area*restarea);ratio=area/restarea;row={'root_residual_fraction':fraction,'minimum_fixed_rest_normal_cosine':float(cos.min()),'minimum_area_ratio':float(ratio.min()),'maximum_area_ratio':float(ratio.max())};attempts.append(row)
 if cos.min()>.5 and ratio.min()>.4 and ratio.max()<2.5:chosen=trial;break
assert chosen is not None;P=chosen;assert np.array_equal(P[:,[0,2]],original[:,[0,2]]);assert np.array_equal(P[core],posed[core]);fn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);N=np.zeros_like(P)
for k in range(3):np.add.at(N,T[:,k],fn)
N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30);D.update(pos=P,normal=N,pre_seating_pos=original,affine_seated_pos=posed);out=R/'inputs/posed_ear239.npz';np.savez_compressed(out,**D);residual=target-P[ring,1];report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256((R/'inputs/posed_ear211.npz').read_bytes()).hexdigest(),'interpolated_target_sha256':hashlib.sha256((R/'inputs/ear_foundation224.npz').read_bytes()).hexdigest(),'depth_shear_coefficients':beta.tolist(),'affine_jacobian_determinant':float(np.linalg.det(J)),'all_front_XZ_positions_byte_equal':True,'native_UV_topology_held':True,'anatomical_core_after_affine_pose_held_exact':True,'residual_trials':attempts,'chosen_residual_fraction':fraction,'remaining_root_target_residual_abs_mm':(np.percentile(abs(residual),[50,90,100])*1000).tolist(),'total_y_motion_minmax_mm':(np.array([(P[:,1]-original[:,1]).min(),(P[:,1]-original[:,1]).max()])*1000).tolist(),'status':'Isolated registration trial against an inferred source-constrained foundation. No actual/source-projected ear silhouette, full contact, annulus or material clearance yet.'};(R/'checks/posed_ear239.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
