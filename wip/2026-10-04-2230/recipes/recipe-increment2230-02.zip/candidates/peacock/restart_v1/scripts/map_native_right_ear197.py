"""Locate the native opposite ear by an exact rest-position mirror bijection.
Uses the existing original right-side faces and corner UVs; no reflected mesh is invented.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,json,hashlib
from scipy.spatial import cKDTree
R=Path(__file__).resolve().parents[1];S=R.parents[2]/'shared_sources/makehuman';a=np.load(R/'inputs/native_ear_domain193.npz');D={k:a[k] for k in a.files};a.close();V=D['native_pos'];left=D['native_quads'];a=np.load(S/'checks/native_donor.npz');allF=a['polygon_indices'].reshape(-1,4);allUV=a['polygon_uv_indices'].reshape(-1,4);bodyids=a['body_face_ids'];a.close();body=allF[bodyids];used=np.unique(left);bv=np.unique(body);target=V[used]*np.array([-1,1,1]);dist,ii=cKDTree(V[bv]).query(target);assert dist.max()<1e-12,dist.max();mapped=bv[ii];assert len(np.unique(mapped))==len(mapped);lookup={int(a):int(b) for a,b in zip(used,mapped)}
def cycle(q):return min(tuple(np.roll(q,k)) for k in range(4))
face_lookup={cycle(q):int(fi) for fi,q in zip(bodyids,body)};right_ids=[]
for q in left:
 want=np.array([lookup[int(v)] for v in q[::-1]]);assert cycle(want) in face_lookup;right_ids.append(face_lookup[cycle(want)])
right=allF[right_ids];E=Counter(tuple(sorted((int(a),int(b)))) for q in right for a,b in zip(q,np.roll(q,-1)));border=[e for e,c in E.items() if c==1];adj=defaultdict(list)
for a,b in border:adj[a].append(b);adj[b].append(a)
assert all(len(v)==2 for v in adj.values());start=min(adj);ring=[start];prev=None;cur=start
for _ in range(len(adj)+1):
 nxt=adj[cur][0] if adj[cur][0]!=prev else adj[cur][1]
 if nxt==start:break
 assert nxt not in ring;ring.append(nxt);prev,cur=cur,nxt
assert len(ring)==len(adj)==32;D['native_quads']=right;D['native_corner_uv']=allUV[right_ids];D['native_source_face_ids']=np.array(right_ids);D['native_boundary_vertex_ids']=np.array(ring);out=R/'inputs/native_ear_domain197.npz';np.savez_compressed(out,**D);report={'base_obj_sha256':hashlib.sha256((S/'raw/base.obj').read_bytes()).hexdigest(),'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'mapped_vertices':len(mapped),'maximum_native_mirror_position_error':float(dist.max()),'bijection':True,'uses_actual_native_right_faces_uv_and_winding':True,'quads':len(right),'boundary_vertices':len(ring),'native_bounds':[V[mapped].min(0).tolist(),V[mapped].max(0).tolist()],'status':'Right ear identity/provenance only. No Peacock fit or source cut.'};(R/'checks/native_right_ear197.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
