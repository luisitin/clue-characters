"""Audit an immutable geometric ear-attachment trial against retained character.
The full textured character remains held on disk. This assembled numeric trial
uses the exact178 POSITION data and the two explicitly named new components.
"""
from pathlib import Path
from collections import Counter
import numpy as np,json,hashlib
from audit_intersections_v4 import audit
R=Path(__file__).resolve().parents[1]
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
D=load('face_nosepaint178');S=load('source_clean1');H=load('host_ear_domain205');E=load('posed_ear211');A=load('ear_annulus216')
P,T,N=D['pos'],D['tri'],D['normal'];wanted=Counter(tuple(sorted(map(tuple,q))) for q in S['pos'][S['tri'][H['source_faces']]]);drop=np.zeros(len(T),bool);found=Counter()
for i,q in enumerate(P[T]):
 key=tuple(sorted(map(tuple,q)))
 if key in wanted:drop[i]=True;found[key]+=1
assert found==wanted
before=len(P);npiece=len(E['pos']);Q=np.vstack([P,E['pos'],A['pos']]);F=np.vstack([T[~drop],E['tri']+before,A['tri']+before+npiece]);NN=np.vstack([N,E['normal'],A['normal']]);parts=np.r_[np.zeros((~drop).sum(),int),np.ones(len(E['tri']),int),np.full(len(A['tri']),2,int)];ranges={'held':[0,int((~drop).sum())],'native_ear':[int((~drop).sum()),int((~drop).sum()+len(E['tri']))],'annulus':[int((~drop).sum()+len(E['tri'])),len(F)]}
# Exact shared outer/inner positions prove the local join closes topologically.
gp,g=np.unique(Q,axis=0,return_inverse=True);GF=g[F];EC=Counter(tuple(sorted((int(a),int(b)))) for tr in GF for a,b in zip(tr,np.roll(tr,-1)));newedges=set(tuple(sorted((int(a),int(b)))) for tr in GF[parts>0] for a,b in zip(tr,np.roll(tr,-1)));bad=[(list(e),EC[e]) for e in newedges if EC[e]!=2];assert not bad,bad[:20]
out=R/'inputs/ear_assembly217_geometry.npz';np.savez_compressed(out,pos=Q,normal=NN,tri=F,material=parts)
q=Q[F];lo=q.min(1);hi=q.max(1);selected=np.where(parts>0)[0];lower=lo[selected].min(0);upper=hi[selected].max(0);potential=np.all(hi>=lower,axis=1)&np.all(lo<=upper,axis=1);ids=np.where(potential)[0];used,inv=np.unique(F[ids],return_inverse=True);localF=inv.reshape(-1,3);localP=Q[used];bounds=np.r_[lower,upper].tolist();print(json.dumps({'stage':'COMPACT_READY','potential_triangles':len(ids),'new_triangles':len(selected),'new_edges_all_incidence2':True}),flush=True)
report=audit(localP,localF,bounds=bounds)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in report[key]:row['faces']=[int(ids[i]) for i in row['faces']]
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:report[key]=[[int(ids[i]) for i in row] for row in report[key]]
report['zero_area_faces']=[int(ids[i]) for i in report['zero_area_faces']]
def owner(i):return next(k for k,(a,b) in ranges.items() if a<=i<b)
crossowner=Counter(tuple(sorted(owner(i) for i in r['faces'])) for r in report['proper_crossings']);report.update(component_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),source178_sha256=hashlib.sha256((R/'inputs/face_nosepaint178.npz').read_bytes()).hexdigest(),component_face_ranges=ranges,removed_source_faces=H['source_faces'].tolist(),new_edges_all_incidence2=True,triangle_count=len(F),proper_crossing_component_counts={','.join(k):v for k,v in crossowner.items()},scope='Numeric assembled trial in float64. All new triangles versus conservative held-character AABB candidates. Local folds and exact exported appearance remain separate gates; no character clearance.')
(R/'checks/ear_assembly217_intersections_v4.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report.items()},indent=2),flush=True)
