"""Conservative spatial compaction before VTK's uniform-grid broad phase.
Every potential outside triangle is retained: its AABB must overlap the full selected-triangle union.
"""
import sys,json,hashlib,time
from pathlib import Path
import numpy as np
from audit_intersections_v4 import audit
from glb_io import GLB
R=Path(__file__).resolve().parents[1];name=sys.argv[1];region=sys.argv[2] if len(sys.argv)>2 else 'all';p=R/f'checks/peacock_{name}.glb';g=GLB(p);prs=g.j['meshes'][0]['primitives'];at=prs[0]['attributes'];P=g.read(at['POSITION']).astype(float)[:,[0,2,1]];P[:,1]*=-1;T=np.concatenate([g.read(pr['indices']).reshape(-1,3) for pr in prs]);part=np.concatenate([np.full(g.j['accessors'][pr['indices']]['count']//3,pr['material'],int) for pr in prs]);assert g.j['nodes'][0].get('scale',[1,1,1])==[1,1,1] and not any(k in g.j['nodes'][0] for k in ('matrix','rotation','translation'));regions={'chin':[-.015,-.080,.627,.012,-.050,.648],'nose':[.029,-.135,.727,.047,-.112,.741],'all':[-.068,-.18,.670,.084,-.069,.804],'left_eye':[-.057,-.16,.755,-.003,-.105,.795],'right_eye':[.018,-.16,.735,.064,-.09,.772],'mouth':[-.016,-.16,.673,.065,-.095,.716]};bounds=regions[region] if region not in ('eye_new','ear_new') else np.r_[P[T[np.isin(part,[8,9] if region=='ear_new' else [2,3,4])]].min(axis=(0,1)),P[T[np.isin(part,[8,9] if region=='ear_new' else [2,3,4])]].max(axis=(0,1))].tolist();q=P[T];lo=q.min(1);hi=q.max(1);selected=np.where(np.all(hi>=bounds[:3],axis=1)&np.all(lo<=bounds[3:],axis=1))[0];unionlo=lo[selected].min(0);unionhi=hi[selected].max(0);potential=np.all(hi>=unionlo,axis=1)&np.all(lo<=unionhi,axis=1);ids=np.where(potential)[0];assert np.all(potential[selected]);assert np.all(np.any((hi[~potential]<unionlo)|(lo[~potential]>unionhi),axis=1));used,inv=np.unique(T[ids],return_inverse=True);localT=inv.reshape(-1,3);localP=P[used];print(json.dumps({'stage':'COMPACT_READY','whole_triangles':len(T),'selected_triangles':len(selected),'potential_triangles':len(ids),'local_vertices':len(used),'union_bounds':[unionlo.tolist(),unionhi.tolist()]}),flush=True)
report=audit(localP,localT,bounds=bounds)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in report[key]:row['faces']=[int(ids[i]) for i in row['faces']]
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:
 report[key]=[[int(ids[i]) for i in row] for row in report[key]]
report['zero_area_faces']=[int(ids[i]) for i in report['zero_area_faces']];report.update(candidate_glb_sha256=g.sha256,whole_triangles=len(T),selected_triangles=len(selected),spatial_compaction_is_conservative=True,union_bounds=[unionlo.tolist(),unionhi.tolist()],global_face_indices_restored=True,scope='Actual exported float32 geometry; face IDs follow concatenated material primitives. Selected region versus all triangles with potentially intersecting AABBs; local topology only, not whole-character clearance')
(R/f'checks/{name}_{region}_exact_glb_intersections_v4.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report.items()},indent=2),flush=True)
