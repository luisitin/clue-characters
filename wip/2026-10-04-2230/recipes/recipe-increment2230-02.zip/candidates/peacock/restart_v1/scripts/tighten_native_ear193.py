"""Tighten the native ear domain in its anatomical lateral chart, retaining the concha.
No X-depth threshold is used: that would remove the recessed canal surface.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,json
R=Path(__file__).resolve().parents[1];a=np.load(R/'inputs/native_ear_domain190.npz');D={k:a[k] for k in a.files};a.close();V=D['native_pos'];Q=D['native_quads'];C=V[Q].mean(1);attempts=[];chosen=None
for ry,rz in [(.37,.28),(.40,.30),(.43,.33),(.46,.36)]:
 mask=((C[:,1]-7.12)/ry)**2+((C[:,2]-.54)/rz)**2<=1;ids=np.where(mask)[0];F=Q[ids];counts=Counter(tuple(sorted((int(a),int(b)))) for tr in F for a,b in zip(tr,np.roll(tr,-1)));border=[e for e,c in counts.items() if c==1];adj=defaultdict(list)
 for a,b in border:adj[a].append(b);adj[b].append(a)
 loops=[];remaining=set(adj)
 while remaining:
  start=min(remaining);loop=[start];previous=None;current=start
  for _ in range(len(adj)+2):
   if len(adj[current])!=2:break
   nxt=adj[current][0] if adj[current][0]!=previous else adj[current][1]
   if nxt==start:break
   if nxt in loop:break
   loop.append(nxt);previous,current=current,nxt
  remaining-=set(loop);loops.append(loop)
 used=np.unique(F);chi=len(used)-len(counts)+len(F);healthy=len(loops)==1 and all(len(v)==2 for v in adj.values()) and chi==1 and max(counts.values())==2;core=np.unique(Q[np.max(V[Q][:,:,0],axis=1)>.80]);core_held=np.isin(core,used).all();row={'chart_radii_yz':[ry,rz],'quads':len(F),'vertices':len(used),'euler':chi,'boundary_loops':list(map(len,loops)),'healthy_single_disk':healthy,'outermost_helix_vertices_held':bool(core_held),'bounds_native':[V[used].min(0).tolist(),V[used].max(0).tolist()]};attempts.append(row)
 if healthy and core_held and chosen is None:chosen=(ids,np.array(loops[0]));break
report={'attempts':attempts,'chosen':chosen is not None,'status':'Native-domain topology only; no Peacock fit/cut or appearance clearance.'}
if chosen:
 ids,b=chosen;D['native_quads']=Q[ids];D['native_corner_uv']=D['native_corner_uv'][ids];D['native_source_face_ids']=D['native_source_face_ids'][ids];D['native_boundary_vertex_ids']=b;np.savez_compressed(R/'inputs/native_ear_domain193.npz',**D);report['boundary_vertex_ids']=b.tolist()
(R/'checks/native_ear_domain193.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
