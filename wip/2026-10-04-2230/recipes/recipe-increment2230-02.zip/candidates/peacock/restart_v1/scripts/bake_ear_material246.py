"""Bake native/rest UV ear skin and registered source attachment materials.

The existing feature-free generated material175 supplies subtle grain. Named
healthy178 skin samples set the broad color. Source hair and the held outer
boundary transfer through exact source triangles/UVs, without geometry changes.
This is a material trial, not character/head approval.
"""
from pathlib import Path
from collections import Counter
import numpy as np,json,hashlib
from PIL import Image
from scipy.ndimage import distance_transform_edt
from subdivide_pose_ear208 import inside_distance
R=Path(__file__).resolve().parents[1];W=2048
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
def smooth(x):x=np.clip(x,0,1);return x*x*x*(10-15*x+6*x*x)
def linear(c):return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)
def srgb(c):return np.where(c<=.0031308,c*12.92,1.055*np.maximum(c,0)**(1/2.4)-.055)
def sample(im,uv):
 xy=uv*np.array([im.shape[1],im.shape[0]])-.5;ij=np.floor(xy).astype(int);f=xy-ij;x=np.clip(ij[:,0],0,im.shape[1]-1);y=np.clip(ij[:,1],0,im.shape[0]-1);x1=np.minimum(x+1,im.shape[1]-1);y1=np.minimum(y+1,im.shape[0]-1);fx=f[:,0,None];fy=f[:,1,None]
 return im[y,x]*(1-fx)*(1-fy)+im[y,x1]*fx*(1-fy)+im[y1,x]*(1-fx)*fy+im[y1,x1]*fx*fy
def pixels(uv):
 q=uv*W;lo=np.maximum(np.floor(q.min(0)).astype(int),0);hi=np.minimum(np.ceil(q.max(0)).astype(int),W-1)
 if np.any(hi<lo):return np.empty(0,int),np.empty(0,int),np.empty((0,3))
 xx,yy=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));p=np.column_stack([xx.ravel()+.5,yy.ravel()+.5]);e=q[1]-q[0];f=q[2]-q[0];r=p-q[0];det=e[0]*f[1]-e[1]*f[0]
 if abs(det)<1e-12:return np.empty(0,int),np.empty(0,int),np.empty((0,3))
 b=(r[:,0]*f[1]-r[:,1]*f[0])/det;c=(e[0]*r[:,1]-e[1]*r[:,0])/det;bar=np.column_stack([1-b-c,b,c]);take=bar.min(1)>=-1e-9;return yy.ravel()[take],xx.ravel()[take],bar[take]

B=load('face_nosepaint178');S=load('source_clean1');H=load('host_ear_domain205');E=load('posed_ear239');A=load('ear_annulus240');G=load('ear_assembly242_geometry');U=load('ear_atlas_layout231');Eold=load('posed_ear211');Aold=load('ear_annulus216')
assert np.array_equal(E['tri'],Eold['tri']) and np.array_equal(E['corner_uv'],Eold['corner_uv'])
assert np.array_equal(A['tri'],Aold['tri']) and np.array_equal(A['pos'][:,[0,2]],Aold['pos'][:,[0,2]])
materials=json.loads((R/'inputs/face_nosepaint178_materials.json').read_text());wanted=Counter(tuple(sorted(map(tuple,q))) for q in S['pos'][S['tri'][H['source_faces']]]);drop=np.zeros(len(B['tri']),bool);found=Counter()
for i,q in enumerate(B['pos'][B['tri']]):
 key=tuple(sorted(map(tuple,q)))
 if key in wanted:drop[i]=True;found[key]+=1
assert found==wanted;source_ids=np.where(drop)[0];assert np.array_equal(G['pos'][G['tri'][G['material']==0]],B['pos'][B['tri'][~drop]])
anchors=json.loads((R/'checks/ear_skin_anchors245.json').read_text())['anchors'];anchor_ids=[0,1,2,3];base=np.median(linear(np.array([anchors[i]['base_srgb255'] for i in anchor_ids])/255),axis=0);rough=float(np.median([anchors[i]['orm255'][1] for i in anchor_ids]));skin_aux=np.array([255.,rough,0.]);plate=np.asarray(Image.open(R/'inputs/skin_material175.png').convert('RGB'));plate_mean=plate.mean(axis=(0,1))
lo=A['pos'][:,[0,2]].min(0);hi=A['pos'][:,[0,2]].max(0);span=hi-lo
def source_uv(p):
 uv=(p[:,[0,2]]-lo)/span;uv[:,1]=1-uv[:,1];return (8+uv*(W-16))/W
depth=np.full((W,W),np.inf,np.float32);source_rgb=np.tile(np.rint(srgb(base)*255).astype(np.uint8),(W,W,1));source_orm=np.tile(skin_aux.astype(np.uint8),(W,W,1));source_valid=np.zeros((W,W),bool);images={}
for mat in np.unique(B['material'][source_ids]):
 for key in ['base_path','orm_path']:
  path=materials[int(mat)][key]
  if path not in images:images[path]=np.asarray(Image.open(path).convert('RGB'))
for fi in source_ids:
 q=B['pos'][B['tri'][fi]];e=q[1]-q[0];f=q[2]-q[0]
 if np.cross(e,f)[1]>=-1e-12:continue
 yy,xx,bar=pixels(source_uv(q))
 if not len(yy):continue
 z=bar@q[:,1];hit=z<depth[yy,xx]-1e-9;yy,xx,bar,z=yy[hit],xx[hit],bar[hit],z[hit];uv=bar@B['uv'][B['tri'][fi]];mat=materials[int(B['material'][fi])]
 source_rgb[yy,xx]=np.clip(np.rint(sample(images[mat['base_path']],uv)),0,255).astype(np.uint8);source_orm[yy,xx]=np.clip(np.rint(sample(images[mat['orm_path']],uv)),0,255).astype(np.uint8);depth[yy,xx]=z;source_valid[yy,xx]=True
del images,depth

def field(p,pinna,return_weight,outer_distance):
 uv=source_uv(p);old=sample(source_rgb,uv);aux=sample(source_orm,uv);ij=np.clip(np.floor(uv*W).astype(int),0,W-1);good=source_valid[ij[:,1],ij[:,0]]
 # A bounded material-only hair rule preserves the known posterior/upper brown
 # source regions. Gray jewellery is not classified as hair, and pinna skin is
 # protected explicitly in native anatomical coordinates.
 color_ratio=old[:,0]/np.maximum(old[:,1],1);brown=smooth((color_ratio-1.5)/.3)*smooth((145-old.mean(1))/45)
 spatial=np.maximum(smooth((-.111-p[:,0])/.006),smooth((p[:,2]-.783)/.010))
 hair=brown*spatial*(1-pinna);outer=1-smooth(outer_distance/.004);keep=np.maximum.reduce([return_weight,hair,outer]);keep*=1-pinna*.98
 missing=int(np.count_nonzero((keep>.01)&~good));keep[~good]=0
 grain=(sample(plate,np.mod((p[:,[0,2]]-np.array([-.12,.71]))/.04,1))-plate_mean)*.22;new_srgb=np.clip(srgb(base)*255+grain,0,255);new_lin=linear(new_srgb/255);rgb=srgb(linear(old/255)*keep[:,None]+new_lin*(1-keep[:,None]));orm=aux*keep[:,None]+skin_aux*(1-keep[:,None]);orm[:,0]=255
 return np.clip(np.rint(rgb*255),0,255).astype(np.uint8),np.clip(np.rint(orm),0,255).astype(np.uint8),missing

pose=json.loads((R/'checks/posed_ear203.json').read_text());M=np.asarray(pose['native_to_world_matrix']);anchor=np.asarray(pose['native_anchor']);center=np.asarray(pose['target_center']);native=(E['rest_pos']-center)@np.linalg.inv(M).T+anchor
nx,ny,nz=native.T;ellipse=np.sqrt(((ny-7.105)/.29)**2+((nz-.52)/.18)**2);pinna=np.maximum(smooth((-.735-nx)/.03),1-smooth((ellipse-.8)/.3));pinna*=smooth(E['root_geodesic_distance']/.004)
outer=H['boundary_world'][:,[0,2]];dE=inside_distance(E['pos'][:,[0,2]],outer);dA=inside_distance(A['pos'][:,[0,2]],outer);charts={};new_uv=[]
for name,D,uv,pm,rw,dist in [('native',E,U['native_corner_uv_png'],pinna,np.zeros(len(E['pos'])),dE),('attachment',A,U['annulus_corner_uv_png'],np.zeros(len(A['pos'])),A['source_return_weight'],dA)]:
 rgb=np.zeros((W,W,3),np.uint8);orm=np.zeros_like(rgb);valid=np.zeros((W,W),bool);coverage=[];missing=0
 for fi,tr in enumerate(D['tri']):
  yy,xx,bar=pixels(uv[fi]);coverage.append(len(yy))
  if not len(yy):continue
  p=bar@D['pos'][tr];color,aux,bad=field(p,bar@pm[tr],bar@rw[tr],bar@dist[tr]);rgb[yy,xx]=color;orm[yy,xx]=aux;valid[yy,xx]=True;missing+=bad
  if fi%3000==0:print('BAKE',name,fi,'/',len(D['tri']),flush=True)
 assert min(coverage)>0
 # Filtering padding is a data bake operation on the actual occupied chart.
 distances,indices=distance_transform_edt(~valid,return_indices=True);pad=(~valid)&(distances<=8);rgb[pad]=rgb[indices[0][pad],indices[1][pad]];orm[pad]=orm[indices[0][pad],indices[1][pad]];del distances,indices
 basepath=R/f'inputs/ear246_{name}_basecolor.png';ormpath=R/f'inputs/ear246_{name}_ORM.png';Image.fromarray(rgb).save(basepath);Image.fromarray(orm).save(ormpath);charts[name]={'image_size':[W,W],'occupied_texels':int(valid.sum()),'padded_texels':int(pad.sum()),'minimum_face_texel_centers':min(coverage),'source_needed_missing_texels_fell_back_to_generated_skin':missing,'basecolor_sha256':hashlib.sha256(basepath.read_bytes()).hexdigest(),'orm_sha256':hashlib.sha256(ormpath.read_bytes()).hexdigest()};materials.append({'name':'Anatomical ear skin' if name=='native' else 'Registered ear attachment skin and hair','base_path':str(basepath),'orm_path':str(ormpath),'occlusion_strength':0});new_uv.append(uv)

new=G['material']>0;newP=G['pos'][G['tri'][new]].reshape(-1,3);newN=G['normal'][G['tri'][new]].reshape(-1,3);UV=np.concatenate(new_uv).reshape(-1,2);P2=np.vstack([B['pos'],newP]);N2=np.vstack([B['normal'],newN]);U2=np.vstack([B['uv'],UV]);T2=np.vstack([B['tri'][~drop],np.arange(len(newP)).reshape(-1,3)+len(B['pos'])]);part=np.r_[B['material'][~drop],np.full(len(E['tri']),len(materials)-2),np.full(len(A['tri']),len(materials)-1)];assert np.array_equal(P2[T2],G['pos'][G['tri']]) and np.array_equal(N2[T2],G['normal'][G['tri']])
out=R/'inputs/face_ear246.npz';np.savez_compressed(out,pos=P2,normal=N2,uv=U2,tri=T2,material=part);(R/'inputs/face_ear246_materials.json').write_text(json.dumps(materials,indent=2));report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'geometry_parent_sha256':hashlib.sha256((R/'inputs/ear_assembly242_geometry.npz').read_bytes()).hexdigest(),'generated_material175_sha256':hashlib.sha256((R/'inputs/skin_material175.png').read_bytes()).hexdigest(),'atlas_layout231_sha256':hashlib.sha256((R/'inputs/ear_atlas_layout231.npz').read_bytes()).hexdigest(),'triangles':len(T2),'all_oriented_corner_positions_normals_equal_geometry_parent':True,'held178_corner_materials_UVs_unchanged':True,'healthy_skin_anchor_ids':anchor_ids,'base_srgb255':(srgb(base)*255).tolist(),'skin_roughness_255':rough,'charts':charts,'source_fields_projected_from_original_face_ids':source_ids.tolist(),'status':'Material-context trial only. Source misses, actual exported PBR/front/profile/under/top appearance, skin-hair boundaries and original-art fit still need inspection. No final head/character clearance.'};(R/'checks/face_ear246.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='source_fields_projected_from_original_face_ids'},indent=2))
