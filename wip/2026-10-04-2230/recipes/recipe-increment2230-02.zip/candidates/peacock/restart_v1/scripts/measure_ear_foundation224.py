"""Measure a source-constrained head foundation before changing the donor root.
The interpolation uses only the exact outer rim and its intact exterior faces;
the obsolete ear/lobe and the arbitrary donor root are excluded as controls.
"""
from pathlib import Path
from collections import defaultdict
import numpy as np,json
from scipy.interpolate import RBFInterpolator
R=Path(__file__).resolve().parents[1]
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
S,H,D,A=map(load,['source_clean1','host_ear_domain205','posed_ear211','ear_annulus216']);P,T=S['pos'],S['tri'];gp,G=np.unique(P,axis=0,return_inverse=True);F=G[T];E=defaultdict(list);old=set(map(int,H['source_faces']))
for fi,tr in enumerate(F):
 for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append(fi)
lookup={tuple(p):i for i,p in enumerate(gp)};ring=[lookup[tuple(p)] for p in H['boundary_world']];fs=[]
for a,b in zip(ring,np.roll(ring,-1)):
 out=[i for i in E[tuple(sorted((int(a),int(b))))] if i not in old];assert len(out)==1;fs.extend(out)
ctrl=gp[np.unique(F[fs])];xz,ii=np.unique(ctrl[:,[0,2]],axis=0,return_index=True);ctrl=ctrl[ii];base=RBFInterpolator(xz,ctrl[:,1],kernel='thin_plate_spline',smoothing=1e-12);root=D['pos'][D['boundary_vertex_ids']];delta=base(root[:,[0,2]])-root[:,1];AP=A['pos'];y=base(AP[:,[0,2]]);drift=y-AP[:,1]
np.savez_compressed(R/'inputs/ear_foundation224.npz',control_pos=ctrl,root_target_y=base(root[:,[0,2]]),annulus_target_y=y)
report={'controls':len(ctrl),'root_y_motion_minmax_mm':(np.array([delta.min(),delta.max()])*1000).tolist(),'root_y_motion_abs_percentiles_mm':(np.percentile(abs(delta),[50,90,100])*1000).tolist(),'annulus_y_motion_minmax_mm':(np.array([drift.min(),drift.max()])*1000).tolist(),'root_motion_rows':[{'world':p.tolist(),'target_y':float(v),'delta_mm':float(d*1000)} for p,v,d in zip(root,base(root[:,[0,2]]),delta)],'status':'Read-only source-constrained foundation measurement. No donor or source positions changed; this interpolation is not accepted anatomy without contact/silhouette tests.'};(R/'checks/ear_foundation224.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='root_motion_rows'},indent=2))
