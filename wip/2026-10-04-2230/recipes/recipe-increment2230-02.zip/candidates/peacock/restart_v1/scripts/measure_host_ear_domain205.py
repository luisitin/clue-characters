"""Read-only bounded anatomical source-ear replacement-domain study.
Includes the source ear/lobe geometry in a front-side prism, excludes physical eye domains,
and insists on one healthy original outer cycle before any replacement can be attempted.
"""
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1];p=R/'inputs/source_clean1.npz';a=np.load(p);P=a['pos'];T=a['tri'];N=a['normal'];a.close();q=P[T];C=q.mean(1);points,G=np.unique(P,axis=0,return_inverse=True);GT=G[T];E=defaultdict(list);VF=defaultdict(set)
for fi,tr in enumerate(GT):
 for x in tr:VF[int(x)].add(fi)
 for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append(fi)
eye=set()
for name in ['eye_left_domain103','eye_right_domain90']:
 a=np.load(R/f'inputs/{name}.npz');eye.update(map(int,a['source_faces']));a.close()
def proper_cross(a,b,c,d):
 def cross(u,v):return u[0]*v[1]-u[1]*v[0]
 x1=cross(b-a,c-a);x2=cross(b-a,d-a);y1=cross(d-c,a-c);y2=cross(d-c,b-c);return x1*x2<-1e-20 and y1*y2<-1e-20
attempts=[];chosen=None
for defect_radius in [.006,.008,.010,.012]:
 rx,rz,ymax=.034,.049,-.025
 eligible=(((C[:,0]+.107)/rx)**2+((C[:,2]-.751)/rz)**2<1)|(((C[:,0]+.08146)**2+(C[:,2]-.71331)**2)<defect_radius**2);eligible&=C[:,1]<ymax;eligible&=~((C[:,0]>-.075)&(C[:,2]>.743));selected=set(np.where(eligible)[0])-eye;failure=None
 for step in range(30):
  counts=Counter(tuple(sorted((int(a),int(b)))) for fi in selected for a,b in zip(GT[fi],np.roll(GT[fi],-1)));border=[e for e,n in counts.items() if n==1];deg=Counter(v for e in border for v in e);bad={v for v,n in deg.items() if n!=2};expand=set()
  for e in border:
   if len(E[e])!=2:expand.update(E[e])
  for v in bad:expand.update(VF[v])
  expand-=selected
  if not expand:break
  pts=C[list(expand)];inside=(pts[:,0]>-.16)&(pts[:,0]<-.065)&(pts[:,1]<.025)&(pts[:,2]>.68)&(pts[:,2]<.812)
  if not inside.all() or expand&eye:failure='Required boundary closure would leave bounded ear prism or touch held eye domain';break
  selected.update(expand)
 counts=Counter(tuple(sorted((int(a),int(b)))) for fi in selected for a,b in zip(GT[fi],np.roll(GT[fi],-1)));border=[e for e,n in counts.items() if n==1];adj=defaultdict(list)
 for a,b in border:adj[a].append(b);adj[b].append(a)
 loops=[];remaining=set(adj)
 while remaining:
  start=min(remaining);loop=[start];prev=None;cur=start
  for _ in range(len(adj)+2):
   if len(adj[cur])!=2:break
   nxt=adj[cur][0] if adj[cur][0]!=prev else adj[cur][1]
   if nxt==start:break
   if nxt in loop:break
   loop.append(nxt);prev,cur=cur,nxt
  remaining-=set(loop);loops.append(loop)
 healthy=len(loops)==1 and all(len(v)==2 for v in adj.values()) and all(len(E[e])==2 for e in border);crossings=[]
 if healthy:
  ring=points[loops[0]][:,[0,2]]
  for i in range(len(ring)):
   for j in range(i+2,len(ring)):
    if i==0 and j==len(ring)-1:continue
    if proper_cross(ring[i],ring[(i+1)%len(ring)],ring[j],ring[(j+1)%len(ring)]):crossings.append([i,j])
 margin=None
 if healthy:
  vv=points[loops[0]][:,[0,2]];dd=np.roll(vv,-1,axis=0)-vv;rr=np.array([-.08146,.71331])-vv;tt=np.clip(np.sum(rr*dd,axis=1)/np.sum(dd*dd,axis=1),0,1);margin=float(np.linalg.norm(rr-tt[:,None]*dd,axis=1).min())
 row={'added_defect_disk_radius':defect_radius,'fold_to_rim_margin_mm':None if margin is None else margin*1000,'ellipse_radii_xz':[rx,rz],'center_xz':[-.107,.751],'initial_y_max':ymax,'selected_faces':len(selected),'boundary_loops':list(map(len,loops)),'bad_degree_count':sum(len(v)!=2 for v in adj.values()),'bad_global_boundary_edge_count':sum(len(E[e])!=2 for e in border),'healthy_single_cycle':healthy,'front_chart_rim_crossings':crossings,'closure_failure':failure,'selected_bounds':[q[list(selected)].min(axis=(0,1)).tolist(),q[list(selected)].max(axis=(0,1)).tolist()]};attempts.append(row)
 if healthy and not crossings and failure is None and margin>=.0045 and chosen is None:chosen=(np.array(sorted(selected)),np.array(loops[0]));break
report={'minimum_requested_defect_margin_mm':4.5,'margin_rationale':'Reserves at least1.5mm for each side of the future junction plus explicit remaining clearance; actual fitted-ring containment remains a separate gate.','source_component_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'attempts':attempts,'candidate_found':chosen is not None,'status':'Read-only anatomical domain selection. Actual selected-surface/retained ownership, source silhouette, donor-root containment, normals and all local contacts must pass before cutting.'}
if chosen:
 ids,ring=chosen;np.savez_compressed(R/'inputs/host_ear_domain205.npz',source_faces=ids,boundary_position_groups=ring,boundary_world=points[ring]);report['source_face_ids']=ids.tolist();report['boundary_world']=points[ring].tolist()
(R/'checks/host_ear_domain205.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['source_face_ids','boundary_world']},indent=2))
