"""Measure the generated albedo plate's frame using held surrounding texture.
Image resampling is only for feature analysis. The original generated PNG is
preserved; later bakes sample it at full resolution through the fitted mapping.
"""
from pathlib import Path
import numpy as np,json,hashlib
from PIL import Image
from scipy.ndimage import gaussian_filter
from scipy.signal import correlate
R=Path(__file__).resolve().parents[1];srcpath=R/'renders/ear_albedo250/ear_albedo_315_+00.png';dstpath=R/'inputs/ear_albedo_plate251.png';im=Image.open(srcpath).convert('RGB');sz=im.size;assert sz==(800,800);a=np.asarray(im,dtype=np.float32);b=np.asarray(Image.open(dstpath).convert('RGB').resize(sz,Image.Resampling.LANCZOS),dtype=np.float32);weights=np.array([.2126,.7152,.0722]);a=gaussian_filter(a@weights,1.6);b=gaussian_filter(b@weights,1.6);half=23;radius=38;n=(2*half+1)**2;rows=[]
for y in range(65,736,45):
 for x in range(65,736,45):
  # The edited ear/scalp area provides no registration correspondences.
  if 220<x<610 and y>165:continue
  p=a[y-half:y+half+1,x-half:x+half+1];std=float(p.std())
  if std<7:continue
  p=p-p.mean();g=b[y-half-radius:y+half+radius+1,x-half-radius:x+half+radius+1];ones=np.ones(p.shape);total=correlate(g,ones,mode='valid',method='fft');energy=correlate(g*g,ones,mode='valid',method='fft')-total*total/n;cov=correlate(g,p,mode='valid',method='fft');score=cov/np.sqrt(np.maximum(energy,1e-9)*np.sum(p*p));iy,ix=np.unravel_index(np.argmax(score),score.shape);peak=float(score[iy,ix]);s2=score.copy();s2[max(0,iy-6):iy+7,max(0,ix-6):ix+7]=-np.inf;gap=peak-float(s2.max())
  if peak<.72 or gap<.018 or min(ix,iy)<2 or max(ix,iy)>2*radius-2:continue
  rows.append({'source_xy':[x,y],'plate_xy_in_800_frame':[x+int(ix)-radius,y+int(iy)-radius],'ncc':peak,'peak_gap':gap,'source_std':std})
assert len(rows)>=8,rows
S=np.array([r['source_xy'] for r in rows],float);D=np.array([r['plate_xy_in_800_frame'] for r in rows],float);X=np.column_stack([S,np.ones(len(S))]);rng=np.random.default_rng(252);best=None
for _ in range(600):
 ids=rng.choice(len(S),3,replace=False)
 if abs(np.linalg.det(X[ids]))<5000:continue
 B=np.linalg.solve(X[ids],D[ids]);det=float(np.linalg.det(B[:2]));
 if not .85<det<1.15 or np.max(abs(B[:2]-np.eye(2)))>.15:continue
 error=np.linalg.norm(X@B-D,axis=1);inside=error<5;quality=sum(rows[i]['ncc']**3 for i in np.where(inside)[0])
 if best is None or quality>best[0]:best=(quality,inside)
assert best is not None and best[1].sum()>=8
inside=best[1]
for _ in range(4):
 B=np.linalg.lstsq(X[inside],D[inside],rcond=None)[0];error=np.linalg.norm(X@B-D,axis=1);inside=error<5
assert inside.sum()>=8 and np.ptp(S[inside],axis=0).min()>300
for i,row in enumerate(rows):row.update(inlier=bool(inside[i]),affine_residual_pixels=float(error[i]))
report={'source_png_sha256':hashlib.sha256(srcpath.read_bytes()).hexdigest(),'plate_png_sha256':hashlib.sha256(dstpath.read_bytes()).hexdigest(),'source_dimensions':list(sz),'plate_dimensions':list(Image.open(dstpath).size),'source_pixels_to_plate_800_pixels_matrix':B.tolist(),'mapping_determinant':float(np.linalg.det(B[:2])),'matches':len(rows),'inliers':int(inside.sum()),'inlier_RMS_pixels':float(np.sqrt(np.mean(error[inside]**2))),'inlier_max_pixels':float(error[inside].max()),'inlier_source_span_pixels':np.ptp(S[inside],axis=0).tolist(),'matches_detail':rows,'scope':'Global frame registration from surrounding unedited hair/context only. The deliberately repaired hairline is not forced back to the old ragged edge. Does not prove a baked or exported appearance.'};(R/'checks/ear_plate_registration252.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='matches_detail'},indent=2))
