"""Verify the exported253 trial differs only in the two intended albedo maps."""
from pathlib import Path
import numpy as np,json,hashlib,copy
from glb_io import GLB
R=Path(__file__).resolve().parents[1];a=GLB(R/'checks/peacock_face_ear246.glb');b=GLB(R/'checks/peacock_face_ear253.glb');pa=a.j['meshes'][0]['primitives'];pb=b.j['meshes'][0]['primitives'];assert len(pa)==len(pb);checks={}
for key in ['POSITION','NORMAL','TEXCOORD_0']:
 aa=a.read(pa[0]['attributes'][key],False);bb=b.read(pb[0]['attributes'][key],False);checks[key]=np.array_equal(aa,bb);assert checks[key]
assert all(x['material']==y['material'] and np.array_equal(a.read(x['indices']),b.read(y['indices'])) for x,y in zip(pa,pb))
ma=copy.deepcopy(a.j['materials']);mb=copy.deepcopy(b.j['materials'])
for m in ma+mb:m.pop('name',None)
assert ma==mb
def images(g):
 out=[]
 for im in g.j['images']:
  v=g.j['bufferViews'][im['bufferView']];p=v.get('byteOffset',0);out.append(hashlib.sha256(g.bin[p:p+v['byteLength']]).hexdigest())
 return out
ia,ib=images(a),images(b);assert len(ia)==len(ib);changed=[i for i,(x,y) in enumerate(zip(ia,ib)) if x!=y];assert set(changed)<=set([16,18]) and 18 in changed
report={'source_glb_sha256':a.sha256,'candidate_glb_sha256':b.sha256,'all_mesh_accessors_byte_equal':checks,'all_index_arrays_and_material_indices_equal':True,'all_shader_values_except_names_equal':True,'changed_embedded_image_ids':changed,'all_original_face_and_all_ORM_image_bytes_equal':True,'scope':'Actual exported material-only identity proof. The246 ear-region geometric audit transfers;253 appearance still requires its own exact PBR/unlit/all-angle checks.'};(R/'checks/ear_material_identity254.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
