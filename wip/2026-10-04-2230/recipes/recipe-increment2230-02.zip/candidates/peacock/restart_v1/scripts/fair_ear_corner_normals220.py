"""Preserve source corner-normal seams while continuing ear attachment shading.

This trial carries the original normal semantics per new triangle corner and
keeps all held source data and oriented positions exact. Direction comparisons
normalize the source vectors, whose stored lengths are not necessarily one.
"""
from pathlib import Path
from collections import defaultdict
import numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1]
def load(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
D=load('ear_assembly217_geometry');A=load('ear_annulus216');P,T,N,part=D['pos'],D['tri'],D['normal'],D['material'];gp,G=np.unique(P,axis=0,return_inverse=True);GT=G[T];new=part>0;NF=T[new];fn=np.cross(P[NF[:,1]]-P[NF[:,0]],P[NF[:,2]]-P[NF[:,0]]);groupN=np.zeros_like(gp)
for k in range(3):np.add.at(groupN,G[NF[:,k]],fn)
groupN/=np.maximum(np.linalg.norm(groupN,axis=1)[:,None],1e-30);cornerN=groupN[G[NF]].copy();cornerP=P[NF].copy();newpart=part[new];no=int(A['outer_boundary_count']);outer=A['pos'][:no];oxz=outer[:,[0,2]];lookup={tuple(p):i for i,p in enumerate(gp)};og=[lookup[tuple(p)] for p in outer];E=defaultdict(list)
for fi in np.where(part==0)[0]:
 for a,b in zip(GT[fi],np.roll(GT[fi],-1)):E[tuple(sorted((int(a),int(b))))].append(fi)
source_faces=[];source_pos=[];source_norm=[]
for a,b in zip(og,np.roll(og,-1)):
 fs=E[tuple(sorted((int(a),int(b))))];assert len(fs)==1;fi=fs[0];source_faces.append(fi);source_pos.append(P[T[fi]]);source_norm.append(N[T[fi]])
source_pos=np.array(source_pos);source_norm=np.array(source_norm);edge=np.roll(oxz,-1,axis=0)-oxz
af=np.where(newpart==2)[0];cent=cornerP[af].mean(1)[:,[0,2]];rel=cent[:,None,:]-oxz[None,:,:];tt=np.clip(np.sum(rel*edge,axis=2)/np.sum(edge*edge,axis=1),0,1);dist=np.linalg.norm(rel-tt[:,:,None]*edge,axis=2);nearest=np.argmin(dist,axis=1);inv=np.linalg.inv(np.concatenate([source_pos[:,:,[0,2]],np.ones((no,3,1))],axis=2));corner_distance=[]
for idx,j in zip(af,nearest):
 q=cornerP[idx][:,[0,2]];r=q[:,None,:]-oxz[None,:,:];t=np.clip(np.sum(r*edge,axis=2)/np.sum(edge*edge,axis=1),0,1);dd=np.linalg.norm(r-t[:,:,None]*edge,axis=2).min(1);bar=np.column_stack([q,np.ones(3)])@inv[j];prior=bar@source_norm[j];prior/=np.linalg.norm(prior,axis=1)[:,None];x=np.clip(dd/.002,0,1);w=x*x*x*(10-15*x+6*x*x);cornerN[idx]=(1-w[:,None])*prior+w[:,None]*cornerN[idx];cornerN[idx]/=np.linalg.norm(cornerN[idx],axis=1)[:,None]

# Every outer boundary triangle follows exactly the retained face's three
# authored normals, extrapolated across its short geometric tangent wedge.
AE=defaultdict(list)
for fi in af:
 for a,b in zip(G[NF[fi]],np.roll(G[NF[fi]],-1)):AE[tuple(sorted((int(a),int(b))))].append(int(fi))
maximum=0
for j,(a,b) in enumerate(zip(og,np.roll(og,-1))):
 fs=AE[tuple(sorted((int(a),int(b))))];assert len(fs)==1;fi=fs[0];q=cornerP[fi][:,[0,2]];bar=np.column_stack([q,np.ones(3)])@inv[j];prior=bar@source_norm[j];prior/=np.linalg.norm(prior,axis=1)[:,None];cornerN[fi]=prior
 for group in [a,b]:
  nc=np.where(G[NF[fi]]==group)[0][0];sc=np.where(GT[source_faces[j]]==group)[0][0];maximum=max(maximum,float(np.degrees(np.arccos(np.clip(cornerN[fi,nc]@(N[T[source_faces[j],sc]]/np.linalg.norm(N[T[source_faces[j],sc]])),-1,1)))))
assert maximum<.001,maximum
newP=cornerP.reshape(-1,3);newN=cornerN.reshape(-1,3);newT=np.arange(len(newP)).reshape(-1,3)+len(P);P2=np.vstack([P,newP]);N2=np.vstack([N,newN]);T2=np.vstack([T[~new],newT]);part2=np.r_[part[~new],newpart];assert np.array_equal(P2[T2],P[T])
out=R/'inputs/ear_assembly220_geometry.npz';np.savez_compressed(out,pos=P2,normal=N2,tri=T2,material=part2);report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'parent_sha256':hashlib.sha256((R/'inputs/ear_assembly217_geometry.npz').read_bytes()).hexdigest(),'oriented_triangle_corner_positions_byte_equal':True,'all_held_source_corner_normals_byte_equal':True,'outer_authored_corner_normal_join_max_degrees':maximum,'new_corner_attributes_expanded_to_preserve_existing_source_seams':True,'source_normal_return_band_mm':2,'scope':'Normal-only continuation on217 numeric trial. Source per-corner shading semantics are preserved instead of averaged. Geometry checks transfer; visible shading and exported GLB regressions remain open.'};(R/'checks/ear_corner_normals220.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
