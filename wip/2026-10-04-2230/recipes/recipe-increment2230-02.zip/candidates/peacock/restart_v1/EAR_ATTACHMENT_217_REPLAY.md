# Peacock anatomical-ear attachment study217

This is an unfinished, unpainted geometry study. The coherent painted WIP remains178. The original178 files are unchanged. The new ear has real helix, concha and tragus geometry, but its fit, shading, ear jewellery and material appearance have not passed the complete head gate.

## Provenance

The anatomical data comes from MakeHuman's CC0 base asset at commit a8bc2d54ff0ac92e78ff71431b1023eda42bf482. The base.obj SHA-256 is8e761e6624b8f54536409135d1636da63b32486a90d4897f84e121d144f6fb4c. The CC0 data license is separate from the program's code license. Shared native topology is loaded from shared_sources/makehuman/checks/native_donor.npz using its retained loader and pinned OBJ.

inputs/sources/l-ear-scale-incr189.target is an unchanged official CC0 target file used only as an anatomical support hint. Its morph is never applied. Its SHA-256 is8112e638fb6ecc46569c527494f5b20acd0c5544d891dbf09c7876402eac384c; full pinned path and Git blob are in checks/native_ear_target189.json.

## Reproduction order

1. extract_native_ear190.py finds the target-supported native region. tighten_native_ear193.py chooses a bounded371-quad disk with one32-node root; the recessed concha is preserved. map_native_right_ear197.py identifies the actual native right-side faces by an exact mirrored vertex bijection, preserving their original winding and corner UVs. It does not manufacture reflected triangle attributes.
2. measure_host_ear_domain205.py selects683 original faces around the old ear, fused lobe/jewellery and lower attachment fold. It excludes both repaired eye domains and yields one63-node healthy original rim. audit_host_ear_boundary206.py checks the exterior face and shading ownership; the diagnosed lower fold lies4.5795mm inside this rim.
3. pose_native_ear203.py applies the recorded positive-determinant affine transform. subdivide_pose_ear208.py performs two native Catmull-Clark levels and a monotone compression confined to the upper plain attachment. This intermediate's root still exceeds the source domain and is not an accepted fit.
4. fit_ear_root211.py chooses a0.86 root-chart scale with1.961mm sampled host clearance. A positive graph Laplacian extends the displacement while exactly holding5165 vertices at least8mm geodesically from the root. Its fixed-parent normal cosine remains positive, with no triangle collapse. These are local preflights, not whole-surface clearance.
5. build_ear_annulus216.py constructs a constrained Triangle annulus from the exact63-node source rim to the128-node subdivided native root. Both sides have explicit geometric tangent wedges. A bounded height solve joins them; healthy source depth returns outside the original-ear and lower-lobe reconstruction masks. The earlier212 mask incorrectly returned to obsolete fused lobe/jewellery relief and produced11 visible sharp folds;216 excludes that measured footprint.
6. audit_ear_assembly217.py creates an immutable numeric trial against178 and conservatively checks all potentially intersecting retained triangles. All new edges have incidence2. Its219513 total triangles include11872 native-ear and4741 attachment triangles. V4 reports zero proper crossings, positive-area coplanar overlaps, exact triangle copies, collapsed triangles or shared-edge folds above105degrees. The maximum tested adjacent angle is75.71degrees, so curvature and appearance still need inspection.
7. render_ear_assembly214.py is the bounded clay renderer. The saved217 front and315-degree close views under renders/ear_assembly218 confirm that216 removes the lower folded tear visible in213. They still expose boundary shading and broad lower attachment curvature. These are NPZ-bound geometry studies, not exact exported-GLB or painted appearance evidence.

The additional normal-only220 study continues source corner shading and shared native/annular normals without changing any oriented triangle position. It remains a separate unaccepted shading trial until its saved comparisons are inspected.

## Dependencies and scope

The scripts use NumPy, SciPy, the official Triangle module under shared_tools/triangle_lib, and the retained V4 helpers audit_intersections_v4.py/exact_triangle_pair.py. Rendering uses Blender4.3.2. Heavy stages acquire the shared external flock before allocating their inputs, with separate per-stage launch logs.

The ear attachment has no final UV atlas or authored skin/hair material yet. The original head identity, current eyes, mouth and178 face paint remain held outside the selected domain. Source skin/hair-boundary form, jewellery, top/under/opposite views and actual float32 exported contacts remain open. The ear study does not clear the other ear, neck, hat/feather, collar or body defects.
