# Peacock anatomical-ear and registered-paint study253

This is a local ear refinement in an unfinished character. The held coherent reference checkpoint remains178. Study253 has not passed the complete head or character review.

Exact GLB: checks/peacock_face_ear253.glb, SHA-256218578737fb97594419893cbee341ad81b2cf399fb2abac4c317f49bc9cfd3f7,219513 triangles. Its mesh NPZ is byte-identical to246, SHA-2565859c5a0b21389cf211065e2a13b78289fc913813289f6a2e68b08c70aa41b89. The two local names share an immutable hardlink; their material manifests differ.

## Build order after the retained217 recipe

1. measure_ear_foundation224.py estimates a head-depth field from90 intact exterior/rim controls. This is an interpolation, not observed hidden skull anatomy.
2. seat_ear_on_foundation239.py applies a determinant-one depth shear while holding every front X/Z point. Only25percent of the remaining root correction passed the fixed-rest normal/area limits; larger fractions were rejected. The remaining target discrepancy is documented, not silently treated as an exact fit.
3. build_ear_annulus240.py joins the exact original63-node outer rim to the128-node native ear root. audit_ear_assembly241.py checks the new ear/attachment against all potentially intersecting retained geometry. fair_ear_corner_normals242.py continues the original corner-normal semantics. Direction checks normalize the stored source vectors before comparing angles.
4. audit_ear_uv231.py provides two2048-pixel charts. Native UVs are affine-repacked from the original donor; the attachment uses its positive X/Z chart.239 retains the native UV/topology and240 retains216's exact X/Z triangulation, so the231 layout remains identical. It has zero strict interior overlapping texel centers and no unsampled faces, with minimum coverage4 and3 centers. Both maps have8-pixel filtering padding.
5. sample_ear_skin245.py reads six exact nearby skin/material anchors from178. bake_ear_material246.py uses the first four plus the preserved feature-free generated material175. This first color trial is rejected as a final appearance: it exposed an obsolete painted ear outline and ragged skin/hair color boundaries.
6. Export246 with export_layered51.py. audit_glb_region248.py face_ear246 ear_new checks actual exported float32 geometry. The bounded region reports zero proper crossings, positive-area coplanar overlaps, exact copies, collapsed triangles and edge folds above105degrees. This is not a whole-character contact claim.
7. inputs/ear_albedo_plate251.png is a new nondeterministic image-generation input, SHA-25600be3c4c9e33378a98b4d35a391fe30b7f8bcb44697896dac6261a3ef00862bb. Its complete prompt and source roles are in checks/ear_albedo_plate251_provenance.json. It repairs the actual246 unlit camera view, preserving a flat skin albedo without drawing another ear or jewellery. It is not a model render or approval image.
8. register_ear_plate252.py measures the global frame from surrounding unedited texture.56 of58 matches fit with1.074-pixel RMS and determinant0.998310. The saved mapping and exact camera JSON are consumed by bake_ear_plate253.py. The deliberately repaired hairline is not warped back to the old ragged edge.
9. bake_ear_plate253.py protects native pinna pigmentation and applies the registered plate to visible scalp/attachment texels, returning to the held outer color at the boundary. All mesh/UV/index data and ORM maps remain unchanged. Export253 and run verify_ear_material_variant254.py. It verifies that only embedded base-color images16 and18 differ; all mesh accessors, indices, material indices, other images and shader values are identical.

## Existing appearance evidence

The actual253 front and315-degree PBR views are in renders/face_ear253_export. They show real pinna relief and removal of246's duplicate painted ear outline, with a cleaner hair transition. The broader form below the lobe remains a shape observation to compare with the original source/art jaw angle before further sculpting.242's front,270-degree profile, under and top clay views are in renders/ear_regression244. Exact253 PBR under/profile regressions are still required.

The pearl earring is not yet restored. The other ear, original neck fragmentation, hat/feather/hair defects, collar/necklace and remaining body/hand/coat/shoe work are open. No completed-head or completed-character claim is made.

## Compact recovery inputs

Preserve the unique251 PNG and provenance. Useful small binary state is inputs/posed_ear239.npz, inputs/ear_annulus240.npz and inputs/ear_atlas_layout231.npz. The canonical editable178 NPZ retains exact double-precision source correspondence; its manifest/texture dependencies accompany its held GLB. The generated material175 was already a required face-paint input. The new246/253 maps are deterministic bakes from these inputs and recipes, but a clean-room end-to-end replay has not yet been performed.

Native anatomy remains the pinned MakeHuman CC0 asset described by the preceding217 provenance. No donor face replaced Peacock's original face identity.
