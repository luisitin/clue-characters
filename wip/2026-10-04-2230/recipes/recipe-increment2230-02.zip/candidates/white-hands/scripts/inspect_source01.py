import sys,pathlib,numpy as np,json,hashlib
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white';sys.path.insert(0,str(owner/'scripts'));from glb_io import read_glb
src=owner/'models/white_25_continuous_neck_paint_trial.glb';j,b,a=read_glb(src);q=j['meshes'][0]['primitives'][0];P=a(q['attributes']['POSITION']);N=a(q['attributes']['NORMAL']);UV=a(q['attributes']['TEXCOORD_0']);F=a(q['indices']).reshape(-1,3);node=j['nodes'][0];W=(P*node['scale']+node['translation'])[:,[0,2,1]]*[1,-1,1];C=W[F].mean(1);raw=np.load(owner/'checks/white_22_source_face_lineage.npz')['retained_original_raw_faces'];assert len(raw)==len(F)+84
# White25 neck material partition: recover current0 original face ID by exact face position lookup.
jo,bo,ao=read_glb(owner/'models/white_22_forehead_family_cleanup.glb');fo=ao(jo['meshes'][0]['primitives'][0]['indices']).reshape(-1,3);lookup={tuple(f):int(v)for f,v in zip(fo,raw)};raw0=np.array([lookup[tuple(f)]for f in F]);report={'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'bounds_world':[W.min(0).tolist(),W.max(0).tolist()]}
for side,sgn in [('left',-1),('right',1)]:
 selected=(C[:,0]*sgn>.14)&(C[:,0]*sgn<.36)&(C[:,2]>.05)&(C[:,2]<.35)
 ids=np.flatnonzero(selected);np.savez_compressed(r/'checks'/f'source01_{side}.npz',P=P,N=N,UV=UV,F=F,W=W,region_faces=ids,raw_face_ids=raw0,node_scale=node['scale'],node_translation=node['translation']);report[side]={'faces':len(ids),'bounds':[W[F[ids]].min((0,1)).tolist(),W[F[ids]].max((0,1)).tolist()]}
(r/'checks/source01_inspection.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
