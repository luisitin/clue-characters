"""Read-only exact retained-side ownership, connected components and chart diagnostics."""
import pathlib,os,json,numpy as np,collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
def polygon_check(q):
 n=len(q);cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
 area=.5*sum(cross(q[i],q[(i+1)%n])for i in range(n));valid=True
 for i in range(n):
  a,b=q[i],q[(i+1)%n]
  if np.linalg.norm(b-a)<1e-10:valid=False
  for j in range(i+2,n):
   if i==0 and j==n-1:continue
   c,d=q[j],q[(j+1)%n];u=cross(b-a,c-a);v=cross(b-a,d-a);x=cross(d-c,a-c);y=cross(d-c,b-c)
   if u*v < -1e-20 and x*y < -1e-20:valid=False
 return valid,abs(area)

r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','left');z=np.load(r/'checks'/f'source01_{side}.npz');domain=os.environ.get('DOMAIN','14');rings=os.environ.get('RINGS','2');d=np.load(r/'checks'/f'domain{domain}_{side}_{rings}.npz');colors=np.load(r/'checks'/f'source03_{side}_colors.npz')['RGB'];F=z['F'];P=z['P'];W=z['W'];U,iv=np.unique(P,axis=0,return_inverse=True);G=iv[F];selected=np.zeros(len(F),bool);selected[d['selected_faces']]=True;edges=collections.defaultdict(list)
for fi,face in enumerate(G):
 for a,b in zip(face,np.roll(face,-1)):edges[tuple(sorted((int(a),int(b))))].append(fi)
pairs=[]
for e,fs in edges.items():
 remain=[f for f in fs if not selected[f]]
 for i,a in enumerate(remain):
  for b in remain[i+1:]:pairs.append((a,b))
pair=np.array(pairs);mat=coo_matrix((np.ones(len(pair)),(pair[:,0],pair[:,1])),shape=(len(F),len(F)));_,labels=connected_components(mat,directed=False);C=W[F].mean(1);tri=W[F];fn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);fn/=np.maximum(np.linalg.norm(fn,axis=1)[:,None],1e-20);reports=[]
for k,(a,b)in enumerate(zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])):
 ids=d['loop_vertices'][a:b];points=d['unique_world_positions'][ids];ret=[]
 for x,y in zip(ids,np.roll(ids,-1)):
  fs=edges[tuple(sorted((int(x),int(y))))];remain=[f for f in fs if not selected[f]];assert len(remain)==1;ret.append(remain[0])
 groups=[]
 for lab in set(labels[ret]):
  fs=np.flatnonzero((labels==lab)&~selected);groups.append({'label':int(lab),'retained_faces':len(fs),'raw_ids_if_small':z['raw_face_ids'][fs].tolist()if len(fs)<200 else None,'bounds':[W[F[fs]].min((0,1)).tolist(),W[F[fs]].max((0,1)).tolist()]})
 charts=[]
 for cols in [[1,2],[0,2],[0,1]]:
  valid,area=polygon_check(points[:,cols]);charts.append({'columns':cols,'simple':valid,'area':area})
 rep={'loop':k,'vertices':len(ids),'center':points.mean(0).tolist(),'retained_raw_ids':z['raw_face_ids'][ret].tolist(),'retained_rgb_mean':colors[ret].mean(0).tolist(),'retained_normal_mean':fn[ret].mean(0).tolist(),'retained_connected_components':groups,'charts':charts};reports.append(rep)
(r/'checks'/f'interfaces15_{side}.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2),flush=True)
