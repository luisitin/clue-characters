"""Read-only physical return-loop projection search; no source or boundary movements."""
import pathlib,os,json,numpy as np,math
r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','right');prefix='16'if side=='right'else'14';rings='4'if side=='right'else'2';d=np.load(r/'checks'/f'domain{prefix}_{side}_{rings}.npz');s=np.load(r/'checks'/f'source01_{side}.npz');meta=json.load((r/'checks'/f'interfaces15_{side}.json').open());loop=next(q['loop']for q in meta if q['vertices']>80 and abs(q['center'][0])<.29);a,b=d['loop_offsets'][loop:loop+2];ids=d['loop_vertices'][a:b];P=d['unique_world_positions'][ids];n=len(P);A=P;B=np.roll(P,-1,axis=0);ii,jj=np.triu_indices(n,2);use=~((ii==0)&(jj==n-1));ii,jj=ii[use],jj[use];v1=np.cross(B[ii]-A[ii],A[jj]-A[ii]);v2=np.cross(B[ii]-A[ii],B[jj]-A[ii]);v3=np.cross(B[jj]-A[jj],A[ii]-A[jj]);v4=np.cross(B[jj]-A[jj],B[ii]-A[jj]);F=s['F'];raw=s['raw_face_ids'];lookup={int(k):i for i,k in enumerate(raw)};rr=[lookup[k]for k in meta[loop]['retained_raw_ids']];tri=s['W'][F[rr]];N=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-20);sgn=1 if side=='right'else-1;result=[];best_cross=None
for elev in np.arange(-80,81,4):
 for yaw in np.arange(-80,81,4):
  e,y=np.radians([elev,yaw]);normal=np.array([sgn*np.cos(e)*np.cos(y),np.cos(e)*np.sin(y),np.sin(e)]);u1=v1@normal;u2=v2@normal;w1=v3@normal;w2=v4@normal;proper=(u1*u2<-1e-22)&(w1*w2<-1e-22);count=int(proper.sum());score=float((N@normal).min())
  if best_cross is None or count<best_cross['proper_crossings']:best_cross={'yaw':int(yaw),'elevation':int(elev),'proper_crossings':count,'normal':normal.tolist()}
  if count:continue
  axis=np.array([0.,0.,1.]);axis-=normal*(axis@normal);axis/=np.linalg.norm(axis);other=np.cross(normal,axis);Q=(P-P.mean(0))@np.array([other,axis]).T;edge=np.roll(Q,-1,axis=0)-Q;touch=False
  if np.linalg.norm(edge,axis=1).min()<1e-7:continue
  candidates=np.flatnonzero((u1*u2<=1e-24)&(w1*w2<=1e-24))
  for k in candidates:
   i,j=ii[k],jj[k];lo1=np.minimum(Q[i],Q[(i+1)%n]);hi1=np.maximum(Q[i],Q[(i+1)%n]);lo2=np.minimum(Q[j],Q[(j+1)%n]);hi2=np.maximum(Q[j],Q[(j+1)%n]);
   if np.all(hi1>=lo2-1e-10)and np.all(hi2>=lo1-1e-10):touch=True;break
  if touch:continue
  area=.5*abs(np.sum(Q[:,0]*np.roll(Q[:,1],-1)-Q[:,1]*np.roll(Q[:,0],-1)));result.append({'yaw':int(yaw),'elevation':int(elev),'normal':normal.tolist(),'axis_u':other.tolist(),'axis_v':axis.tolist(),'minimum_retained_normal_dot':score,'projected_area':float(area)})
result.sort(key=lambda q:(q['minimum_retained_normal_dot'],q['projected_area']),reverse=True);report={'side':side,'loop':int(loop),'vertices':n,'best_strict_crossing_count':best_cross,'simple_chart_count':len(result),'best_simple_charts':result[:10],'all_world_positions_held':True,'scope':'Read-only projection search. A simple projected boundary alone does not certify tangent compatibility, filling, source ownership or visual fit.'};(r/'checks'/f'return_chart24_{side}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
