import sys,pathlib,numpy as np,json,io,collections
from PIL import Image
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white';sys.path.insert(0,str(owner/'scripts'));from glb_io import read_glb
j,b,a=read_glb(owner/'models/white_25_continuous_neck_paint_trial.glb');pr=j['meshes'][0]['primitives'][0];q=j['textures'][j['materials'][0]['pbrMetallicRoughness']['baseColorTexture']['index']];ii=q.get('source',q.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];im=np.array(Image.open(io.BytesIO(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB'));H,Wi=im.shape[:2];reports={}
for side,sgn in [('left',-1),('right',1)]:
 z=np.load(r/'checks'/f'source01_{side}.npz');P=z['P'];F=z['F'];UV=z['UV'];W=z['W'];raw=z['raw_face_ids'];ids=z['region_faces'];uv=UV[F].mean(1);rgb=im[(uv[:,1]*H).astype(int).clip(0,H-1),(uv[:,0]*Wi).astype(int).clip(0,Wi-1)].astype(float);C=W[F].mean(1);skin=(rgb[:,0]>rgb[:,1]*1.22)&(rgb[:,0]>rgb[:,2]*1.4)&(rgb[:,0]>65)&(rgb[:,1]>25);chosen=ids[skin[ids]];_,vi=np.unique(P,axis=0,return_inverse=True);edge={};rows=[];cols=[]
 for fi in chosen:
  for va,vb in zip(vi[F[fi]],np.roll(vi[F[fi]],-1)):
   key=tuple(sorted((int(va),int(vb))))
   for prev in edge.get(key,[]):rows.append(int(fi));cols.append(prev)
   edge.setdefault(key,[]).append(int(fi))
 mat=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(F),len(F)));_,lab=connected_components(mat,directed=False);groups=[]
 for k,c in collections.Counter(lab[chosen]).most_common(20):
  fs=chosen[lab[chosen]==k];q=W[F[fs]];groups.append({'label':int(k),'faces':int(c),'bounds':[q.min((0,1)).tolist(),q.max((0,1)).tolist()],'center':C[fs].mean(0).tolist(),'raw_ids':raw[fs].tolist()})
 # Obtain spatial cross-sections to assess whether hand/cuff is a standalone appendage.
 slices=[]
 for height in [.14,.18,.22,.26,.30]:
  sel=ids[(C[ids,2]>height-.015)&(C[ids,2]<height+.015)];slices.append({'height':height,'skin_bounds':[C[sel[skin[sel]]].min(0).tolist(),C[sel[skin[sel]]].max(0).tolist()] if skin[sel].any()else None})
 reports[side]={'skin_groups':groups,'sections':slices};np.savez_compressed(r/'checks'/f'source03_{side}_colors.npz',RGB=rgb,skin_faces=chosen,skin_labels=lab[chosen])
(r/'checks/source03_segments.json').write_text(json.dumps(reports,indent=2));print({s:{'groups':[{k:v for k,v in x.items()if k!='raw_ids'}for x in q['skin_groups'][:6]],'slices':q['sections']}for s,q in reports.items()},flush=True)
