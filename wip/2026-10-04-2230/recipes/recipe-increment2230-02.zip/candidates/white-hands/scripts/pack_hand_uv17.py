"""Pack native per-corner hand islands by rigid UV transforms; audit actual texel multiplicity."""
import pathlib,os,json,numpy as np,collections,itertools,hashlib
r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','R');src=r/'checks'/f'fist_seed13_{side}.npz';z=np.load(src);T=z['T'];UV=z['UVcorner'].astype(float);P=z['P'];parent=np.arange(len(T));edges={}
def root(a):
 while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
 return a
for fi,f in enumerate(T):
 for k in range(3):
  l=(k+1)%3;a=(int(f[k]),*UV[fi,k]);b=(int(f[l]),*UV[fi,l]);key=tuple(sorted((a,b)))
  if key in edges:
   x,y=root(fi),root(edges[key]);parent[max(x,y)]=min(x,y)
  else:edges[key]=fi
labels=np.array([root(i)for i in range(len(T))]);unique=np.unique(labels);groups=[np.flatnonzero(labels==k)for k in unique];groups.sort(key=lambda q:-len(q));bounds=[(UV[g].min((0,1)),UV[g].max((0,1)))for g in groups];dims=np.array([hi-lo for lo,hi in bounds]);K=len(groups);assert K<12,(K,[len(g)for g in groups]);best=None
for rot in itertools.product([0,1],repeat=K):
 sizes=np.array([d[::-1]if q else d for d,q in zip(dims,rot)])
 for cols in range(1,K+1):
  rows=(K+cols-1)//cols;cw=np.array([max(sizes[k,0]for k in range(c,K,cols))for c in range(min(cols,K))]);rh=np.array([max(sizes[k,1]for k in range(row*cols,min((row+1)*cols,K)))for row in range(rows)]);scale=min((.98-(cols-1)*.012)/cw.sum(),(.98-(rows-1)*.012)/rh.sum())
  if best is None or scale>best[0]:best=(scale,rot,cols,cw,rh)
scale,rot,cols,cw,rh=best;packed=np.empty_like(UV);transforms=[];chart=np.empty(len(T),int)
for k,(g,(lo,hi),rotate)in enumerate(zip(groups,bounds,rot)):
 row,col=divmod(k,cols);origin=np.array([.01+sum(cw[:col])*scale+col*.012,.01+sum(rh[:row])*scale+row*.012]);M=np.array([[0,-1],[1,0]])if rotate else np.eye(2);corner=np.array([[lo[0],lo[1]],[lo[0],hi[1]],[hi[0],lo[1]],[hi[0],hi[1]]]);offset=origin-(corner@M.T).min(0)*scale;packed[g]=UV[g]@(M*scale).T+offset;chart[g]=k;transforms.append({'island':k,'faces':len(g),'matrix':(M*scale).tolist(),'translation':offset.tolist()})
assert packed.min()>=.009999 and packed.max()<=.990001;area=lambda q:(q[:,1,0]-q[:,0,0])*(q[:,2,1]-q[:,0,1])-(q[:,1,1]-q[:,0,1])*(q[:,2,0]-q[:,0,0]);a0=area(UV);a1=area(packed);assert np.all(a0*a1>0);assert np.allclose(a1,a0*scale*scale,rtol=1e-7,atol=1e-12);res=2048;count=np.zeros((res,res),np.uint16);samples=np.zeros(len(T),int)
for i,q in enumerate(packed):
 lo=np.maximum(np.ceil(q.min(0)*res-.5).astype(int),0);hi=np.minimum(np.floor(q.max(0)*res-.5).astype(int),res-1)
 if np.any(hi<lo):continue
 xx,yy=np.meshgrid((np.arange(lo[0],hi[0]+1)+.5)/res,(np.arange(lo[1],hi[1]+1)+.5)/res);u=((q[1,0]-xx)*(q[2,1]-yy)-(q[1,1]-yy)*(q[2,0]-xx))/a1[i];v=((q[2,0]-xx)*(q[0,1]-yy)-(q[2,1]-yy)*(q[0,0]-xx))/a1[i];w=1-u-v;inside=(u>1e-8)&(v>1e-8)&(w>1e-8);samples[i]=inside.sum();count[lo[1]:hi[1]+1,lo[0]:hi[0]+1]+=inside
np.savez_compressed(r/'checks'/f'hand_uv17_{side}.npz',P=P,T=T,N=z['N'],UVcorner_native=UV,UVcorner_packed=packed,chart=chart,source_face_ids=z['source_face_ids'],face_texel_samples=samples);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'side':side,'islands':K,'transforms':transforms,'scale':scale,'resolution':res,'occupied_texels':int((count>0).sum()),'multiply_covered_strict_interior_texels':int((count>1).sum()),'maximum_multiplicity':int(count.max()),'faces_with_no_strict_interior_texel_center':np.flatnonzero(samples==0).tolist(),'minimum_uv_triangle_area':float(abs(a1).min()/2),'uv_winding_and_shape_held_up_to_rigid_transform_uniform_scale':True,'scope':'UV packing and raster preflight. Continuous overlap, tangents, baked-paint ownership and every thin-face coverage remain separate gates.'};(r/'checks'/f'hand_uv17_{side}.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k!='transforms'},flush=True)
