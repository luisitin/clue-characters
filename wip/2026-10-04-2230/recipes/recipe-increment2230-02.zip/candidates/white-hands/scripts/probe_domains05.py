"""Read-only geometric hand/cuff domain search. No body deletion or output model."""
import pathlib,numpy as np,json,collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
r=pathlib.Path(__file__).resolve().parents[1];reports=[]
for side,sgn in [('left',-1),('right',1)]:
 z=np.load(r/'checks'/f'source01_{side}.npz');P=z['P'];W=z['W'];F=z['F'];C=W[F].mean(1);raw=z['raw_face_ids'];un,g=np.unique(P,axis=0,return_inverse=True);G=g[F];edges={}
 for fi,face in enumerate(G):
  for a,b in zip(face,np.roll(face,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
 pairs=[(a,b)for fs in edges.values()for a in fs for b in fs if a<b];pair=np.array(pairs);center=np.array([sgn*.345,.02,.276]);axis=np.array([-sgn*.8,0,-.6]);d=(W-center)@axis
 for xi in [.17,.18,.19,.20,.21]:
  for h in [.095,.115,.13]:
   chosen=(d[F].max(1)>0)&(C[:,0]*sgn>xi)&(C[:,2]>h)&(C[:,2]<.335)&(C[:,1]<.14)&(C[:,1]>-.14);seeds=chosen&(C[:,0]*sgn>.23)&(C[:,0]*sgn<.29)&(C[:,1]<0)&(C[:,2]>.16)&(C[:,2]<.23);adjpair=pair[chosen[pair].all(1)];mat=coo_matrix((np.ones(len(adjpair)),(adjpair[:,0],adjpair[:,1])),shape=(len(F),len(F)));_,labs=connected_components(mat,directed=False);k=collections.Counter(labs[seeds]).most_common(1)[0][0];ids=np.flatnonzero(chosen&(labs==k));selected=np.zeros(len(F),bool);selected[ids]=True;bounds=[];nonman=[]
   for e,fs in edges.items():
    if any(selected[f]for f in fs)and not all(selected[f]for f in fs):bounds.append(e)
    if any(selected[f]for f in fs)and len(fs)!=2:nonman.append((e,fs))
   deg=collections.Counter(v for e in bounds for v in e);adj={}
   for a,b in bounds:adj.setdefault(a,set()).add(b);adj.setdefault(b,set()).add(a)
   left=set(adj);cc=[]
   while left:
    group=set();stack=[min(left)]
    while stack:
     u=stack.pop()
     if u in group:continue
     group.add(u);stack.extend(adj[u]-group)
    left-=group;cc.append(group)
   components=[{'n':len(q),'center':((un[list(q)]*z['node_scale']+z['node_translation'])[:,[0,2,1]]*[1,-1,1]).mean(0).tolist()}for q in cc];report={'side':side,'inner_x':xi,'low_z':h,'faces':len(ids),'boundary_edges':len(bounds),'boundary_degree_histogram':dict(collections.Counter(deg.values())),'boundary_components':components,'selected_nonmanifold_edges':len(nonman)};reports.append(report)
   if xi==.19 and h==.115:np.savez_compressed(r/'checks'/f'domain05_{side}.npz',selected_faces=ids,raw_ids=raw[ids],boundary_edges=np.array(bounds),boundary_unique_positions=un,source_physical_face_ids=G,proximal_center=center,proximal_axis=axis)
(r/'checks/domain05_search.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2),flush=True)
