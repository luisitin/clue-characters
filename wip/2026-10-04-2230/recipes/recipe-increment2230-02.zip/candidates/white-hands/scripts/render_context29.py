import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white'
for label,angle,target,scale in [('front',0,'[0.00319,-0.04,0.16]','.68'),('rear',180,'[0.00319,-0.04,0.16]','.68'),('whole_front',0,'[0.00319,-0.00726,0.00057]','2.16')]:
 env=dict(os.environ,GLB=str(r/'models/white29_open_context_diagnostic.glb'),OUT=str(r/'renders'/f'white29_open_context_{label}.png'),MODE='pbr',TARGET=target,SCALE=scale,ANGLE=str(angle),ELEV='0',RES='768',SAMPLES='16');env.pop('CAMERA_META',None);env.pop('WORLD_ENV',None)
 with (r/'checks'/f'context29_{label}.log').open('w')as f:subprocess.run(['flock',os.environ.get('CHARACTER_BUILD_LOCK','/tmp/character-build-heavy.lock'),'bash','-c','date -u +START_%FT%TZ; "$@"; s=$?; date -u +END_%FT%TZ; exit $s','white_context29','blender','-b','-t','2','--python-exit-code','1','--python',str(owner/'scripts/render_exact.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
