"""Bounded thenar skin fairing on exact failed contacts; no topology, pose or UV replacement."""
import pathlib,json,numpy as np,collections,sys,hashlib
from scipy.sparse import coo_matrix,eye
from scipy.sparse.linalg import spsolve
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import append_accessor,write_glb
j={'asset':{'version':'2.0','generator':'White bounded thenar skin27'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0,'name':'White hands27 local thenar fairing study27'}],'meshes':[{'primitives':[]}],'buffers':[],'bufferViews':[],'accessors':[],'materials':[]};buf=b'';reports={}
for side in ['R','L']:
 src=r/'checks'/f'fist_seed25_{side}.npz';z=np.load(src);data={k:z[k]for k in z.files};P=z['P'];T=z['T'];old=P.copy();audit=json.load((r/'checks'/f'fist_seed25_{side}_audit.json').open());badfaces=set(f for q in audit['proper_crossings']for f in q['faces'])|set(f for q in audit['manifold_edge_folds_over_105_degrees']for f in q);assert badfaces;seed=set(T[sorted(badfaces)].ravel());adj=collections.defaultdict(set)
 for a,b,c in T:
  for u,v in [(a,b),(b,c),(c,a)]:adj[int(u)].add(int(v));adj[int(v)].add(int(u))
 def grow(start,k):
  out=set(start)
  for _ in range(k):out|=set(n for v in list(out)for n in adj[v])
  return out
 core=grow(seed,2);support=grow(seed,6);vid=np.array(sorted(support));rows=[];cols=[];values=[]
 for i in range(len(P)):
  rows.append(i);cols.append(i);values.append(1.)
  for v in adj[i]:rows.append(i);cols.append(v);values.append(-1/len(adj[i]))
 L=coo_matrix((values,(rows,cols)),shape=(len(P),len(P))).tocsr();A=L[:,vid];rhs=np.zeros_like(P);rhs[list(core)]=-(L@P)[list(core)];ridge=.015;delta=spsolve(A.T@A+ridge*eye(len(vid),format='csc'),A.T@rhs);P[vid]+=delta;move=np.linalg.norm(P-old,axis=1);assert move.max()<.006
 # New angle-weighted normals only in the local affected face star; other normals remain exact.
 tri=P[T];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area2=np.linalg.norm(cross,axis=1);assert area2.min()>1e-14;fn=cross/area2[:,None];newN=np.zeros_like(P)
 for k in range(3):
  a=tri[:,(k+1)%3]-tri[:,k];b=tri[:,(k+2)%3]-tri[:,k];angle=np.arctan2(np.linalg.norm(np.cross(a,b),axis=1),np.sum(a*b,axis=1));np.add.at(newN,T[:,k],fn*angle[:,None])
 newN/=np.maximum(np.linalg.norm(newN,axis=1)[:,None],1e-20);N=z['N'].copy();normal_ids=np.array(sorted(grow(support,1)));N[normal_ids]=newN[normal_ids];ref=np.load(r/'checks'/f'fist_seed13_{side}.npz');assert len(P)==len(ref['P']) and np.array_equal(z['donor_ids'],ref['donor_ids']) and np.array_equal(z['donor_faces'],ref['donor_faces']);keys_now=np.unique(np.c_[T.ravel(),z['UVcorner'].reshape(-1,2)],axis=0);keys_ref=np.unique(np.c_[ref['T'].ravel(),ref['UVcorner'].reshape(-1,2)],axis=0);assert np.array_equal(keys_now,keys_ref);reference_diagonal_changed=int(np.any(T!=ref['T'],axis=1).sum());rt=ref['P'][T];rf=np.cross(rt[:,1]-rt[:,0],rt[:,2]-rt[:,0]);rf/=np.linalg.norm(rf,axis=1)[:,None];dots=np.sum(fn*rf,axis=1);data.update(P=P,N=N,thenar_changed_vertex_ids=vid,thenar_normal_vertex_ids=normal_ids,thenar_original_positions=old[vid]);np.savez_compressed(r/'checks'/f'fist_seed27_{side}.npz',**data)
 # Exact native UVs are held here. Packed atlas/tangents can be rebound after this geometry gate.
 uv=z['UVcorner'].astype(np.float32).copy();uv[:,:,1]=1-uv[:,:,1];keys=np.c_[T.ravel(),uv.reshape(-1,2)];unique,back=np.unique(keys,axis=0,return_inverse=True);sv=unique[:,0].astype(int);TT=back.reshape(-1,3);attrs={}
 for name,q,kind in [('POSITION',P[sv][:,[0,2,1]]*[1,1,-1],'VEC3'),('NORMAL',N[sv][:,[0,2,1]]*[1,1,-1],'VEC3'),('TEXCOORD_0',unique[:,1:],'VEC2')]:attrs[name],buf=append_accessor(j,buf,q.astype(np.float32),kind,34962)
 ix,buf=append_accessor(j,buf,TT.astype(np.uint32),'SCALAR',34963);mi=len(j['materials']);j['materials'].append({'name':side+' provisional source-tone26','pbrMetallicRoughness':{'baseColorFactor':[.57,.28,.145,1],'roughnessFactor':.62,'metallicFactor':0}});j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4});reports[side]={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'failed_triangles':len(badfaces),'seed_vertices':len(seed),'core_vertices':len(core),'support_vertices':len(support),'changed_normal_vertices':len(normal_ids),'max_displacement_m':float(move.max()),'p95_displacement_m':float(np.quantile(move[vid],.95)),'outside_support_positions_exactly_held':True,'all_topology_and_native_UVs_held':True,'minimum_reference13_geometric_normal_dot':float(dots.min()),'reference13_normal_reversals':int((dots<=0).sum()),'reference13_triangle_rows_with_different_diagonals':reference_diagonal_changed,'reference_vertex_and_native_corner_bindings_exact':True,'ridge':ridge,'scope':'Local skin-surface fairing trial. Full crossing, fold, appearance and contact gates must be rerun.'}
write_glb(r/'models/fist_seed27.glb',j,buf);(r/'checks/fist_seed27.json').write_text(json.dumps(reports,indent=2));print(reports,flush=True)
