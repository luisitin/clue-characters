"""Check unique occupied texels and per-face coverage before ear material bake.
Native ear corner UVs are affine-repacked only; attachment uses its proved
single-valued X/Z chart. The two charts use separate2048px maps with8px margins.
"""
from pathlib import Path
import numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1];W=2048;pad=8
def read(name):
 a=np.load(R/f'inputs/{name}.npz');d={k:a[k] for k in a.files};a.close();return d
E=read('posed_ear211');A=read('ear_annulus216');u=E['corner_uv'];native=np.concatenate([u[:,[0,1,2]],u[:,[0,2,3]]]);native[:,:,1]*=-1
annulus=A['pos'][A['tri']][:,:,[0,2]].copy();annulus[:,:,1]*=-1
result={};store={}
for name,uv in [('native',native),('annulus',annulus)]:
 lo=uv.min(axis=(0,1));hi=uv.max(axis=(0,1));px=pad+(uv-lo)/(hi-lo)*(W-2*pad);atlasUV=px/W;owner=np.full((W,W),-1,np.int32);count=np.zeros(len(px),np.int32);overlap=0;sample_pairs=set()
 for fi,q in enumerate(px):
  xmin=max(0,int(np.floor(q[:,0].min())));xmax=min(W-1,int(np.ceil(q[:,0].max())));ymin=max(0,int(np.floor(q[:,1].min())));ymax=min(W-1,int(np.ceil(q[:,1].max())));xx,yy=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5);p=np.column_stack([xx.ravel(),yy.ravel()]);e=q[1]-q[0];f=q[2]-q[0];r=p-q[0];det=e[0]*f[1]-e[1]*f[0];assert abs(det)>1e-10;b=(r[:,0]*f[1]-r[:,1]*f[0])/det;c=(e[0]*r[:,1]-e[1]*r[:,0])/det;a=1-b-c;inside=(a>=-1e-9)&(b>=-1e-9)&(c>=-1e-9);count[fi]=inside.sum();strict=(a>1e-9)&(b>1e-9)&(c>1e-9);sx=p[strict,0].astype(int);sy=p[strict,1].astype(int);prior=owner[sy,sx];bad=prior>=0;overlap+=int(bad.sum())
  if bad.any():sample_pairs.update((int(x),fi) for x in np.unique(prior[bad]))
  owner[sy,sx]=fi
 result[name]={'triangles':len(px),'image_size':[W,W],'padding_pixels':pad,'affine_original_uv_bounds':[lo.tolist(),hi.tolist()],'strict_interior_overlap_texels':overlap,'overlap_pairs':sorted(sample_pairs),'minimum_face_texel_centers':int(count.min()),'zero_center_faces':np.where(count==0)[0].tolist(),'face_coverage_percentiles':np.percentile(count,[0,1,50,99,100]).tolist(),'occupied_strict_texels':int((owner>=0).sum())};store[name+'_corner_uv_png']=atlasUV;store[name+'_face_coverage']=count
out=R/'inputs/ear_atlas_layout231.npz';np.savez_compressed(out,**store);report={'layout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_native_ear_sha256':hashlib.sha256((R/'inputs/posed_ear211.npz').read_bytes()).hexdigest(),'source_annulus_sha256':hashlib.sha256((R/'inputs/ear_annulus216.npz').read_bytes()).hexdigest(),'charts':result,'scope':'Atlas occupancy and per-face coverage only. No material bake or geometry promotion.'};(R/'checks/ear_uv231.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
