"""Measure distal skin around official posed bone frames before adding nail detail."""
from pathlib import Path
import hashlib
import json
import numpy as np
from glb_io import read_glb

root = Path(__file__).resolve().parents[1]
source = root / 'components/scarlett_right_hand111.glb'
document, binary, accessor = read_glb(source)
primitive = document['meshes'][0]['primitives'][0]
positions = accessor(primitive['attributes']['POSITION'])[:, [0, 2, 1]] * [1, -1, 1]
faces = accessor(primitive['indices']).reshape(-1, 3)
triangles = positions[faces]
edge1 = triangles[:, 1] - triangles[:, 0]
edge2 = triangles[:, 2] - triangles[:, 0]
geometric = np.cross(edge1, edge2)
geometric /= np.linalg.norm(geometric, axis=1)[:, None]
bones = json.loads((root / 'checks/scarlett_hand110.json').read_text())['posed_bones']

def exit_ray(origin, direction):
    h = np.cross(direction, edge2)
    determinant = np.einsum('ij,ij->i', edge1, h)
    inverse = np.divide(1, determinant, out=np.zeros_like(determinant), where=abs(determinant) > 1e-14)
    offset = origin - triangles[:, 0]
    u = np.einsum('ij,ij->i', offset, h) * inverse
    q = np.cross(offset, edge1)
    v = (q @ direction) * inverse
    distance = np.einsum('ij,ij->i', q, edge2) * inverse
    valid = (abs(determinant) > 1e-14) & (u >= -1e-9) & (v >= -1e-9) & (u+v <= 1+1e-9) & (distance > 1e-7)
    candidates = np.flatnonzero(valid)
    assert len(candidates), 'Distal bone ray misses the actual skin'
    face = int(candidates[np.argmin(distance[candidates])])
    outward = float(geometric[face] @ direction)
    assert outward > .20, ('Bone center is outside skin or dorsal axis is invalid', face, outward)
    assert .0005 < distance[face] < .015, ('Unexpected distal skin radius', face, distance[face])
    return {'face': face, 'distance_m': float(distance[face]), 'outward_geometric_dot': outward,
            'position_blender': (origin + distance[face]*direction).tolist(),
            'barycentric': [float(1-u[face]-v[face]), float(u[face]), float(v[face])]}

controls = []
for digit in range(1, 6):
    bone = bones[f'finger{digit}-3.R']
    head, tail = np.array(bone['head']), np.array(bone['tail'])
    longitudinal = tail - head
    length = float(np.linalg.norm(longitudinal))
    longitudinal /= length
    dorsal = np.array(bone['matrix'])[:3, 2]
    dorsal -= longitudinal * (dorsal @ longitudinal)
    dorsal /= np.linalg.norm(dorsal)
    lateral = np.cross(longitudinal, dorsal)
    lateral /= np.linalg.norm(lateral)
    center = head + .62*length*longitudinal
    initial_positive = exit_ray(center, lateral)
    initial_negative = exit_ray(center, -lateral)
    recenter = .5*(initial_positive['distance_m']-initial_negative['distance_m'])
    assert abs(recenter) < .0025
    center += recenter*lateral
    rays = {name: exit_ray(center, direction) for name, direction in [
        ('dorsal', dorsal), ('palm', -dorsal), ('side_positive', lateral), ('side_negative', -lateral)]}
    half_width = .72*min(rays['side_positive']['distance_m'], rays['side_negative']['distance_m'])
    controls.append({'digit': digit, 'bone': f'finger{digit}-3.R', 'bone_center_blender': center.tolist(),
                     'longitudinal_blender': longitudinal.tolist(), 'dorsal_blender': dorsal.tolist(),
                     'lateral_blender': lateral.tolist(), 'distal_bone_length_m': length,
                     'lateral_recenter_m': float(recenter), 'nail_half_length_m': min(.30*length, 1.30*half_width), 'nail_half_width_m': half_width,
                     'dorsal_skin_distance_m': rays['dorsal']['distance_m'], 'rays': rays})
report = {'source': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'controls': controls, 'scope': 'Read-only anatomical nail-placement measurements. Outward skin exits are verified, but nail shape/orientation still requires actual all-angle appearance review.'}
(root / 'checks/scarlett129_nail_controls.json').write_text(json.dumps(report, indent=2))
print(report, flush=True)
