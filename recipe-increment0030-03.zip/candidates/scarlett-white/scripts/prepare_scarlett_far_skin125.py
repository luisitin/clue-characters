"""Prepare a non-overlapping skin chart and explicit retained-boundary colors.
The old front projection put fringe pigment on the new orbital skin. Geometry is
held; source-cheek pigment, physical aperture and native boundary UVs drive paint.
"""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image
from glb_io import read_glb

root = Path(__file__).resolve().parents[1]
source = root / 'models/scarlett_23_far_join_fairing_trial.glb'
document, binary, accessor = read_glb(source)
scale = np.array(document['nodes'][0]['scale'])
translation = np.array(document['nodes'][0]['translation'])
archive = np.load(root / 'checks/scarlett_far_patch45.npz')
data = {key: archive[key] for key in archive.files}
archive.close()
normal = np.array(json.loads((root / 'checks/scarlett_tangent_chart44_search.json').read_text())['domains'][0]['best_valid_simple_containing_charts'][0]['normal'])
right = np.array([1., 0., 0.])
right -= normal * (normal @ right)
right /= np.linalg.norm(right)
up = np.cross(normal, right)
basis = np.stack([right, up], axis=1)
used, inverse = np.unique(data['skin_triangles'], return_inverse=True)
faces = inverse.reshape(-1, 3)
primitive = document['meshes'][0]['primitives'][5]
assert np.array_equal(accessor(primitive['indices']).reshape(-1, 3), faces)
rest = data['skin_positions_world'][used]
current = accessor(primitive['attributes']['POSITION']) * scale + translation
assert np.max(np.abs(rest[:, :2] - current[:, :2])) < 1e-7
chart = rest @ basis
lower = chart.min(axis=0) - .0005
upper = chart.max(axis=0) + .0005
span = upper - lower
skin_uv = (chart - lower) / span
outer = data['skin_positions_world'][data['outer_vertex_ids']] @ basis
rim_world = data['cap_positions_world'][data['aperture_vertex_ids']]
rim = rim_world @ basis
contact_rest = data['contact_positions_world'][data['contact_triangles']].reshape(-1, 3)
contact = document['meshes'][0]['primitives'][7]
contact_current = accessor(contact['attributes']['POSITION']) * scale + translation
assert contact_current.shape == contact_rest.shape
assert np.max(np.abs(contact_current[:, :2] - contact_rest[:, :2])) < 1e-7
contact_uv = (contact_rest @ basis - lower) / span
triangles = skin_uv[faces]
area = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
assert area.min() > 0

original = root / 'models/scarlett_01_exact_duplicates.glb'
old_document, old_binary, old_accessor = read_glb(original)
old_primitive = old_document['meshes'][0]['primitives'][0]
old_positions = old_accessor(old_primitive['attributes']['POSITION']) * scale + translation
old_uv = old_accessor(old_primitive['attributes']['TEXCOORD_0'])
old_faces = old_accessor(old_primitive['indices']).reshape(-1, 3)
unique, physical_ids = np.unique(old_positions, axis=0, return_inverse=True)
raw_ids = np.load(root / 'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids']
material = old_document['materials'][old_primitive['material']]
pbr = material['pbrMetallicRoughness']
assert pbr.get('baseColorFactor', [1, 1, 1, 1]) == [1, 1, 1, 1]
texture = old_document['textures'][pbr['baseColorTexture']['index']]
image_id = texture.get('source', texture.get('extensions', {}).get('EXT_texture_webp', {}).get('source'))
view = old_document['bufferViews'][old_document['images'][image_id]['bufferView']]
payload = old_binary[view.get('byteOffset', 0):view.get('byteOffset', 0) + view['byteLength']]
base = np.asarray(Image.open(io.BytesIO(payload)).convert('RGB'))

def sample(uv):
    height, width = base.shape[:2]
    xy = uv * [width, height] - .5
    integer = np.floor(xy).astype(int)
    fraction = xy - integer
    x, y = integer[:, 0] % width, integer[:, 1] % height
    return (base[y, x] * (1-fraction[:, 0, None]) * (1-fraction[:, 1, None])
            + base[y, (x+1) % width] * fraction[:, 0, None] * (1-fraction[:, 1, None])
            + base[(y+1) % height, x] * (1-fraction[:, 0, None]) * fraction[:, 1, None]
            + base[(y+1) % height, (x+1) % width] * fraction[:, 0, None] * fraction[:, 1, None])

joins = json.loads((root / 'checks/scarlett_far_patch45_registration_tangents.json').read_text())['retained_tangent_joins']
boundary_colors = []
boundary_faces = []
fractions = np.linspace(0, 1, 512)
for edge in range(len(outer)):
    next_edge = (edge + 1) % len(outer)
    candidates = [item['retained_raw_face'] for item in joins if item['outer_edge'] == [edge, next_edge]]
    choices = []
    for raw in candidates:
        face_id = int(np.flatnonzero(raw_ids == raw)[0])
        face = old_faces[face_id]
        points = old_positions[face]
        geometric = np.cross(points[1]-points[0], points[2]-points[0])
        geometric /= np.linalg.norm(geometric)
        choices.append((float(geometric @ normal), raw, face_id))
    _, raw, face_id = max(choices)
    face = old_faces[face_id]
    position_ids = physical_ids[face]
    corners = [int(np.flatnonzero(position_ids == data['outer_source_position_ids'][i])[0]) for i in [edge, next_edge]]
    edge_uv = old_uv[face[corners]]
    boundary_colors.append(sample((1-fractions[:, None])*edge_uv[0] + fractions[:, None]*edge_uv[1]))
    boundary_faces.append({'edge': [edge, next_edge], 'raw_source_face': raw, 'candidate_count': len(candidates)})

# Fixed anatomical cheek region from the direct native4K source projection.
palette_image = root / 'checks/scarlett_10_orbital_native4k_albedo.png'
image = Image.open(palette_image).convert('RGB')
rectangle = tuple(round(value * 4096 / 800) for value in [250, 480, 335, 570])
cheek = np.asarray(image.crop(rectangle)).reshape(-1, 3).astype(float)
image.close()
valid = (cheek[:, 0] > 100) & (cheek[:, 0] > cheek[:, 1]*1.12) & (cheek[:, 1] > cheek[:, 2]*1.10)
assert valid.sum() > 1000
skin = np.percentile(cheek[valid], 65, axis=0)
centered = rim_world[:, :2] - rim_world[:, :2].mean(axis=0)
_, axes = np.linalg.eigh(np.cov(centered.T))
longitudinal = axes[:, -1]
if longitudinal[0] < 0:
    longitudinal *= -1
vertical = np.array([-longitudinal[1], longitudinal[0]])
segment_centers = (centered + np.roll(centered, -1, axis=0)) / 2
upper_segments = segment_centers @ vertical > 0
output = root / 'checks/scarlett125_far_skin_context.npz'
np.savez_compressed(output, outer=outer, rim=rim, upper_segments=upper_segments,
                    boundary_colors=np.asarray(boundary_colors), skin_RGB=skin,
                    lower=lower, span=span, skin_uv=skin_uv.astype(np.float32),
                    contact_uv=contact_uv.astype(np.float32), skin_triangles=faces)
report = {
    'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'context_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'atlas_dimensions': [2048, 2048], 'minimum_signed_skin_UV_twice_area': float(area.min()),
    'parameterization': 'Held45 simple facial chart, bound through the exact07 compacted vertex map. All geometry stays held.',
    'boundary_color_source': 'Direct original4K native-UV samples on retained source edges, never projected fringe pixels.',
    'boundary_faces': boundary_faces, 'healthy_cheek_palette_rectangle_at800': [250, 480, 335, 570],
    'healthy_cheek_samples': int(valid.sum()), 'neutral_skin_RGB': skin.tolist(),
    'source_albedo_sha256': hashlib.sha256(payload).hexdigest(),
    'status': 'Explicit material input only. Registered front and exposing all-angle skin/hair ownership need actual-model review.'
}
(root / 'checks/scarlett125_far_skin_context.json').write_text(json.dumps(report, indent=2))
print({key: value for key, value in report.items() if key != 'boundary_faces'}, flush=True)
