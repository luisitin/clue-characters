"""Add integral sub-millimetre nail relief without detached nail layers."""
from pathlib import Path
import json, hashlib
import numpy as np
from glb_io import read_glb, append_accessor, write_glb
from scarlett_nail_field130 import scalar_height, material_weight

root = Path(__file__).resolve().parents[1]
source = root/'components/scarlett_right_hand111.glb'
j, b, a = read_glb(source)
pr = j['meshes'][0]['primitives'][0]
P = a(pr['attributes']['POSITION']).astype('f8')[:,[0,2,1]]*[1,-1,1]
N = a(pr['attributes']['NORMAL']).astype('f8')[:,[0,2,1]]*[1,-1,1]
F = a(pr['indices']).reshape(-1,3)
controls = json.loads((root/'checks/scarlett129_nail_controls.json').read_text())['controls']
Q = P.copy(); newN=N.copy(); active=np.zeros(len(P),int); rows=[]
for control in controls:
    delta = scalar_height(P,control)
    direction = np.asarray(control['dorsal_blender'])
    gradient=np.zeros_like(P)
    for axis in range(3):
        shift=np.zeros(3); shift[axis]=1e-6
        gradient[:,axis]=(scalar_height(P+shift,control)-scalar_height(P-shift,control))/(2e-6)
    touched=abs(delta)>1e-10; active+=touched
    determinant=1+gradient@direction
    assert determinant.min()>.75
    Q+=delta[:,None]*direction
    newN-=gradient*((N@direction)/determinant)[:,None]
    rows.append({'digit':control['digit'],'moved_vertices':int(touched.sum()),'maximum_rise_m':float(delta.max()),'maximum_groove_m':float(delta.min()),'minimum_deformation_jacobian':float(determinant.min())})
assert active.max()==1
newN/=np.linalg.norm(newN,axis=1)[:,None]
oldC=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]])
newC=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]])
cos=np.sum(oldC*newC,axis=1)/(np.linalg.norm(oldC,axis=1)*np.linalg.norm(newC,axis=1))
print({'minimum_old_new_normal_dot':float(cos.min()),'worst_face':int(np.argmin(cos)),'worst_vertices':F[int(np.argmin(cos))].tolist(),'per_digit':rows},flush=True)
assert cos.min()>.98
weld, inverse=np.unique(P,axis=0,return_inverse=True)
lo=np.full((len(weld),3),np.inf); hi=np.full((len(weld),3),-np.inf)
np.minimum.at(lo,inverse,Q); np.maximum.at(hi,inverse,Q)
assert np.max(hi-lo)==0
weight=material_weight(P,controls)
skin=np.array([251,185,145])/255.; nail=np.array([230,170,156])/255.
srgb=(1-weight[:,None])*skin+weight[:,None]*nail
linear=np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
for key,values,kind in [('POSITION',Q[:,[0,2,1]]*[1,1,-1],'VEC3'),('NORMAL',newN[:,[0,2,1]]*[1,1,-1],'VEC3'),('COLOR_0',np.c_[linear,np.ones(len(P))],'VEC4')]:
    pr['attributes'][key],b=append_accessor(j,b,values.astype('f4'),kind,34962)
pr['attributes'].pop('TANGENT',None)
pr['material']=len(j.setdefault('materials',[]));j['materials'].append({'name':'Temporary neutral skin and integral nude nail color','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0,'roughnessFactor':.48}})
out=root/'components/scarlett_right_hand130_nail_relief_trial.glb';write_glb(out,j,b)
np.savez_compressed(root/'checks/scarlett130_nail_relief.npz',P=P,Q=Q,N=N,NEW_N=newN,T=F,NAIL_WEIGHT=weight)
report={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'controls':rows,'triangles':len(F),'minimum_old_new_face_normal_dot':float(cos.min()),'exact_position_group_divergence_m':float(np.max(hi-lo)),'fixed_face_winding':True,'source_pose_outside_nail_support_held':True,'scope':'Integral nail relief study with temporary vertex pigment. No detached shell; fresh serialized self-audit and actual dorsal/thumb/side review required. Forearm/character integration remains open.'}
(root/'checks/scarlett130_nail_relief.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
