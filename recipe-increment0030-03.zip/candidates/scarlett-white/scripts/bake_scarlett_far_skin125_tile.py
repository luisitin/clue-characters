"""Bounded2K neutral orbital albedo tile with explicit lid/boundary ownership."""
from pathlib import Path
import hashlib
import json
import os
import numpy as np
from PIL import Image

root = Path(__file__).resolve().parents[1]
context_path = root / 'checks/scarlett125_far_skin_context.npz'
archive = np.load(context_path)
data = {key: archive[key] for key in archive.files}
archive.close()
tile = int(os.environ['TILE'])
resolution, rows = 2048, 256
assert 0 <= tile < 8
row_start = tile * rows
yy, xx = np.meshgrid(np.arange(row_start, row_start+rows), np.arange(resolution), indexing='ij')
uv = np.column_stack([(xx.ravel()+.5)/resolution, (yy.ravel()+.5)/resolution])
points = data['lower'] + uv * data['span']
outer_distance = np.full(len(points), np.inf)
boundary_color = np.zeros((len(points), 3))
outer = data['outer']
for edge, (start, end) in enumerate(zip(outer, np.roll(outer, -1, axis=0))):
    direction = end - start
    fraction = np.clip((points-start) @ direction / (direction @ direction), 0, 1)
    difference = points - start - fraction[:, None]*direction
    squared = np.einsum('ij,ij->i', difference, difference)
    closer = squared < outer_distance
    location = fraction[closer] * 511
    index = np.floor(location).astype(int)
    alpha = location - index
    colors = data['boundary_colors'][edge]
    boundary_color[closer] = colors[index]*(1-alpha[:, None]) + colors[np.minimum(index+1, 511)]*alpha[:, None]
    outer_distance[closer] = squared[closer]
outer_distance = np.sqrt(outer_distance)
inner_distance = np.full(len(points), np.inf)
upper_lid = np.zeros(len(points), bool)
rim = data['rim']
for edge, (start, end) in enumerate(zip(rim, np.roll(rim, -1, axis=0))):
    direction = end - start
    fraction = np.clip((points-start) @ direction / (direction @ direction), 0, 1)
    difference = points - start - fraction[:, None]*direction
    squared = np.einsum('ij,ij->i', difference, difference)
    closer = squared < inner_distance
    inner_distance[closer] = squared[closer]
    upper_lid[closer] = data['upper_segments'][edge]
inner_distance = np.sqrt(inner_distance)

def smooth(value):
    value = np.clip(value, 0, 1)
    return value*value*(3-2*value)

grain = (.004*np.sin(points[:, 0]*18073 + points[:, 1]*13019)
         + .002*np.sin(points[:, 0]*27131 - points[:, 1]*22117))
skin = data['skin_RGB'][None, :] * (1+grain[:, None])
neutral_weight = smooth(outer_distance/.0025)
color = boundary_color*(1-neutral_weight[:, None]) + skin*neutral_weight[:, None]
makeup = .13*np.exp(-.5*(inner_distance/.0014)**2)*upper_lid
color = color*(1-makeup[:, None]) + np.array([184., 104., 85.])*makeup[:, None]
width = np.where(upper_lid, .00024, .000075)
liner = np.exp(-.5*(inner_distance/width)**2)*np.where(upper_lid, .98, .45)
liner_color = np.where(upper_lid[:, None], [28., 18., 18.], [93., 44., 32.])
color = color*(1-liner[:, None]) + liner_color*liner[:, None]
pixels = np.rint(np.clip(color, 0, 255)).astype(np.uint8).reshape(rows, resolution, 3)
output = root / 'checks' / f'scarlett125_far_skin_tile{tile}.png'
Image.fromarray(pixels).save(output)
report = {
    'tile': tile, 'row_start': row_start, 'rows': rows,
    'context_sha256': hashlib.sha256(context_path.read_bytes()).hexdigest(),
    'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'neutral_skin_RGB': data['skin_RGB'].tolist(),
    'outer_boundary_blend_width_m': .0025,
    'upper_liner_sigma_m': .00024, 'lower_liner_sigma_m': .000075,
    'provenance': 'Direct source-cheek palette, retained-edge nativeUV colors, explicit physical eyelid contour and subtle procedural pigment variation. No projected fringe paint, baked glints or directional shadows.'
}
(root / 'checks' / f'scarlett125_far_skin_tile{tile}.json').write_text(json.dumps(report, indent=2))
print(report, flush=True)
