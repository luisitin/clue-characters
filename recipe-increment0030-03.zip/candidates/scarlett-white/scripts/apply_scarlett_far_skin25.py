"""Apply the explicit far-orbital skin atlas while holding every geometric byte."""
from pathlib import Path
import copy
import hashlib
import json
import numpy as np
from PIL import Image
from glb_io import read_glb, append_accessor, write_glb

root = Path(__file__).resolve().parents[1]
source = root / 'models/scarlett_23_far_join_fairing_trial.glb'
document, binary, accessor = read_glb(source)
before = copy.deepcopy(document)
context_path = root / 'checks/scarlett125_far_skin_context.npz'
context_hash = hashlib.sha256(context_path.read_bytes()).hexdigest()
context = np.load(context_path)
skin_uv = context['skin_uv']
contact_uv = context['contact_uv']
context.close()
context_report = json.loads((root / 'checks/scarlett125_far_skin_context.json').read_text())
assert context_report['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
atlas = Image.new('RGB', (2048, 2048))
for tile in range(8):
    image = root / 'checks' / f'scarlett125_far_skin_tile{tile}.png'
    report = json.loads((root / 'checks' / f'scarlett125_far_skin_tile{tile}.json').read_text())
    assert report['context_sha256'] == context_hash
    assert report['sha256'] == hashlib.sha256(image.read_bytes()).hexdigest()
    atlas.paste(Image.open(image), (0, tile*256))
image = root / 'checks/scarlett125_far_skin_albedo_2048.png'
atlas.save(image)
payload = image.read_bytes()
binary += b'\0' * ((-len(binary)) % 4)
view_index = len(document['bufferViews'])
document['bufferViews'].append({'buffer': 0, 'byteOffset': len(binary), 'byteLength': len(payload)})
binary += payload
image_index = len(document['images'])
document['images'].append({'name': 'Scarlett neutral far orbital skin125', 'bufferView': view_index, 'mimeType': 'image/png'})
texture_index = len(document['textures'])
document['textures'].append({'source': image_index})
for index, uv in [(5, skin_uv), (7, contact_uv)]:
    primitive = document['meshes'][0]['primitives'][index]
    assert len(uv) == len(accessor(primitive['attributes']['POSITION']))
    primitive['attributes']['TEXCOORD_0'], binary = append_accessor(document, binary, uv.astype(np.float32), 'VEC2', 34962)
    primitive['attributes'].pop('TANGENT', None)
    material = copy.deepcopy(document['materials'][primitive['material']])
    material['name'] = 'Scarlett neutral orbital skin' if index == 5 else 'Scarlett physical lid margin'
    material['pbrMetallicRoughness']['baseColorTexture']['index'] = texture_index
    primitive['material'] = len(document['materials'])
    document['materials'].append(material)
output = root / 'models/scarlett_25_far_skin_material_trial.glb'
write_glb(output, document, binary)
new_document, new_binary, new_accessor = read_glb(output)
for index, primitive in enumerate(new_document['meshes'][0]['primitives']):
    old_primitive = before['meshes'][0]['primitives'][index]
    assert np.array_equal(new_accessor(primitive['indices']), accessor(old_primitive['indices']))
    for key, attribute in primitive['attributes'].items():
        if index in [5, 7] and key == 'TEXCOORD_0':
            continue
        assert np.array_equal(new_accessor(attribute), accessor(old_primitive['attributes'][key]))
report = {
    'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'output': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'changed_material_UV_primitives': [5, 7],
    'all_positions_normals_indices_other_attributes_and_other_materials_held': True,
    'atlas_sha256': hashlib.sha256(payload).hexdigest(), 'atlas_dimensions': [2048, 2048],
    'provenance': context_report,
    'status': 'Unapproved material-only study. Actual exposing/front/under skin-hair ownership and identity checks required.'
}
(root / 'checks/scarlett_25_far_skin_material_trial.json').write_text(json.dumps(report, indent=2))
print({key: value for key, value in report.items() if key != 'provenance'}, flush=True)
