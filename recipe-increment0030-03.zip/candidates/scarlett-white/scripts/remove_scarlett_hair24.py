"""Two bounded backed hair-flap families; preserve every unrelated source face."""
import pathlib,json,hashlib,collections,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_20_face_material_geometry_merge.glb';sha=hashlib.sha256(src.read_bytes()).hexdigest();targets=[27235,83662,28932,52091,50881];proofs={}
for raw in targets:
 stage=122 if raw in[27235,50881]else 119;path=r/'checks'/f'scarlett{stage}_raw{raw}_support.json';q=json.loads(path.read_text());assert q['sha256']==sha and q['candidate_raw_face']==raw;assert q['jointly_excluded_raw_faces']==(targets if stage==122 else targets[:-1])
 for obs in q['observations']:
  cc=obs['counts']['all'];assert cc['n']==cc['first_hit_front_with_ties']==cc['front_backing_within_5mm']==3321
  assert all(v['raw_face']>=0 and v['raw_face']not in targets for v in obs['backing_faces'])
 proofs[raw]=(path,q)
# The additional fifth exclusion cannot invalidate the three already-passed
# four-face proofs: it is strictly back-facing in all same observer directions,
# and never provided retained front support. All3321 samples have independent
# behind-surface support, so foreground occlusion is never a substitute.
for obs in proofs[50881][1]['observations']:assert obs['candidate_normal_dot']>1e-6
for raw in[83662,28932,52091]:
 for old,new in zip(proofs[raw][1]['observations'],proofs[50881][1]['observations']):assert np.allclose(old['direction_gltf'],new['direction_gltf'],atol=1e-14,rtol=0)
j,b,a=read_glb(src);sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];SF=sa(sp['indices']).reshape(-1,3);rawids=np.load(r/'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids'];lookup={tuple(map(int,f)):int(rawids[i])for i,f in enumerate(SF)};P=sa(sp['attributes']['POSITION']);U,iv=np.unique(P,axis=0,return_inverse=True);before=[];after=[];removed=[];rmfaces=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 if p['attributes']['POSITION']!=sp['attributes']['POSITION']:continue
 F=a(p['indices']).reshape(-1,3);ids=np.array([lookup.get(tuple(map(int,f)),-1)for f in F]);keep=~np.isin(ids,targets);before.extend(F.tolist());after.extend(F[keep].tolist())
 if not keep.all():removed.extend([{'raw_face':int(ids[k]),'primitive':pi,'face':int(k)}for k in np.flatnonzero(~keep)]);rmfaces.extend(F[~keep].tolist());p['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
assert sorted(q['raw_face']for q in removed)==sorted(targets)
def count(faces):return collections.Counter(tuple(sorted((int(u),int(v))))for f in iv[np.array(faces)]for u,v in zip(f,np.roll(f,-1)))
bc,ac=count(before),count(after);touched={tuple(sorted((int(u),int(v))))for f in iv[np.array(rmfaces)]for u,v in zip(f,np.roll(f,-1))};out=r/'models/scarlett_24_hair_overlap_cleanup.glb';write_glb(out,j,b);rep={'source':str(src),'source_sha256':sha,'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_faces':removed,'families':[[27235,83662,50881],[28932,52091]],'all_other_indices_attributes_images_materials_held':True,'joint_proof_reports':[{'raw_face':raw,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'maximum_front_backing_mm':max(o['nearest_front_backing_min_median_max_mm'][-1]for o in q['observations']),'foreground_counts_not_used_as_support':[o['counts']['all']['foreground_occluded']for o in q['observations']]}for raw,(path,q)in proofs.items()],'monotone_exclusion_proof':'The final fifth face50881 is strictly back-facing in every saved observer and is absent from every prior front-backing list; removing it cannot invalidate the three previously complete four-face first-behind-front proofs.83662 has foreground occlusion at many samples, but all3321 also independently meet the retained front backing condition, so no foreground substitution is used.27235 and50881 are freshly tested under the full five-face union.','source_edge_incidence':[{'position_ids':list(e),'before':bc[e],'after':ac[e]}for e in sorted(touched)],'status':'Internal supported hair-family cleanup. Exact matched and alternate-angle appearance remains required; no whole-hair/head clearance.'};(r/'checks/scarlett_24_hair_overlap_cleanup.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
