"""Bounded integral nail-plate field, evaluated in posed Blender coordinates."""
import numpy as np

def smoothstep(x):
    x = np.clip(x, 0., 1.)
    return x*x*(3.-2.*x)

def nail_coordinate(points, control):
    center = np.asarray(control['bone_center_blender'])
    local = points-center
    along = local@np.asarray(control['longitudinal_blender'])/control['nail_half_length_m']
    across = local@np.asarray(control['lateral_blender'])/control['nail_half_width_m']
    depth = local@np.asarray(control['dorsal_blender'])
    radius = (along**4+across**4)**.25
    dorsal_gate = smoothstep((depth/control['dorsal_skin_distance_m']-.30)/.35)
    return radius, dorsal_gate

def scalar_height(points, control):
    radius, gate = nail_coordinate(points, control)
    plate = smoothstep((1.04-radius)/.32)
    groove = np.exp(-((radius-1.13)/.11)**2)
    support = smoothstep((1.52-radius)/.22)
    return gate*support*(.000085*plate-.000015*groove)

def material_weight(points, controls):
    weight = np.zeros(len(points))
    for control in controls:
        radius, gate = nail_coordinate(points, control)
        weight = np.maximum(weight, gate*smoothstep((1.015-radius)/.065))
    return weight
