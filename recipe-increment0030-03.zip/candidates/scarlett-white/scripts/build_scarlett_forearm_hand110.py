"""First recovered anatomical hand trial. Native topology/UV, official normalized weights, fixed rest winding."""
import bpy,sys,json,math,hashlib,os
from pathlib import Path
import numpy as np
from mathutils import Vector,Matrix
D=Path(__file__).resolve().parents[1];ROOT=D.parents[1]
TAG=os.environ.get('HAND_TAG','110');SUBDIV=int(os.environ.get('SUBDIV','2'));SIDE='R';FLEX=-1 if SIDE=='R' else 1
assert SIDE in ('R','L')
sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'))
from load_donor import load_donor
a=load_donor();V=a['positions'];UV=a['uv'];J=a['joint_positions'];bones=a['rig']['bones']
wrist=J[f'wrist.{SIDE}____head'];forward=J[f'finger3-1.{SIDE}____head']-wrist;forward/=np.linalg.norm(forward)
side=J[f'finger2-1.{SIDE}____head']-J[f'finger5-1.{SIDE}____head'];side-=side@forward*forward;side/=np.linalg.norm(side)
dorsal=np.cross(forward,side);dorsal/=np.linalg.norm(dorsal)
F=np.array([-.015,.006,.060]);F/=np.linalg.norm(F)
N=np.array([-.40,-.91,0.]);N-=N@F*F;N/=np.linalg.norm(N);S=np.cross(N,F);S/=np.linalg.norm(S)
R=np.column_stack([F,S,N])@np.column_stack([forward,side,dorsal]).T
assert np.linalg.det(R)>.999999
scale=.060/np.linalg.norm(J[f'finger3-1.{SIDE}____head']-wrist)
anchor=np.array([-.153825,-.0685,.674276])
for folder in ['native','components','checks']:(D/folder).mkdir(exist_ok=True)

elbow_native=J['lowerarm01.R____head'];arm_forward=wrist-elbow_native;arm_length=np.linalg.norm(arm_forward);arm_forward/=arm_length
elbow_target=np.array([-.267,-.063,.416]);target_forward=anchor-elbow_target;target_length=np.linalg.norm(target_forward);target_forward/=target_length;old_arm_forward=R@arm_forward
v=np.cross(old_arm_forward,target_forward);direction_dot=float(old_arm_forward@target_forward);c=direction_dot;K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]);align=np.eye(3)+K+K@K/(1+c);assert c>.4 and np.linalg.det(align)>.999999
def world(p):
 pp=np.asarray(p);q=np.atleast_2d(pp)-wrist;long=q@arm_forward;t=-long/arm_length;rad=q-long[:,None]*arm_forward;old=q@R.T*scale+anchor;center=anchor+(elbow_target-anchor)*t[:,None];radscale=scale*(1+.35*np.clip(t,0,1));fitted=center+(rad@R.T@align.T)*radscale[:,None];w=np.clip((-long-.05)/.50,0,1);w=w*w*(3-2*w);result=old*(1-w[:,None])+fitted*w[:,None];return result[0]if pp.ndim==1 else result
proj=(V-wrist)@forward;dist=np.linalg.norm(V-wrist,axis=1);arm_q=(V-wrist)@arm_forward;arm_rad=np.linalg.norm(V-wrist-arm_q[:,None]*arm_forward,axis=1)
chosen=[]
for i in a['body_face_ids']:
    face=a['faces'][i]
    if all(arm_q[x]>-.90*arm_length and arm_rad[x]<1.50 and V[x,0]<-2.5 for x in face):chosen.append(int(i))
ids=np.unique(np.concatenate([a['faces'][i] for i in chosen]));lookup={int(v):i for i,v in enumerate(ids)}
faces=[[lookup[v] for v in a['faces'][i]] for i in chosen]
assert set(json.loads((D/'checks/scarlett_hand86.json').read_text())['source_body_faces']).issubset(chosen)
pv=world(V[ids]);native_rest=V[ids];edges={}
for face in faces:
    for x,y in zip(face,face[1:]+face[:1]):edges.setdefault(tuple(sorted((x,y))),[]).append((x,y))
boundary=[q[0] for q in edges.values() if len(q)==1]
assert all(len(q)<=2 for q in edges.values())
degrees={}
for x,y in boundary:degrees[x]=degrees.get(x,0)+1;degrees[y]=degrees.get(y,0)+1
assert set(degrees.values())=={2},degrees
# A cap only for the winding test; never exported as hand skin.
c=native_rest[list(degrees)].mean(axis=0);volume=0.
for face in faces:
    for k in range(1,len(face)-1):volume+=np.dot(native_rest[face[0]],np.cross(native_rest[face[k]],native_rest[face[k+1]]))/6
for x,y in boundary:volume+=np.dot(c,np.cross(native_rest[y],native_rest[x]))/6
assert volume>0,('Unexpected rest winding; inspect before fitting',volume)
bpy.ops.wm.read_factory_settings(use_empty=True)
mesh=bpy.data.meshes.new('Official right hand rest UV');mesh.from_pydata(pv.tolist(),[],faces);mesh.update()
ob=bpy.data.objects.new(f'Scarlett relaxed temple hand{TAG} {SIDE}',mesh);bpy.context.collection.objects.link(ob)
uvlayer=mesh.uv_layers.new(name='NativeHandUV')
for poly,sourceface in zip(mesh.polygons,chosen):
    for loopid,uvi in zip(poly.loop_indices,a['face_uv'][sourceface]):uvlayer.data[loopid].uv=UV[uvi]
    poly.use_smooth=True
armdata=bpy.data.armatures.new('Official hand articulation');arm=bpy.data.objects.new('Official hand articulation',armdata);bpy.context.collection.objects.link(arm)
bpy.context.view_layer.objects.active=arm;arm.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for name,b in bones.items():
    e=armdata.edit_bones.new(name);e.head=world(J[b['head']]);e.tail=world(J[b['tail']])
    if (e.tail-e.head).length<1e-6:e.tail=e.head+Vector((0,0,1e-4))
    e.align_roll(Vector(N))
for name,b in bones.items():
    if b.get('parent'):armdata.edit_bones[name].parent=armdata.edit_bones[b['parent']]
bpy.ops.object.mode_set(mode='OBJECT');arm.select_set(False)
weights=a['weights_normalized'][ids]
for k,name in enumerate(a['bone_names']):
    active=np.flatnonzero(weights[:,k]>0)
    if len(active):
        group=ob.vertex_groups.new(name=name)
        for i in active:group.add([int(i)],float(weights[i,k]),'REPLACE')
mod=ob.modifiers.new('Official weighted preserve-volume articulation','ARMATURE');mod.object=arm;mod.use_deform_preserve_volume=True
angles={}
for digit in (2,3,4,5):
    for seg,degrees_ in enumerate([float(v) for v in os.environ.get('CURL','8,15,8').split(',')],1):
        name=f'finger{digit}-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
        if seg==1:
            rest_dir=np.array(pb.bone.tail_local-pb.bone.head_local);rest_dir/=np.linalg.norm(rest_dir);alpha=math.atan2(rest_dir@S,rest_dir@F);pb.rotation_euler.z=-.9*alpha;angles[name+' adduction local_z']=math.degrees(-.9*alpha)
for seg,degrees_ in enumerate([15,15,10],1):
    name=f'finger1-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
# Thumb opposition is assessed from actual views.
sub=ob.modifiers.new('Anatomical surface subdivision','SUBSURF');sub.levels=SUBDIV;sub.render_levels=SUBDIV
mat=bpy.data.materials.new('Neutral skin trial');mat.diffuse_color=(.61,.36,.23,1);mat.use_nodes=True
mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.61,.36,.23,1)
mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.55;ob.data.materials.append(mat)
bpy.context.view_layer.update()
posed_bones={name:{'head':list(pb.head),'tail':list(pb.tail),'matrix':[list(row) for row in pb.matrix]} for name,pb in arm.pose.bones.items() if name.endswith('.'+SIDE) and any(q in name for q in ('finger','wrist','metacarpal'))}
rest_report={'forearm_native_length':float(arm_length),'forearm_target_elbow_blender':elbow_target.tolist(),'forearm_target_axis_length':float(target_length),'forearm_direction_dot_before_fit':direction_dot,'forearm_radial_scale_proximal_factor':1.35,'wrist_blend_native_interval':[-.55,-.05],'distal_hand_rest_mapping_held_above_native_q':-.05,'posed_bones':posed_bones,'source_manifest_sha256':hashlib.sha256((ROOT/'shared_sources/makehuman/provenance/manifest.json').read_bytes()).hexdigest(),'source_body_faces':chosen,'source_vertices':ids.tolist(),'rest_quads':len(faces),'rest_vertices':len(pv),'boundary_edges':len(boundary),'boundary_degree_two':True,'rest_cap_volume':float(volume),'fixed_original_OBJ_winding':True,'raw_weight_sum_range':[float(a['weight_sums_raw'][ids].min()),float(a['weight_sums_raw'][ids].max())],'normalized_weight_max_error':float(np.abs(weights.sum(axis=1)-1).max()),'world_forward':F.tolist(),'index_straightened':False,'fit_basis':'Held87 distal hand registration. The extended native forearm is smoothly fit toward a provisional elbow center at Blender[-.267,-.063,.416], based on the source cross-section study107. This center is not a verified cut/attachment boundary. Distal mapping stays exact outside the wrist blend; proximal radial scale increases35percent.','world_anchor':anchor.tolist(),'scale':scale,'native_forward':forward.tolist(),'native_thumbward':side.tolist(),'donor_side':SIDE,'native_basis_normal':dorsal.tolist(),'native_anatomical_dorsal':(-FLEX*dorsal).tolist(),'world_anatomical_dorsal':(-FLEX*N).tolist(),'pose_degrees_local_x':angles,'scope':'Extended anatomical forearm/hand fitting component. Source is not cut; provisional elbow center from measured source sections is not an approved attachment loop. Exact self/intersection and actual all-angle pose/contact checks required.'}
bpy.context.view_layer.update();bpy.ops.wm.save_as_mainfile(filepath=str(D/f'native/scarlett_right_hand{TAG}.blend'))
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for modifier in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=modifier.name)
ob.data.calc_loop_triangles();rest_report['evaluated_triangles']=len(ob.data.loop_triangles)
out=D/f'components/scarlett_right_hand{TAG}.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
rest_report['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(D/f'checks/scarlett_hand{TAG}.json').write_text(json.dumps(rest_report,indent=2));print(json.dumps({k:v for k,v in rest_report.items() if k not in ('source_body_faces','source_vertices')},indent=2),flush=True)
