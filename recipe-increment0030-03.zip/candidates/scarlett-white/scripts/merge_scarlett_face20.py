"""Merge held eye optics with the separately supported forehead overlap cleanup."""
import pathlib,json,hashlib,numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_16_optical_axis_trial.glb';baseline=r/'models/scarlett_10_native4k_orbital_albedo.glb';j,b,a=read_glb(src);oj,ob,oa=read_glb(baseline);sc=np.array(j['nodes'][0]['scale']);tr=np.array(j['nodes'][0]['translation']);changed=[]
assert j['nodes']==oj['nodes']
for pi,(p,op)in enumerate(zip(j['meshes'][0]['primitives'],oj['meshes'][0]['primitives'])):
 F=a(p['indices']).reshape(-1,3);assert np.array_equal(F,oa(op['indices']).reshape(-1,3));P=a(p['attributes']['POSITION'])*sc+tr;oldP=oa(op['attributes']['POSITION'])*sc+tr;which=np.linalg.norm(P-oldP,axis=1)>1e-12
 if which.any():
  assert pi in[5,6,7,8,9,10];ids=np.flatnonzero(which[F].any(1));changed.extend([P[F[ids]],oldP[F[ids]]])
 else:
  if pi not in[5,6,7,8,9,10]:
   for key,ai in op['attributes'].items():assert np.array_equal(a(p['attributes'][key]),oa(ai))
changed=np.concatenate(changed);proofs=[];targets=[85184,51820,51821]
for rawid in targets:
 path=r/'checks'/f'scarlett94_raw{rawid}_support.json';q=json.loads(path.read_text());assert q['sha256']==hashlib.sha256(baseline.read_bytes()).hexdigest();tri=np.array(q['candidate_world_gltf_triangle']);separations=[]
 for obs in q['observations']:
  c=obs['counts']['all'];assert c['n']==c['first_hit_front_with_ties']==c['front_backing_within_5mm']==3321 and c['foreground_occluded']==0
  M=np.array(obs['camera_world_matrix_blender']);B=np.stack([changed[:,:,0],-changed[:,:,2],changed[:,:,1]],axis=-1);Q=np.c_[tri[:,0],-tri[:,2],tri[:,1]];proj=B@M[:3,:2];qt=Q@M[:3,:2];overlap=np.all(proj.max(1)>=qt.min(0)-1e-8,axis=1)&np.all(proj.min(1)<=qt.max(0)+1e-8,axis=1);assert not overlap.any(),('Changed eye geometry enters forehead proof ray bundle',rawid,obs['angle_degrees']);separations.append({'angle':obs['angle_degrees'],'changed_eye_triangles_overlapping_projected_forehead_triangle':0})
 proofs.append({'raw_face':rawid,'support_report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'eye_change_exclusion':separations})
sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];raw=np.load(r/'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids'];lookup={tuple(map(int,f)):int(raw[i])for i,f in enumerate(sa(sp['indices']).reshape(-1,3))};removed=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 if p['attributes']['POSITION']!=sp['attributes']['POSITION']:continue
 F=a(p['indices']).reshape(-1,3);ids=np.array([lookup.get(tuple(map(int,f)),-1)for f in F]);keep=~np.isin(ids,targets)
 if not keep.all():removed.extend(ids[~keep].tolist());p['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963)
assert sorted(removed)==sorted(targets)
out=r/'models/scarlett_20_face_material_geometry_merge.glb';write_glb(out,j,b);rep={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'forehead_baseline_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_raw_faces':removed,'proofs':proofs,'eye_geometry_and_all_materials_held_from16':True,'retained_source_attributes_held_from10':True,'status':'Coherent WIP face merge. Local eye and forehead evidence retained; new exact-file render regression and all remaining character gates stay open.'};(r/'checks/scarlett_20_face_material_geometry_merge.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
