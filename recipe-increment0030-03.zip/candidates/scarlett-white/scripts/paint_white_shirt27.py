"""Material-only repair of verified pale spill inside the black shirt panel.
World bounds separate apron/strap/button surfaces. Independent triangle charts
keep UVs disjoint; all original integer corner attributes are copied verbatim.
"""
import pathlib,json,hashlib,io,copy,struct,numpy as np
from PIL import Image
from scipy.spatial import cKDTree
from scipy.ndimage import distance_transform_edt
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_25_continuous_neck_paint_trial.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];F=a(p['indices']).reshape(-1,3);P=a(p['attributes']['POSITION'])*j['nodes'][0]['scale']+j['nodes'][0]['translation'];N=a(p['attributes']['NORMAL']);UV=a(p['attributes']['TEXCOORD_0']);C=P[F].mean(1);norm=N[F].mean(1);norm/=np.linalg.norm(norm,axis=1)[:,None];mat=j['materials'][p['material']]
def tex(ti):
 t=j['textures'][ti];ii=t.get('source',t.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];return np.asarray(Image.open(io.BytesIO(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB'))
base=tex(mat['pbrMetallicRoughness']['baseColorTexture']['index']);orm=tex(mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index'])
def sample(im,uv):
 h,w=im.shape[:2];xy=uv*np.array([w,h])-.5;ii=np.floor(xy).astype(int);f=xy-ii;xx=ii[:,0]%w;yy=ii[:,1]%h;return im[yy,xx]*(1-f[:,0,None])*(1-f[:,1,None])+im[yy,(xx+1)%w]*f[:,0,None]*(1-f[:,1,None])+im[(yy+1)%h,xx]*(1-f[:,0,None])*f[:,1,None]+im[(yy+1)%h,(xx+1)%w]*f[:,0,None]*f[:,1,None]
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
low=np.array([-.119,.474,.085]);high=np.array([-.025,.505,.143]);tri=P[F];selected=np.flatnonzero(np.all(tri.max(1)>=low,axis=1)&np.all(tri.min(1)<=high,axis=1)&(norm[:,2]>.25));assert 4<len(selected)<400
# Healthy black cloth donors in an expanded same-panel volume. Buttons and
# pale apron/strap material cannot donate to the replacement field.
domain=(C[:,0]>-.125)&(C[:,0]<-.023)&(C[:,1]>.466)&(C[:,1]<.548)&(C[:,2]>.04)&(C[:,2]<.148)&(norm[:,2]>.35);donor_ids=np.flatnonzero(domain);bc=np.array([[1/3]*3,[.6,.2,.2],[.2,.6,.2],[.2,.2,.6]]);dP=np.einsum('bj,fjk->fbk',bc,P[F[donor_ids]]).reshape(-1,3);dUV=np.einsum('bj,fjk->fbk',bc,UV[F[donor_ids]]).reshape(-1,2);dRGB=sample(base,dUV);good=(dRGB.max(1)<88)&(dRGB.min(1)>7)&((dRGB.max(1)-dRGB.min(1))<30);dORM=sample(orm,dUV)[good];dP=dP[good];dRGB=dRGB[good];assert len(dP)>50;tree=cKDTree(dP[:,:2])
# A dense, bounded source-contamination footprint includes its dim perimeter.
seed_bc=np.array([[i/12,k/12,1-(i+k)/12]for i in range(13)for k in range(13-i)]);seedP=np.einsum('bj,fjk->fbk',seed_bc,P[F[selected]]).reshape(-1,3);seedUV=np.einsum('bj,fjk->fbk',seed_bc,UV[F[selected]]).reshape(-1,2);seedRGB=sample(base,seedUV);seed_alpha=np.prod(smooth((seedP-low)/.004)*smooth((high-seedP)/.004),axis=1);seedP=seedP[(seedRGB.mean(1)>110)&(seed_alpha>.05)];assert len(seedP)>20;contamination=cKDTree(seedP[:,:2])
S=2048;grid=int(np.ceil(np.sqrt(len(selected))));cell=S//grid;pad=5;assert cell>=70;paint=np.zeros((S,S,3),np.uint8);rough=np.zeros_like(paint);newUV=[];changed=0;maxdistance=0.;sourceface=[]
for i,fi in enumerate(selected):
 gx=i%grid;gy=i//grid;x0=gx*cell;y0=gy*cell;corn=np.array([[x0+pad,y0+pad],[x0+cell-pad-1,y0+pad],[x0+pad,y0+cell-pad-1]],float);newUV.extend((corn+.5)/S);yy,xx=np.meshgrid(np.arange(y0,y0+cell),np.arange(x0,x0+cell),indexing='ij');u=(xx-corn[0,0])/(corn[1,0]-corn[0,0]);v=(yy-corn[0,1])/(corn[2,1]-corn[0,1]);inside=(u>=0)&(v>=0)&(u+v<=1);weights=np.c_[1-u[inside]-v[inside],u[inside],v[inside]];Q=weights@P[F[fi]];uv=weights@UV[F[fi]];color=sample(base,uv);o=sample(orm,uv);alpha=np.prod(smooth((Q-low)/.004)*smooth((high-Q)/.004),axis=1);dd=contamination.query(Q[:,:2])[0];alpha*=1-smooth((dd-.002)/.003);dist,idx=tree.query(Q[:,:2],k=12);w=1/np.maximum(dist,.002)**2;field=(dRGB[idx]*w[:,:,None]).sum(1)/w.sum(1)[:,None];maxdistance=max(maxdistance,float(dist[:,0][alpha>.01].max())if np.any(alpha>.01)else 0.);changed+=int((alpha>.01).sum());color=color*(1-alpha[:,None])+field*alpha[:,None];ormfield=(dORM[idx]*w[:,:,None]).sum(1)/w.sum(1)[:,None];o=o*(1-alpha[:,None])+ormfield*alpha[:,None]
 tile=np.zeros((cell,cell,3),np.uint8);tile[inside]=np.rint(np.clip(color,0,255)).astype(np.uint8);otile=np.zeros_like(tile);otile[inside]=np.rint(np.clip(o,0,255)).astype(np.uint8);_,nearest=distance_transform_edt(~inside,return_indices=True);tile[~inside]=tile[nearest[0][~inside],nearest[1][~inside]];otile[~inside]=otile[nearest[0][~inside],nearest[1][~inside]];paint[y0:y0+cell,x0:x0+cell]=tile;rough[y0:y0+cell,x0:x0+cell]=otile;sourceface.append(int(fi))
assert changed>100 and maxdistance<.035
textures=[]
for data,label in[(paint,'albedo'),(rough,'ORM')]:
 q=io.BytesIO();Image.fromarray(data).save(q,format='PNG');payload=q.getvalue();(r/'checks'/f'white27_shirt_{label}.png').write_bytes(payload);b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(payload)});b+=payload;ii=len(j['images']);j['images'].append({'name':'White bounded shirt spill cleanup27 '+label,'bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});textures.append(ti)
attrs={};ids=F[selected].reshape(-1)
for key,ai in p['attributes'].items():
 if key in['TEXCOORD_0','TANGENT']:continue
 raw=a(ai,normalized=False)[ids];raw=np.ascontiguousarray(raw);old=j['accessors'][ai];b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':raw.nbytes,'target':34962});b+=raw.tobytes();q={'bufferView':vi,'componentType':old['componentType'],'count':len(ids),'type':old['type']}
 if key=='POSITION':q.update(min=raw.min(0).tolist(),max=raw.max(0).tolist())
 if old.get('normalized'):q['normalized']=True
 attrs[key]=len(j['accessors']);j['accessors'].append(q)
attrs['TEXCOORD_0'],b=append_accessor(j,b,np.array(newUV,np.float32),'VEC2',34962);ix,b=append_accessor(j,b,np.arange(len(ids),dtype=np.uint32),'SCALAR',34963);newmat=copy.deepcopy(mat);newmat['name']='White measured black shirt panel27';newmat['pbrMetallicRoughness']['baseColorTexture']['index']=textures[0];newmat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=textures[1]
if'occlusionTexture'in newmat:newmat['occlusionTexture']['index']=textures[1]
mi=len(j['materials']);j['materials'].append(newmat);keep=np.ones(len(F),bool);keep[selected]=False;p['indices'],b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'mode':4,'material':mi});out=r/'models/white_27_shirt_paint_trial.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out)
for key,ai in attrs.items():
 if key!='TEXCOORD_0':assert np.array_equal(aa(ai,normalized=False),a(j['meshes'][0]['primitives'][0]['attributes'][key],normalized=False)[ids])
rep={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'selected_source25_primitive0_faces':selected.tolist(),'source_corner_attributes_bitwise_held':True,'source_face_multiset_held':True,'new_disjoint_triangle_charts':len(selected),'atlas_dimensions':[S,S],'cell_pixels':cell,'gutter_pixels':pad,'atlas_chart_overlap_faces':0,'changed_texels':changed,'dense_contamination_seed_points':len(seedP),'contamination_full_radius_m':.002,'contamination_fade_outer_radius_m':.005,'base_and_ORM_restored_from_same_healthy_cloth_donors':True,'physical_mask_bounds_gltf':[low.tolist(),high.tolist()],'healthy_same_panel_donor_samples':len(dP),'maximum_nearest_donor_distance_m':maxdistance,'protected_regions':'Explicit bounds exclude central buttons, apron front at greater Z and both outer straps. The measured bright-contamination footprint is dilated2mm and faded to5mm within the bounded cloth field, covering its dim outline; base color and ORM use the same healthy cloth donors.','status':'Material-only internal trial. Exact PBR/unlit and side-boundary appearance required; geometry, collar, cuffs/hands and whole-character gates remain open.'};(r/'checks/white_27_shirt_paint_trial.json').write_text(json.dumps(rep,indent=2));print({k:v for k,v in rep.items()if k!='selected_source25_primitive0_faces'},flush=True)
