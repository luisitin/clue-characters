import argparse,json,time,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from uv_raster import samples
from cloth_fields233 import ClothFields
D=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--row',type=int,required=True);args=ap.parse_args();res=2048;row0=args.row;row1=min(row0+512,res);z=np.load(D/'inputs/grip_cuff231_binding.npz');a={k:z[k] for k in z.files};zt=np.load(D/'inputs/grip_cuff232_tangents.npz');basis={k:zt[k] for k in zt.files};T=a['T'];M=a['MATERIAL'];selected=np.flatnonzero(M<3);UV=a['UV_PACKED'];ST=a['SOURCE_UV'];PT=a['P'][T];NT=a['N'][T];TB=basis['T_NATIVE'];SG=basis['SIGN_NATIVE'];E=(PT[:,1:]-PT[:,:1]).transpose(0,2,1);EU=(ST[:,1:]-ST[:,:1]).transpose(0,2,1);Juv=EU@np.linalg.inv(E.transpose(0,2,1)@E)@E.transpose(0,2,1);fields=ClothFields();valid=np.zeros((row1-row0,res),'u1');color=np.zeros((row1-row0,res,3),'u1');normal=np.zeros_like(color);orm=np.zeros_like(color);buffers=[];count=0;start=time.time()
def flush():
 global buffers,count
 if not buffers:return
 fi=np.concatenate([b[0] for b in buffers]);y=np.concatenate([b[1] for b in buffers]);x=np.concatenate([b[2] for b in buffers]);b=np.concatenate([b[3] for b in buffers]);P=np.einsum('ni,nij->nj',b,PT[fi]);N=np.einsum('ni,nij->nj',b,NT[fi]);N/=np.linalg.norm(N,axis=1,keepdims=True);uv=np.einsum('ni,nij->nj',b,ST[fi]);mat=M[fi];C,H,rough=fields.material(P,N,uv,mat);grad=np.empty_like(P);eps=.00006
 for axis in range(3):
  delta=np.zeros(3);delta[axis]=eps;duv=Juv[fi,:,axis]*eps;hp=fields.material(P+delta,N,uv+duv,mat,False)[1];hm=fields.material(P-delta,N,uv-duv,mat,False)[1];grad[:,axis]=(hp-hm)/(2*eps)
 tangent=np.einsum('ni,nij->nj',b,TB[fi]);tangent-=np.sum(tangent*N,axis=1,keepdims=True)*N;tangent/=np.linalg.norm(tangent,axis=1,keepdims=True);bit=np.cross(N,tangent)*SG[fi,0,None];nn=np.column_stack((-np.sum(grad*tangent,axis=1),-np.sum(grad*bit,axis=1),np.ones(len(fi))));nn/=np.linalg.norm(nn,axis=1,keepdims=True);assert not np.any(valid[y,x]);valid[y,x]=1;color[y,x]=np.rint(C*255).astype('u1');normal[y,x]=np.rint((nn*.5+.5)*255).astype('u1');orm[y,x,0]=255;orm[y,x,1]=np.rint(rough*255).astype('u1');buffers=[];count=0
for i,y,x,b in samples(UV[selected],res,row0,row1):
 fi=selected[i];buffers.append((np.full(len(y),fi,'i4'),y,x,b));count+=len(y)
 if count>=16384:flush()
flush();folder=D/'textures/cuff234_tiles';folder.mkdir(exist_ok=True);out={}
for name,value in [('base',color),('normal',normal),('orm',orm),('valid',valid*255)]:
 p=folder/f'{name}_{row0}.png';Image.fromarray(value).save(p);out[name]=hashlib.sha256(p.read_bytes()).hexdigest()
r={'row0':row0,'row1':row1,'resolution':res,'occupied_texels':int(valid.sum()),'outputs':out,'seconds':time.time()-start,'normal_basis':'World-metric scalar field derivative projected onto explicit native Mikk tangent/signed bitangent. UV seam stitches use original-chart Jacobian, not repacked cell coordinates.','scope':'Outer wool/lining/cotton only. Separate cap tile is intentional repeat material.'};(folder/f'tile_{row0}.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
