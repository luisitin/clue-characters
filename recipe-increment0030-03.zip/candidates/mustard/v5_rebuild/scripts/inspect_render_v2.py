"""Actual GLB import and immutable-view evidence. Run in Blender under run_heavy.sh."""
import bpy, os, math, json, hashlib
from pathlib import Path
from mathutils import Vector

D=Path(__file__).resolve().parents[1]
ROOT=D.parents[2]
src=Path(os.environ.get('GLB',str(ROOT/'sources/prelod-cd4c20d/sus-mustard.glb')))
out=Path(os.environ.get('OUT',str(D/'diagnostics/source_front')))
out.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(src))
objs=[o for o in bpy.context.scene.objects if o.type=='MESH']
points=[o.matrix_world@Vector(c) for o in objs for c in o.bound_box]
lo=Vector([min(p[i] for p in points) for i in range(3)])
hi=Vector([max(p[i] for p in points) for i in range(3)])
target=Vector([float(x) for x in os.environ.get('TARGET',','.join(str(v) for v in (lo+hi)/2)).split(',')])
az=math.radians(float(os.environ.get('AZ','0')))
el=math.radians(float(os.environ.get('ELEV_DEG','8')))
scale=float(os.environ.get('SCALE',str(max(hi.z-lo.z,hi.x-lo.x)*1.12)))
resolution=int(os.environ.get('RES','800'))
mode=os.environ.get('MODE','pbr')
materials=[{'name':m.name,'use_nodes':m.use_nodes} for m in bpy.data.materials]
images=[{'name':im.name,'size':list(im.size),'colorspace':im.colorspace_settings.name} for im in bpy.data.images]
if mode=='clay':
    for mat in bpy.data.materials:
        mat.use_nodes=True; nodes=mat.node_tree.nodes; nodes.clear()
        diff=nodes.new('ShaderNodeBsdfDiffuse'); diff.inputs['Color'].default_value=(.52,.48,.42,1)
        output=nodes.new('ShaderNodeOutputMaterial'); mat.node_tree.links.new(diff.outputs[0],output.inputs['Surface'])
    for im in list(bpy.data.images):
        if im.users==0: bpy.data.images.remove(im)
elif mode=='unlit':
    for mat in bpy.data.materials:
        if not mat.use_nodes: continue
        nodes=mat.node_tree.nodes; p=next((n for n in nodes if n.type=='BSDF_PRINCIPLED'),None)
        output=next((n for n in nodes if n.type=='OUTPUT_MATERIAL'),None)
        if not p or not output: continue
        emission=nodes.new('ShaderNodeEmission')
        emission.inputs[0].default_value=p.inputs['Base Color'].default_value
        for link in list(p.inputs['Base Color'].links):mat.node_tree.links.new(link.from_socket,emission.inputs[0])
        mat.node_tree.links.new(emission.outputs[0],output.inputs['Surface'])

scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=int(os.environ.get('SAMPLES','32'))
scene.cycles.use_denoising=False
scene.render.resolution_x=resolution;scene.render.resolution_y=resolution;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.world=bpy.data.worlds.new('Studio world');scene.world.use_nodes=True
scene.world.node_tree.nodes.get('Background').inputs[0].default_value=(.16,.18,.21,1)
scene.world.node_tree.nodes.get('Background').inputs[1].default_value=.45
scene.view_settings.view_transform='AgX'
cam_data=bpy.data.cameras.new('Evidence camera');cam=bpy.data.objects.new('Evidence camera',cam_data);scene.collection.objects.link(cam)
direction=Vector((math.sin(az)*math.cos(el),-math.cos(az)*math.cos(el),math.sin(el)))
cam.location=target+direction*max(4.0,scale*2)
cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
cam_data.type='ORTHO';cam_data.ortho_scale=scale;cam_data.clip_start=.001;cam_data.clip_end=100
scene.camera=cam
for name,offset,power,size in [('Key',(-3,-4,5),650,4),('Fill',(4,-2,2),300,3),('Rim',(2,4,4),500,3)]:
    ld=bpy.data.lights.new(name,'AREA');ld.energy=power;ld.shape='DISK';ld.size=size
    ob=bpy.data.objects.new(name,ld);scene.collection.objects.link(ob);ob.location=target+Vector(offset)
    ob.rotation_euler=(target-ob.location).to_track_quat('-Z','Y').to_euler()
bpy.context.view_layer.update()
meshes=[]
for o in objs:
    o.data.calc_loop_triangles()
    meshes.append({'name':o.name,'vertices':len(o.data.vertices),'triangles':len(o.data.loop_triangles),'matrix_world':[list(r) for r in o.matrix_world]})
report={'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'mode':mode,'bounds':[list(lo),list(hi)],'target':list(target),'azimuth_degrees':math.degrees(az),'elevation_degrees':math.degrees(el),'camera_matrix_world':[list(r) for r in cam.matrix_world],'projection':'ORTHO','ortho_scale':scale,'pixels':[resolution,resolution],'meshes':meshes,'triangles':sum(x['triangles'] for x in meshes),'materials':materials,'images':images,'material_override_mode':mode if mode=='clay' else None,'geometry_custom_normals_overridden':False,'normal_texture_disabled':mode=='clay','samples':scene.cycles.samples}
out.with_suffix('.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report),flush=True)
scene.render.filepath=str(out.with_suffix('.png'))
if os.environ.get('NO_RENDER','0')!='1':bpy.ops.render.render(write_still=True)
