"""Read-only clean garment-section candidates around the registered gripping wrist.
No source removal or skin/cloth ownership is inferred from color.
"""
from pathlib import Path
import numpy as np,json,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_cut_unit104.glb');P,T,N,UV=g.native();unique,group=np.unique(P,axis=0,return_inverse=True);G=group[T];r=json.loads((D/'audit/grip150_registration.json').read_text());H=np.array([-.335,-.065,.380]);rows=[]
for trial_axis,offset in [(v,s) for v in [[.3,-.95,.05],[.25,-.94,.25],[0.,-1.,0.],[.5,-.85,.15]] for s in [-.03,-.02,-.01,0.,.01,.02]]:
 axis=np.array(trial_axis);axis/=np.linalg.norm(axis);C=H-offset*axis;sd=(P-C)@axis;lo=P[T].min(1);hi=P[T].max(1);near=np.ones(len(T),bool);crossing=np.flatnonzero(near&(np.min(sd[T],axis=1)<0)&(np.max(sd[T],axis=1)>0));nodes={};positions=[];segments=[];owners=[]
 for fi in crossing:
  ids=T[fi];seen=[]
  for k in range(3):
   a,b=int(ids[k]),int(ids[(k+1)%3])
   if sd[a]*sd[b]<0:
    key=tuple(sorted((int(group[a]),int(group[b]))))
    if key not in nodes:
     w=sd[a]/(sd[a]-sd[b]);nodes[key]=len(positions);positions.append(P[a]+w*(P[b]-P[a]))
    seen.append(nodes[key])
  assert len(seen)==2;segments.append(seen);owners.append(int(fi))
 positions=np.array(positions);segments=np.array(segments);adj=collections.defaultdict(list)
 for j,(a,b) in enumerate(segments):adj[int(a)].append((int(b),j));adj[int(b)].append((int(a),j))
 visited=set();components=[]
 for seed in adj:
  if seed in visited:continue
  stack=[seed];vertices=[];edges=set();visited.add(seed)
  while stack:
   x=stack.pop();vertices.append(x)
   for y,e in adj[x]:
    edges.add(e)
    if y not in visited:visited.add(y);stack.append(y)
  vp=positions[vertices];center=vp.mean(0);radius=np.linalg.norm(vp-C,axis=1);dist=float(np.linalg.norm(center-C))
  if dist>.20:continue
  degree=collections.Counter(len(adj[x]) for x in vertices);simple=set(degree)=={2};ordered=[]
  if simple:
   cur=seed;prev=None
   while not ordered or cur!=ordered[0]:
    ordered.append(cur);nxt=next(y for y,e in adj[cur] if y!=prev);prev,cur=cur,nxt;assert len(ordered)<=len(vertices)+1
  localfaces=np.array([owners[e] for e in sorted(edges)]);tp=P[T[localfaces]];gn=np.cross(tp[:,1]-tp[:,0],tp[:,2]-tp[:,0]);gn/=np.linalg.norm(gn,axis=1,keepdims=True);normaldots=np.einsum('ij,ikj->ik',gn,N[T[localfaces]])
  components.append({'nodes':len(vertices),'edges':len(edges),'degree_counts':dict(degree),'simple_closed_cycle':simple,'center':center.tolist(),'center_distance_to_wrist_axis_m':dist,'radius_range_from_wrist_axis_m':[float(radius.min()),float(radius.max())],'world_bounds':[vp.min(0).tolist(),vp.max(0).tolist()],'source_face_ids':localfaces.tolist(),'opposed_corner_normals':int(np.count_nonzero(normaldots<0)),'ordered_boundary_positions':positions[ordered].tolist() if simple else None})
 rows.append({'proximal_offset_m':offset,'plane_center':C.tolist(),'plane_normal':axis.tolist(),'components':components})
result={'source_sha256':g.sha256,'registered_hand_sha256':r['output_sha256'],'provisional_forearm_region_center':H.tolist(),'full_source_plane_intersections':True,'sections':rows,'scope':'Geometric section inventory only. A simple cycle and positive source normals do not alone prove garment ownership. Inspect actual source/part-ID views and protect the separate diagonal belt before any cut.'};(D/'audit/grip_sleeve163_full_sections.json').write_text(json.dumps(result,indent=2));print(json.dumps([{'offset':x['proximal_offset_m'],'components':[{k:v for k,v in c.items() if k not in ('source_face_ids','ordered_boundary_positions')} for c in x['components']]} for x in rows],indent=2),flush=True)
