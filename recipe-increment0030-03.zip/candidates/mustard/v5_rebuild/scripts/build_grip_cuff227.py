"""Tailored coat tube with a deep lining return and independent-looking close-fitting shirt cuff.
The connected return lies deep inside the sleeve, rather than spanning the visible mouth as a disc.
"""
from pathlib import Path
import numpy as np,json,copy
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from glb_io import GLB
D=Path(__file__).resolve().parents[1];body=GLB(D/'inputs/body_domain_cut203.glb');BP,BT,BN,BUV=body.native();z=np.load(D/'inputs/grip_profile220.npz');a={k:z[k] for k in z.files};rim=a['RIM'];ids=a['SOURCE_IDS'];M=len(rim);C0=a['CENTER'];N0=a['N0'];U0=a['U0'];V0=a['V0'];F=a['F'];H=a['H'];UF=a['UF'];VF=a['VF'];sourceU=a['ARC'];count=192;u=np.arange(count)/count;sgn=np.sign(a['THETA'][-1]-a['THETA'][0]);theta=a['THETA'][0]+sgn*2*np.pi*u
def interp(data):return np.column_stack([np.interp(u,np.r_[sourceU,1],np.r_[data[:,k],data[0,k]]) for k in range(data.shape[1])]) if data.ndim==2 else np.interp(u,np.r_[sourceU,1],np.r_[data,data[0]])
sourceP=interp(rim);sourceN=interp(BN[ids]);sourceN/=np.linalg.norm(sourceN,axis=1,keepdims=True);D0=N0-sourceN*np.sum(sourceN*N0,axis=1,keepdims=True);D0/=np.linalg.norm(D0,axis=1,keepdims=True)
q=(rim-C0)@np.column_stack((U0,V0));r0=np.quantile(np.abs(q),.985,axis=0);frontR=np.array([.047,.049]);Cfront=H-.007*F;delta=Cfront-C0
def smooth(t):return t*t*(3-2*t)
rotation_axis=np.cross(N0,F);rotation_sine=np.linalg.norm(rotation_axis);rotation_angle=np.arccos(np.clip(N0@F,-1,1));rotation_axis/=rotation_sine;K=np.array([[0,-rotation_axis[2],rotation_axis[1]],[rotation_axis[2],0,-rotation_axis[0]],[-rotation_axis[1],rotation_axis[0],0]])
def frame(t):
 angle=.5*rotation_angle*smooth(t);R=np.eye(3)+np.sin(angle)*K+(1-np.cos(angle))*(K@K);return R@U0,R@V0,R@N0
def coat(t,allowance=0):
    center=C0+t*delta;radius=r0+(frontR-r0)*smooth(t)+allowance
    cu,cv,cn=frame(t);return center+np.cos(theta)[:,None]*cu*radius[0]+np.sin(theta)[:,None]*cv*radius[1]
ideal0=coat(0);desiredDerivative=D0*np.linalg.norm(coat(1)-sourceP,axis=1,keepdims=True)*.85;rows=[rim];us=[sourceU];row_names=['held source garment boundary'];row_material=[]
def add(points,name,material):rows.append(points);us.append(u);row_names.append(name);row_material.append(material)
for t in [.02,.04,.07,.11,.17,.24,.30,.38,.48,.60,.73,.86,1]:
    p=coat(t)
    if t<.30:
        x=t/.30;w0=2*x**3-3*x*x+1;w1=.30*(x**3-2*x*x+x)
        p+=w0*(sourceP-ideal0)+w1*(desiredDerivative-delta)
    add(p,'tailored gold sleeve',0)
frontU,frontV,frontN=frame(1.)
def ellipse(center,ruv,U=frontU,V=frontV):return center+np.cos(theta)[:,None]*U*ruv[0]+np.sin(theta)[:,None]*V*ruv[1]
for s,r in [(.002,.001),(.004,.0005),(.005,-.001),(.004,-.003),(.002,-.004),(0,-.004)]:add(ellipse(Cfront+s*frontN,frontR+r),'rolled wool lip',0)
for t in [.90,.75,.60,.48,.40]:add(coat(t,-.004),'coat lining',1)
# Wool lining and cotton shirt are distinct garments. Do not bridge their openings.
break_strip=len(rows)-1
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=D.parents[2];sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'));from load_donor import load_donor
donor=load_donor();native_wrist=donor['joint_positions']['wrist.R____head'];pose=json.loads((D/'audit/grip179.json').read_text());native_F=np.array(pose['native_forward']);zz=np.load(D/'inputs/grip179_paint_binding185.npz');binding={k:zz[k] for k in zz.files};rest_f=(binding['REST']-native_wrist)@native_F
hg=GLB(D/'inputs/grip_registered210.glb');HP,HT,HN,HUV=hg.native();wrist_faces=np.flatnonzero(np.max(rest_f[binding['T']],axis=1)<.35);bvh=BVHTree.FromPolygons(HP.tolist(),HT[wrist_faces].tolist(),all_triangles=True,epsilon=0)
radialF=np.cos(theta)[:,None]*UF+np.sin(theta)[:,None]*VF
measure_s=np.array([-.018,-.012,-.006,0,.006,.010,.014,.016]);radii=np.full((len(measure_s),count),np.nan);face_hits=[]
for si,ss0 in enumerate(measure_s):
    center=H+ss0*F
    for k,direction in enumerate(radialF):
        hit,n,fi,dd=bvh.ray_cast(Vector(center+direction*.08),Vector(-direction),.08)
        if hit is not None and float(np.dot(n,direction))>.3:
            radii[si,k]=.08-float(dd);face_hits.append(int(wrist_faces[fi]))
for k in range(count):
    valid=np.isfinite(radii[:,k]);assert valid.any(),k;radii[:,k]=np.interp(measure_s,measure_s[valid],radii[valid,k])
assert radii.min()>.005 and radii.max()<.05,(radii.min(),radii.max())
# The open skin extraction stops between wrist sections. The proximal cotton tube
# retains the maximum measured wrist envelope behind that cut rather than diving
# through it. Native anatomical ownership excludes folded fingertip surfaces.
proximal=np.max(radii[:3],axis=0)
def skinradius(s):
    if s<=-.012:return proximal
    current=np.array([np.interp(s,measure_s,radii[:,k]) for k in range(count)])
    if s<-.006:
        w=smooth((s+.012)/.006);return proximal*(1-w)+current*w
    return current
cotton_start=len(rows)
profile=[(-.043,.004),(-.035,.0038),(-.027,.0035),(-.02,.003),(-.012,.0025),(-.006,.002),(0,.002),(.006,.002),(.012,.002)]
profile +=[(.014+.00065*np.sin(phi),.00135+.00065*np.cos(phi)) for phi in np.linspace(0,np.pi,9)]
profile +=[(.010,.0007),(.006,.0007),(0,.0007),(-.006,.001),(-.012,.0015),(-.02,.002),(-.027,.002),(-.035,.002),(-.043,.002)]
profile +=[(-.043-.001*np.sin(phi),.003-.001*np.cos(phi)) for phi in np.linspace(0,np.pi,9)[1:]]
# The cut-plane normal is not an anatomical centerline. Guide the hidden shirt
# toward the actual coat interior using only a translation perpendicular toF.
# Thus every section retains its ordered longitudinal coordinate, preventing
# the folded/returning profile of earlier attempts. The visible wrist is held.
interior_target=C0+.5*delta;hidden_shift=interior_target-(H-.043*F);hidden_shift-=F*(hidden_shift@F);assert abs(hidden_shift@F)<1e-12
for ss0,allowance in profile:
    w=smooth(np.clip((-.018-ss0)/.025,0,1));center=H+ss0*F+w*hidden_shift
    add(center+radialF*(skinradius(ss0)+allowance)[:,None],'independent cotton cuff',2)
rows[-1]=rows[cotton_start].copy()
offsets=[];world=[];UV=[];at=0
for j,(row,uu) in enumerate(zip(rows,us)):
    offsets.append(at);world.extend(np.vstack((row,row[0])));UV.extend(np.column_stack((np.r_[uu,1],np.full(len(row)+1,j/(len(rows)-1)))));at+=len(row)+1
world=np.array(world);UV=np.array(UV,'f4');tri=[];mats=[];strip=[]
for k in range(len(rows)-1):
    if k==break_strip:continue
    A=np.r_[us[k],1];B=np.r_[us[k+1],1];i=j=0;na=len(rows[k]);nb=len(rows[k+1]);oa=offsets[k];ob=offsets[k+1]
    while i<na or j<nb:
        aa=A[i+1] if i<na else np.inf;bb=B[j+1] if j<nb else np.inf
        if abs(aa-bb)<1e-12:
            tri.extend([[oa+i,oa+i+1,ob+j+1],[oa+i,ob+j+1,ob+j]]);mats.extend([row_material[k]]*2);strip.extend([k]*2);i+=1;j+=1
        elif aa<bb:tri.append([oa+i,oa+i+1,ob+j]);mats.append(row_material[k]);strip.append(k);i+=1
        else:tri.append([oa+i,ob+j+1,ob+j]);mats.append(row_material[k]);strip.append(k);j+=1
tri=np.array(tri,'i4');mats=np.array(mats,'i4');strip=np.array(strip,'i4');GN=np.cross(world[tri[:,1]]-world[tri[:,0]],world[tri[:,2]]-world[tri[:,0]]);first=strip==0;rad=world[tri[first]].mean(1)-C0;rad-=np.sum(rad*N0,axis=1,keepdims=True)*N0
if np.sum(GN[first]*rad)<0:tri=tri[:,[0,2,1]];GN=-GN
# Recessed lining closure,18mm behind its held deep inner edge. It never spans
# the visible sleeve mouth and does not connect the cotton cuff to the wool.
from scipy.spatial import Delaunay
boundary=rows[break_strip];cap_center=boundary.mean(0);capU,capV,capN=frame(.40);cap_xy=(boundary-cap_center)@np.column_stack((capU,capV));cap_r=np.array([np.max(np.abs(cap_xy[:,0])),np.max(np.abs(cap_xy[:,1]))]);grid=[]
for iy,yy in enumerate(np.arange(-cap_r[1],cap_r[1]+.0045,.0045)):
    for xx in np.arange(-cap_r[0],cap_r[0]+.0045,.0045):
        xx+=.00227*(iy%2)
        if (xx/cap_r[0])**2+(yy/cap_r[1])**2<.94**2:grid.append((xx,yy))
xy=np.vstack((cap_xy,np.array(grid)));dt=Delaunay(xy);cap_faces=dt.simplices.copy();rr=(xy[:,0]/cap_r[0])**2+(xy[:,1]/cap_r[1])**2;capP=cap_center+xy[:,0,None]*capU+xy[:,1,None]*capV-.050*np.maximum(1-rr,0)[:,None]*capN;capP[:count]=boundary
cap_map=np.arange(len(world),len(world)+len(capP));new_cap=cap_map[cap_faces];world=np.vstack((world,capP));UV=np.vstack((UV,(xy/.08+.5).astype('f4')));capGN=np.cross(world[new_cap[:,1]]-world[new_cap[:,0]],world[new_cap[:,2]]-world[new_cap[:,0]]);flip=(capGN@capN)<0;new_cap[flip]=new_cap[flip][:,[0,2,1]];capGN=np.cross(world[new_cap[:,1]]-world[new_cap[:,0]],world[new_cap[:,2]]-world[new_cap[:,0]]);assert np.min(capGN@capN)>0
tri=np.vstack((tri,new_cap));GN=np.vstack((GN,capGN));mats=np.r_[mats,np.full(len(new_cap),3)];strip=np.r_[strip,np.full(len(new_cap),-1)]
area=np.linalg.norm(GN,axis=1);assert area.min()>1e-12
_,pg=np.unique(world,axis=0,return_inverse=True);acc=np.zeros((pg.max()+1,3))
for k in range(3):np.add.at(acc,pg[tri[:,k]],GN)
norm=acc[pg];norm/=np.linalg.norm(norm,axis=1,keepdims=True);norm[:M]=BN[ids];norm[M]=BN[ids[0]];dots=np.einsum('ij,ikj->ik',GN/area[:,None],norm[tri]);bad=np.flatnonzero(dots.min(1)<0);print('BAD_NORMALS',[(int(i),int(strip[i]),float(dots[i].min())) for i in bad[:40]],flush=True)
np.savez_compressed(D/'inputs/separate_grip_cuff227_diagnostic.npz',P=world,T=tri,N=norm,DOTS=dots,STRIP=strip,MATERIAL=mats);assert not len(bad)
node=copy.deepcopy(body.j['nodes'][0]);old=body.primitive();rawP=body.read(old['attributes']['POSITION'],False);rawN=body.read(old['attributes']['NORMAL'],False);S=np.array(node.get('scale',[1,1,1]));Tr=np.array(node.get('translation',[0,0,0]));P=(((world[:,[0,2,1]]*[1,1,-1])-Tr)/S).astype('f4');P[:M]=rawP[ids];P[M]=rawP[ids[0]];NN=(norm[:,[0,2,1]]*[1,1,-1]).astype('f4');NN[:M]=rawN[ids];NN[M]=rawN[ids[0]]
g=object.__new__(GLB);g.bin=bytearray();g.j={'asset':{'version':'2.0','generator':'Layered cuff227'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'meshes':[],'nodes':[],'materials':[],'scenes':[{'nodes':[0]}],'scene':0};attrs={'POSITION':g.append(P,'VEC3',5126,34962),'NORMAL':g.append(NN,'VEC3',5126,34962),'TEXCOORD_0':g.append(UV,'VEC2',5126,34962)};prims=[]
for mi,(name,col,rough) in enumerate([('Mustard wool coat cuff',[.54,.30,.065,1],.76),('Mustard wool lining',[.54,.30,.065,1],.88),('Ivory cotton shirt cuff',[.8,.77,.68,1],.83),('Recessed wool sleeve lining',[.54,.30,.065,1],.88)]):
    g.j['materials'].append({'name':name,'pbrMetallicRoughness':{'baseColorFactor':col,'roughnessFactor':rough,'metallicFactor':0},'doubleSided':False});prims.append({'attributes':attrs.copy(),'indices':g.append(tri[mats==mi].ravel(),'SCALAR',5125,34963),'material':mi,'mode':4})
g.j['meshes']=[{'name':'Layered gripping cuff227','primitives':prims}];node.update(mesh=0,name='Layered gripping cuff227');node.pop('children',None);g.j['nodes']=[node];out=D/'inputs/grip_cuff227.glb';sha=g.save(out);actual=(P.astype('f8')*S+Tr)[:,[0,2,1]]*[1,-1,1];assert np.array_equal(actual[:M],rim)
np.savez_compressed(D/'inputs/grip_cuff227_binding.npz',P=actual,T=tri,N=norm,UV=UV,MATERIAL=mats,STRIP=strip,BOUNDARY_BODY_IDS=ids,BOUNDARY_CUFF_IDS=np.arange(M))
report={'mouth_frame_rotation_degrees':float(np.degrees(rotation_angle)*.5),'mouth_to_hand_axis_degrees':float(np.degrees(rotation_angle)*.5),'mouth_normal_matches_hand_axis':False,'fixed_source_frame_at_root':True,'hidden_shirt_perpendicular_shift':hidden_shift.tolist(),'wrist_axis_coordinate_preserved':True,'recessed_lining_closure':{'depth_m':.050,'triangles':len(new_cap),'boundary_positions_exact':True,'chart':'Separate material, world-metric intentionally repeatable fabric UV'},'separate_clothing_components':True,'lining_inner_edge_scope':'Closed by a recessed constrained triangulation at the deep interior edge; visible mouth remains open around cotton.','wrist_native_face_count':len(wrist_faces),'wrist_profile_range':[float(radii.min()),float(radii.max())],'output_sha256':sha,'body_sha256':body.sha256,'triangles':len(tri),'rings':len(rows),'source_boundary_nodes':M,'uniform_interior_samples':count,'boundary_positions_and_normals_exact':True,'minimum_double_area':float(area.min()),'minimum_corner_normal_dot_geometry':float(dots.min()),'initial_ellipse_radii':r0.tolist(),'coat_mouth_radii':frontR.tolist(),'rows':row_names,'scope':'Separate anatomically measured cotton cuff and body-connected wool sleeve/lining. No artificial coat-to-shirt bridge; contact and exposing views pending.'}
(D/'audit/grip_cuff227.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2),flush=True)
