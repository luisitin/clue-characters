"""Identify whether the54-node aperture is accidental removal of intact source backing."""
from pathlib import Path
import numpy as np,json,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_cut_unit104.glb');P,T,N,UV=g.native();r=json.loads((D/'audit/old_prop215_domain.json').read_text());sphere=r['sleeve_radius']-np.linalg.norm(P-np.array(r['sleeve_center']),axis=1);plane=(P-np.array(r['sleeve_plane_center']))@np.array(r['sleeve_plane_normal']);sv=np.minimum(sphere,plane)
B,A=np.array(r['shaft_segment_endpoints']);axis=(A-B)/np.linalg.norm(A-B);span=np.linalg.norm(A-B);tt=(P-B)@axis;nearest=B+np.clip(tt,0,span)[:,None]*axis;rad=.047+.018*(1-np.clip(tt/.06,0,1))+.016*np.clip((tt-span+.06)/.06,0,1);shaft=rad-np.linalg.norm(P-nearest,axis=1);ell=(1-np.linalg.norm((P-r['hand_ellipsoid_center'])/r['hand_ellipsoid_radii'],axis=1))*.10;lim=np.clip(-.05-(P[:,0]+.24)*.61,-.13,.025);hand=np.minimum.reduce([ell,plane,lim-P[:,1]]);other=np.maximum(shaft,hand)
_,G=np.unique(P,axis=0,return_inverse=True);TG=G[T];edges=collections.defaultdict(list)
for fi,tr in enumerate(TG):
 for k,(a,b) in enumerate(zip(tr,np.roll(tr,-1))):edges[tuple(sorted((int(a),int(b))))].append(fi)
active=sv[T].max(1)>0;seed=29177;assert active[seed];selected={seed};todo=[seed]
while todo:
 fi=todo.pop()
 for k,(a,b) in enumerate(zip(TG[fi],np.roll(TG[fi],-1))):
  va,vb=T[fi,k],T[fi,(k+1)%3]
  if max(sv[va],sv[vb])<=0:continue
  for j in edges[tuple(sorted((int(a),int(b))))]:
   if active[j] and j not in selected:selected.add(j);todo.append(j)
ids=np.array(sorted(selected));tri=P[T[ids]];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);GN/=np.maximum(np.linalg.norm(GN,axis=1,keepdims=True),1e-30);full=sv[T[ids]].min(1)>0;cross=~full;vi=np.unique(T[ids]);comp={'source_faces':ids.tolist(),'count':len(ids),'source_bounds':[tri.min((0,1)).tolist(),tri.max((0,1)).tolist()],'full_inside':int(full.sum()),'crossing':int(cross.sum()),'maximum_other_removal_field':float(other[vi].max()),'other_field_positive_faces':ids[other[T[ids]].max(1)>0].tolist(),'GN_front_facing_quantiles':np.quantile(-GN[:,1],[0,.05,.5,.95,1]).tolist()}
base=GLB(D/'inputs/body_domain_cut217.glb');BP,BT,BN,BUV=base.native();z=np.load(D/'inputs/domain_cut_boundary217.npz');parent=z['PARENT'];br=json.loads((D/'audit/body_domain_cut217.json').read_text());loop=next(c for c in br['new_boundary_components'] if c['nodes']==54);U,GG=np.unique(BP,axis=0,return_inverse=True);TG2=GG[BT];ee=collections.defaultdict(list)
for fi,tr in enumerate(TG2):
 for a,b in zip(tr,np.roll(tr,-1)):ee[tuple(sorted((int(a),int(b))))].append(fi)
border=[]
for a,b in zip(loop['position_groups'],np.roll(loop['position_groups'],-1)):
 fs=ee[tuple(sorted((int(a),int(b))))];assert len(fs)==1;border.append(int(parent[fs[0]]))
points=np.array(loop['positions']);dsphere=r['sleeve_radius']-np.linalg.norm(points-r['sleeve_center'],axis=1);dplane=(points-r['sleeve_plane_center'])@r['sleeve_plane_normal'];out={'source104_sha256':g.sha256,'source217_sha256':base.sha256,'seed_from_saved_original_front_backing_ray':seed,'positive_sleeve_domain_component':comp,'aperture54_adjacent_original_parents':sorted(set(border)),'all_aperture54_border_parents_in_component':set(border)<=selected,'aperture54_sleeve_field_residual_max_m':float(np.abs(np.minimum(dsphere,dplane)).max()),'scope':'Read-only original-source lineage proof. A small independent sleeve-domain component with no hand/shaft field overlap can be restored from exact original triangles instead of inventing a support patch. Do not infer that property without these numerical results.'};(D/'audit/coat236_backing_proof.json').write_text(json.dumps(out,indent=2));print(json.dumps({**out,'positive_sleeve_domain_component':{k:(len(v) if k=='source_faces' else v) for k,v in comp.items()}},indent=2),flush=True)
