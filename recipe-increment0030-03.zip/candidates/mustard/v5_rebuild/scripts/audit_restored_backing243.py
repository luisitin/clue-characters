"""Exact exported restored102 coat faces versus every possible body/assembly neighbor."""
from pathlib import Path
import numpy as np,json,hashlib
from glb_io import GLB
from audit_intersections_selected238 import audit
D=Path(__file__).resolve().parents[1]
report=json.loads((D/'audit/body_backing242_restoration.json').read_text())
z=np.load(D/'inputs/body_backing242_binding.npz');parent=z['PARENT'];allrestored=report['restored_original_faces']+json.loads((D/'audit/body_backing237_restoration.json').read_text())['restored_original_faces'];restored=np.isin(parent,allrestored);assert restored.sum()==102
def read(name):
 g=GLB(D/'inputs'/name);P,_,N,UV=g.native();T=np.concatenate([g.read(pr['indices']).reshape(-1,3) for pr in g.j['meshes'][g.j['nodes'][0]['mesh']]['primitives']]);return g,P,T
bg,BP,BT=read('body_backing242.glb');assert bg.sha256==report['output_sha256'];tri=BP[BT[restored]];lo=tri.min((0,1))-1e-8;hi=tri.max((0,1))+1e-8
positions=[];triangles=[];labels=[];lineage=[];selected=[];hashes={};offset=0;faceoff=0
for label,name in [('body','body_backing242.glb'),('hand','grip_registered210.glb'),('prop','prop_registered209.glb'),('cuff','grip_cuff235.glb')]:
 g,P,T=read(name);hashes[label]=g.sha256;tp=P[T];ids=np.flatnonzero(np.all(tp.max(1)>=lo,axis=1)&np.all(tp.min(1)<=hi,axis=1));used=np.unique(T[ids]);positions.append(P[used]);triangles.append(np.searchsorted(used,T[ids])+offset);offset+=len(used);labels.extend([label]*len(ids));lineage.extend(ids.tolist())
 if label=='body':selected.extend((faceoff+np.flatnonzero(restored[ids])).tolist())
 faceoff+=len(ids)
P=np.concatenate(positions);T=np.concatenate(triangles);labels=np.array(labels);lineage=np.array(lineage);assert len(selected)==102;r=audit(P,T,selected_faces=selected)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for pair in r[key]:
  ids=np.array(pair['faces']);pair['parts']=labels[ids].tolist();pair['part_faces']=lineage[ids].tolist();pair['body104_parents']=[int(parent[lineage[i]]) if labels[i]=='body' else None for i in ids]
selset=set(selected);folds=[p for p in r['manifold_edge_folds_over_105_degrees'] if selset.intersection(p)];copies=[p for p in r['position_triangle_copy_groups'] if selset.intersection(p)];r['restored_face_fold_pairs']=folds;r['restored_face_copy_groups']=copies
r.update(hashes=hashes,selected_restored_faces=102,compact_counts={x:int(np.count_nonzero(labels==x)) for x in hashes},scope='Only102 exact restored original coat faces queried, against every triangle whose full AABB intersects their union. Unchanged V4/exact-pair predicates, exact exported floats, all primitive indices. Separate from prior cuff-wide228; inherited body folds classified independently.',source_bounds=[lo.tolist(),hi.tolist()],predicate_wrapper_sha256=hashlib.sha256((D/'scripts/audit_intersections_selected238.py').read_bytes()).hexdigest())
(D/'audit/body_backing243_contact.json').write_text(json.dumps(r,indent=2));print({k:(len(r[k]) if isinstance(r[k],list) else r[k]) for k in ['proper_crossings','positive_area_coplanar_pairs','restored_face_fold_pairs','restored_face_copy_groups','compact_counts','seconds']},flush=True)
