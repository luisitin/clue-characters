# Bounded selected-face wrapper238. V4 predicate unchanged; optional explicit
# selection only narrows the source-face loop, with all external AABB neighbors held.
# Original V4 SHA225efbf988e0c10eed0b6e4c3d709c4f1cf4d3016f249319d947e606c03d90a7.
"""Full or bounded surface audit. VTK broad phase, explicit proper/coplanar/copy categories.

Version4 verifies reported candidates using exact rational plane cuts and witnesses.
Version3 removes the VTK triangle narrow predicate; VTK is broad phase only.
Version2 separates the geometric plane-cut epsilon from reported crossing length.
Exact-position shared edges are excluded from non-adjacent crossing counts and tested
separately for large normal folds. Shared-vertex pairs are NOT blindly excluded: a
positive-length crossing away from their common point is still reported.
"""
import argparse,json,time,hashlib
from pathlib import Path
import numpy as np
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from glb_io import GLB
from exact_triangle_pair import exact_pair

def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
def coplanar_area(A,B,normal,tol):
    drop=np.argmax(np.abs(normal));origin=A[0].astype(np.longdouble);A=np.delete(A.astype(np.longdouble)-origin,drop,axis=1);B=np.delete(B.astype(np.longdouble)-origin,drop,axis=1)
    sign=1 if cross2(B[1]-B[0],B[2]-B[0])>=0 else -1
    poly=list(A)
    for k in range(3):
        edge=B[(k+1)%3]-B[k];q=[]
        for i in range(len(poly)):
            x=poly[i-1];y=poly[i];dx=sign*cross2(edge,x-B[k]);dy=sign*cross2(edge,y-B[k]);ix=dx>=-tol;iy=dy>=-tol
            if ix!=iy:q.append(x+(y-x)*dx/(dx-dy))
            if iy:q.append(y)
        poly=q
        if not poly:return 0.
    return abs(sum(cross2(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly))))/2

def plane_cut(A,d,tol):
    points=[]
    for i in range(3):
        j=(i+1)%3
        if abs(d[i])<=tol:points.append(A[i])
        if (d[i]<-tol and d[j]>tol)or(d[i]>tol and d[j]<-tol):points.append(A[i]+(A[j]-A[i])*d[i]/(d[i]-d[j]))
    return np.array(points)

def audit(P,T,tol=1e-8,bounds=None,selected_faces=None):
    geometric_epsilon=min(1e-12,tol*1e-4)
    start=time.time();unique,group=np.unique(P,axis=0,return_inverse=True);G=group[T];tri=P[T]
    areaN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);length=np.linalg.norm(areaN,axis=1);N=areaN/np.maximum(length[:,None],1e-30)
    lo=tri.min(axis=1);hi=tri.max(axis=1)
    _,back,counts=np.unique(np.sort(G,axis=1),axis=0,return_inverse=True,return_counts=True)
    copygroups=[np.flatnonzero(back==k).tolist() for k in np.flatnonzero(counts>1)]
    edges={}
    for fi,tr in enumerate(G):
        for a,b in zip(tr,np.roll(tr,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
    edgepairs=np.array([fs for fs in edges.values() if len(fs)==2],int)
    dots=np.sum(N[edgepairs[:,0]]*N[edgepairs[:,1]],axis=1) if len(edgepairs) else np.array([])
    points=vtk.vtkPoints();points.SetData(numpy_to_vtk(P,deep=True));cells=vtk.vtkCellArray();packed=np.column_stack((np.full(len(T),3),T)).ravel().astype(np.int64)
    cells.SetCells(len(T),numpy_to_vtkIdTypeArray(packed,deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells)
    locator=vtk.vtkStaticCellLocator();locator.SetDataSet(poly);locator.BuildLocator();hits=vtk.vtkIdList()
    selected=np.arange(len(T)) if selected_faces is None else np.asarray(selected_faces,dtype=int)
    assert len(np.unique(selected))==len(selected) and np.all((selected>=0)&(selected<len(T)))
    if bounds is not None:
        box=np.array(bounds);selected=selected[np.all(hi>=box[:3],axis=1)&np.all(lo<=box[3:],axis=1)]
    selected_mask=np.zeros(len(T),bool);selected_mask[selected]=True
    proper=[];coplanar=[];touches=0;edge_skips=0;tested=0;exact_checks=0;exact_rejections=[]
    for step,i in enumerate(selected):
        bb=np.column_stack((lo[i]-tol,hi[i]+tol)).ravel();locator.FindCellsWithinBounds(bb,hits)
        js=np.array([hits.GetId(k) for k in range(hits.GetNumberOfIds())],int)
        js=js[(js>i)|~selected_mask[js]];js=js[np.all(hi[js]>=lo[i]-tol,axis=1)&np.all(lo[js]<=hi[i]+tol,axis=1)]
        for j in js:
            shared=np.intersect1d(G[i],G[j])
            if len(shared)>=2:edge_skips+=1;continue
            if length[i]<1e-16 or length[j]<1e-16:continue
            tested+=1
            dA=(tri[i]-tri[j,0])@N[j];dB=(tri[j]-tri[i,0])@N[i]
            if dA.min()>geometric_epsilon or dA.max()<-geometric_epsilon or dB.min()>geometric_epsilon or dB.max()<-geometric_epsilon:continue
            direction=np.cross(N[i],N[j]);dn=np.linalg.norm(direction)
            if dn<1e-6:
                projected=coplanar_area(tri[i],tri[j],N[i],0.0)
                if projected>0:
                    exact_checks+=1;ex=exact_pair(tri[i],tri[j])
                    if ex['kind']=='proper' and ex['length']>tol:proper.append({'faces':[int(i),int(j)],**ex,'shared_position_vertices':len(shared)})
                    elif ex['kind']=='coplanar_overlap' and ex['projected_area']>tol*tol:coplanar.append({'faces':[int(i),int(j)],**ex})
                    else:exact_rejections.append({'faces':[int(i),int(j)],'candidate':'near_parallel_projected_overlap','exact_kind':ex['kind'],'projected_area':float(projected)});touches+=1
                else:touches+=1
                continue
            if dn<1e-12:continue
            direction/=dn;A=plane_cut(tri[i],dA,geometric_epsilon);B=plane_cut(tri[j],dB,geometric_epsilon)
            if len(A)<2 or len(B)<2:touches+=1;continue
            ia=A@direction;ib=B@direction;l=max(ia.min(),ib.min());h=min(ia.max(),ib.max())
            if h-l>tol:
                exact_checks+=1;ex=exact_pair(tri[i],tri[j])
                if ex['kind']=='proper' and ex['length']>tol:proper.append({'faces':[int(i),int(j)],**ex,'shared_position_vertices':len(shared)})
                elif ex['kind']=='coplanar_overlap' and ex['projected_area']>tol*tol:coplanar.append({'faces':[int(i),int(j)],**ex})
                else:exact_rejections.append({'faces':[int(i),int(j)],'candidate':'floating_cut_interval','floating_length':float(h-l),'exact_kind':ex['kind']});touches+=1
            else:touches+=1
        if step%5000==0:print(f'PROGRESS {step}/{len(selected)} pairs={tested} proper={len(proper)} coplanar={len(coplanar)} elapsed={time.time()-start:.1f}',flush=True)
    return {'triangles':len(T),'physical_vertices':len(unique),'tested_nonadjacent_candidates':tested,'proper_crossings':proper,'positive_area_coplanar_pairs':coplanar,'position_triangle_copy_groups':copygroups,'zero_area_faces':np.flatnonzero(length<1e-16).tolist(),'shared_edge_pairs_excluded':edge_skips,'point_or_subtolerance_contacts':touches,'manifold_edge_max_angle_degrees':float(np.degrees(np.arccos(np.clip(dots.min(),-1,1)))) if len(dots) else None,'manifold_edge_folds_over_105_degrees':edgepairs[dots<np.cos(np.radians(105))].tolist(),'reporting_length_tolerance_m':tol,'geometric_plane_cut_epsilon_m':geometric_epsilon,'bounds':bounds,'seconds':time.time()-start,'exact_predicate_checks':exact_checks,'floating_candidates_rejected_by_exact_predicate':exact_rejections,'narrow_phase':'Rational verification from exact stored binary floats for every reported crossing/overlap; near-parallel projected-overlap fallback; no VTK narrow predicate.','limitations':'Crossings and folds are geometry preflight, not visible-defect classification or contact clearance.'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--out',required=True);parser.add_argument('--bounds',type=float,nargs=6);args=parser.parse_args()
    g=GLB(args.input);P,T,N,UV=g.native();result=audit(P,T,bounds=args.bounds);result['source']=args.input;result['sha256']=g.sha256
    Path(args.out).write_text(json.dumps(result,indent=2));print(json.dumps({k:(len(v) if isinstance(v,list) else v) for k,v in result.items()},indent=2),flush=True)
