"""Metric world-space twill/cotton dye and microrelief using the saved AI fiber input."""
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
D=Path(__file__).resolve().parents[1]
def smooth(a,b,x):
 t=np.clip((x-a)/(b-a),0,1);return t*t*(3-2*t)
class ClothFields:
 def __init__(self):
  self.rgb=np.asarray(Image.open(D/'textures/Mustard_Twill_Albedo_Source_v1.png').convert('RGB'),dtype='f4')/255;self.mean=self.rgb.mean((0,1));lum=self.rgb@np.array([.2126,.7152,.0722]);self.grain=gaussian_filter(lum,.8)-gaussian_filter(lum,5);self.gold=np.array([194,132,34])/255
 def sample(self,img,uv):
  uv=np.mod(uv,2);uv=np.where(uv>1,2-uv,uv);h,w=img.shape[:2];xy=uv*np.array([w-1,h-1]);lo=np.floor(xy).astype(int);hi=np.minimum(lo+1,[w-1,h-1]);f=xy-lo
  if img.ndim==3:f=f[:,:,None]
  return (img[lo[:,1],lo[:,0]]*(1-f[:,0])+img[lo[:,1],hi[:,0]]*f[:,0])*(1-f[:,1])+(img[hi[:,1],lo[:,0]]*(1-f[:,0])+img[hi[:,1],hi[:,0]]*f[:,0])*f[:,1]
 def material(self,P,N,UV,M,color=True):
  weight=np.abs(N)**4;weight/=np.maximum(weight.sum(1,keepdims=True),1e-20);q=P/.060;grain=np.zeros(len(P));rgb=np.zeros((len(P),3)) if color else None
  for k,axes in enumerate(((1,2),(0,2),(0,1))):
   grain+=weight[:,k]*self.sample(self.grain,q[:,axes])
   if color:rgb+=weight[:,k,None]*self.sample(self.rgb,q[:,axes])
  cotton=M==2;lining=(M==1)|(M==3);height=grain*np.where(cotton,.000045,.000180);rough=np.where(cotton,.86,np.where(lining,.91,.80))+grain*.08
  # Restrained surface-following hem stitches: integer circumferential repeat,
  # original source-chart location survives microchart packing.
  seam=np.exp(-((UV[:,1]-(13/59-.0025))/.0011)**2)*(M==0);thread=seam*smooth(.20,.75,np.cos(2*np.pi*140*UV[:,0]));height+=.000033*thread-.000016*seam
  if color:
   fiber=.75+.25*rgb/np.maximum(self.mean,1e-6);base=fiber*self.gold;base[lining]*=.84;white=(.96+.04*(rgb@np.array([.2126,.7152,.0722]))/float(self.mean@np.array([.2126,.7152,.0722])))[:,None]*np.array([.89,.875,.82]);base[cotton]=white[cotton];base-=seam[:,None]*np.array([.024,.018,.008]);base-=thread[:,None]*np.array([.030,.023,.010]);base=np.clip(base,0,1)
  else:base=None
  return base,height,np.clip(rough,.70,.95)
