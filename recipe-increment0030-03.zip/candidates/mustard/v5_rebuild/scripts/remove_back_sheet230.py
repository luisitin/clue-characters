"""Bounded candidate removal of the ray-proven old-hand back sheet226.
No fairing, hole fill, UV or normal change. Protected front backing is retained.
"""
from pathlib import Path
import numpy as np,json,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_domain_cut217.glb');r=json.loads((D/'audit/back_sheet226_ownership.json').read_text());assert g.sha256==r['source217_sha256'];pr=g.primitive();T=g.read(pr['indices']).reshape(-1,3);z=np.load(D/'inputs/domain_cut_boundary217.npz');a={k:z[k] for k in z.files};assert np.array_equal(T,a['T']);remove=np.array(r['selected_retained217_faces'],'i4');sourceids=set(r['selected_source_faces']);assert set(a['PARENT'][remove])<=sourceids
protected=[26902,95470,96246,93268,90632];assert not sourceids.intersection(protected);assert not set(a['PARENT'][remove]).intersection(protected)
# Retain exact original front-hit leather strap controls, independently from the
# provisional old gold-ferrule point mislabeled as coat in112.
z33=np.load(D/'inputs/pointing_cut_boundary33.npz');rawids=np.array(json.loads((D/'audit/source_sanitized01.json').read_text())['retained_source_face_ids']);raw104=rawids[z33['PARENT']];lms=json.loads((D/'audit/prop112_landmarks.json').read_text())['landmarks'];belt=[]
for lm in lms:
 if lm['reference_role'] in ('protected diagonal leather belt','protected leather belt buckle','protected belt lower attachment'):
  ids=np.flatnonzero(raw104==lm['hits'][0]['raw_face']);assert not sourceids.intersection(map(int,ids));belt.extend(map(int,ids))
keep=np.ones(len(T),bool);keep[remove]=False;newT=T[keep];oldattrs=pr['attributes'].copy();pr['indices']=g.append(newT.ravel(),'SCALAR',5125,34963);sha=g.save(D/'inputs/body_back_sheet230.glb');assert pr['attributes']==oldattrs;P,_,N,UV=g.native();newparent=a['PARENT'][keep];cut=np.unique(np.r_[a['CUT_VERTICES'],T[remove].ravel()]).astype('i4');np.savez_compressed(D/'inputs/back_sheet_boundary230.npz',P=P,T=newT,PARENT=newparent,CUT_VERTICES=cut,C=a['C'],N=a['N'])
U,G=np.unique(P,axis=0,return_inverse=True);TG=G[newT];edges=collections.defaultdict(list)
for fi,tr in enumerate(TG):
 for x,y in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(x),int(y))))].append(fi)
cutgroups=set(G[cut]);boundary=[e for e,fs in edges.items() if len(fs)==1 and e[0] in cutgroups and e[1] in cutgroups];adj=collections.defaultdict(set)
for x,y in boundary:adj[x].add(y);adj[y].add(x)
remaining=set(adj);components=[]
while remaining:
 seed=min(remaining);seen={seed};todo=[seed]
 while todo:
  v=todo.pop()
  for w in adj[v]:
   if w not in seen:seen.add(w);todo.append(w)
 remaining-=seen;simple=all(len(adj[v])==2 for v in seen);order=[]
 if simple:
  cur=min(seen);prev=None
  while not order or cur!=order[0]:
   order.append(cur);nxt=min(adj[cur]-({prev} if prev is not None else set()));prev,cur=cur,nxt
  assert len(order)==len(seen)
 components.append({'nodes':len(seen),'simple_cycle':simple,'degree_histogram':{str(k):sum(len(adj[v])==k for v in seen) for k in {len(adj[v]) for v in seen}},'positions':U[order if simple else sorted(seen)].tolist(),'position_groups':order if simple else sorted(seen),'bounds':[U[list(seen)].min(0).tolist(),U[list(seen)].max(0).tolist()]})
out={'source217_sha256':r['source217_sha256'],'output_sha256':sha,'removed217_faces':remove.tolist(),'removed104_parent_faces':sorted(set(map(int,a['PARENT'][remove]))),'protected_front_backing_source104_faces':protected,'protected_belt_source104_faces':belt,'unchanged_POSITION_NORMAL_UV_materials':True,'all_retained_triangle_indices_exact':True,'new_boundary_components':components,'scope':'Candidate removal of the specifically annotated connected old-hand back sheet. Protected front coat/backing and leather strap controls held. Holes and branched rim remain unfilled; no whole coat or assembly approval.'};(D/'audit/body_back_sheet230.json').write_text(json.dumps(out,indent=2));print({'sha256':sha,'removed_faces':len(remove),'components':[(c['nodes'],c['simple_cycle'],c['degree_histogram']) for c in components]},flush=True)
