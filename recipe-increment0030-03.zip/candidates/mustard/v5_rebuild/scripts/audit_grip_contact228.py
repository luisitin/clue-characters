import sys,json
from pathlib import Path
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parents[1];sys.path.insert(0,str(D/'scripts'));from glb_io import GLB
cg=GLB(D/'inputs/grip_cuff227.glb');CP,_,CN,UV=cg.native();primitives=cg.j['meshes'][cg.j['nodes'][0]['mesh']]['primitives'];CT=np.concatenate([cg.read(p['indices']).reshape(-1,3) for p in primitives]);material=np.concatenate([np.full(len(cg.read(p['indices']))//3,p['material']) for p in primitives]);hg=GLB(D/'inputs/grip_registered210.glb');HP,HT,HN,HUV=hg.native();tree=BVHTree.FromPolygons(HP.tolist(),HT.tolist(),all_triangles=True,epsilon=0)
parts=[]
for name,triangles in [('whole cuff',CT),('shirt only',CT[material==2])]:
    edge=np.unique(np.sort(np.concatenate((triangles[:,[0,1]],triangles[:,[1,2]],triangles[:,[2,0]])),axis=1),axis=0);samples=np.concatenate((CP[np.unique(triangles)],CP[edge].mean(1),CP[triangles].mean(1)));distance=[];signed=[];bad=[]
    for i,p in enumerate(samples):
        hit,n,fi,d=tree.find_nearest(Vector(p));distance.append(float(d));sg=float((Vector(p)-hit).dot(n));signed.append(sg)
        if sg<0 and d<.005:bad.append({'sample':i,'point':p.tolist(),'nearest_face':int(fi),'distance':float(d),'signed':sg})
    distance=np.array(distance);signed=np.array(signed);parts.append({'part':name,'samples':len(samples),'minimum_distance':float(distance.min()),'distance_quantiles':np.quantile(distance,[0,.01,.1,.5,.99,1]).tolist(),'signed_quantiles':np.quantile(signed,[0,.01,.1,.5,.99,1]).tolist(),'negative_near_skin_samples':bad});print(name,len(samples),float(distance.min()),len(bad),flush=True)
out={'cuff_sha256':cg.sha256,'hand_sha256':hg.sha256,'parts':parts,'sampling':'Every referenced vertex, every unique indexed edge midpoint, every triangle centroid.','scope':'Dense closest-skin clearance, alongside separate true-crossing and radial-placement proof. Signed values far from the open proximal wrist do not classify a closed volume.'};(D/'audit/grip227_dense_contact.json').write_text(json.dumps(out,indent=2));print(json.dumps({**out,'parts':[{k:v if k!='negative_near_skin_samples' else len(v) for k,v in p.items()} for p in parts]},indent=2),flush=True)
