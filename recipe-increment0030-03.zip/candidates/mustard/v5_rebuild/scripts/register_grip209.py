"""Two rigid hand registration studies around the held shaft. No anatomy deformation."""
from pathlib import Path
import numpy as np,json,copy
from glb_io import GLB
D=Path(__file__).resolve().parents[1];reg=json.loads((D/'audit/grip150_registration.json').read_text());base=np.array(reg['registration_matrix_world']);C=np.array(reg['shaft_center']);A=np.array(reg['shaft_axis']);r=json.loads((D/'audit/grip179.json').read_text());reports=[]
def apply(source,outname,M):
 g=GLB(D/f'inputs/{source}.glb');node=g.j['nodes'][0];assert not any(k in node for k in ('matrix','translation','rotation','scale'));ps=g.j['meshes'][node['mesh']]['primitives'];attrs=ps[0]['attributes'].copy();assert all(p['attributes']==attrs for p in ps);oldP=g.read(attrs['POSITION'],False);oldN=g.read(attrs['NORMAL'],False);P=oldP.astype('f8')[:,[0,2,1]]*[1,-1,1];N=oldN.astype('f8')[:,[0,2,1]]*[1,-1,1];Q=P@M[:3,:3].T+M[:3,3];NN=N@M[:3,:3].T;new=attrs.copy();new['POSITION']=g.append((Q[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962);new['NORMAL']=g.append((NN[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962)
 if 'TANGENT' in attrs:
  tb=g.read(attrs['TANGENT'],False).copy();t=tb[:,:3].astype('f8')[:,[0,2,1]]*[1,-1,1];t=t@M[:3,:3].T;tb[:,:3]=(t[:,[0,2,1]]*[1,1,-1]).astype('f4');new['TANGENT']=g.append(tb,'VEC4',5126,34962)
 for p in ps:p['attributes']=new.copy()
 node['name']=outname;sha=g.save(D/f'inputs/{outname}.glb');check=GLB(D/f'inputs/{outname}.glb');cp=check.read(new['POSITION']).astype('f8')[:,[0,2,1]]*[1,-1,1];_,grp=np.unique(P,axis=0,return_inverse=True);assert len(np.unique(np.column_stack((grp,cp)),axis=0))==len(np.unique(P,axis=0));return {'source':source,'source_sha256':GLB(D/f'inputs/{source}.glb').sha256,'output':outname,'sha256':sha,'matrix':M.tolist(),'maximum_float32_roundoff_m':float(np.linalg.norm(cp-Q,axis=1).max()),'source_position_groups_co_moved':True,'UV_indices_materials_held':True}
prop=apply('finished_prop197','prop_registered209',base);reports.append(prop)
for phi,tag in [(0,209),(-24.5,210)]:
 a=np.radians(phi);K=np.array([[0,-A[2],A[1]],[A[2],0,-A[0]],[-A[1],A[0],0]]);RR=np.eye(3)+np.sin(a)*K+(1-np.cos(a))*K@K;roll=np.eye(4);roll[:3,:3]=RR;roll[:3,3]=C-RR@C;M=roll@base;rep=apply('grip_painted188',f'grip_registered{tag}',M);rep['roll_degrees']=phi;rep['world_anchor']=(M[:3,:3]@r['world_anchor']+M[:3,3]).tolist();rep['world_forward']=(M[:3,:3]@r['world_forward']).tolist();rep['world_anatomical_dorsal']=(M[:3,:3]@r['world_anatomical_dorsal']).tolist();rep['shaft_center']=C.tolist();rep['shaft_axis']=A.tolist();rep['scope']='Rigid registration only. Shaft distances and anatomy shape held up to float32; actual reference pose, sleeve root and body contact remain pending.';reports.append(rep);(D/f'audit/grip{tag}_registration.json').write_text(json.dumps(rep,indent=2))
(D/'audit/grip209_component_registration.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2),flush=True)
