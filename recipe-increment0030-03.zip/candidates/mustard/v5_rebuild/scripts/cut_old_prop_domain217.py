"""Experimental bounded source clipping; retained corners are held, but garment ownership and reconstruction remain unapproved."""
from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_cut_unit104.glb');pr=g.primitive();at=pr['attributes'];oldT=g.read(pr['indices']).reshape(-1,3);oldP=g.read(at['POSITION']).astype('f4');oldN=g.read(at['NORMAL']).astype('f4');oldUV=g.read(at['TEXCOORD_0']).astype('f4');world,T,N,UV=g.native()
domain=json.loads((D/'audit/old_prop215_domain.json').read_text());B,A=np.array(domain['shaft_segment_endpoints']);axis_prop=(A-B)/np.linalg.norm(A-B);span=np.linalg.norm(A-B);t=(world-B)@axis_prop;near=B+np.clip(t,0,span)[:,None]*axis_prop;shaft_r=domain['shaft_radius_m']+.018*(1-np.clip(t/.06,0,1))+.016*np.clip((t-span+.06)/.06,0,1);shaft=shaft_r-np.linalg.norm(world-near,axis=1)
C=np.array(domain['sleeve_plane_center']);axis=np.array(domain['sleeve_plane_normal']);distal=(world-C)@axis;center=np.array(domain['hand_ellipsoid_center']);radii=np.array(domain['hand_ellipsoid_radii']);ell=(1-np.linalg.norm((world-center)/radii,axis=1))*.10;limit=np.clip(-.05-(world[:,0]+.24)*.61,-.13,.025);hand=np.minimum(np.minimum(ell,distal),limit-world[:,1]);sleeve=np.minimum(domain['sleeve_radius']-np.linalg.norm(world-np.array(domain['sleeve_center']),axis=1),distal);sd=np.maximum.reduce([shaft,hand,sleeve]);selected=set(np.flatnonzero(sd[T].max(1)>0).tolist());cross=set(np.flatnonzero((sd[T].max(1)>0)&(sd[T].min(1)<0)).tolist());_,group=np.unique(world,axis=0,return_inverse=True)
P=list(oldP);NN=list(oldN);UU=list(oldUV);edge_attributes={};physical_cut={};cut_indices=set();tris=[];parents=[];changed=[]
def cut_vertex(a,b):
    key=tuple(sorted((int(a),int(b))))
    if key in edge_attributes:return edge_attributes[key]
    ga,gb=int(group[a]),int(group[b]);pk=tuple(sorted((ga,gb)))
    if pk not in physical_cut:
        aa,bb=(a,b) if ga<gb else (b,a);fraction=sd[aa]/(sd[aa]-sd[bb]);physical_cut[pk]=(oldP[aa].astype('f8')+fraction*(oldP[bb].astype('f8')-oldP[aa])).astype('f4')
    fraction=sd[a]/(sd[a]-sd[b]);normal=oldN[a].astype('f8')+fraction*(oldN[b].astype('f8')-oldN[a]);normal/=np.linalg.norm(normal);uv=oldUV[a].astype('f8')+fraction*(oldUV[b].astype('f8')-oldUV[a]);idx=len(P);P.append(physical_cut[pk]);NN.append(normal.astype('f4'));UU.append(uv.astype('f4'));edge_attributes[key]=idx;cut_indices.add(idx);return idx
for fi,tr in enumerate(oldT):
    if fi not in selected:tris.append(tr.tolist());parents.append(fi);continue
    if fi not in cross:continue
    polygon=[]
    for k,current in enumerate(tr):
        previous=tr[k-1];ic=sd[current]<=0;ip=sd[previous]<=0
        if ic!=ip:polygon.append(cut_vertex(previous,current))
        if ic:polygon.append(int(current))
    assert len(polygon) in (3,4)
    for k in range(1,len(polygon)-1):
        changed.append(len(tris));tris.append([polygon[0],polygon[k],polygon[k+1]]);parents.append(fi)
P=np.array(P,'f4');NN=np.array(NN,'f4');UU=np.array(UU,'f4');tris=np.array(tris,'u4');parents=np.array(parents,'i4');changed=np.array(changed,'i4')
oldgn=np.cross(oldP[oldT[:,1]].astype('f8')-oldP[oldT[:,0]],oldP[oldT[:,2]].astype('f8')-oldP[oldT[:,0]])
newgn=np.cross(P[tris[changed,1]].astype('f8')-P[tris[changed,0]],P[tris[changed,2]].astype('f8')-P[tris[changed,0]])
length=np.linalg.norm(newgn,axis=1);dot=np.sum(newgn*oldgn[parents[changed]],axis=1)/(length*np.linalg.norm(oldgn[parents[changed]],axis=1));assert length.min()>1e-18 and dot.min()>.9999
pr['attributes']={'POSITION':g.append(P,'VEC3',5126,34962),'NORMAL':g.append(NN,'VEC3',5126,34962),'TEXCOORD_0':g.append(UU,'VEC2',5126,34962)};pr['indices']=g.append(tris.ravel(),'SCALAR',5125,34963)
out=D/'inputs/body_domain_cut217.glb';sha=g.save(out);new=GLB(out);wp,tt,wn,wuv=new.native();changed_set=set(changed.tolist());retained=np.array([i for i in range(len(tris)) if i not in changed_set]);assert np.array_equal(P[:len(oldP)],oldP) and np.array_equal(NN[:len(oldN)],oldN) and np.array_equal(UU[:len(oldUV)],oldUV)
assert np.array_equal(tris[retained],oldT[parents[retained]])
np.savez_compressed(D/'inputs/domain_cut_boundary217.npz',P=wp,T=tt,PARENT=parents,CHANGED=changed,CUT_VERTICES=np.array(sorted(cut_indices),'i4'),C=C,N=axis)
report={'source_sha256':GLB(D/'inputs/body_cut_unit104.glb').sha256,'output_sha256':sha,'input_triangles':len(oldT),'output_triangles':len(tris),'fully_removed_faces':len(selected)-len(cross),'clipped_source_faces':len(cross),'replacement_triangles':len(changed),'new_attribute_vertices':len(P)-len(oldP),'physical_cut_edge_vertices':len(physical_cut),'retained_triangle_indices_exact':True,'retained_POSITION_NORMAL_UV_exact_in_float32_decode_representation':True,'max_retained_world_roundoff_m':float(np.max(np.linalg.norm(wp[:len(world)]-world,axis=1))),'minimum_clip_relative_orientation_cosine':float(dot.min()),'minimum_clip_double_area_object_units':float(length.min()),'scope':'EXPERIMENTAL bounded geometric field clip for source reconstruction study.215 ownership and full perimeter are not approved. Every untouched source triangle and attribute is held; no global fairing or hidden fill. Must inspect all new loops, source-family ownership, coat backing and sleeve separation before any reconstruction/promotion.'}
(D/'audit/body_domain_cut217.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)

from collections import defaultdict
unique,groups=np.unique(wp,axis=0,return_inverse=True);physicalT=groups[tt];edges=defaultdict(list)
for fi,tr in enumerate(physicalT):
 for a,b in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(a),int(b))))].append(fi)
cutgroups=set(groups[list(cut_indices)].tolist());newedges=[e for e,fs in edges.items() if len(fs)==1 and e[0] in cutgroups and e[1] in cutgroups];adj=defaultdict(set)
for a,b in newedges:adj[a].add(b);adj[b].add(a)
remaining=set(adj);components=[]
while remaining:
 seed=next(iter(remaining));nodes={seed};todo=[seed]
 while todo:
  a=todo.pop()
  for b in adj[a]:
   if b not in nodes:nodes.add(b);todo.append(b)
 remaining-=nodes;ordered=[];simple=all(len(adj[v])==2 for v in nodes)
 if simple:
  start=min(nodes);current=start;previous=None
  while True:
   ordered.append(current);choices=adj[current]-({previous} if previous is not None else set());nxt=min(choices)
   if nxt==start:break
   previous,current=current,nxt
  assert len(ordered)==len(nodes)
 components.append({'nodes':len(nodes),'simple_cycle':simple,'degree_histogram':{str(d):sum(len(adj[v])==d for v in nodes) for d in set(len(adj[v]) for v in nodes)},'bounds':[unique[list(nodes)].min(0).tolist(),unique[list(nodes)].max(0).tolist()],'positions':unique[ordered if simple else sorted(nodes)].tolist(),'position_groups':ordered if simple else sorted(nodes)})
report['new_boundary_components']=components;report['new_boundary_edges']=len(newedges);report['new_cut_vertices_not_on_one_incident_boundary']=len(cutgroups-set(adj));(D/'audit/body_domain_cut217.json').write_text(json.dumps(report,indent=2));print('BOUNDARY',[(x['nodes'],x['simple_cycle'],x['degree_histogram'],x['bounds']) for x in components],flush=True)
