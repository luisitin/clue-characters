"""Read-only source lineage and positive-domain connectivity of small coat apertures."""
from pathlib import Path
import numpy as np,json,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_cut_unit104.glb');P,T,N,UV=g.native();r=json.loads((D/'audit/old_prop215_domain.json').read_text());sphere=r['sleeve_radius']-np.linalg.norm(P-np.array(r['sleeve_center']),axis=1);plane=(P-r['sleeve_plane_center'])@np.array(r['sleeve_plane_normal']);sleeve=np.minimum(sphere,plane)
B,A=np.array(r['shaft_segment_endpoints']);axis=(A-B)/np.linalg.norm(A-B);span=np.linalg.norm(A-B);tt=(P-B)@axis;nearest=B+np.clip(tt,0,span)[:,None]*axis;rad=.047+.018*(1-np.clip(tt/.06,0,1))+.016*np.clip((tt-span+.06)/.06,0,1);shaft=rad-np.linalg.norm(P-nearest,axis=1);ell=(1-np.linalg.norm((P-r['hand_ellipsoid_center'])/r['hand_ellipsoid_radii'],axis=1))*.10;lim=np.clip(-.05-(P[:,0]+.24)*.61,-.13,.025);hand=np.minimum.reduce([ell,plane,lim-P[:,1]]);field=np.maximum.reduce([sleeve,shaft,hand])
_,G=np.unique(P,axis=0,return_inverse=True);TG=G[T];edges=collections.defaultdict(list)
for fi,tr in enumerate(TG):
 for a,b in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(a),int(b))))].append(fi)
active=field[T].max(1)>0
bg=GLB(D/'inputs/body_domain_cut217.glb');BP,BT,_,_=bg.native();z=np.load(D/'inputs/domain_cut_boundary217.npz');parent=z['PARENT'];_,BG=np.unique(BP,axis=0,return_inverse=True);BGT=BG[BT];be=collections.defaultdict(list)
for fi,tr in enumerate(BGT):
 for a,b in zip(tr,np.roll(tr,-1)):be[tuple(sorted((int(a),int(b))))].append(fi)
out=[]
for loop in json.loads((D/'audit/body_domain_cut217.json').read_text())['new_boundary_components']:
 if not loop['simple_cycle'] or loop['nodes']>10:continue
 border=set()
 for a,b in zip(loop['position_groups'],np.roll(loop['position_groups'],-1)):
  fs=be[tuple(sorted((int(a),int(b))))];assert len(fs)==1;border.add(int(parent[fs[0]]))
 seed=min(border);assert active[seed];seen={seed};todo=[seed]
 while todo:
  fi=todo.pop()
  for k,(a,b) in enumerate(zip(TG[fi],np.roll(TG[fi],-1))):
   if max(field[T[fi,k]],field[T[fi,(k+1)%3]])<=0:continue
   for j in edges[tuple(sorted((int(a),int(b))))]:
    if active[j] and j not in seen:seen.add(j);todo.append(j)
 ids=np.array(sorted(seen));vi=np.unique(T[ids]);tri=P[T[ids]];d={**loop,'border104_parents':sorted(border),'positive_domain_component_count':len(ids),'border_in_one_component':border<=seen,'component104_parents':ids.tolist(),'component_bounds':[tri.min((0,1)).tolist(),tri.max((0,1)).tolist()],'maximum_fields':{name:float(values[vi].max()) for name,values in [('shaft',shaft),('hand',hand),('sleeve',sleeve)]}};out.append(d)
r={'source104_sha256':g.sha256,'source217_sha256':bg.sha256,'small_apertures':out,'scope':'Read-only. Positive combined-domain connectivity identifies whether these loops are independent accidental backing cuts or tied to the intentional hand/prop domain. No face restoration/removal authorized by this report alone.'};(D/'audit/remaining_apertures239.json').write_text(json.dumps(r,indent=2));print([{k:v for k,v in a.items() if k not in ['component104_parents','positions','position_groups']} for a in out],flush=True)
