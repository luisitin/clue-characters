"""Tiny equivalence fixtures for optional selected-face V4 loop; no predicate changes."""
from pathlib import Path
import json,hashlib,numpy as np
from audit_intersections_v4 import audit as full
from audit_intersections_selected238 import audit as selected
D=Path(__file__).resolve().parents[1]
A=[[-1,0,0],[1,0,0],[0,1,0]];B=[[0,.2,-1],[0,.2,1],[0,.8,0]];C=[[3,3,3],[4,3,3],[3,4,3]];P=np.array(A+B+C,float);T=np.arange(9).reshape(3,3)
def canonical(r):return [(tuple(sorted(p['faces'])),round(p['length'],12)) for p in r['proper_crossings']]
r=full(P,T);allr=selected(P,T,selected_faces=np.arange(3));one=selected(P,T,selected_faces=[0]);two=selected(P,T,selected_faces=[1]);far=selected(P,T,selected_faces=[2]);assert canonical(r)==canonical(allr)==canonical(one)==canonical(two)==[((0,1),.6)];assert not far['proper_crossings']
for key in ['positive_area_coplanar_pairs','position_triangle_copy_groups','zero_area_faces','manifold_edge_folds_over_105_degrees']:assert r[key]==allr[key]
out={'original_V4_sha256':hashlib.sha256((D/'scripts/audit_intersections_v4.py').read_bytes()).hexdigest(),'selected_wrapper_sha256':hashlib.sha256((D/'scripts/audit_intersections_selected238.py').read_bytes()).hexdigest(),'exact_on_plane_vertex_crossing_length_m':r['proper_crossings'][0]['length'],'all_selection_equal':True,'either_order_selected_face_detects_crossing':True,'unrelated_selection_omits_unrelated_crossing':True,'predicate_unchanged':True,'scope':'Synthetic broad-loop equivalence only. Existing exact-pair fixtures remain the predicate validation; actual restoration238 separately queries exported geometry.'};(D/'audit/selected_wrapper241_fixtures.json').write_text(json.dumps(out,indent=2));print(out,flush=True)
