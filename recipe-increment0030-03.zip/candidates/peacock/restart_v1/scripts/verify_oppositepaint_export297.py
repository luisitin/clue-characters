"""Verify actual exported position/normal corner multiset and held material bytes."""
from pathlib import Path
import numpy as np,json,hashlib
from glb_io import GLB
R=Path(__file__).resolve().parents[1]
def signature(g):
 prs=g.j['meshes'][0]['primitives'];at=prs[0]['attributes'];P=g.read(at['POSITION']);N=g.read(at['NORMAL']);T=np.concatenate([g.read(p['indices']).reshape(-1,3) for p in prs]);q=np.ascontiguousarray(np.concatenate([P[T],N[T]],axis=2).reshape(len(T),18));s=np.sort(q.view('V72').ravel());return hashlib.sha256(s.tobytes()).hexdigest(),len(T)
def image_bytes(g,i):
 v=g.j['bufferViews'][g.j['images'][i]['bufferView']];o=v.get('byteOffset',0);return bytes(g.bin[o:o+v['byteLength']])
old=GLB(R/'checks/peacock_face_lowerpaint264.glb');new=GLB(R/'checks/peacock_face_oppositepaint295.glb');a,n=signature(old);b,m=signature(new);assert a==b and n==m
assert new.j['materials'][:-1]==old.j['materials']
assert all(image_bytes(old,i)==image_bytes(new,i) for i in range(len(old.j['images'])))
report={'source_glb_sha256':old.sha256,'candidate_glb_sha256':new.sha256,'triangles':m,'actual_exported_position_normal_corner_multiset_sha256':a,'all_actual_triangle_position_normal_corners_equal':True,'all_preexisting_embedded_images_byte_equal':True,'all_preexisting_material_shaders_equal':True,'new_material_count':1,'new_ORM_scope':'Sampled from the prior ORM field without a material-value edit; unique-chart rebake includes ordinary8-bit/filtering quantization.','status':'Exported geometry/held material invariance verified. Bounded appearance regressions pending.'};(R/'checks/oppositepaint_export297.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
