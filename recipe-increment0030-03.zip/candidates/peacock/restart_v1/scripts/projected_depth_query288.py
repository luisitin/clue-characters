"""Bounded exact-coordinate orthographic depth queries against projected triangles.
The broad phase bins projected AABBs; the narrow phase evaluates barycentric
coordinates at each requested continuous pixel coordinate. No z-buffer pixel
interpolation crosses a geometric occlusion boundary. All supplied triangles,
including back-facing surfaces, participate as in the double-sided export.
"""
import numpy as np

class ProjectedDepth:
 def __init__(self,triangles,roi=(0,0,799,799),tile=16):
  self.q=np.asarray(triangles,float);self.tile=tile;self.roi=np.asarray(roi,float)
  e=self.q[:,1,:2]-self.q[:,0,:2];f=self.q[:,2,:2]-self.q[:,0,:2];d=e[:,0]*f[:,1]-e[:,1]*f[:,0]
  self.e=e;self.f=f;self.inv=np.zeros(len(d));valid=abs(d)>1e-12;self.inv[valid]=1/d[valid]
  low=np.maximum(self.q[:,:,:2].min(1),self.roi[:2]);high=np.minimum(self.q[:,:,:2].max(1),self.roi[2:]);valid&=(low<=high).all(1);bins={}
  for fi in np.where(valid)[0]:
   lo=np.floor(low[fi]/tile).astype(int);hi=np.floor(high[fi]/tile).astype(int)
   for y in range(lo[1],hi[1]+1):
    for x in range(lo[0],hi[0]+1):bins.setdefault((x,y),[]).append(int(fi))
  self.bins={k:np.asarray(v,int) for k,v in bins.items()};self.queries=0
 def query(self,pixels):
  p=np.asarray(pixels,float);out=np.full(len(p),np.inf);inside=(p>=self.roi[:2]).all(1)&(p<=self.roi[2:]).all(1);ids=np.where(inside)[0];self.queries+=len(ids)
  if not len(ids):return out
  keys=np.floor(p[ids]/self.tile).astype(int);unique,groups=np.unique(keys,axis=0,return_inverse=True)
  for k,key in enumerate(unique):
   cand=self.bins.get(tuple(key))
   if cand is None:continue
   ix=ids[groups==k]
   for at in range(0,len(ix),1024):
    jj=ix[at:at+1024];best=np.full(len(jj),np.inf)
    for bt in range(0,len(cand),256):
     fs=cand[bt:bt+256];dx=p[jj,0,None]-self.q[fs,0,0];dy=p[jj,1,None]-self.q[fs,0,1];b=(dx*self.f[fs,1]-dy*self.f[fs,0])*self.inv[fs];c=(self.e[fs,0]*dy-self.e[fs,1]*dx)*self.inv[fs];z=self.q[fs,0,2]+b*(self.q[fs,1,2]-self.q[fs,0,2])+c*(self.q[fs,2,2]-self.q[fs,0,2]);hit=(b>=-1e-9)&(c>=-1e-9)&(b+c<=1+1e-9)&(z>0);z[~hit]=np.inf;best=np.minimum(best,z.min(1))
    out[jj]=best
  return out

if __name__=='__main__':
 q=np.array([[[0,0,4],[10,0,4],[0,10,4]],[[2,2,3],[8,2,3],[2,8,3]],[[20,20,2],[21,20,2],[20,21,2]]],float)
 d=ProjectedDepth(q,(-1,-1,22,22),4);p=np.array([[1,1],[3,3],[5,5],[9,9],[20.1,20.1]])
 got=d.query(p);want=np.array([4,3,3,np.inf,2]);assert np.array_equal(got,want),(got,want)
 print('Projected depth fixtures passed: nearer sheet, exact shared edge, uncovered point and separate island.')
