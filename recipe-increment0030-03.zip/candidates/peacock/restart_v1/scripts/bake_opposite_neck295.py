"""Registered opposite lower-jaw and upper-neck albedo repair over proven intact source skin.
An explicit camera polygon and anatomical world guard limit the domain. Exact
visible depth and facing gate every painted sample; held positions/normals and
all earlier geometry remain unchanged. Unique padded charts avoid source reuse.
"""
from pathlib import Path
import numpy as np,json,hashlib
from PIL import Image,ImageDraw,ImageFilter
from scipy.ndimage import map_coordinates
from glb_io import GLB
from projected_depth_query288 import ProjectedDepth
R=Path(__file__).resolve().parents[1];name='face_lowerpaint264';size=800
a=np.load(R/f'inputs/{name}.npz');D={k:a[k] for k in a.files};a.close();P,N,T,U,M=[D[k] for k in ['pos','normal','tri','uv','material']]
materials=json.loads((R/f'inputs/{name}_materials.json').read_text())
meta=json.loads((R/'renders/opposite_source269/face_albedo_090_+00.json').read_text());C=np.asarray(meta['camera_world_matrix']);scale=meta['ortho_scale']
reg=json.loads((R/'checks/opposite_plate_registration273.json').read_text());warp=np.asarray(reg['source_pixels_to_plate_800_pixels_matrix'])
platepath=R/'inputs/opposite_neck_plate272.png';assert hashlib.sha256(platepath.read_bytes()).hexdigest()==reg['plate_png_sha256'];plate=np.asarray(Image.open(platepath).convert('RGB'))
def smooth(x):
 x=np.clip(x,0,1);return x*x*x*(10-15*x+6*x*x)
def linear(c):return np.where(c<=.04045,c/12.92,((c+.055)/1.055)**2.4)
def srgb(c):return np.where(c<=.0031308,c*12.92,1.055*np.maximum(c,0)**(1/2.4)-.055)
def sample(im,uv):
 xy=uv*np.array([im.shape[1],im.shape[0]])-.5;ij=np.floor(xy).astype(int);f=xy-ij;x=np.clip(ij[:,0],0,im.shape[1]-1);y=np.clip(ij[:,1],0,im.shape[0]-1);x1=np.minimum(x+1,im.shape[1]-1);y1=np.minimum(y+1,im.shape[0]-1);fx=f[:,0,None];fy=f[:,1,None]
 return im[y,x]*(1-fx)*(1-fy)+im[y,x1]*fx*(1-fy)+im[y1,x]*(1-fx)*fy+im[y1,x1]*fx*fy
def project(p):
 rel=p-C[:3,3];return np.column_stack([(.5+rel@C[:3,0]/scale)*size-.5,(.5-rel@C[:3,1]/scale)*size-.5,-rel@C[:3,2]])
poly=[(332,554),(365,544),(405,543),(440,530),(485,527),(523,537),(540,557),(532,586),(502,609),(476,625),(443,641),(416,650),(400,624),(361,616),(329,602),(316,579)]
mask=Image.new('L',(800,800));ImageDraw.Draw(mask).polygon(poly,fill=255);mask=np.asarray(mask.filter(ImageFilter.GaussianBlur(4)),dtype=np.float32)/255
def domain(pix):return map_coordinates(mask,[pix[:,1],pix[:,0]],order=1,mode='constant',cval=0)*smooth((pix[:,1]-526)/7)
# First-hit field from the actual immutable exported geometry.
g=GLB(R/f'checks/peacock_{name}.glb');prs=g.j['meshes'][0]['primitives'];GP=g.read(prs[0]['attributes']['POSITION']).astype(float)[:,[0,2,1]];GP[:,1]*=-1;GT=np.concatenate([g.read(p['indices']).reshape(-1,3) for p in prs]);q=project(GP)[GT];lo=np.maximum(np.ceil(q[:,:,:2].min(1)).astype(int),0);hi=np.minimum(np.floor(q[:,:,:2].max(1)).astype(int),size-1);depth=np.full((size,size),np.inf)
for fi in np.where(np.all(hi>=lo,axis=1))[0]:
 tr=q[fi];e=tr[1,:2]-tr[0,:2];f=tr[2,:2]-tr[0,:2];den=e[0]*f[1]-e[1]*f[0]
 if abs(den)<1e-12:continue
 xx,yy=np.meshgrid(np.arange(lo[fi,0],hi[fi,0]+1),np.arange(lo[fi,1],hi[fi,1]+1));r=np.column_stack([xx.ravel(),yy.ravel()])-tr[0,:2];b=(r[:,0]*f[1]-r[:,1]*f[0])/den;c=(e[0]*r[:,1]-e[1]*r[:,0])/den;bar=np.column_stack([1-b-c,b,c]);z=bar@tr[:,2];x=xx.ravel();y=yy.ravel();take=(bar.min(1)>=-1e-9)&(z<depth[y,x]);depth[y[take],x[take]]=z[take]
depth[~np.isfinite(depth)]=1e6;visibility=ProjectedDepth(q,roi=(298,509,558,668))
proof=json.loads((R/'checks/opposite_transfer_seams287.json').read_text());proof_xy=np.asarray([r['pixel_xy'] for r in proof['rays']],float);proof_depth=np.asarray([r['hits'][0]['ray_depth'] for r in proof['rays']]);proof_error=float(np.max(np.abs(visibility.query(proof_xy)-proof_depth)));assert proof_error<1e-7,proof_error
del GP,GT,q
Q=project(P);q=Q[T];cent=P[T].mean(1)
# Conservative projected-box intersection, then exact per-sample domain.
selected=(q[:,:,:2].min(1)<[556,666]).all(1)&(q[:,:,:2].max(1)>[300,511]).all(1)&np.isin(M,[0,1,5,6])&(cent[:,0]>-.03)&(cent[:,0]<.10)&(cent[:,1]>-.095)&(cent[:,1]<.03)&(cent[:,2]>.61)&(cent[:,2]<.71)
ids=np.where(selected)[0];assert 5<len(ids)<3000
span=np.maximum(16,np.ceil(np.max(np.linalg.norm(q[ids,:,:2]-np.roll(q[ids,:,:2],1,axis=1),axis=2),axis=1)*2)).astype(int);pad=8;cells=span+2*pad+1;order=np.argsort(-cells);atlas=2**int(np.ceil(np.log2(np.sqrt(np.sum(cells*cells)*1.5))))
while True:
 x=y=rowh=0;placements={}
 for kk in order:
  cell=int(cells[kk])
  if x+cell>atlas:x=0;y+=rowh;rowh=0
  placements[int(kk)]=(x,y);x+=cell;rowh=max(rowh,cell)
 if y+rowh<=atlas:break
 atlas*=2
print("ATLAS_PREFLIGHT",len(ids),atlas,int(cells.max()),int(np.sum(cells*cells)),flush=True)
assert atlas<=4096
images={}
for mi in np.unique(M[ids]):
 for key in ['base_path','orm_path']:
  path=materials[mi][key]
  if path not in images:images[path]=np.asarray(Image.open(path).convert('RGB'))
rgb=np.zeros((atlas,atlas,3),np.uint8);orm=np.zeros_like(rgb);alpha_image=np.zeros((atlas,atlas),np.uint8);newP=P.tolist();newN=N.tolist();newU=U.tolist();newT=T.copy();newM=M.copy();coverage=[];applied=full=0
for kk,fi in enumerate(ids):
 cell=int(cells[kk]);sp=int(span[kk]);xx,yy=np.meshgrid(np.arange(cell),np.arange(cell));b=(xx-pad)/sp;c=(yy-pad)/sp;bar=np.stack([1-b-c,b,c],-1);inside=(bar>=-1e-8).all(2);bar=np.maximum(bar,0);bar/=bar.sum(2,keepdims=True);bar=bar.reshape(-1,3);p=bar@P[T[fi]];uv=bar@U[T[fi]];normal=bar@N[T[fi]];normal/=np.linalg.norm(normal,axis=1)[:,None];v=project(p);w=domain(v[:,:2]);z=np.full(len(v),np.inf);needed=w>1e-8;z[needed]=visibility.query(v[needed,:2]);alpha=w*smooth((.0008-abs(v[:,2]-z))/.0004);skin_max_x=.018+np.maximum(-p[:,1]-.035,0)*1.4;collar_reject=(1-smooth((p[:,2]-.646)/.003))*smooth((p[:,0]-skin_max_x)/.002);collar_reject*=smooth((v[:,1]-(850-.5*v[:,0]))/3);alpha*=1-collar_reject
 mapped=np.column_stack([v[:,:2],np.ones(len(v))])@warp;paint=sample(plate,(mapped+.5)/size);oldrgb=sample(images[materials[M[fi]]['base_path']],uv);color=np.clip(np.rint(srgb(linear(oldrgb/255)*(1-alpha[:,None])+linear(paint/255)*alpha[:,None])*255),0,255).astype(np.uint8);aux=np.clip(np.rint(sample(images[materials[M[fi]]['orm_path']],uv)),0,255).astype(np.uint8)
 x,y=placements[kk];rgb[y:y+cell,x:x+cell]=color.reshape(cell,cell,3);orm[y:y+cell,x:x+cell]=aux.reshape(cell,cell,3);alpha_image[y:y+cell,x:x+cell]=np.rint(alpha.reshape(cell,cell)*255).astype(np.uint8);chart=(np.array([[x+pad,y+pad],[x+pad+sp,y+pad],[x+pad,y+pad+sp]],float)+.5)/atlas;start=len(newP);newP.extend(P[T[fi]].tolist());newN.extend(N[T[fi]].tolist());newU.extend(chart.tolist());newT[fi]=np.arange(start,start+3);newM[fi]=len(materials);coverage.append(int(inside.sum()));applied+=int(((alpha>1e-5)&inside.ravel()).sum());full+=int(((alpha>.999)&inside.ravel()).sum())
P2=np.asarray(newP);N2=np.asarray(newN);assert np.array_equal(P2[newT],P[T]) and np.array_equal(N2[newT],N[T])
target=R/'inputs/face_oppositepaint295.npz';np.savez_compressed(target,pos=P2,normal=N2,uv=np.asarray(newU),tri=newT,material=newM);base=R/'inputs/oppositepaint295_basecolor.png';aux=R/'inputs/oppositepaint295_ORM.png';Image.fromarray(rgb).save(base);Image.fromarray(orm).save(aux);Image.fromarray(alpha_image).save(R/'checks/oppositepaint295_alpha.png');materials.append({'name':'Registered opposite jaw-neck albedo transition','base_path':str(base),'orm_path':str(aux),'occlusion_strength':0});(R/'inputs/face_oppositepaint295_materials.json').write_text(json.dumps(materials,indent=2))
report={'source_glb_sha256':g.sha256,'component_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'plate_sha256':reg['plate_png_sha256'],'triangles':len(T),'selected_source_face_ids':ids.tolist(),'selected_material_counts':{str(mi):int((M[ids]==mi).sum()) for mi in np.unique(M[ids])},'all_triangle_corner_positions_and_normals_exact':True,'atlas_size':atlas,'padding_pixels':pad,'strict_chart_overlap_by_disjoint_cells':0,'minimum_face_texel_centers':min(coverage),'painted_samples':applied,'full_weight_samples':full,'anatomical_camera_polygon800':poly,'mask_feather_sigma_pixels':4,'excludes_generated_ear_interior_and_all_facial_features':True,'ear_exclusion_pixel_y_at_or_above':526,'visibility_depth_tolerance_m':.0008,'continuous_projected_depth_queries':visibility.queries,'exact_saved_ray_depth_max_error_m':proof_error,'authored_normal_visibility_fade_removed':True,'visibility_reason':'Exact287 residuals show pixel-depth interpolation rejects visible crease samples; continuous-coordinate depth replaces that interpolation. First-hit visibility governs this bounded skin-only paint, independent of inherited authored normal direction. Geometry/normal defects remain separate gates.','collar_spatial_exclusion':{'below_z_m':[.646,.649],'maximum_skin_x_m':'.018+max(-Y-.035,0)*1.4','fade_m':.002,'camera_band':'pixelY > 850 - .5*pixelX, with3px fade','provenance':'Exact278 source faces64594/17686 identify the raised collar. Exact293 showed the earlier world-only envelope also clipped valid jaw faces24330/113802, so the exclusion is now limited to the measured collar projection band.'},'status':'Local albedo-only trial. Exact material and silhouette regressions pending. No jaw form change.'};(R/'checks/face_oppositepaint295.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='selected_source_face_ids'},indent=2))
