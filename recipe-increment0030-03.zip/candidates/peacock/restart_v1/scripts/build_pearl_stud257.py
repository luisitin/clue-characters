"""Add one reference pearl stud on the verified native lobe.
The sphere has a deliberately shallow seated contact; no old character surface
is displaced or removed. All other geometry/material attributes remain exact.
"""
from pathlib import Path
import numpy as np,json,hashlib
from PIL import Image
R=Path(__file__).resolve().parents[1];a=np.load(R/'inputs/face_ear253.npz');D={k:a[k] for k in a.files};a.close();materials=json.loads((R/'inputs/face_ear253_materials.json').read_text());measure=json.loads((R/'checks/earring_anchor256.json').read_text());row=next(x for x in measure['samples'] if x['pixel_xy']==[305,370]);assert row['material']==8;anchor=np.asarray(row['world']);axis=np.asarray(row['geometric_normal']);axis/=np.linalg.norm(axis);radius=.0065;seat=.0002;center=anchor+axis*(radius-seat);gold=(1+np.sqrt(5))/2;V=np.array([[-1,gold,0],[1,gold,0],[-1,-gold,0],[1,-gold,0],[0,-1,gold],[0,1,gold],[0,-1,-gold],[0,1,-gold],[gold,0,-1],[gold,0,1],[-gold,0,-1],[-gold,0,1]],float);V/=np.linalg.norm(V,axis=1)[:,None];F=np.array([[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]])
for _ in range(3):
 pts=V.tolist();cache={};faces=[]
 def midpoint(a,b):
  key=tuple(sorted((int(a),int(b))))
  if key not in cache:
   p=V[a]+V[b];p/=np.linalg.norm(p);cache[key]=len(pts);pts.append(p.tolist())
  return cache[key]
 for a,b,c in F:
  ab,bc,ca=midpoint(a,b),midpoint(b,c),midpoint(c,a);faces.extend([[a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca]])
 V=np.array(pts);F=np.array(faces)
fn=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]);assert np.min(np.sum(fn*V[F].mean(1),axis=1))>0;P=center+V*radius;off=len(D['pos']);oldtri=len(D['tri']);oldm=len(materials);D['pos']=np.vstack([D['pos'],P]);D['normal']=np.vstack([D['normal'],V]);D['uv']=np.vstack([D['uv'],np.full((len(P),2),.5)]);D['tri']=np.vstack([D['tri'],F+off]);D['material']=np.r_[D['material'],np.full(len(F),oldm)];base=R/'inputs/pearl257_basecolor.png';orm=R/'inputs/pearl257_ORM.png';Image.fromarray(np.array([[[244,240,228]]],np.uint8)).save(base);Image.fromarray(np.array([[[255,64,0]]],np.uint8)).save(orm);materials.append({'name':'Ivory pearl stud, uniform dielectric material','base_path':str(base),'orm_path':str(orm),'occlusion_strength':0,'uv_rationale':'Intentional constant material swatch; this accessory does not use a uniquely painted atlas.'});out=R/'inputs/face_pearl257.npz';np.savez_compressed(out,**D);(R/'inputs/face_pearl257_materials.json').write_text(json.dumps(materials,indent=2));report={'component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_model_glb_sha256':measure['actual_glb_sha256'],'anchor_source_triangle':row['actual_triangle'],'anchor_source_material':8,'anchor_source_pixel':row['pixel_xy'],'anchor_world':anchor.tolist(),'seating_axis_world':axis.tolist(),'pearl_center_world':center.tolist(),'radius_mm':radius*1000,'nominal_seating_depth_mm':seat*1000,'pearl_vertices':len(P),'pearl_triangles':len(F),'new_vertex_range':[off,len(D['pos'])],'new_triangle_range':[oldtri,len(D['tri'])],'new_material':oldm,'total_triangles':len(D['tri']),'source_corner_attributes_and_materials_held':True,'scope':'Pearl-placement trial only. Actual contact ownership/depth, exported appearance and all-angle lobe seating remain required.'};(R/'checks/pearl_stud257.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
