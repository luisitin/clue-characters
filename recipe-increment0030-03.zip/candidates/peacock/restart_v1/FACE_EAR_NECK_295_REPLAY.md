# Peacock 295: near ear, pearl and bounded neck paint WIP

This is an editable checkpoint, not a complete character or approved head. It builds on the previously preserved face and near-ear study 253. The opposite native-ear studies 294–304 are separate and are not integrated here.

The exact complete GLB is `checks/peacock_face_oppositepaint295.glb`, SHA256 `9fc811cac645d586493caf88d0b5f88182e2bd71a5e6dcc426e6cccc6c6e96c4`, with 220,793 triangles. The canonical editable double-precision component is `inputs/face_oppositepaint295.npz`, SHA256 `acb9b165d6e247afe4eb7b02d21223d9dd102dc388cadb823dcecd3644cecec2`. Its material manifest identifies all images; the GLB embeds the exact image bytes and shader definitions. Saving the GLB, NPZ and material manifest preserves the state without requiring all exploratory trials to be replayed. Local absolute paths in manifests/scripts must be rebased before running elsewhere.

## Changes and evidence

- A 6.5 mm ivory pearl stud is seated on the verified near native lobe. Actual float32 contact 260 identifies 32 intended buried pearl/lobe contacts only; maximum analytic sphere penetration is 0.2104 mm. It is not a zero-intersection claim.
- Lower paint repair 264 crosses the previously mismatched original-body/refined-face/ear material boundary with a registered, padded chart. All triangle positions and normals stay exact.
- Opposite paint repair 295 replaces the jagged gray/brown jaw and upper-neck islands on an intact original skin surface. The generated ear interior, facial features and raised collar are excluded. Exact projected-coordinate visibility avoids crossing geometric occlusion boundaries with a bilinearly sampled depth buffer. The revised collar mask avoids suppressing valid jaw skin.
- Actual exported unlit and PBR profile 90°, front 0° and oblique 45° have been inspected. Near-ear top and under views are also saved for 264. Current 295's unchanged geometry/normal corner multiset and every earlier embedded image/shader are verified by 297.
- Open defects include the fused opposite ear, a fine source jaw slit, a shallow near-ear posterior ridge, irregular hair/hat/feather, collar/necklace, and the remaining original body/hands/coat/gown/shoes. No full-head or whole-character clearance follows from these local checks.

## Minimal continuation/replay order

1. Restore exact 253 and its editable NPZ/materials from the prior ear checkpoint. It depends on canonical 178, posed 239, annulus 240, atlas 231 and the saved generated plate 251. Do not substitute a generic donor face or a different source mesh.
2. Run `build_pearl_stud257.py`, then `audit_pearl_contact258.py`, and export `face_pearl257` with `export_layered51.py`. The builder consumes the measured lobe ray report 256. `audit_pearl_contact 260.py` verifies the actual exported float32 contact.
3. Run `bake_lower_attachment264.py`, export `face_lowerpaint264`, and run `verify_lowerpaint_export265.py`. This uses plate 251, registration 252 and the exact ear camera metadata 250.
4. Preserve the unique generated `inputs/opposite_neck_plate272.png` and its provenance. Registration 273 uses the saved exact opposite albedo image 269; its stored mapping and camera JSON are sufficient inputs for the final bake.
5. Run `projected_depth_query288.py` for its fixture check, then `bake_opposite_neck295.py`. The latter consumes exact 264, plate 272, registration 273, camera metadata 269 and the saved first-hit ray depths 287 as a narrow numerical attribution guard. The earlier 274/281/289 paint experiments do not need to be regenerated.
6. Export `face_oppositepaint295` and run `verify_oppositepaint_export297.py`. Render the actual GLB with `render_layered_glb53.py`, using the exact material manifest and the saved matching cameras. Use `render_ear_material249.py` for near-ear macros.

The shaders in this checkpoint deliberately disable legacy baked AO; the actual-view renderers reproduce that exported choice. New ORM charts resample existing ORM fields without changing intended material values, so filtering/8-bit rebake quantization remains distinct from byte equality of the earlier embedded maps.

All heavy builds, image-array operations and renders require an external shared lock before process startup. This text records the existing local pipeline and evidence; it does not claim an independent clean-room replay.

## Unique new paint input

`inputs/opposite_neck_plate272.png` has SHA256 `6b9e951ff00cc4ca4bb6c314c42aeb7e37921e6af557ff1fd31dc1a3f3cc6d86`. It was authored with the built-in image tool from the exact model albedo/clay renders and the original character palette reference. It is an authoring input, not proof of exported appearance. The complete prompt and input hashes are in `checks/opposite_neck_plate272_provenance.json`.

The native ear data remains the previously documented MakeHuman CC0 asset. Its license is separate from the MakeHuman program code. The original character reference/source provenance remains in the recovery source inventory.
