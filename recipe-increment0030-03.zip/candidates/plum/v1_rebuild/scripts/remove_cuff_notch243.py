"""Remove only the two complete supported source branches proved in195.
Append a new index accessor; preserve every old BIN byte and vertex attribute.
"""
from pathlib import Path
import collections,json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];proof=json.loads((O/'checks/cuff_notch241.json').read_text());src=O/'components/source_cuff_cleanup198.glb';assert hashlib.sha256(src.read_bytes()).hexdigest()==proof['source_sha256'];groups=proof['groups'];assert len(groups)==2 and proof['combined_attachment_pass'] and all(g['coverage_pass']for g in groups);remove=set(fi for g in groups for fi in g['faces']);assert len(remove)==16
j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=a(pr['attributes']['POSITION']);F=a(pr['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
affected=set(k for k,v in edge.items()if any(f in remove for f,_,_ in v));checks=[]
for k in sorted(affected):
 keep=[(fi,aa,bb)for fi,aa,bb in edge[k]if fi not in remove];assert len(keep)in(0,2),(k,keep)
 if len(keep)==2:assert keep[0][1:]==keep[1][1:][::-1],(k,keep)
 checks.append({'edge':list(k),'retained_directed':keep})
mask=np.ones(len(F),bool);mask[sorted(remove)]=False;newF=F[mask].astype('<u4');payload=bytearray(b);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':newF.nbytes,'target':34963});payload.extend(newF.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':newF.size,'type':'SCALAR','min':[int(newF.min())],'max':[int(newF.max())]});pr['indices']=ai;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_cuff_cleanup243.glb';dst.write_bytes(raw);jj,bb,aa=read_glb(dst);assert bb[:len(b)]==b
np.savez_compressed(O/'checks/cuff_cleanup243_lineage.npz',source198_face=np.flatnonzero(mask));r={'source_sha256':proof['source_sha256'],'output_sha256':hashlib.sha256(raw).hexdigest(),'complete_removed_source198_faces':sorted(remove),'removed_component_roots':[g['root']for g in groups],'all_prior_BIN_bytes_unchanged':True,'all_vertex_attributes_and_materials_unchanged':True,'combined_surviving_edge_incidence_and_directed_parity_pass':True,'affected_edge_checks':checks,'triangles':len(newF),'scope':'Bounded complete-family source overlap removal from the low opposite sleeve notch, after every projected triangle and edge has retained healthy backing within3mm. Actual matched side/front appearance is still required. Remaining source defects, open117-edge cuff and existing crossings are not cleared.'};(O/'checks/cuff_cleanup243.json').write_text(json.dumps(r,indent=2));print('CUFF243',r['output_sha256'],len(newF),flush=True)
