"""Exact exported closed-wrist seam and orientation audit, no edits."""
from pathlib import Path
import collections,json,hashlib,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/hand_wrist201.glb';j,b,a=read_glb(src);M=node_matrix(j['nodes'][0]);PP=[];NN=[];FF=[];groups=[];offset=0;attrs=[]
for k,pr in enumerate(j['meshes'][0]['primitives']):
 P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(int);PP.append(P);NN.append(N);FF.append(F+offset);offset+=len(P);groups.extend([k]*len(F));attrs.append({'primitive':k,'counts':{name:len(a(ai))for name,ai in pr['attributes'].items()}})
P=np.concatenate(PP);N=np.concatenate(NN);F=np.concatenate(FF);grp=np.array(groups);used=np.unique(F);U,inv=np.unique(P[used],axis=0,return_inverse=True);mapv=np.full(len(P),-1,int);mapv[used]=inv;T=mapv[F];edge=collections.defaultdict(list);G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);area=np.linalg.norm(G,axis=1)/2;GN=G/(2*area[:,None]);
for fi,f in enumerate(T):
 for k,(aa,bb)in enumerate(zip(f,np.roll(f,-1))):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb),int(F[fi,k]),int(F[fi,(k+1)%3])))
bad=[k for k,v in edge.items()if len(v)!=2];parity=[k for k,v in edge.items()if len(v)==2 and v[0][1:3]!=v[1][1:3][::-1]];assert not bad and not parity,(bad[:3],parity[:3]);seams=[];maxext=0
for key,vs in edge.items():
 fa,fb=vs[0][0],vs[1][0];angle=float(np.degrees(np.arccos(np.clip(GN[fa]@GN[fb],-1,1))))
 if grp[fa]==1 or grp[fb]==1:maxext=max(maxext,angle)
 if grp[fa]!=grp[fb]:
  ns=[]
  for vv in key:
   pair=[]
   for v in vs:
    ai=v[3]if v[1]==vv else v[4];pair.append(N[ai])
   ns.append(float(np.degrees(np.arccos(np.clip(pair[0]@pair[1],-1,1)))))
  seams.append({'edge':list(key),'world_edge':U[list(key)].tolist(),'geometric_dihedral_degrees':angle,'stored_normal_angles_degrees':ns})
assert len(seams)==172;vol=float(np.sum(np.einsum('ij,ij->i',P[F[:,0]],np.cross(P[F[:,1]],P[F[:,2]])))/6);assert vol>0
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'triangles':len(F),'used_physical_vertices':len(U),'edge_count':len(edge),'Euler_characteristic':int(len(U)-len(edge)+len(F)),'boundary_or_nonmanifold_edges':len(bad),'parity_failures':len(parity),'signed_volume_m3':vol,'seam_edges':len(seams),'maximum_seam_geometric_dihedral_degrees':max(x['geometric_dihedral_degrees']for x in seams),'maximum_seam_stored_normal_mismatch_degrees':max(v for x in seams for v in x['stored_normal_angles_degrees']),'maximum_extension_incident_dihedral_degrees':maxext,'minimum_triangle_area_m2':float(area.min()),'attribute_counts':attrs,'seams':seams,'scope':'Exact closed-wrist topology/seam evidence only. Actual all-angle shape, cloth containment, hand/head contact and final material remain distinct.'};(O/'checks/wrist_seam204.json').write_text(json.dumps(r,indent=2));print('WRIST204',{k:v for k,v in r.items()if k!='seams'},flush=True)
