"""Actual-export local seam topology and dense cloth/closed-skin clearance."""
from pathlib import Path
import collections,json,hashlib,numpy as np,vtk
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1]
def parts(src):
 j,b,a=read_glb(src);out=[]
 for node in j['nodes']:
  if 'mesh'not in node:continue
  M=node_matrix(node)
  for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
   P=a(p['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(p['indices']).reshape(-1,3).astype(int);out.append((P,N,F))
 return out
bodies=parts(O/'components/source_cuff_cleanup198.glb');cloth=parts(O/'components/layered_cuff222.glb');old_knit=parts(O/'components/layered_cuff206.glb')[1];assert all(np.array_equal(a,b)for a,b in zip(old_knit,cloth[1])),'Unchanged knit regenerated differently';hand=parts(O/'components/hand_wrist201.glb');HP=np.concatenate([x[0]for x in hand]);HN=np.concatenate([x[1]for x in hand]);HF=np.concatenate([x[2]+sum(len(y[0])for y in hand[:i])for i,x in enumerate(hand)]);HT=HP[HF];HG=np.cross(HT[:,1]-HT[:,0],HT[:,2]-HT[:,0]);HG/=np.linalg.norm(HG,axis=1)[:,None];
points=vtk.vtkPoints();points.SetDataTypeToDouble()
for p in HP:points.InsertNextPoint(p)
cells=vtk.vtkCellArray()
for f in HF:cells.InsertNextCell(3,f)
poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);loc=vtk.vtkStaticCellLocator();loc.SetDataSet(poly);loc.BuildLocator();closest=[0.,0.,0.];cell=vtk.reference(0);sub=vtk.reference(0);dist2=vtk.reference(0.);reports=[]
for ci,(P,N,F)in enumerate(cloth):
 U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edges=collections.defaultdict(list)
 for fi,f in enumerate(T):
  for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
 boundary=[k for k,v in edges.items()if len(v)==1];bad=[k for k,v in edges.items()if len(v)>2];parity=[k for k,v in edges.items()if len(v)==2 and v[0][1:]!=v[1][1:][::-1]];assert not bad and not parity
 if ci==1:assert not boundary and len(U)-len(edges)+len(F)==0
 G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);a=np.linalg.norm(G,axis=1);GN=G/a[:,None];SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];pairs=np.array([[v[0][0],v[1][0]]for v in edges.values()if len(v)==2]);angles=np.degrees(np.arccos(np.clip((GN[pairs[:,0]]*GN[pairs[:,1]]).sum(1),-1,1)));samples=np.concatenate([U,P[F].mean(1),(P[F[:,0]]+P[F[:,1]])/2,(P[F[:,1]]+P[F[:,2]])/2,(P[F[:,2]]+P[F[:,0]])/2]);mins=[1e9,1e9];arg=None;negative=[]
 for si,q in enumerate(samples):
  loc.FindClosestPoint(q,closest,cell,sub,dist2);fi=int(cell);dd=q-np.array(closest);distance=float(np.sqrt(float(dist2)));signed=float(dd@HG[fi])
  if signed<mins[0]:mins[0]=signed;arg={'sample':si,'world':q.tolist(),'skin_triangle':fi,'closest':list(closest),'distance_m':distance}
  mins[1]=min(mins[1],distance)
  if signed<-1e-7:negative.append(si)
  if si%25000==0:print('CLEARANCE224',ci,si,len(samples),mins,flush=True)
 vol=float(np.sum(np.einsum('ij,ij->i',P[F[:,0]],np.cross(P[F[:,1]],P[F[:,2]])))/6)
 if ci==1:assert vol>0
 reports.append({'component':ci,'triangles':len(F),'physical_vertices':len(U),'boundary_edges':len(boundary),'nonmanifold_edges':len(bad),'directed_parity_failures':len(parity),'Euler_characteristic':int(len(U)-len(edges)+len(F)),'signed_volume_m3':vol,'maximum_internal_adjacent_angle_degrees':float(angles.max()),'minimum_geometric_stored_normal_dot':float((GN*SN).sum(1).min()),'samples_vertices_all_edges_centroids':len(samples),'minimum_oriented_skin_clearance_m':mins[0],'minimum_distance_m':mins[1],'minimum_clearance_sample':arg,'negative_samples':negative})
# The source body's explicit117-node end must join exactly to the new wool edge.
P=np.concatenate([bodies[0][0],cloth[0][0]]);N=np.concatenate([bodies[0][1],cloth[0][1]]);F=np.vstack([bodies[0][2],cloth[0][2]+len(bodies[0][0])]);groups=np.r_[np.zeros(len(bodies[0][2]),int),np.ones(len(cloth[0][2]),int)];U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list);G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);G/=np.linalg.norm(G,axis=1)[:,None]
for fi,f in enumerate(T):
 for k,(aa,bb)in enumerate(zip(f,np.roll(f,-1))):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb),int(F[fi,k]),int(F[fi,(k+1)%3])))
seams=[]
for key,v in edge.items():
 if len(v)!=2 or groups[v[0][0]]==groups[v[1][0]]:continue
 assert v[0][1:3]==v[1][1:3][::-1];nerr=[]
 for vv in key:
  normals=[N[x[3]if x[1]==vv else x[4]]for x in v];nerr.append(float(np.degrees(np.arccos(np.clip(normals[0]@normals[1],-1,1)))))
 seams.append({'edge':list(key),'normal_mismatch_deg':nerr,'geometric_dihedral_deg':float(np.degrees(np.arccos(np.clip(G[v[0][0]]@G[v[1][0]],-1,1))))})
assert len(seams)==117,len(seams);r={'cloth_sha256':hashlib.sha256((O/'components/layered_cuff222.glb').read_bytes()).hexdigest(),'hand_sha256':hashlib.sha256((O/'components/hand_wrist201.glb').read_bytes()).hexdigest(),'body_sha256':hashlib.sha256((O/'components/source_cuff_cleanup198.glb').read_bytes()).hexdigest(),'parts':reports,'old206_knit_positions_normals_indices_exactly_held':True,'coat_wool_seam_edges':len(seams),'maximum_coat_wool_seam_normal_mismatch_degrees':max(x for s in seams for x in s['normal_mismatch_deg']),'maximum_coat_wool_seam_geometric_dihedral_degrees':max(s['geometric_dihedral_deg']for s in seams),'all_coat_wool_edges_have_opposite_direction':True,'scope':'Dense sampled clearance plus exact seam topology. Exact full triangle intersection207 and exposing actual views remain separate; hidden lining inner hem has an intentional small cloth separation from the knit.'};(O/'checks/layered_cuff224.json').write_text(json.dumps(r,indent=2));print('END224',r,flush=True)
