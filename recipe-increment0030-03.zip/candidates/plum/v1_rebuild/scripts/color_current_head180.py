"""Provisional material context only: held067 colours on exact orbital140 geometry."""
from pathlib import Path
import hashlib,json,struct,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];skin=O/'components/head_orbits140.glb';color=O/'components/head_colors067.glb';gj,gb,ga=read_glb(skin);j,b,a=read_glb(color);gp=gj['meshes'][0]['primitives'][0];p=j['meshes'][0]['primitives'][0];assert np.array_equal(ga(gp['indices']),a(p['indices']));assert np.array_equal(ga(gp['attributes']['TEXCOORD_0']),a(p['attributes']['TEXCOORD_0']));payload=bytearray(b)
for semantic in ['POSITION','NORMAL']:
 values=ga(gp['attributes'][semantic]).astype('<f4');assert len(values)==j['accessors'][p['attributes'][semantic]]['count'];payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':values.nbytes,'target':34962});payload.extend(values.tobytes());ai=len(j['accessors']);row={'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC3'}
 if semantic=='POSITION':row.update(min=values.min(0).tolist(),max=values.max(0).tolist())
 j['accessors'].append(row);p['attributes'][semantic]=ai
j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/head_colors180.glb';dst.write_bytes(raw);report={'geometry_source_sha256':hashlib.sha256(skin.read_bytes()).hexdigest(),'color_source_sha256':hashlib.sha256(color.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'all_geometry_indices_UVs_exact140':True,'scope':'Provisional vertex-colour likeness context. Not final raster skin/brow paint, not a material or whole-head pass.'};(O/'checks/head_colors180.json').write_text(json.dumps(report,indent=2));print('HEAD180',report,flush=True)
# The eye colour context must also retain the held058 geometry exactly.
ej,eb,ea=read_glb(O/'components/eyes_colors060.glb');hj,hb,ha=read_glb(O/'components/eye_wide058.glb');assert len(ej['meshes'])==len(hj['meshes'])
for em,hm in zip(ej['meshes'],hj['meshes']):
 for ep,hp in zip(em['primitives'],hm['primitives']):
  for sem in ['POSITION','NORMAL','TEXCOORD_0']:assert np.array_equal(ea(ep['attributes'][sem]),ha(hp['attributes'][sem]))
  assert np.array_equal(ea(ep['indices']),ha(hp['indices']))
