"""Weld the four intentional spectacle solid junctions, then add tiny weld fillets.
The five separate closed analytic solids are kept as immutable source snapshots.
Exact boolean union is confined to the spectacle component; no head/hair edit.
"""
import bpy,bmesh,math,pathlib,json,hashlib,numpy as np
O=pathlib.Path(__file__).resolve().parents[1];sources=[O/'components/spectacle_front059.glb',O/'components/spectacle_temples069.glb'];bpy.ops.wm.read_factory_settings(use_empty=True)
for p in sources:bpy.ops.import_scene.gltf(filepath=str(p))
objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];assert len(objects)==5
source_points=np.array([tuple(v.co)for ob in objects for v in ob.data.vertices],float);center=(source_points.min(0)+source_points.max(0))/2;unit_scale=1000.
for ob in objects:
 for v in ob.data.vertices:v.co=(np.array(v.co)-center)*unit_scale
 ob.data.update()
for o in objects:
 assert np.max(abs(np.array(o.matrix_world)-np.eye(4)))<1e-8
 for p in o.data.polygons:p.use_smooth=True
base=next(o for o in objects if 'rim059 positive'in o.name);material=base.data.materials[0].copy();material.name='Plum | continuous dark warm metal spectacles193';order=[next(o for o in objects if 'nasal bridge'in o.name),next(o for o in objects if 'rim059 negative'in o.name),next(o for o in objects if 'temple069 positive'in o.name),next(o for o in objects if 'temple069 negative'in o.name)];bpy.context.view_layer.objects.active=base;base.select_set(True)
for other in order:
 mod=base.modifiers.new('Exact solid weld with '+other.name,'BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=other;bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(other,do_unlink=True)

def audit_mesh(label):
 bm=bmesh.new();bm.from_mesh(base.data);bm.verts.ensure_lookup_table();bm.edges.ensure_lookup_table();bm.faces.ensure_lookup_table();bound=sum(e.is_boundary for e in bm.edges);non=sum(not e.is_manifold for e in bm.edges);parent=list(range(len(bm.verts)))
 def root(k):
  while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
  return k
 for e in bm.edges:
  aa,bb=e.verts;parent[root(aa.index)]=root(bb.index)
 comps=len({root(i)for i in range(len(parent))});volume=bm.calc_volume(signed=True);row={'stage':label,'vertices':len(bm.verts),'edges':len(bm.edges),'polygons':len(bm.faces),'boundary_edges':bound,'nonmanifold_edges':non,'connected_components':comps,'signed_volume_native_units3':float(volume),'Euler_characteristic':len(bm.verts)-len(bm.edges)+len(bm.faces)};bm.free();assert bound==0 and non==0 and comps==1 and volume>0 and row['Euler_characteristic']==-2,row;return row
before=audit_mesh('exact_union_mm_local');bm=bmesh.new();bm.from_mesh(base.data);nv=len(bm.verts);nf=len(bm.faces);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.0001);bmesh.ops.dissolve_degenerate(bm,dist=.0001,edges=list(bm.edges));bm.normal_update();cleanup={'vertices_before':nv,'vertices_after':len(bm.verts),'polygons_before':nf,'polygons_after':len(bm.faces),'maximum_merge_distance_world_m':1e-7};bm.to_mesh(base.data);bm.free();cleaned=audit_mesh('nanometre_scale_boolean_cleanup');
# Hold the clean exact union. Prior globally clamped bevels are rejected.
bm=bmesh.new();bm.from_mesh(base.data);edge_stats=[{'length_mm':float(e.calc_length()),'dihedral_degrees':float(math.degrees(e.calc_face_angle()))}for e in bm.edges if e.is_manifold and e.calc_face_angle()>math.radians(35)];bm.free()

for p in base.data.polygons:p.use_smooth=True
base.data.materials.clear();base.data.materials.append(material)
for p in base.data.polygons:p.material_index=0
base.name='Plum | joined centred spectacles193';after=audit_mesh('unfilleted_exact_union');tri=base.modifiers.new('Final explicit triangles','TRIANGULATE');tri.quad_method='BEAUTY';tri.ngon_method='BEAUTY';bpy.ops.object.modifier_apply(modifier=tri.name);# Rebuild only this new owned constant-material solid to discard inherited loop-normal layers.
coords=[tuple(v.co)for v in base.data.vertices];polys=[list(p.vertices)for p in base.data.polygons];fresh=bpy.data.meshes.new('Continuous solid spectacle mesh193');fresh.from_pydata(coords,[],polys);fresh.update();base.data=fresh;fresh.materials.append(material)
for p in fresh.polygons:p.use_smooth=True
final=audit_mesh('triangulated_fresh_normals');base.location=center.tolist();base.scale=(.001,.001,.001);bpy.context.view_layer.update();bpy.ops.object.select_all(action='DESELECT');base.select_set(True);bpy.context.view_layer.objects.active=base;dst=O/'components/spectacles_joined193.glb';bpy.ops.export_scene.gltf(filepath=str(dst),export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_materials='EXPORT',export_animations=False);report={'sources':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sources],'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'stages_native_mm_units':[before,cleaned,after,final],'world_signed_volume_m3':final['signed_volume_native_units3']*1e-9,'world_center':center.tolist(),'native_coordinate_scale':1000,'boolean_cleanup':cleanup,'fillet_width_m':0,'fillet_status':'Previous clamped bevel rejected; exact union held without a claimed fillet','sharp_edge_stats_before_triangulation':edge_stats,'scope':'Unapproved joined spectacle component. Topology/positive-volume checks do not substitute for actual exported self/head contacts, corner normals and matched appearance. Head, eyes, hair and hand unchanged.'};(O/'checks/spectacles193.json').write_text(json.dumps(report,indent=2));print('SPECTACLES193',report,flush=True)
