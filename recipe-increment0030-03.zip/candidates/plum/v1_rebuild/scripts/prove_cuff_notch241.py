"""Read-only full connected-family diagnosis at exact189 dark source hits.
No color-derived deletion. Exact-position incidence; all proposed families are
excluded from complete projected triangle/edge coverage support.
"""
from pathlib import Path
import sys, json, hashlib, collections, numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(R/'shared_helpers'))
from projected_backing import prove_coverage
src=O/'components/source_cuff_cleanup198.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);tri=P[F];cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1)/2;G=cross/(2*area[:,None]);SN=N[F].mean(1);SN/=np.linalg.norm(SN,axis=1)[:,None];dot=(SN*G).sum(1);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list);parent=np.arange(len(F))
def root(k):
 while parent[k]!=k:parent[k]=parent[parent[k]];k=int(parent[k])
 return k
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
for family in edge.values():
 if len(family)==2:parent[root(family[1])]=root(family[0])
bins=collections.defaultdict(list)
for fi in range(len(F)):bins[root(fi)].append(fi)
seeds=[16861,16862,16867];roots=sorted(set(root(s)for s in seeds));groups=[]
for rr in roots:
 ids=np.array(bins[rr]);group=set(map(int,ids));xyz=tri[ids];lo=xyz.min((0,1));hi=xyz.max((0,1));extent=float(np.linalg.norm(hi-lo));boundary=[]
 for key,fam in edge.items():
  inside=[f for f in fam if f in group]
  if not inside or (len(fam)>1 and len(inside)==len(fam)):continue
  retained=[f for f in fam if f not in group];directed=[]
  for fi in retained:
   f=T[fi]
   for aa,bb in zip(f,np.roll(f,-1)):
    if tuple(sorted((int(aa),int(bb))))==key:directed.append([int(aa),int(bb)])
  parity=len(retained)==0 or (len(retained)==2 and directed[0]==directed[1][::-1])
  boundary.append({'edge':list(key),'world_points':U[list(key)].tolist(),'source_faces':fam,'retained_faces':retained,'directed_retained':directed,'retained_incidence_and_parity_pass':parity})
 groups.append({'root':rr,'seeds':[s for s in seeds if root(s)==rr],'faces':ids.tolist(),'face_count':len(ids),'extent_m':extent,'bounds':[lo.tolist(),hi.tolist()],'area_m2':float(area[ids].sum()),'normal_dot_range':[float(dot[ids].min()),float(dot[ids].max())],'boundary':boundary,'attachment_pass':all(v['retained_incidence_and_parity_pass']for v in boundary)})
 print('FAMILY241',rr,len(ids),extent,groups[-1]['attachment_pass'],flush=True)
excluded=sorted(set(fi for g in groups for fi in g['faces']));healthy=dot>.3;lo=tri.min(1);hi=tri.max(1);
for group in groups:
 fs=np.array(group['faces']);bad=fs[dot[fs]<-.5];assert len(bad);seed=int(bad[np.argmax(area[bad])]);D=SN[seed];helper=np.eye(3)[np.argmin(abs(D))];AX=np.cross(helper,D);AX/=np.linalg.norm(AX);AY=np.cross(D,AX);group['chart_U_V_D']=np.array([AX,AY,D]).tolist();proofs=[]
 if group['face_count']>500 or group['extent_m']>.05:
  group['hold_reason']='Family exceeds bounded local diagnostic domain';group['coverage_pass']=False;continue
 for fi in group['faces']:
  subject=tri[fi];near=np.all(hi>=subject.min(0)-.0031,axis=1)&np.all(lo<=subject.max(0)+.0031,axis=1)&healthy;ids=np.flatnonzero(near)
  try:proof=prove_coverage(subject,tri[ids],ids,AX,AY,D,excluded_support_ids=excluded,maximum_ray_depth=.003,minimum_support_facing=.15)
  except (AssertionError,np.linalg.LinAlgError) as err:proof={'passed':False,'reason':'Unresolved numeric support test; no tolerance relaxation','error':str(err)}
  proofs.append({'face':fi,'coverage':proof})
 group['coverage']=proofs;group['coverage_pass']=all(x['coverage']['passed']for x in proofs);print('COVERAGE241',group['root'],group['coverage_pass'],len(proofs),flush=True)
r={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'seeds':seeds,'excluded_entire_family':excluded,'projection_choice':'Each complete family uses the authored outward normal of its largest opposed face, preserving the3mm depth limit; this is separate from the diagnostic camera ray.','groups':groups,'scope':'Read-only complete family/support evidence. No model modified. A removal still requires combined attachment parity, ownership and matched actual view regression.'};
removed=set(excluded);combined=[]
for key,fam in edge.items():
 if not any(fi in removed for fi in fam):continue
 retained=[fi for fi in fam if fi not in removed];directed=[]
 for fi in retained:
  for aa,bb in zip(T[fi],np.roll(T[fi],-1)):
   if tuple(sorted((int(aa),int(bb))))==key:directed.append([int(aa),int(bb)])
 passed=len(retained)==0 or (len(retained)==2 and directed[0]==directed[1][::-1]);combined.append({'edge':list(key),'retained_faces':retained,'directed_retained':directed,'pass':passed})
r['combined_affected_edges']=combined;r['combined_attachment_pass']=all(x['pass']for x in combined);r['all_full_family_coverage_pass']=all(g['coverage_pass']for g in groups);print('COMBINED241',r['combined_attachment_pass'],r['all_full_family_coverage_pass'],flush=True)
(O/'checks/cuff_notch241.json').write_text(json.dumps(r,indent=2));print('END241',flush=True)
