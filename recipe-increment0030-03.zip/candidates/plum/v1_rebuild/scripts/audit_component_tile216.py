"""Actual exported GLB component geometry, all nodes/primitives and explicit broad-phase bounds."""
import pathlib,argparse,json,hashlib,numpy as np,collections
from glb_io import read_glb,node_matrix
from intersection_v4_selected216 import audit
O=pathlib.Path(__file__).resolve().parents[1];pa=argparse.ArgumentParser();pa.add_argument('--inputs',nargs='+',required=True);pa.add_argument('--out',required=True);pa.add_argument('--bounds',nargs=6,type=float);pa.add_argument('--start',type=int,required=True);pa.add_argument('--stop',type=int,required=True);args=pa.parse_args();Ps=[];Fs=[];groups=[];offset=0;faceoffset=0;sources=[]
for path in args.inputs:
 j,b,a=read_glb(path);sources.append({'path':path,'sha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()});scene=j.get('scenes',[{'nodes':list(range(len(j['nodes'])))}])[j.get('scene',0)];visited=set()
 def visit(ni,parent):
  global offset,faceoffset
  assert ni not in visited;visited.add(ni);node=j['nodes'][ni];M=parent@node_matrix(node)
  if 'mesh'in node:
   for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
    assert p.get('mode',4)==4;P=a(p['attributes']['POSITION']).astype(float);F=a(p['indices']).reshape(-1,3).astype(np.int64);assert F.max()<len(P)
    for k,ai in p['attributes'].items():assert j['accessors'][ai]['count']==len(P),(path,ni,pi,k)
    W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];assert np.isfinite(W).all();Ps.append(W);Fs.append(F+offset);material=j.get('materials',[{}])[p.get('material',0)].get('name','');groups.append({'source':path,'node':node.get('name',str(ni)),'mesh':node['mesh'],'primitive':pi,'material':material,'face_start':faceoffset,'face_stop':faceoffset+len(F),'vertex_count':len(P)});offset+=len(P);faceoffset+=len(F)
  for child in node.get('children',[]):visit(child,M)
 for ni in scene['nodes']:visit(ni,np.eye(4))
P=np.vstack(Ps);F=np.vstack(Fs);assert 0<=args.start<args.stop<=len(F);r=audit(P,F,bounds=args.bounds,selected_faces=np.arange(args.start,args.stop));r['selected_global_face_range']=[args.start,args.stop];groupid=np.empty(len(F),int)
for i,g in enumerate(groups):groupid[g['face_start']:g['face_stop']]=i
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in r[key]:row['component_groups']=[int(groupid[x])for x in row['faces']]
r['selector_provenance']=json.loads((O/'checks/selected_audit217.json').read_text());assert r['selector_provenance']['selected_core_sha256']==hashlib.sha256((O/'scripts/intersection_v4_selected216.py').read_bytes()).hexdigest();r.update({'sources':sources,'component_groups':groups,'attribute_counts_and_indices_valid':True,'unchanged_predicate_lineage':json.loads((O/'checks/intersection_v4_provenance.json').read_text()),'selector_change':'Exact V4 predicates held; only explicit selected face IDs constrain the outer loop. All original faces remain comparison targets. Cross-tile pair duplicates must be deduplicated in aggregation.','scope':'Actual exported component preflight. Bounds limit the selected triangles but retain all others for pair tests. Explicit component contact, shared-boundary fold behavior, visual shape and complete character gates remain separate.'});pathlib.Path(args.out).write_text(json.dumps(r,indent=2));print('COMPONENT_AUDIT216',len(r['proper_crossings']),len(r['positive_area_coplanar_pairs']),len(r['position_triangle_copy_groups']),len(r['zero_area_faces']),r['manifold_edge_max_angle_degrees'],flush=True)
