"""Fixture proof that216 only partitions selected faces, retaining all targets."""
from pathlib import Path
import ast,hashlib,json,numpy as np
import intersection_v4_core as original
import intersection_v4_selected216 as tiled
O=Path(__file__).resolve().parents[1];aa=ast.parse((O/'scripts/intersection_v4_core.py').read_text());bb=ast.parse((O/'scripts/intersection_v4_selected216.py').read_text());fa={n.name:ast.dump(n)for n in aa.body if isinstance(n,ast.FunctionDef)};fb={n.name:ast.dump(n)for n in bb.body if isinstance(n,ast.FunctionDef)};assert set(fa)==set(fb) and all(fa[k]==fb[k]for k in fa if k!='audit')
# One proper non-adjacent crossing, one positive-area coplanar overlap, a
# disconnected healthy triangle, and an exact same-position duplicate.
P=np.array([[-1,-1,0],[1,-1,0],[0,1,0],[0,-.3,-1],[0,-.3,1],[0,.7,.2],[-.4,-.4,0],[.4,-.4,0],[0,.4,0],[3,0,0],[4,0,0],[3,1,0]],float);F=np.array([[0,1,2],[3,4,5],[6,7,8],[9,10,11],[0,1,2]],int)
r=original.audit(P,F);whole=tiled.audit(P,F,selected_faces=np.arange(len(F)));out=[tiled.audit(P,F,selected_faces=[i])for i in range(len(F))]
def pairs(r,key):return {tuple(sorted(x['faces']))for x in r[key]}
checks=[]
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 expected=pairs(r,key);actual=set().union(*(pairs(x,key)for x in out));assert actual==expected==pairs(whole,key),(key,expected,actual);checks.append({'key':key,'full_pairs':sorted(expected),'deduplicated_tile_pairs':sorted(actual),'pass':True})
for key in ['position_triangle_copy_groups','zero_area_faces','manifold_edge_folds_over_105_degrees']:
 assert r[key]==whole[key] and all(x[key]==r[key]for x in out)
rpt={'old_core_sha256':hashlib.sha256((O/'scripts/intersection_v4_core.py').read_bytes()).hexdigest(),'selected_core_sha256':hashlib.sha256((O/'scripts/intersection_v4_selected216.py').read_bytes()).hexdigest(),'all_non_audit_function_ASTs_exact':True,'added_behavior':'One optional selected_faces argument filters only the outer iteration after the original spatial bounds. All input triangles remain broad/narrow-phase targets; every predicate is unchanged.','fixtures':checks,'global_copies_collapses_folds_identical':True,'scope':'Partitions audit selection only. Tile reports require pair deduplication and complete stated range coverage; a tile is not a whole-object clearance.'};(O/'checks/selected_audit217.json').write_text(json.dumps(rpt,indent=2));print('SELECT217_PASS',flush=True)
