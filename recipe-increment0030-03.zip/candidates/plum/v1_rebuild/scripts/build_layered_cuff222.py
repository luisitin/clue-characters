"""Measured layered wool lip, recessed lining and closed knit cuff study.
Actual source boundary and wrist sections define geometry. No hand/coat moves.
All materials are provisional; numeric and exposing views remain mandatory.
"""
from pathlib import Path
import collections,json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];body=O/'components/source_cuff_cleanup198.glb';hand=O/'components/hand_wrist201.glb';field=json.loads((O/'checks/cuff_field152.json').read_text());HC=np.array(field['native_wrist_area_centroid']);AX=np.array(field['target_frame']);TA=AX[2];outer=np.array(json.loads((O/'checks/cuff_export175.json').read_text())['ordered_cuff_world_points'])
def read_parts(src):
 j,b,a=read_glb(src);M=node_matrix(j['nodes'][0]);parts=[]
 for pr in j['meshes'][0]['primitives']:
  P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float);N=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(int);parts.append((P,N,F))
 return parts
BP,BN,BF=read_parts(body)[0];U,ids,iv=np.unique(BP,axis=0,return_index=True,return_inverse=True);BT=iv[BF];lookup={tuple(p):i for i,p in enumerate(U)};bd=[]
for p in outer:
 ds=np.linalg.norm(U-p,axis=1);i=int(ds.argmin());assert ds[i]<1e-7;bd.append(i)
outer=U[bd];xy=(outer-HC)@AX[:2].T;area=np.sum(xy[:,0]*np.roll(xy[:,1],-1)-xy[:,1]*np.roll(xy[:,0],-1))/2
if area<0:outer=outer[::-1];bd=bd[::-1];xy=xy[::-1]
angles=np.mod(np.arctan2(xy[:,1],xy[:,0]),2*np.pi);start=int(np.argmin(angles));outer=np.roll(outer,-start,axis=0);bd=np.roll(bd,-start);xy=np.roll(xy,-start,axis=0);angles=np.roll(angles,-start);assert np.all(np.diff(angles)>1e-6),'Non-injective source polar boundary';n=len(outer);phase=angles[0];nt=256;theta=phase+np.arange(nt)/nt*2*np.pi;dir2=np.column_stack([np.cos(theta),np.sin(theta)])
G=np.cross(BP[BF[:,1]]-BP[BF[:,0]],BP[BF[:,2]]-BP[BF[:,0]]);vn=np.zeros_like(U)
for k in range(3):np.add.at(vn,BT[:,k],G)
gn=vn[bd];tangent=np.roll(outer,-1,axis=0)-np.roll(outer,1,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None];gn-=tangent*(gn*tangent).sum(1)[:,None];gn/=np.linalg.norm(gn,axis=1)[:,None];# Constrain each roll trajectory to its own radial/axis plane. This keeps
# every measured polar angle injective, while solving the start derivative
# with a uniform axial roll, avoiding the observed tiny tangential twists. The source join angle is explicitly audited afterward.
radial=(outer-HC)-((outer-HC)@TA)[:,None]*TA;radial/=np.linalg.norm(radial,axis=1)[:,None];nr=(gn*radial).sum(1);assert nr.min()>.2,('Non-radial source end normal',nr.min());alpha=np.zeros(len(outer));entry=TA[None]+alpha[:,None]*radial;entry/=np.linalg.norm(entry,axis=1)[:,None];bend=radial-alpha[:,None]*TA;bend/=np.linalg.norm(bend,axis=1)[:,None];assert (entry@TA).min()>.2;stored=BN[ids[bd]]
# Cross-section curve starts in the retained cloth's actual tangent direction.
radius=.00035;liprings=[]
for th in np.linspace(0,np.pi,9):liprings.append(outer+radius*np.sin(th)*entry+radius*(np.cos(th)-1)*bend)
lip=np.concatenate(liprings);lipF=[]
for r in range(8):
 for k in range(n):kk=(k+1)%n;aa=r*n+k;bb=r*n+kk;cc=(r+1)*n+kk;dd=(r+1)*n+k;lipF.extend([[aa,bb,cc],[aa,cc,dd]])
# Align the uniform knit/lining phase to the actual returned wool edge.
# The failed203 modulo ordering merely wrapped a tiny negative first shift.
OL=liprings[-1];oxy=(OL-HC)@AX[:2].T;oq=(OL-HC)@TA;oa=np.unwrap(np.arctan2(oxy[:,1],oxy[:,0]));assert np.all(np.diff(oa)>0),'Actual wool-return angular reversal';phase=oa[0];theta=phase+np.arange(nt)/nt*2*np.pi;dir2=np.column_stack([np.cos(theta),np.sin(theta)])
# Exact complete sections of the closed wrist study. All radial rays must see
# exactly one section contour; duplicated shared-vertex hits are deduplicated.
hparts=read_parts(hand);HP=np.concatenate([x[0]for x in hparts]);HF=np.concatenate([x[2]+sum(len(y[0])for y in hparts[:k])for k,x in enumerate(hparts)]);HT=HP[HF];qh=(HT-HC)@TA;section_cache={};section_reports=[]
def radial_skin(q):
 key=round(float(q),9)
 if key in section_cache:return section_cache[key]
 ss=qh-q;fi=np.flatnonzero((ss.min(1)<=0)&(ss.max(1)>=0));segments=[]
 for t,dd in zip(HT[fi],ss[fi]):
  hits=[]
  for k in range(3):
   kk=(k+1)%3
   if abs(dd[k])<1e-12:hits.append(t[k])
   if dd[k]*dd[kk]<0:hits.append(t[k]+(-dd[k]/(dd[kk]-dd[k]))*(t[kk]-t[k]))
  if len(hits)>1:
   uniq=[]
   for p in hits:
    if not any(np.linalg.norm(p-v)<1e-10 for v in uniq):uniq.append(p)
   if len(uniq)==2 and np.linalg.norm(uniq[1]-uniq[0])>1e-10:segments.append((np.array(uniq)-HC)@AX[:2].T)
 seg=np.array(segments);aa=seg[:,0];ee=seg[:,1]-aa;rho=[]
 for d in dir2:
  det=d[0]*(-ee[:,1])-d[1]*(-ee[:,0]);valid=abs(det)>1e-14
  rr=np.full(len(seg),np.nan);tt=rr.copy();rr[valid]=(aa[valid,0]*(-ee[valid,1])-aa[valid,1]*(-ee[valid,0]))/det[valid];tt[valid]=(d[0]*aa[valid,1]-d[1]*aa[valid,0])/det[valid];hits=np.sort(rr[valid&(rr>0)&(tt>=-1e-9)&(tt<=1+1e-9)]);uniq=[]
  for r in hits:
   if not uniq or abs(r-uniq[-1])>1e-7:uniq.append(float(r))
  assert len(uniq)==1,('Ambiguous actual wrist radial section',q,d,uniq);rho.append(uniq[0])
 section_cache[key]=np.array(rho);section_reports.append({'q_m':q,'source_segments':len(seg),'min_radius_m':min(rho),'max_radius_m':max(rho)});return section_cache[key]
def points(q,offset):return HC+(dir2*(radial_skin(q)+offset)[:,None])@AX[:2]+q*TA
# Closed knitted shell with .65mm thickness and .45mm minimum radial clearance.
qbottom=-.012;qshoulder=.0036;thick=.00065;ro=.00110;ri=.00045;knitrings=[]
for q in np.linspace(qbottom,qshoulder,33):knitrings.append(points(q,ro))
for th in np.linspace(0,np.pi,9)[1:]:
 q=qshoulder+thick/2*np.sin(th);off=(ro+ri)/2+thick/2*np.cos(th);knitrings.append(points(q,off))
for q in np.linspace(qshoulder,qbottom,33)[1:]:knitrings.append(points(q,ri))
knit=np.concatenate(knitrings);knitF=[];nr=len(knitrings)
for r in range(nr):
 rr=(r+1)%nr
 for k in range(nt):kk=(k+1)%nt;aa=r*nt+k;bb=r*nt+kk;cc=rr*nt+kk;dd=rr*nt+k;knitF.extend([[aa,bb,cc],[aa,cc,dd]])
# Recessed lining runs from the wool return to a .20mm spaced join outside
# the knit, avoiding a flat disc spanning the wrist opening.
assert np.all(np.diff(oa)>0) and abs(oa[0]-theta[0])<1e-14
def ray_outer(d):
 hits=[]
 for k,(a,b)in enumerate(zip(oxy,np.roll(oxy,-1,axis=0))):
  e=b-a;mat=np.column_stack([d,-e]);det=np.linalg.det(mat)
  if abs(det)<1e-14:continue
  r,t=np.linalg.solve(mat,a)
  if r>0 and -1e-9<=t<1-1e-9:hits.append((r,(1-t)*oq[k]+t*oq[(k+1)%n]))
 assert len(hits)==1;return hits[0]
outerR=np.array([ray_outer(d)for d in dir2]);innerR=radial_skin(-.010)+ro+.00020;assert (outerR[:,0]-innerR).min()>.003
liningrings=[OL];liningangles=[oa];
for u in np.linspace(0,1,9)[1:]:
 rr=(1-u)*outerR[:,0]+u*innerR;qq=(1-u)*outerR[:,1]+u*(-.010)-.002*np.sin(np.pi*u);liningrings.append(HC+(dir2*rr[:,None])@AX[:2]+qq[:,None]*TA);liningangles.append(theta)
lining=np.concatenate(liningrings);liningF=[];offsets=np.cumsum([0]+[len(x)for x in liningrings[:-1]])
def stitch(A,B,aa,bb):
 # Both rings traverse strictly increasing angle with the same winding. Use
 # explicit cyclic segment correspondence, never a nearest-vertex fan.
 m=len(aa);n2=len(bb);i=j2=0;out=[]
 while i<m or j2<n2:
  an=aa[(i+1)%m]+(2*np.pi if i+1>=m else 0)if i<m else 1e100;bn=bb[(j2+1)%n2]+(2*np.pi if j2+1>=n2 else 0)if j2<n2 else 1e100
  ai=A+i%m;bj=B+j2%n2
  if abs(an-bn)<1e-10:out.extend([[ai,A+(i+1)%m,B+(j2+1)%n2],[ai,B+(j2+1)%n2,bj]]);i+=1;j2+=1
  elif an<bn:out.append([ai,A+(i+1)%m,bj]);i+=1
  else:out.append([ai,B+(j2+1)%n2,bj]);j2+=1
 return out
# The lip's first angle can move slightly as it rounds; rotate the inner ring
# phase to that endpoint, otherwise the zipper would have a twisted first cell.
assert abs(oa[0]-theta[0])<.03
# Use one phase anchor shared by both rings, and retain every actual outer node.
# If the differing first angles matter, a future explicit split is required.
assert abs(oa[0]-theta[0])<1e-5,('Lining start phases differ; split correspondence first',oa[0],theta[0])
for r in range(len(liningrings)-1):liningF+=stitch(offsets[r],offsets[r+1],liningangles[r],liningangles[r+1])
# Join wool and lining with an identical endpoint ring, one physical sheet.
WF=np.array(lipF,int);LF=np.array(liningF,int)+len(lip);W=np.concatenate([lip,lining]);Fcoat=np.vstack([WF,LF]);parts=[('Rounded wool lip and recessed lining222',W,Fcoat,[.19,.08,.24,1]),('Closed teal knitted cuff222',knit,np.array(knitF,int),[.055,.17,.17,1])]
binary=bytearray();views=[];accessors=[];meshes=[];nodes=[];materials=[];stats=[]
def acc(A,typ,component=5126,target=34962):
 A=np.ascontiguousarray(A);binary.extend(b'\0'*((-len(binary))%4));vi=len(views);views.append({'buffer':0,'byteOffset':len(binary),'byteLength':A.nbytes,'target':target});binary.extend(A.tobytes());ai=len(accessors);row={'bufferView':vi,'componentType':component,'count':len(A),'type':typ}
 if typ=='VEC3':row.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 accessors.append(row);return ai
for pi,(name,P,F,col)in enumerate(parts):
 G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);area=np.linalg.norm(G,axis=1)/2;assert area.min()>1e-12,(name,area.min());UU,ivv=np.unique(P,axis=0,return_inverse=True);Ng=np.zeros_like(UU)
 for k in range(3):np.add.at(Ng,ivv[F[:,k]],G)
 Ng/=np.linalg.norm(Ng,axis=1)[:,None];N=Ng[ivv]
 if pi==0:N[:n]=stored
 gp=(P[:,[0,2,1]]*[1,1,-1]).astype('<f4');gn=(N[:,[0,2,1]]*[1,1,-1]).astype('<f4');at={'POSITION':acc(gp,'VEC3'),'NORMAL':acc(gn,'VEC3')};ix=acc(F.astype('<u4').ravel(),'SCALAR',5125,34963);meshes.append({'name':name,'primitives':[{'attributes':at,'indices':ix,'material':pi}]});nodes.append({'name':name,'mesh':pi});materials.append({'name':name+' provisional material','pbrMetallicRoughness':{'baseColorFactor':col,'metallicFactor':0,'roughnessFactor':.84},'doubleSided':False});stats.append({'name':name,'vertices':len(P),'triangles':len(F),'min_area_m2':float(area.min())})
J={'asset':{'version':'2.0','generator':'Plum layered cuff222'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(binary)}],'bufferViews':views,'accessors':accessors};js=json.dumps(J,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary;dst=O/'components/layered_cuff222.glb';dst.write_bytes(raw);r={'body_sha256':hashlib.sha256(body.read_bytes()).hexdigest(),'hand_sha256':hashlib.sha256(hand.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'parts':stats,'source_outer_nodes':n,'skin_polar_rays':nt,'skin_sections':section_reports,'wool_roll_radius_m':radius,'roll_tangent':'Uniform axial; source seam normal held but geometric tangent continuity remains an audited gate','knit_thickness_m':thick,'knit_radial_skin_clearance_m':ri,'lining_to_knit_radial_gap_m':.0002,'scope':'Unapproved layered clothing interface. Hand and source body unchanged. No skin cone. Source boundary, complete exact intersections, dense clearance and true underside/opposite actual views remain mandatory; materials are provisional and no final cloth UV detail is claimed.'};(O/'checks/layered_cuff222.json').write_text(json.dumps(r,indent=2));print('CUFF222',r['output_sha256'],stats,flush=True)
