"""Aggregate a complete explicit face-range audit without hiding missing tiles."""
from pathlib import Path
import argparse,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--reports',nargs='+',required=True);p.add_argument('--start',type=int,required=True);p.add_argument('--stop',type=int,required=True);p.add_argument('--out',required=True);a=p.parse_args();rows=[json.loads(Path(x).read_text())for x in a.reports];base=rows[0];ranges=[]
for r in rows:
 for key in ['sources','component_groups','triangles','bounds','selector_provenance','position_triangle_copy_groups','zero_area_faces','manifold_edge_folds_over_105_degrees']:assert r[key]==base[key],('Mixed immutable inputs or predicate configuration',key)
 ranges.append(r['selected_global_face_range'])
ranges=sorted(ranges);cursor=a.start
for lo,hi in ranges:assert lo==cursor and hi>lo,('Gap or overlapping tile range',cursor,lo,hi);cursor=hi
assert cursor==a.stop,('Incomplete requested coverage',cursor,a.stop)
out={k:v for k,v in base.items()if k not in ['selected_global_face_range','proper_crossings','positive_area_coplanar_pairs']}
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 d={}
 for r in rows:
  for v in r[key]:
   pair=tuple(sorted(v['faces']))
   if pair in d:assert d[pair]['kind']==v['kind']
   else:d[pair]=v
 out[key]=[d[k]for k in sorted(d)]
out.update(selected_global_face_range=[a.start,a.stop],complete_contiguous_tile_coverage=True,tile_reports=[{'path':x,'sha256':hashlib.sha256(Path(x).read_bytes()).hexdigest()}for x in a.reports],seconds=sum(r['seconds']for r in rows),scope='Complete selected-face range against all immutable input geometry, using separate externally locked tiles. Unselected-only pairs are intentionally not re-audited and cannot inherit a new clearance claim. Global topology diagnostics are repeated unchanged.');Path(a.out).write_text(json.dumps(out,indent=2));print('AGGREGATE218',a.start,a.stop,len(out['proper_crossings']),len(out['positive_area_coplanar_pairs']),flush=True)
