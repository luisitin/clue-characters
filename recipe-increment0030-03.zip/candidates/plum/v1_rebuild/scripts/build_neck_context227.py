"""Diagnostic-only neck assembly, with exact plane clipping and held skin normals.
Source upper head/hand are intentionally absent above the neck plane in this
study. Its old hand stump remains open and is NOT a finished body extraction.
"""
from pathlib import Path
import json,struct,hashlib,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];r=json.loads((O/'checks/neck_loft213.json').read_text());assert r['folds_over105']==0 and r['minimum_triangle_area_m2']>1e-12;d=np.load(O/'checks/neck_loft213.npz');loftP=d['positions'];loftN=d['normals'];loftF=d['triangles'];d.close()

def clipped(src,C,N,positive):
 j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];NN=a(pr['attributes']['NORMAL']).astype(float);NN=(NN@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];NN/=np.linalg.norm(NN,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);DS=(U-C)@N;sign=1 if positive else -1;L=P.tolist();NL=NN.tolist();newF=[];cache={};geomcache={};count=0
 def split(aa,bb):
  key=tuple(sorted((int(aa),int(bb))))
  if key in cache:return cache[key]
  ia,ib=map(int,iv[[aa,bb]]);gk=tuple(sorted((ia,ib)))
  if gk not in geomcache:
   ga,gb=gk;t=-DS[ga]/(DS[gb]-DS[ga]);geomcache[gk]=U[ga]+t*(U[gb]-U[ga])
  da,db=DS[[ia,ib]];t=-da/(db-da);normal=(1-t)*NN[aa]+t*NN[bb];normal/=np.linalg.norm(normal);ix=len(L);L.append(geomcache[gk].tolist());NL.append(normal.tolist());cache[key]=ix;return ix
 for f in F:
  dd=DS[iv[f]]*sign
  if np.min(dd)>=0:newF.append(f.tolist());continue
  if np.max(dd)<=0:continue
  poly=[]
  for aa,bb in zip(f,np.roll(f,-1)):
   da,db=DS[iv[[aa,bb]]]*sign
   if da>=0:poly.append(int(aa))
   if da*db<0:poly.append(split(int(aa),int(bb)))
  assert len(poly)in(3,4)
  for k in range(1,len(poly)-1):newF.append([poly[0],poly[k],poly[k+1]])
  count+=1
 Q=np.array(L);QN=np.array(NL);T=np.array(newF,np.int64);used=np.unique(T);mapping=np.full(len(Q),-1,np.int64);mapping[used]=np.arange(len(used));return Q[used],QN[used],mapping[T],{'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'split_source_triangles':count,'clipped_triangles':len(T),'exact_plane_edge_cache':True,'side':'positive'if positive else'negative'}

components=[];reports=[]
for i,label in [(0,'Retained source below neck plane, diagnostic open hand stump'),(1,'Held donor above upper neck plane')]:
 e=r['endpoints'][i];P,N,F,rep=clipped(Path(e['source']),np.array(e['plane_origin']),np.array(e['plane_normal']),i==1);
 if i==1:assert rep['split_source_triangles']==e['count'], 'Additional donor cut loop requires explicit classification'
 components.append((label,P,N,F));reports.append(rep)
components.append(('New source-to-donor neck loft126, unapproved',loftP,loftN,loftF))
binary=bytearray();views=[];accessors=[];meshes=[];nodes=[]
def acc(A,typ,component,target):
 A=np.ascontiguousarray(A);binary.extend(b'\0'*((-len(binary))%4));vi=len(views);views.append({'buffer':0,'byteOffset':len(binary),'byteLength':A.nbytes,'target':target});binary.extend(A.tobytes());ai=len(accessors);row={'bufferView':vi,'componentType':component,'count':len(A),'type':typ}
 if typ=='VEC3':row.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 accessors.append(row);return ai
for label,P,N,F in components:
 gp=(P[:,[0,2,1]]*[1,1,-1]).astype('<f4');gn=(N[:,[0,2,1]]*[1,1,-1]).astype('<f4');attrs={'POSITION':acc(gp,'VEC3',5126,34962),'NORMAL':acc(gn,'VEC3',5126,34962)};ix=acc(F.astype('<u4').ravel(),'SCALAR',5125,34963);mi=len(meshes);meshes.append({'name':label,'primitives':[{'attributes':attrs,'indices':ix,'material':0}]});nodes.append({'name':label,'mesh':mi})
J={'asset':{'version':'2.0','generator':'Plum diagnostic neck context127'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':[{'name':'Neutral diagnostic skin and source clay','pbrMetallicRoughness':{'baseColorFactor':[.45,.45,.45,1],'metallicFactor':0,'roughnessFactor':.85},'doubleSided':False}],'buffers':[{'byteLength':len(binary)}],'bufferViews':views,'accessors':accessors};js=json.dumps(J,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary;dst=O/'components/neck_context227.glb';assert all(x['componentType'] in (5125,5126) for x in accessors);dst.write_bytes(raw)
# Every explicit endpoint occurs identically after shared float32 world encoding.
endpoint=[]
for i in [0,1]:
 held=components[i][1].astype('<f4');ring=(loftP[:len(r['endpoints'][0]['boundary_provenance'])]if i==0 else loftP[-r['endpoints'][1]['count']:]).astype('<f4');lookup=set(map(tuple,held));missing=[k for k,p in enumerate(ring)if tuple(p)not in lookup];assert not missing,('Endpoint drift',i,missing[:10]);endpoint.append({'ring':i,'vertices':len(ring),'exact_float32_position_matches':True})
report={'output_sha256':hashlib.sha256(raw).hexdigest(),'inputs':reports,'loft_report_sha256':hashlib.sha256((O/'checks/neck_loft213.json').read_bytes()).hexdigest(),'endpoint_correspondence':endpoint,'triangles':sum(len(c[3])for c in components),'scope':'Unapproved diagnostic neck assembly only. The intentionally clipped source hand stub is open, no final hair/material/body integration is represented. Original assets unchanged.'};(O/'checks/neck_context227.json').write_text(json.dumps(report,indent=2));print('CONTEXT227',report,flush=True)
