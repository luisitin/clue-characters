"""Bounded native wrist continuation below a measured whole donor section.
Keeps every distal source triangle/attribute, interpolates the exact section,
then adds a monotone Hermite forearm segment and hidden cap. No pose change.
The new continuation has its own diagnostic material/UV chart; skin paint later.
"""
from pathlib import Path
import collections,json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/thinking_hand038.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);attrs={k:a(v).astype(float)for k,v in pr['attributes'].items()};P=attrs['POSITION'];WP=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=attrs['NORMAL'];WN=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];WN/=np.linalg.norm(WN,axis=1)[:,None];F=a(pr['indices']).reshape(-1,3).astype(np.int64);source_attrs={k:v.copy()for k,v in attrs.items()}
r130=json.loads((O/'checks/join_sections130.json').read_text());row=next(x for x in r130['sections']if x['label']=='donor_wrist_bone_axis_+0.000');C=np.array(row['origin_world']);TA=np.array(row['normal_world']);HC=np.array(json.loads((O/'checks/cuff_field152.json').read_text())['native_wrist_area_centroid']);assert abs((HC-C)@TA)<1e-9
U,iv=np.unique(WP,axis=0,return_inverse=True);DS=(U-C)@TA;cache={};geomcache={};L={k:v.tolist()for k,v in attrs.items()};newF=[];parents=[];cut=0
# Every geometric edge intersection is calculated once, independent of UV splits.
def local_point(p):
 q=p[[0,2,1]]*[1,1,-1];return (q-M[:3,3])@np.linalg.inv(M[:3,:3]).T

def split(aa,bb):
 key=tuple(sorted((int(aa),int(bb))))
 if key in cache:return cache[key]
 ga,gb=map(int,iv[[aa,bb]]);gk=tuple(sorted((ga,gb)))
 if gk not in geomcache:
  va,vb=gk;t=-DS[va]/(DS[vb]-DS[va]);geomcache[gk]=local_point(U[va]+t*(U[vb]-U[va]))
 t=-DS[ga]/(DS[gb]-DS[ga]);ix=len(L['POSITION'])
 for k in L:
  value=(1-t)*attrs[k][aa]+t*attrs[k][bb]
  if k=='POSITION':value=geomcache[gk]
  if k=='NORMAL':value/=np.linalg.norm(value)
  if k=='TANGENT':
   assert attrs[k][aa,3]==attrs[k][bb,3];value[:3]/=np.linalg.norm(value[:3]);value[3]=attrs[k][aa,3]
  L[k].append(value.tolist())
 cache[key]=ix;return ix
for fi,f in enumerate(F):
 ds=DS[iv[f]]
 if ds.min()>=0:newF.append(f.tolist());parents.append(fi);continue
 if ds.max()<=0:continue
 poly=[]
 for aa,bb in zip(f,np.roll(f,-1)):
  da,db=DS[iv[[aa,bb]]]
  if da>=0:poly.append(int(aa))
  if da*db<0:poly.append(split(int(aa),int(bb)))
 assert len(poly)in(3,4)
 for k in range(1,len(poly)-1):newF.append([poly[0],poly[k],poly[k+1]]);parents.append(fi)
 cut+=1
attrs={k:np.array(v)for k,v in L.items()};F2=np.array(newF,int);world=(attrs['POSITION']@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];norm=(attrs['NORMAL']@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];norm/=np.linalg.norm(norm,axis=1)[:,None];used=np.unique(F2);UU,first,inv=np.unique(world[used],axis=0,return_index=True,return_inverse=True);attr_to_group=np.full(len(world),-1,int);attr_to_group[used]=inv;T=attr_to_group[F2];edges=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
bound=[v[0][1:]for k,v in edges.items()if len(v)==1];assert len(bound)==172,len(bound);succ={aa:bb for aa,bb in bound};assert len(succ)==172;order=[min(succ)]
while succ[order[-1]]!=order[0]:
 nxt=succ[order[-1]];assert nxt not in order;order.append(nxt)
assert len(order)==172
Q=UU[order];gn=collections.defaultdict(list)
for ix in used:gn[int(attr_to_group[ix])].append(norm[ix])
QN=np.array([np.mean(gn[k],axis=0)for k in order]);QN/=np.linalg.norm(QN,axis=1)[:,None];assert abs((Q-C)@TA).max()<1e-9
# Native surface tangent at upper section, normalized to unit axial derivative.
end=TA[None]-QN*(QN@TA)[:,None];axial=end@TA;assert axial.min()>.3;end=end/axial[:,None];height=.018;bottom=HC-height*TA+(Q-HC)*1.025;bottom_tangent=np.tile(TA,(len(Q),1));rings=25;verts=[]
for u in np.linspace(0,1,rings):
 h00=2*u**3-3*u**2+1;h10=u**3-2*u**2+u;h01=-2*u**3+3*u**2;h11=u**3-u**2
 verts.append(h00*bottom+h10*height*bottom_tangent+h01*Q+h11*height*end)
EP=np.concatenate(verts);n=len(Q);assert np.max(abs((EP-HC)@TA-np.repeat(np.linspace(-height,0,rings),n)))<1e-9
EF=[]
for rr in range(rings-1):
 for k in range(n):
  kk=(k+1)%n;aa=rr*n+k;bb=rr*n+kk;cc=(rr+1)*n+kk;dd=(rr+1)*n+k;EF.extend([[aa,bb,cc],[aa,cc,dd]])
# Bottom cap is hidden beneath lining; an explicit annular contraction preserves
# a simple polar-shaped cross-section without a reversed outside fan.
center=HC-height*TA;ci=len(EP);EP=np.vstack([EP,center]);
for k in range(n):EF.append([ci,(k+1)%n,k])
EF=np.array(EF,int);G=np.cross(EP[EF[:,1]]-EP[EF[:,0]],EP[EF[:,2]]-EP[EF[:,0]]);area=np.linalg.norm(G,axis=1)/2;assert area.min()>1e-12;EN=np.zeros_like(EP)
for k in range(3):np.add.at(EN,EF[:,k],G)
EN/=np.linalg.norm(EN,axis=1)[:,None];EN[(rings-1)*n:rings*n]=QN
# Extension chart is separate from the held native-rest UVs, with diagnostic
# material. Do not interpret this as a passed unique skin atlas.
uv=np.zeros((len(EP),2));
for rr in range(rings):uv[rr*n:(rr+1)*n]=np.column_stack([np.arange(n)/n,np.full(n,rr/(rings-1))])
uv[ci]=[.5,0]
localEP=np.array([local_point(p)for p in EP]);localEN=(EN[:,[0,2,1]]*[1,1,-1])@M[:3,:3];localEN/=np.linalg.norm(localEN,axis=1)[:,None]
# Make the geometric seam bit-identical in the native accessor, retaining the
# original clipped skin's per-corner UVs and authored normals.
for k,gid in enumerate(order):localEP[(rings-1)*n+k]=attrs['POSITION'][used[first[gid]]]
binary=bytearray(b)
def acc(A,typ,component=5126,target=34962):
 A=np.ascontiguousarray(A);binary.extend(b'\0'*((-len(binary))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(binary),'byteLength':A.nbytes,'target':target});binary.extend(A.tobytes());ai=len(j['accessors']);r={'bufferView':vi,'componentType':component,'count':len(A),'type':typ}
 if typ=='VEC3':r.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 j['accessors'].append(r);return ai
pr['attributes']={k:acc(v.astype('<f4'),'VEC'+str(v.shape[1]))for k,v in attrs.items()};pr['indices']=acc(F2.astype('<u4').ravel(),'SCALAR',5125,34963);mat=len(j.setdefault('materials',[]));j['materials'].append({'name':'Plum wrist continuation201 diagnostic skin','pbrMetallicRoughness':{'baseColorFactor':[.45,.45,.45,1],'metallicFactor':0,'roughnessFactor':.8},'doubleSided':False});ext={'attributes':{'POSITION':acc(localEP.astype('<f4'),'VEC3'),'NORMAL':acc(localEN.astype('<f4'),'VEC3'),'TEXCOORD_0':acc(uv.astype('<f4'),'VEC2')},'indices':acc(EF.astype('<u4').ravel(),'SCALAR',5125,34963),'material':mat};j['meshes'][0]['primitives'].append(ext);j['nodes'][0]['name']='Plum held thinking hand with bounded wrist continuation201';j['buffers'][0]['byteLength']=len(binary);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary;dst=O/'components/hand_wrist201.glb';dst.write_bytes(raw)
unchanged={k:bool(np.array_equal(attrs[k][:len(v)].astype('<f4'),v.astype('<f4')))for k,v in source_attrs.items()};assert all(unchanged.values());report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'source_attributes_held_exact':unchanged,'cut_source_faces':cut,'held_clipped_hand_triangles':len(F2),'new_extension_triangles':len(EF),'upper_section_nodes':n,'world_origin':C.tolist(),'axis':TA.tolist(),'upper_area_centroid':HC.tolist(),'extension_height_m':height,'bottom_radial_factor':1.025,'axial_monotonicity_error_m':float(np.max(abs((EP[:rings*n]-HC)@TA-np.repeat(np.linspace(-height,0,rings),n)))),'min_new_triangle_area_m2':float(area.min()),'endpoint_tangent_axial_min_before_normalization':float(axial.min()),'top_seam_native_position_bitidentical':True,'scope':'Separate unapproved continuation. Original distal anatomy/pose/rest UVs held. New material/UV chart is diagnostic, not a paint pass. Full seam orientation, actual crossing/copy/fold and cuff containment/all-angle views required.'};(O/'checks/wrist201.json').write_text(json.dumps(report,indent=2));np.savez_compressed(O/'checks/wrist201_binding.npz',retained_source_faces=np.array(parents),upper_boundary_world=Q,extension_world=EP,extension_triangles=EF);print('WRIST201',report,flush=True)
