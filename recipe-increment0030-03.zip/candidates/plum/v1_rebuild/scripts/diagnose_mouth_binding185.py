"""Bounded official CC0 mouth-width study on the held inspected head.
Rebuilt native Catmull-Clark correspondence supplies the deformation; no guessed
export vertex order is used. Eye apertures and all original UV/index data remain
held. Provisional colours are context only, not final painting.
"""
import bpy,sys,pathlib,json,hashlib,struct,collections,math,numpy as np
O=pathlib.Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(O/'scripts'));from glb_io import read_glb
D=R/'shared_sources/makehuman';target=D/'raw/targets/mouth/mouth-scale-horiz-decr.target';weight=.55;meta=json.loads((O/'checks/head_trial025.json').read_text());z=np.load(O/'checks/head_trial025_native.npz');used=z['native_source_vertex_ids'];control=z['world_positions'];offsets=z['polygon_offsets'];indices=z['polygon_indices'];corner_uv_ids=z['corner_uv_ids'];z.close();faces=[indices[a:b].tolist()for a,b in zip(offsets[:-1],offsets[1:])];native_delta=np.zeros((19158,3))
for line in target.read_text().splitlines():
 s=line.split()
 if not s or s[0].startswith('#'):continue
 native_delta[int(s[0])]+=weight*np.array(list(map(float,s[1:4])))
scales=np.array(meta['native_axis_scales_xyz']);yaw=math.radians(meta['world_yaw_deg']);M=np.array([[math.cos(yaw),-math.sin(yaw),0],[math.sin(yaw),math.cos(yaw),0],[0,0,1.]]);delta=((native_delta[used]*scales)[:,[0,2,1]]*[1,-1,1])@M.T
sys.path.insert(0,str(D/'scripts'));from load_donor import load_obj
full_native_UV=load_obj()[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
def evaluated(P,name):
 me=bpy.data.meshes.new(name);me.from_pydata(P.tolist(),[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True)
 uv=me.uv_layers.new(name='native_rest_UV')
 for li,ui in enumerate(corner_uv_ids):uv.data[li].uv=full_native_UV[ui]
 for poly in me.polygons:poly.use_smooth=True
 sub=ob.modifiers.new('Exact native Catmull Clark2','SUBSURF');sub.levels=2;sub.render_levels=2;bpy.ops.object.modifier_apply(modifier=sub.name);bpy.context.view_layer.update();Q=np.array([tuple(v.co)for v in ob.data.vertices],float);ob.select_set(False);return Q
base_eval=evaluated(control,'Native held control rebuild');new_eval=evaluated(control+delta,'Official mouth width candidate');assert base_eval.shape==new_eval.shape;deval=new_eval-base_eval
bj,bb,ba=read_glb(O/'components/head_trial025.glb');bp=bj['meshes'][0]['primitives'][0];BP=ba(bp['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];lookup=collections.defaultdict(list)
for i,p in enumerate(base_eval):lookup[tuple(p)].append(i)

from mathutils.kdtree import KDTree
kdtree=KDTree(len(base_eval))
for i,p in enumerate(base_eval):kdtree.insert(tuple(p),i)
kdtree.balance();distances=[];nearest=[];exact=0;ambiguous=[]
for i,p in enumerate(BP):
 q,idx,distance=kdtree.find(tuple(p));distances.append(distance);nearest.append(idx);exact+=int(tuple(p)in lookup)
 near=kdtree.find_range(tuple(p),1e-7)
 if len(near)>1 and np.max(np.linalg.norm(deval[[v[1]for v in near]]-deval[idx],axis=1))>1e-10:ambiguous.append({'export_vertex':i,'candidate_indices':[int(v[1])for v in near],'candidate_distances_m':[float(v[2])for v in near]})
r={'base025_sha256':hashlib.sha256((O/'components/head_trial025.glb').read_bytes()).hexdigest(),'native_control_metadata_sha256':hashlib.sha256((O/'checks/head_trial025_native.npz').read_bytes()).hexdigest(),'base_eval_vertices':len(base_eval),'export_vertices':len(BP),'exact_position_matches':exact,'maximum_nearest_distance_m':max(distances),'p99_nearest_distance_m':float(np.quantile(distances,.99)),'count_above_100nm':sum(x>1e-7 for x in distances),'ambiguous_differently_deforming_candidates_within_100nm':ambiguous,'worst_export_indices':np.argsort(distances)[-20:].tolist(),'source_nodes':bj['nodes'],'scope':'Read-only same-native-topology correspondence diagnostic. No morph GLB emitted. A small distance alone cannot override ambiguous differently deforming coincident layers.'};(O/'checks/mouth_binding185.json').write_text(json.dumps(r,indent=2));np.savez_compressed(O/'checks/mouth_binding185.npz',base_eval_positions=base_eval,new_eval_positions=new_eval,base_export_positions=BP,nearest_eval_indices=np.array(nearest),nearest_distances=np.array(distances));print('BIND185',r,flush=True)
