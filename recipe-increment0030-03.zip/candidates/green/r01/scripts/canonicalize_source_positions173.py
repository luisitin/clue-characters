"""Make the source's float32 consumer positions explicit at generated patch seams."""
import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_context170.glb';j,b,A=read_glb(src);old=copy.deepcopy(j);mapping={};rows=[]
for mi,mesh in enumerate(j['meshes']):
 for pi,pr in enumerate(mesh['primitives']):
  index=pr['attributes']['POSITION'];a=old['accessors'][index]
  if not a.get('normalized'):continue
  if index not in mapping:
   before=A(index);after=before.astype('float32');new,b=append_accessor(j,b,after,'VEC3',34962);mapping[index]=new;delta=np.linalg.norm(after.astype(float)-before,axis=1);rows.append({'source_accessor':index,'new_accessor':new,'vertices':len(before),'original_component_type':a['componentType'],'maximum_local_displacement_m':float(delta.max()),'float32_decoded_positions_exact':True})
  pr['attributes']['POSITION']=mapping[index]
assert len(rows)==1
out=R/'Green_full_context173_fp32.glb';write_glb(out,j,b);jj,bb,B=read_glb(out)
for sm,dm in zip(old['meshes'],jj['meshes']):
 for sp,dp in zip(sm['primitives'],dm['primitives']):
  assert sp['indices']==dp['indices']and sp['material']==dp['material'];assert np.array_equal(A(sp['indices']),B(dp['indices']))
  for key in sp['attributes']:
   if key=='POSITION':assert np.array_equal(A(sp['attributes'][key]).astype('float32'),B(dp['attributes'][key]).astype('float32'))
   else:assert sp['attributes'][key]==dp['attributes'][key]and np.array_equal(A(sp['attributes'][key]),B(dp['attributes'][key]))
for key in ['nodes','scenes','materials','images','textures','samplers']:assert old.get(key)==jj.get(key)
worldBound=rows[0]['maximum_local_displacement_m']*max(old['nodes'][0]['scale']);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changed_accessors':rows,'maximum_source_world_displacement_m':worldBound,'all_float32_decoded_positions_exact':True,'all_non_position_attributes_topology_materials_maps_and_transforms_exact':True,'reason':'Generated source-boundary positions were copied from float32-decoded signed-normalized INT16 values. The old geometric audit used that same float32 decode, whereas the new generic audit retained float64 normalized fractions, exposing submicron near-edge overlaps. This makes the consumer-precision source positions explicit; it does not change source shape at float32 precision.','status':'Representation-only seam repair; rerun exact actual-coordinate crossings/joins and appearance before acceptance.'};(R/'audit/source_positions173.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
