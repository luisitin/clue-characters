"""First bounded whole hand/handle/case placement study against the reference-facing body camera."""
import pathlib,sys,json,hashlib,copy,numpy as np
from scipy.spatial.transform import Rotation
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
src=R/'Green_grip_case127.glb';j,b,A=read_glb(src);old=copy.deepcopy(j);CG=np.array([[1.,0,0],[0,0,-1],[0,1,0]])
def matrix(node):
 assert not node.get('children')
 if'matrix'in node:return np.array(node['matrix']).reshape((4,4),order='F')
 M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);return M
D=load_donor();V=D['positions'];faces=D['faces'];groups=D['face_group'];J={name:V[np.unique(np.concatenate([faces[i]for i in np.flatnonzero(groups==name)]))].mean(0)for name in ['joint-l-hand','joint-l-elbow']};binding=np.load(R/'audit/grip88_binding.npz');B=binding['native_basis'];OB=binding['world_basis'];scale=binding['scale'];anchor=binding['anchor'];HM=matrix(j['nodes'][0]);wrist=CG@(HM[:3,:3]@(CG.T@anchor)+HM[:3,3]);native=(B@(J['joint-l-elbow']-J['joint-l-hand'])*scale)@OB.T;prox=CG@HM[:3,:3]@CG.T@native;prox/=np.linalg.norm(prox)
# Recover the complete actual exported root, using the saved exact clip and float32 consumer positions.
bj,bb,BA=read_glb(R/'Green_grip_body138.glb');node=bj['nodes'][0];segments=np.load(R/'audit/grip_body138_binding.npz')['root_segments_local'].astype('float32');points,inv=np.unique(segments.reshape(-1,3),axis=0,return_inverse=True);edges=inv.reshape(-1,2);degree=np.bincount(edges.ravel(),minlength=len(points));assert np.all(degree==2);adj={i:[]for i in range(len(points))}
for a,c in edges:adj[int(a)].append(int(c));adj[int(c)].append(int(a))
seq=[0];prev=None;cur=0
while True:
 nxt=next(k for k in adj[cur]if k!=prev)
 if nxt==0:break
 seq.append(nxt);prev,cur=cur,nxt
assert len(seq)==len(points);ring=(points[seq]*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];q=ring[:,:2];cr=q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1);area=cr.sum()/2;center=np.r_[((q+np.roll(q,-1,axis=0))*cr[:,None]).sum(0)/(6*area),ring[:,2].mean()]
meta=json.loads((R/'renders/sleeve69/body_angle_-11_paint.json').read_text());C=np.array(meta['camera_world_matrix']);K=meta['resolution'][0]/meta['ortho_scale'];right=C[:3,0];up=C[:3,1];ray=-C[:3,2];ray/=np.linalg.norm(ray)
def project(p):
 q=p-C[:3,3];return np.array([512+q@right*K,512-q@up*K])
registration=json.loads((R/'audit/hand_reference14.json').read_text());reference=np.array([341.,441.]);target=reference@np.array(registration['reference_body_similarity_rotation'])*registration['reference_body_similarity_scale']+np.array(registration['reference_body_similarity_translation']);before=project(wrist);inplane=right*(target[0]-before[0])/K+up*(before[1]-target[1])/K;seed=wrist+inplane;depth,length=np.linalg.lstsq(np.column_stack([ray,prox]),center-seed,rcond=None)[0];assert -.25<depth<.25 and .07<length<.30,(depth,length);delta=inplane+ray*depth;newWrist=wrist+delta;assert np.linalg.norm(project(newWrist)-target)<1e-4;shift=CG.T@delta
for node in j['nodes']:
 M=matrix(node);M[:3,3]+=shift
 for key in ['translation','rotation','scale']:node.pop(key,None)
 node['matrix']=M.T.ravel().tolist()
for key in ['meshes','accessors','materials','images','textures','bufferViews']:assert old.get(key)==j.get(key)
out=R/'Green_grip_case143_pose.glb';write_glb(out,j,b);np.savez_compressed(R/'audit/grip_fit143_binding.npz',source_sleeve_root_world=ring,source_sleeve_root_local=points[seq],native_forearm_proximal_world=prox,wrist_before_world=wrist,wrist_after_world=newWrist,translation_world=delta);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_component_local_geometry_normals_UVs_tangents_maps_materials_exact':True,'one_common_rigid_translation_world':delta.tolist(),'reference_wrist_proxy_pixel':reference.tolist(),'reference_proxy_uncertainty_px':5,'registered_body_rms_px':registration['reference_body_rms_px'],'target_viewport_pixel':target.tolist(),'projected_wrist_before_after':[before.tolist(),project(newWrist).tolist()],'source_sleeve_root_center_world':center.tolist(),'root_vertices':len(ring),'wrist_world':newWrist.tolist(),'native_forearm_proximal_world':prox.tolist(),'root_to_wrist_length_m':float(np.linalg.norm(center-newWrist)),'axis_consistency_angle_degrees':float(np.degrees(np.arccos(np.clip((center-newWrist)@prox/np.linalg.norm(center-newWrist),-1,1)))),'axis_fit_residual_m':float(np.linalg.norm(center-newWrist-prox*length)),'status':'Unadopted first placement study. The art wrist proxy is uncertain and not an anatomical recovered joint. No case rotation, hand shape or local contact fit changed. Actual whole-body reference comparison, sleeve/skin continuation and body contacts remain pending.'};(R/'audit/grip_fit143.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
