"""Resolve the one nonmanifold source boundary in domain129 and register exact retained joins."""
import pathlib,json,hashlib,numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_sleeve75_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);N=A(pr['attributes']['NORMAL']);F=A(pr['indices']).reshape(-1,3);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);W=(P*scale+translation)[:,[0,2,1]]*[1,-1,1];NW=(N/scale)[:,[0,2,1]]*[1,-1,1];NW/=np.linalg.norm(NW,axis=1)[:,None];Q,g=np.unique(P,axis=0,return_inverse=True);QW=(Q*scale+translation)[:,[0,2,1]]*[1,-1,1];G=g[F];z=np.load(R/'audit/grip_domain130.npz');selected=np.zeros(len(F),bool);selected[z['selected_faces']]=True;original=selected.copy();bodyBounds=z['body_loop_world'];allowedLow=bodyBounds.min(0)-.015;allowedHigh=bodyBounds.max(0)+.015;edges={}
for fi,f in enumerate(G):
 for a,bb in zip(f,np.roll(f,-1)):edges.setdefault(tuple(sorted((int(a),int(bb)))),[]).append(fi)
for iteration in range(16):
 boundary={e:fs for e,fs in edges.items()if selected[fs].any()and(~selected[fs]).any()};bad={e:fs for e,fs in boundary.items()if np.sum(~selected[fs])!=1}
 for edge,faces in boundary.items():
  if QW[list(edge),2].mean()>=.15:continue
  for fi in faces:
   if selected[fi]:continue
   tri=W[F[fi]];normal=np.cross(tri[1]-tri[0],tri[2]-tri[0]);normal/=np.linalg.norm(normal)
   if normal[0]<=.04:bad[edge]=faces
 if not bad:break
 for fs in bad.values():
  for fi in fs:
   if selected[fi]:continue
   points=W[F[fi]];assert np.all(points>=allowedLow)&np.all(points<=allowedHigh), ('Chart expansion exceeds15mm bounded margin',fi,points.tolist())
   selected[fi]=True
else:raise AssertionError('Unresolved nonmanifold source boundary')
E=np.array(list(boundary));vs,inv=np.unique(E,return_inverse=True);e=inv.reshape(-1,2);rr=np.r_[e[:,0],e[:,1]];cc=np.r_[e[:,1],e[:,0]];nc,labels=connected_components(coo_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(vs),len(vs))),directed=False);deg=np.bincount(e.ravel(),minlength=len(vs));assert np.all(deg==2),dict(zip(*np.unique(deg,return_counts=True)));assert nc==2;loops=[];bindings={'selected_faces':np.flatnonzero(selected),'additional_source_faces':np.flatnonzero(selected&~original)}
for part in range(nc):
 members=set(vs[labels==part].tolist());adj={v:[]for v in members}
 for a,bb in E:
  if int(a)in members:adj[int(a)].append(int(bb));adj[int(bb)].append(int(a))
 seq=[min(members)];prev=None;cur=seq[0]
 while True:
  nxt=next(v for v in adj[cur]if v!=prev)
  if nxt==seq[0]:break
  seq.append(nxt);prev,cur=cur,nxt
 assert len(seq)==len(members);seq=np.array(seq);qw=QW[seq];name='body'if qw[:,2].min()<.15 else'arm_root';direct=[];supports=[];norms=[];localIds=[];spans=[]
 for va,vb in zip(seq,np.roll(seq,-1)):
  fs=boundary[tuple(sorted((int(va),int(vb))))];fi=next(f for f in fs if not selected[f]);supports.append(fi);gg=G[fi];ia=int(np.where(gg==va)[0][0]);ib=int(np.where(gg==vb)[0][0]);direct.append((ib-ia)%3==1);norms.append(NW[F[fi,ia]]);localIds.append(F[fi,ia]);corners=np.flatnonzero(G==va);allN=NW[F.ravel()[corners]];spans.append(float(np.degrees(np.arccos(np.clip(allN@allN[0],-1,1))).max()))
 if sum(direct)>len(direct)/2:seq=seq[::-1];qw=qw[::-1]
 # Recompute supports and outward kept-corner normals after direction selection.
 support=[];localIds=[];vertexN=[];directions=[]
 for va,vb in zip(seq,np.roll(seq,-1)):
  fs=boundary[tuple(sorted((int(va),int(vb))))];fi=next(f for f in fs if not selected[f]);support.append(fi);gg=G[fi];ia=int(np.where(gg==va)[0][0]);ib=int(np.where(gg==vb)[0][0]);directions.append((ib-ia)%3==1);localIds.append(F[fi,ia]);vertexN.append(NW[F[fi,ia]])
 projection=qw[:,1:3];area=float(np.sum(projection[:,0]*np.roll(projection[:,1],-1)-projection[:,1]*np.roll(projection[:,0],-1))/2);bindings[name+'_loop_world']=qw;bindings[name+'_loop_source_local']=P[localIds];bindings[name+'_loop_source_normal_local']=N[localIds];bindings[name+'_loop_source_vertex_ids']=np.array(localIds);bindings[name+'_support_faces']=np.array(support);bindings[name+'_loop_normal_world']=np.array(vertexN);loops.append({'name':name,'vertices':len(seq),'bounds_world':[qw.min(0).tolist(),qw.max(0).tolist()],'projection_YZ_signed_area':area,'retained_edges_same_direction_as_new_loop':int(sum(directions)),'maximum_original_normal_span_at_boundary_degrees':max(spans)})
np.savez_compressed(R/'audit/grip_domain137.npz',**bindings);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'selected_faces':int(selected.sum()),'source_faces_added_for_healthy_chart_and_join':np.flatnonzero(selected&~original).tolist(),'loops':loops,'status':'Domain expansion includes the identified horizontal needle and any newly exposed nonmanifold support, belowZ.15 only. Exact domain preparation only. No geometry removed. The arm root still needs conforming plane clipping; body projection, tangent wedges/source volume and local all-surface checks remain pending.'};(R/'audit/grip_domain137.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
