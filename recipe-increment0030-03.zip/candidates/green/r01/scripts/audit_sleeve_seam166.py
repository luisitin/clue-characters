import pathlib,json,hashlib,collections,numpy as np
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_sleeve159_body.glb';j,b,A=read_glb(src);parts=j['meshes'][0]['primitives'];P=[];N=[];F=[];owners=[];off=0
for pi,pr in enumerate(parts):
 p=A(pr['attributes']['POSITION']).astype(float);n=A(pr['attributes']['NORMAL']).astype(float);f=A(pr['indices']).astype(np.int64).reshape(-1,3);P.append(p);N.append(n);F.append(f+off);owners.extend([pi]*len(f));off+=len(p)
P=np.vstack(P);N=np.vstack(N);F=np.vstack(F);owners=np.array(owners);U,g=np.unique(P,axis=0,return_inverse=True);physical=g[F]
with np.load(R/'audit/grip_sleeve158_binding.npz')as z:root=z['root_local'].copy()
lookup={tuple(p):i for i,p in enumerate(U)};rootids=np.array([lookup[tuple(p)]for p in root]);wanted={tuple(sorted((int(a),int(c))))for a,c in zip(rootids,np.roll(rootids,-1))};inc=collections.defaultdict(list)
for fi,f in enumerate(physical):
 for a,c in zip(f,np.roll(f,-1)):
  key=tuple(sorted((int(a),int(c))))
  if key in wanted:inc[key].append((fi,int(a),int(c)))
assert len(inc)==142;assert all(len(v)==2 and v[0][1:]==v[1][1:][::-1]for v in inc.values())
tri=P[F];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);GN/=np.linalg.norm(GN,axis=1)[:,None];ang=[];ndiff=[]
for edge,rows in inc.items():
 a,c=[x[0]for x in rows];assert set(owners[[a,c]])=={6,8};ang.append(float(np.degrees(np.arccos(np.clip(GN[a]@GN[c],-1,1)))))
 for vi in edge:
  na=N[F[a][physical[a]==vi]][0];nc=N[F[c][physical[c]==vi]][0];ndiff.append(float(np.linalg.norm(na-nc)))
knit=P[F[owners==9]];volume=float(np.einsum('ij,ij->i',knit[:,0],np.cross(knit[:,1],knit[:,2])).sum()/6)
newN=N[np.unique(F[owners>=8])];report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'root_edges':142,'root_two_face_parity_and_opposite_winding':True,'maximum_source_join_dihedral_degrees':max(ang),'maximum_exact_stored_normal_difference':max(ndiff),'knit_signed_local_volume':volume,'new_referenced_zero_normals':int((np.linalg.norm(newN,axis=1)<1e-8).sum()),'new_referenced_normal_unit_max_error':float(abs(np.linalg.norm(newN,axis=1)-1).max()),'status':'Exact source root seam and winding preflight. Contact/appearance/atlas still separate.'}
assert volume>0,report
(R/'audit/sleeve_seam166.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
