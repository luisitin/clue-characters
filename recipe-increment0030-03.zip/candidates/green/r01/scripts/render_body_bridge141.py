import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/render_exact.py').read_text();extra="""
regions['grip_source_front123']=((.315,.125,.11),.33,-11,.04)
regions['grip_source_back123']=((.315,.125,.11),.33,169,.04)
regions['body_bridge_side141']=((.305,.105,.075),.23,90,.04)
""";assert code.count('target,scale,angle,elev=regions[tag];')==1;code=code.replace('target,scale,angle,elev=regions[tag];',extra+'target,scale,angle,elev=regions[tag];');exec(compile(code,'render_body_bridge141','exec'))
