#!/usr/bin/env bash
set -euo pipefail
R=clue-recovery-20261004/candidates/green/r01
bash "$R/scripts/run_heavy_stage.sh" eye_merge169 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/prepare_eye_merge169.py" > "$R/logs/eye_merge169.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" eye_component169 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/compact_glb168.py" Green_eyes169_raw_component Green_eyes169_component > "$R/logs/eye_component169.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" full_merge170 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/merge_exact_components.py" Green_full_context170_raw Green_eye_cut169_body Green_eyes169_component > "$R/logs/full_merge170.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" compact170 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/compact_glb168.py" Green_full_context170_raw Green_full_context170 > "$R/logs/compact170.log" 2>&1
