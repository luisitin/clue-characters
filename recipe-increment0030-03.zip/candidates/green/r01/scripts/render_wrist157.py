import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/render_exact.py').read_text()
extra="""
regions['grip_wrist157_front']=((.374,.14,.026),.15,-11,.02)
regions['grip_wrist157_opposite']=((.374,.14,.026),.15,169,.02)
regions['grip_pose157_front']=((.379,.125,-.04),.28,-11,.02)
"""
assert code.count('target,scale,angle,elev=regions[tag];')==1
code=code.replace('target,scale,angle,elev=regions[tag];',extra+'target,scale,angle,elev=regions[tag];')
exec(compile(code,'render_wrist157','exec'))
