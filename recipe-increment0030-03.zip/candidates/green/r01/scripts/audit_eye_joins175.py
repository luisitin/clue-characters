"""Actual assembled eye joins and inherited bounded-cap closure classification."""
import pathlib,json,hashlib,collections,numpy as np
from scipy.spatial.transform import Rotation
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_context173_fp32.glb';j,b,A=read_glb(src);P=[];N=[];F=[];owner=[];off=0
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:
  M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  p=A(pr['attributes']['POSITION']).astype(float);nn=A(pr['attributes']['NORMAL']).astype(float);ff=A(pr['indices']).astype(np.int64).reshape(-1,3);P.append((p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]);wn=(nn@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];wn/=np.linalg.norm(wn,axis=1)[:,None];N.append(wn);F.append(ff+off);owner.extend([[ni,pi]]*len(ff));off+=len(p)
P=np.vstack(P);N=np.vstack(N);F=np.vstack(F);owner=np.array(owner);target=len(j['nodes'])-1;eye=np.flatnonzero(owner[:,0]==target);bounds=P[F[eye]].reshape(-1,3);lo=bounds.min(0);hi=bounds.max(0);tri=P[F];potential=np.all(tri.max(1)>=lo-1e-8,axis=1)&np.all(tri.min(1)<=hi+1e-8,axis=1);ids=np.flatnonzero(potential);used=np.unique(F[ids]);_,g=np.unique(P[used],axis=0,return_inverse=True);mapping=np.full(len(P),-1,int);mapping[used]=g;G=mapping[F[ids]];edges=collections.defaultdict(list)
for local,f in enumerate(G):
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append((int(ids[local]),int(a),int(c)))
GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);GN/=np.maximum(np.linalg.norm(GN,axis=1)[:,None],1e-30);reports=[]
for ei in [0,1]:
 pi=ei*3;skin=(owner[:,0]==target)&(owner[:,1]==pi);ownEdges=collections.defaultdict(list)
 for local,fi in enumerate(ids):
  if not skin[fi]:continue
  for a,c in zip(G[local],np.roll(G[local],-1)):ownEdges[tuple(sorted((int(a),int(c))))].append(int(fi))
 row={'eye':ei,'outer':[],'inner':[],'unmatched':[],'winding_conflicts':[],'normal_differences':[]}
 for key,fs in ownEdges.items():
  if len(fs)!=1:continue
  allrows=edges[key];mine=next(x for x in allrows if skin[x[0]]);others=[x for x in allrows if not skin[x[0]]]
  if len(others)!=1:row['unmatched'].append(key);continue
  other=others[0]
  if mine[1:]!=other[1:][::-1]:row['winding_conflicts'].append(key)
  typ='inner'if tuple(owner[other[0]])==(target,pi+1)else'outer';row[typ].append(float(np.degrees(np.arccos(np.clip(GN[mine[0]]@GN[other[0]],-1,1)))))
  for vi in key:
   ia=F[mine[0]][mapping[F[mine[0]]]==vi][0];ib=F[other[0]][mapping[F[other[0]]]==vi][0];row['normal_differences'].append(float(np.linalg.norm(N[ia]-N[ib])))
 assert not row['unmatched']and not row['winding_conflicts'];assert len(row['inner'])==192
 for typ in ['outer','inner']:row[typ]={'edge_count':len(row[typ]),'max_dihedral_degrees':max(row[typ])}
 row['maximum_normal_vector_difference']=max(row.pop('normal_differences'));reports.append(row)
v4=json.loads((R/'audit/eyes174_v4.json').read_text());front=json.loads((R/'audit/eyes50.json').read_text())['front_triangles'];capids=np.flatnonzero((owner[:,0]==target)&(owner[:,1]==2));start=capids.min();classify=lambda i:'front'if i<front else'back'if i<front*2 else'side';classes=collections.Counter()
for fs in v4['new_folds']:
 assert all(tuple(owner[x])==(target,2)for x in fs);pair=tuple(sorted(classify(x-start)for x in fs));assert pair in [('back','side'),('front','side')];classes[str(pair)]+=1
report={'candidate_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eyes':reports,'new_crossings':v4['new_crossings'],'bounded_cap_sharp_closure_pairs':dict(classes),'no_internal_eye_surface_folds':True,'scope':'Exact actual source/skin and skin/wall joins across assembled nodes, including normal continuity. The121 sharp cap edges remain solely its held hidden closure; final closure visibility/material/expression remain separate.'};(R/'audit/eye_joins175.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
