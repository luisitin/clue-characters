"""Diagnostic only: unchanged119 geometry/maps with normal-map shader strength zero."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/render_exact.py').read_text();extra="""
regions['case_frontcorner121']=((.326,-.131,-.304),.085,235,1.2)
""";code=code.replace('target,scale,angle,elev=regions[tag];',extra+'target,scale,angle,elev=regions[tag];');code=code.replace('scene=bpy.context.scene',"for mat in bpy.data.materials:\n if mat.use_nodes:\n  for n in mat.node_tree.nodes:\n   if n.type=='NORMAL_MAP':n.inputs['Strength'].default_value=0.\nscene=bpy.context.scene");code=code.replace("'source_textures_unchanged':true", "'source_textures_unchanged':true") if False else code
code=code.replace("'shader_mode':mode,", "'shader_mode':mode,'diagnostic_shader_override':'Normal-map Strength set to0 on every material; geometry and encoded maps retained',")
exec(compile(code,'render_case_no_normal124','exec'))
