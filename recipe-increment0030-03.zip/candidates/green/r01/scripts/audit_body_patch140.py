"""Exact exported body-patch joins and source-volume comparison outside the removed bridge band."""
import pathlib,sys,json,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
source=R/'Green_sleeve75_body.glb';candidate=R/'Green_grip_body138.glb';sj,sb,S=read_glb(source);cj,cb,C=read_glb(candidate);node=sj['nodes'][0];assert node==cj['nodes'][0];scale=np.array(node['scale']);offset=np.array(node['translation'])
def world(p):return(p.astype('float32').astype(float)*scale+offset)[:,[0,2,1]]*[1,-1,1]
sp=sj['meshes'][0]['primitives'][0];P=S(sp['attributes']['POSITION']).astype('float32');N=S(sp['attributes']['NORMAL']).astype('float32');F=S(sp['indices']).reshape(-1,3);W=world(P);dom=np.load(R/'audit/grip_domain137.npz');bid=dom['body_loop_source_vertex_ids'];q=cj['meshes'][0]['primitives'][7];QP=C(q['attributes']['POSITION']);QN=C(q['attributes']['NORMAL']);QW=world(QP);QF=C(q['indices']).reshape(-1,3);assert np.array_equal(QP[:len(bid)],P[bid]);assert np.array_equal(QN[:len(bid)],N[bid])
# All actual primitive boundaries are welded only by exact decoded position.
positions=[];faces=[];own=[];off=0
for pi,pr in enumerate(cj['meshes'][0]['primitives']):
 p=C(pr['attributes']['POSITION']).astype('float32');f=C(pr['indices']).reshape(-1,3);positions.append(p);faces.append(f+off);own.extend([pi]*len(f));off+=len(p)
allP=np.vstack(positions);allW=world(allP);allF=np.vstack(faces);own=np.array(own);U,g=np.unique(allP,axis=0,return_inverse=True);GF=g[allF];edgeMap={}
for fi,f in enumerate(GF):
 for a,b in zip(f,np.roll(f,-1)):edgeMap.setdefault(tuple(sorted((int(a),int(b)))),[]).append((fi,int(a),int(b)))
patchEdges={}
for fi in np.flatnonzero(own==7):
 for a,b in zip(GF[fi],np.roll(GF[fi],-1)):patchEdges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
outer=[e for e,fs in patchEdges.items()if len(fs)==1];join=[];angles=[]
for e in outer:
 rows=edgeMap[e];ok=len(rows)==2 and rows[0][1]==rows[1][2]and rows[0][2]==rows[1][1];join.append(ok)
 if len(rows)==2:
  ts=allW[allF[[r[0]for r in rows]]];nn=np.cross(ts[:,1]-ts[:,0],ts[:,2]-ts[:,0]);nn/=np.linalg.norm(nn,axis=1)[:,None];angles.append(float(np.degrees(np.arccos(np.clip(nn[0]@nn[1],-1,1)))))
# Cached world arrays and source tree; no repeated archive decompression.
arm=np.zeros(len(F),bool);arm[np.load(R/'audit/grip_ownership125.npz')['selected_faces']]=True;tri=W[F];lo=QW.min(0)-.015;hi=QW.max(0)+.015;keep=(~arm)&np.all(tri.max(1)>=lo,axis=1)&np.all(tri.min(1)<=hi,axis=1);sourceIds=np.flatnonzero(keep);tree=BVHTree.FromPolygons(W.tolist(),F[sourceIds].tolist(),all_triangles=True);samples=np.vstack([QW,QW[QF].mean(1)]);cuts=np.load(R/'audit/grip_ownership125.npz')['cut_edges_world'][:,:,1:3];dist=np.full(len(samples),np.inf)
for a,b in cuts:
 e=b-a;den=e@e
 if den<1e-20:continue
 t=np.clip(((samples[:,1:3]-a)@e)/den,0,1);dist=np.minimum(dist,np.linalg.norm(samples[:,1:3]-a-t[:,None]*e,axis=1))
far=dist>.012;delta=[];farDelta=[];miss=0;reversedHits=0;startX=float(hi[0]+.1)
for k,p in enumerate(samples):
 origin=Vector((startX,float(p[1]),float(p[2])));found=None
 for _ in range(8):
  hit,normal,fi,length=tree.ray_cast(origin,Vector((-1,0,0)),.5)
  if hit is None:break
  if normal.x>.05:found=hit;break
  reversedHits+=1;origin=hit+Vector((-1e-7,0,0))
 if found is None:miss+=1;continue
 d=float(p[0]-found.x);delta.append(d)
 if far[k]:farDelta.append(d)
rep={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'exact_decoded_boundary_POSITION_NORMAL_values':True,'body_patch_boundary_edges':len(outer),'proper_two_face_opposite_direction_joins':int(sum(join)),'boundary_geometric_dihedral_degrees_p50_p95_max':np.percentile(angles,[50,95,100]).tolist(),'source_ray_samples':len(samples),'source_ray_misses':miss,'reverse_facing_hits_skipped':reversedHits,'source_depth_error_abs_m_p50_p95_max':np.percentile(abs(np.array(delta)),[50,95,100]).tolist(),'outside_12mm_bridge_band_samples':len(farDelta),'outside_band_source_depth_error_abs_m_p50_p95_max':np.percentile(abs(np.array(farDelta)),[50,95,100]).tolist(),'scope':'Actual exported patch joins and source X-height comparison using the retained body ownership, with front-facing ray selection. Removed rung/needle regions have intentionally changed shape. This is not an appearance or complete-character pass.'};(R/'audit/body_patch140.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
