"""All new sleeve layers against all potentially intersecting exact assembled targets."""
import pathlib,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
from glb_source import read_glb
from intersection_kernel_v4_selected import audit
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_context161.glb';j,b,A=read_glb(src);P=[];F=[];own=[];offset=0
for ni,node in enumerate(j['nodes']):
 assert not node.get('children')
 if 'mesh'not in node:continue
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:
  M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  p=A(pr['attributes']['POSITION']).astype(float);f=A(pr['indices']).astype(np.int64).reshape(-1,3);P.append((p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]);F.append(f+offset);own.extend([[ni,pi]]*len(f));offset+=len(p)
P=np.vstack(P);F=np.vstack(F);own=np.array(own);new=(own[:,0]==0)&np.isin(own[:,1],[8,9]);tri=P[F];lo=tri.min(1);hi=tri.max(1);lower=lo[new].min(0);upper=hi[new].max(0);target=np.all(hi>=lower-1e-8,axis=1)&np.all(lo<=upper+1e-8,axis=1);ids=np.flatnonzero(target);used,inv=np.unique(F[ids],return_inverse=True);selected=np.flatnonzero(new[ids]);print({'stage':'COMPACT_READY','new':len(selected),'retained':int((~new[ids]).sum()),'triangles':len(F)},flush=True)
res=audit(P[used],inv.reshape(-1,3),selected_faces=selected,progress_interval=2000)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in res[key]:
  row['faces']=[int(ids[x])for x in row['faces']];row['owners']=own[row['faces']].tolist();row['involves_new_sleeve']=bool(new[row['faces']].any())
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:res[key]=[[int(ids[x])for x in row]for row in res[key]]
res['zero_area_faces']=[int(ids[x])for x in res['zero_area_faces']]
res.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),selected_sleeve_triangles=len(selected),retained_potential_triangles=int((~new[ids]).sum()),new_crossings=sum(x['involves_new_sleeve']for x in res['proper_crossings']),new_coplanar=sum(x['involves_new_sleeve']for x in res['positive_area_coplanar_pairs']),new_folds=[x for x in res['manifold_edge_folds_over_105_degrees']if new[x].any()],new_copies=[x for x in res['position_triangle_copy_groups']if new[x].any()],new_zero_area=[x for x in res['zero_area_faces']if new[x]],scope='Every new159wool/knit/lining triangle against exact assembly161 conservative AABB targets. No inherited-body self clearance; shape, dense distances, root parity and final paint remain separate.')
(R/'audit/grip_sleeve162_v4.json').write_text(json.dumps(res,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in res.items()},flush=True)
