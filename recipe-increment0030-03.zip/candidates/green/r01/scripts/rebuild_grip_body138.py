"""Remove verified sleeve/body bridges and rebuild only their bounded coat-side surface."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.interpolate import RBFInterpolator
from scipy.spatial import cKDTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
src=R/'Green_sleeve75_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']).astype(float);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);W=(P*scale+translation)[:,[0,2,1]]*[1,-1,1];NW=(N/scale)[:,[0,2,1]]*[1,-1,1];NW/=np.linalg.norm(NW,axis=1)[:,None];z=np.load(R/'audit/grip_domain137.npz');data={k:z[k]for k in z.files};z.close();selected=np.zeros(len(F),bool);selected[data['selected_faces']]=True;arm=np.zeros(len(F),bool);arm[np.load(R/'audit/grip_ownership125.npz')['selected_faces']]=True;boundaryIds=data['body_loop_source_vertex_ids'];Q=W[boundaryIds];B=Q[:,1:3];no=len(B);support=data['body_support_faces'];S=W[F[support]];GN=np.cross(S[:,1]-S[:,0],S[:,2]-S[:,0]);GN/=np.linalg.norm(GN,axis=1)[:,None];print({'outer_vertices':no,'support_min_geometric_normal_X':float(GN[:,0].min())},flush=True);assert GN[:,0].min()>.04,'Body chart has an edge wall or projection fold'
def inside(poly,pts):
 out=np.zeros(len(pts),bool)
 for a,c in zip(poly,np.roll(poly,-1,axis=0)):out^=((a[1]>pts[:,1])!=(c[1]>pts[:,1]))&(pts[:,0]<(c[0]-a[0])*(pts[:,1]-a[1])/(c[1]-a[1]+1e-300)+a[0])
 return out
# Segment pair intersections are checked before accepting this 2D domain.
def cross(a,c):return a[...,0]*c[...,1]-a[...,1]*c[...,0]
for i,(a,c)in enumerate(zip(B,np.roll(B,-1,axis=0))):
 for k in range(i+2,no):
  if i==0 and k==no-1:continue
  u,v=B[k],B[(k+1)%no];den=cross(c-a,v-u)
  if abs(den)<1e-14:continue
  t=cross(u-a,v-u)/den;s=cross(u-a,c-a)/den
  assert not(1e-9<t<1-1e-9 and 1e-9<s<1-1e-9),('Projected boundary crosses',i,k)
planes=[];guides=[];controls=[];guideWidths=[]
def interior_angle(k):
 incoming=B[k]-B[(k-1)%no];outgoing=B[(k+1)%no]-B[k];return np.pi-np.arctan2(cross(incoming,outgoing),incoming@outgoing)
for i,(a,c)in enumerate(zip(B,np.roll(B,-1,axis=0))):
 e=c-a;L=np.linalg.norm(e);inward=np.array([-e[1],e[0]])/L;theta=min(interior_angle(i),interior_angle((i+1)%no),np.pi);h=min(.0007,L*.08,.4*L*np.tan(theta/4));assert h>1e-10;guide=(a+c)/2+inward*h
 for _ in range(12):
  if inside(B,guide[None])[0]:break
  h*=.5;guide=(a+c)/2+inward*h
 assert inside(B,guide[None])[0];plane=np.linalg.solve(np.column_stack([S[i,:,1:3],np.ones(3)]),S[i,:,0]);planes.append(plane);guides.append(guide);guideWidths.append(h)
 for u,v in [(a,c),(a,guide),(guide,c)]:
  count=max(3,int(np.ceil(np.linalg.norm(v-u)/.0004))+1);t=np.linspace(0,1,count);q=u[None]*(1-t[:,None])+v[None]*t[:,None];xx=np.column_stack([q,np.ones(len(q))])@plane;controls.extend(np.column_stack([q,xx]))
guides=np.array(guides);planes=np.array(planes)
# Only source samples outside the old bridge band constrain interior volume.
oldBody=np.flatnonzero(selected&~arm);T=W[F[oldBody]];mid=T.mean(1);fn=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);fn/=np.maximum(np.linalg.norm(fn,axis=1)[:,None],1e-30);cuts=np.load(R/'audit/grip_ownership125.npz')['cut_edges_world'][:,:,1:3];distance=np.full(len(mid),np.inf)
for u,v in cuts:
 e=v-u;l=e@e
 if l<1e-20:continue
 t=np.clip(((mid[:,1:3]-u)@e)/l,0,1);distance=np.minimum(distance,np.linalg.norm(mid[:,1:3]-u-t[:,None]*e,axis=1))
trusted=(distance>.012)&(fn[:,0]>.2)&inside(B,mid[:,1:3]);controls.extend(np.column_stack([mid[trusted,1:3],mid[trusted,0]]));controls=np.array(controls);_,first=np.unique(np.round(controls[:,:2],11),axis=0,return_index=True);controls=controls[first];center=B.mean(0);print({'stage':'TPS_CONTROLS_READY','controls':len(controls)},flush=True);fit=RBFInterpolator((controls[:,:2]-center)/.10,controls[:,2],kernel='thin_plate_spline',smoothing=1e-13)
y,zv=np.meshgrid(np.arange(B[:,0].min(),B[:,0].max(),.0015),np.arange(B[:,1].min(),B[:,1].max(),.0015));samples=np.column_stack([y.ravel(),zv.ravel()]);samples=samples[inside(B,samples)];ds=np.full(len(samples),np.inf)
segments=np.vstack([np.column_stack([np.arange(no),np.roll(np.arange(no),-1)]),np.column_stack([np.arange(no),no+np.arange(no)]),np.column_stack([no+np.arange(no),np.roll(np.arange(no),-1)])]);verts=np.vstack([B,guides])
for ia,ib in segments:
 u,v=verts[[ia,ib]];e=v-u;t=np.clip(((samples-u)@e)/(e@e),0,1);ds=np.minimum(ds,np.linalg.norm(samples-u-t[:,None]*e,axis=1))
samples=samples[ds>.00018];tr=triangle.triangulate({'vertices':np.vstack([verts,samples]),'segments':segments},'pYYq24Q');V=tr['vertices'];FF=tr['triangles'];assert np.array_equal(V[:no],B);areas=cross(V[FF[:,1]]-V[FF[:,0]],V[FF[:,2]]-V[FF[:,0]]);assert areas.min()>0
print({'stage':'TRIANGULATION_READY','vertices':len(V),'triangles':len(FF)},flush=True);X=fit((V-center)/.10);X[:no]=Q[:,0];wedgeCount=np.zeros(len(V),int);fixed=np.zeros(len(V),bool);fixed[:no]=True;wedgeMembers=[]
for i in range(no):
 tri=np.array([B[i],B[(i+1)%no],guides[i]]);e=tri[1]-tri[0];f=tri[2]-tri[0];v=V-tri[0];den=cross(e,f);u=cross(v,f)/den;w=cross(e,v)/den;take=(u>=-1e-8)&(w>=-1e-8)&(u+w<=1+1e-8);expected=np.column_stack([V[take],np.ones(take.sum())])@planes[i];overlap=take&(wedgeCount>0)
 if overlap.any():assert np.max(abs(X[overlap]-np.column_stack([V[overlap],np.ones(overlap.sum())])@planes[i]))<1e-6,'Overlapping tangent wedges disagree'
 X[take]=expected;fixed[take]=True;wedgeCount[take]+=1;wedgeMembers.append(take)
X[:no]=Q[:,0];newW=np.column_stack([X,V]);newW[:no]=Q;geom=np.cross(newW[FF[:,1]]-newW[FF[:,0]],newW[FF[:,2]]-newW[FF[:,0]]);NN=np.zeros_like(newW)
for k in range(3):np.add.at(NN,FF[:,k],geom)
NN/=np.linalg.norm(NN,axis=1)[:,None];residual=np.zeros_like(NN);normalFixed=np.zeros(len(V),bool)
for i,take in enumerate(wedgeMembers):
 bary=np.column_stack([V[take],np.ones(take.sum())])@np.linalg.inv(np.column_stack([S[i,:,1:3],np.ones(3)]));ns=bary@NW[F[support[i]]];ns/=np.linalg.norm(ns,axis=1)[:,None];residual[take]=ns-NN[take];normalFixed[take]=True
residual[:no]=NW[boundaryIds]-NN[:no];normalFixed[:no]=True;heldResidual=residual.copy();E=np.unique(np.sort(np.vstack([FF[:,[0,1]],FF[:,[1,2]],FF[:,[2,0]]]),axis=1),axis=0);degree=np.bincount(E.ravel(),minlength=len(V))
for _ in range(350):
 total=np.zeros_like(residual);np.add.at(total,E[:,0],residual[E[:,1]]);np.add.at(total,E[:,1],residual[E[:,0]]);r=.98*total/np.maximum(degree[:,None],1);r[normalFixed]=heldResidual[normalFixed]
 if np.max(abs(r-residual))<1e-9:break
 residual=r
NN+=residual;NN/=np.linalg.norm(NN,axis=1)[:,None];newP=(newW[:,[0,2,1]]*[1,1,-1]-translation)/scale;newN=NN[:,[0,2,1]]*[1,1,-1]*scale;newN/=np.linalg.norm(newN,axis=1)[:,None];newP[:no]=P[boundaryIds];newN[:no]=N[boundaryIds]
# Keep the proximal part of the source arm's straddling triangles, forming a true Z=.16 ring.
level=.16;d=W[:,2]-level;cp=[];cn=[];cu=[];cf=[];physical={};rootSegments=[]
for fi in np.flatnonzero(arm&(d[F].min(1)<0)&(d[F].max(1)>0)):
 f=F[fi];poly=[];hits=[]
 for va,vb in zip(f,np.roll(f,-1)):
  if d[va]>=0:poly.append((P[va],N[va],UV[va]))
  if d[va]*d[vb]<0:
   key=tuple(sorted((tuple(P[va]),tuple(P[vb]))));t=d[va]/(d[va]-d[vb]);p=physical.setdefault(key,P[va]+t*(P[vb]-P[va]));n=N[va]+t*(N[vb]-N[va]);n/=np.linalg.norm(n);uv=UV[va]+t*(UV[vb]-UV[va]);poly.append((p,n,uv));hits.append(p)
 if len(hits)==2:rootSegments.append(hits)
 start=len(cp)
 for p,n,uv in poly:cp.append(p);cn.append(n);cu.append(uv)
 for k in range(1,len(poly)-1):cf.append([start,start+k,start+k+1])
cp=np.array(cp);cn=np.array(cn);cu=np.array(cu);cf=np.array(cf);pr['indices'],b=append_accessor(j,b,F[~selected].astype('uint32'),'SCALAR',34963)
def append_mesh(label,p,n,u,f,mat):
 global b
 at={}
 for name,arr,kind in [('POSITION',p,'VEC3'),('NORMAL',n,'VEC3'),('TEXCOORD_0',u,'VEC2')]:at[name],b=append_accessor(j,b,arr.astype('float32'),kind,34962)
 ix,b=append_accessor(j,b,f.astype('uint32'),'SCALAR',34963);pi=len(j['meshes'][0]['primitives']);j['meshes'][0]['primitives'].append({'attributes':at,'indices':ix,'material':mat,'mode':4});return pi
clipPrimitive=append_mesh('Held clipped proximal arm',cp,cn,cu,cf,pr['material']);mi=len(j['materials']);j['materials'].append({'name':'Coat-side bridge repair geometry diagnostic','pbrMetallicRoughness':{'baseColorFactor':[.015,.18,.095,1],'roughnessFactor':.7,'metallicFactor':0},'doubleSided':False});uv=(V-V.min(0))/(V.max(0)-V.min(0));uv[:,1]=1-uv[:,1];patchPrimitive=append_mesh('Bounded coat-side bridge repair',newP,newN,uv,FF,mi);out=R/'Green_grip_body138.glb';write_glb(out,j,b);np.savez_compressed(R/'audit/grip_body138_binding.npz',patch_world=newW,patch_triangles=FF,patch_source_boundary=boundaryIds,patch_support=support,patch_fixed=fixed,root_segments_local=np.array(rootSegments),source_removed=np.flatnonzero(selected),trusted_source_face_ids=oldBody[trusted]);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_source_faces':int(selected.sum()),'clipped_proximal_triangles':len(cf),'body_patch_triangles':len(FF),'body_patch_boundary_vertices':no,'tangent_guide_width_min_max_m':[float(min(guideWidths)),float(max(guideWidths))],'trusted_interior_source_controls':int(trusted.sum()),'interpolation_control_count':len(controls),'minimum_projected_double_area':float(areas.min()),'source_boundary_positions_normals_held':True,'new_primitives':[clipPrimitive,patchPrimitive],'status':'Unadopted bounded coat-side reconstruction and open right-sleeve support. New anatomical hand/case/sleeve are not integrated. V4, exact joins/source-volume error and exposed actual views must agree before promotion.'};(R/'audit/grip_body138.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
