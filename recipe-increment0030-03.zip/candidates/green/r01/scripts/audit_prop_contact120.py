"""Recheck assembled grip/handle and seated case contact using exact current transforms."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/audit_grip_clearance106.py').read_text();prefix=code[:code.index('assert len(objects)==2')]
prefix=prefix.replace("src=R/'Green_grip_handle105.glb'","src=R/'Green_grip_case119.glb'")
a=prefix.index("pre=json.loads");b=prefix.index('\nj,b,A=',a)
prefix=prefix[:a]+"dedup=json.loads((R/'audit/image_dedup119.json').read_text());pre=json.loads((R/'audit/grip_case117_v4.json').read_text());assert dedup['candidate_sha256']==sha and pre['source_sha256']==dedup['source_sha256'] and pre['prop_proper']==0 and pre['prop_coplanar']==0"+prefix[b:]
exec(compile(prefix,'load119_exact_geometry','exec'))
body=code[code.index('assert len(objects)==2'):code.index("rep={'source_sha256'")]
exec('def measure(objects):\n'+''.join(' '+line+'\n'for line in body.splitlines())+' return best,where,vf,tested\n')
assert len(objects)==32
allp=[];allf=[];off=0
for p,f,e in objects[2:]:allp.append(p);allf.append(f+off);off+=len(p)
P=np.vstack(allp);F=np.vstack(allf);E=np.unique(np.sort(np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),axis=1),axis=0);case=(P,F,E)
reports=[]
for names,pair in [(('hand','handle'),objects[:2]),(('handle','case'),[objects[1],case]),(('hand','case'),[objects[0],case])]:
 d,where,vf,tested=measure(pair);rec={'parts':names,'minimum_mesh_boundary_clearance_m':d,'closest_feature':where,'vertex_face_checks':vf,'candidate_edge_edge_pairs_tested':tested};reports.append(rec);print(rec,flush=True)
rep={'source_sha256':sha,'pairs':reports,'scope':'All three complete component boundary distances after exact disjointness and byte-level image-dedup geometry equivalence. Float64 edge minima and Blender BVH nearest faces. Does not establish cuff, body contact or reference placement.'};(R/'audit/prop_contact120.json').write_text(json.dumps(rep,indent=2))
