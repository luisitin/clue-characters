"""Green-specific forearm sleeve around the held native-axis skin continuation.
Root positions/normal jets are retained. Cloth, knit and backing remain distinct
construction layers; all generated material charts are diagnostic at this stage.
"""
import pathlib,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
from scipy.ndimage import gaussian_filter1d
from scipy.interpolate import CubicSpline
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import spsolve
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_body151.glb';j,b,A=read_glb(src)
with np.load(R/'audit/grip_sleeve158_binding.npz')as archive:z={k:archive[k]for k in archive.files}
root=z['root_world'];rootP=z['root_local'];rootN=z['root_normal_local'];rootWN=z['root_normal_world'];M=z['node_matrix'];n=len(root)
fit=json.loads((R/'audit/grip_fit143.json').read_text());prox=np.array(fit['native_forearm_proximal_world']);axis=-prox;wrist=np.array(fit['wrist_world']);axis0=np.array([0.,0,-1]);frame0=np.array([[1.,0],[0,-1],[0,0]])
q=root[:,:2];cr=q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1);rc=np.r_[((q+np.roll(q,-1,axis=0))*cr[:,None]).sum(0)/(3*cr.sum()),root[:,2].mean()]
q0=(root-rc)@frame0;turn=np.cross(axis0,axis);angle=np.arccos(np.clip(axis0@axis,-1,1));turn/=np.linalg.norm(turn);frame1=Rotation.from_rotvec(turn*angle).as_matrix()@frame0
sj,sb,S=read_glb(R/'Green_grip_wrist154.glb');sm=np.array(sj['nodes'][0]['matrix']).reshape((4,4),order='F');samples=[]
levels=[.017,.021,.029,.038,.043,.046]
for pr in sj['meshes'][0]['primitives']:
 p=S(pr['attributes']['POSITION']).astype(float);w=(p@sm[:3,:3].T+sm[:3,3])[:,[0,2,1]]*[1,-1,1];f=S(pr['indices']).astype(np.int64).reshape(-1,3)
 for level in levels:
  d=(w-wrist)@prox-level
  for fi in np.flatnonzero((d[f].min(1)<0)&(d[f].max(1)>0)):
   for a,c in zip(f[fi],np.roll(f[fi],-1)):
    if d[a]*d[c]<0:samples.append(w[a]+d[a]/(d[a]-d[c])*(w[c]-w[a]))
samples=np.array(samples);assert len(samples)>100
hem=wrist+prox*.029;qq=(samples-hem)@frame1;offset=(qq.max(0)+qq.min(0))/2;hem+=frame1@offset;qq-=offset
skinr=np.max(abs(qq),axis=0);skinr*=np.sqrt(np.sum((qq/skinr)**2,axis=1).max());knitInner=skinr+.0007;knitOuter=knitInner+.0011;outer=knitOuter+.0045
length=np.linalg.norm(hem-rc);edge=np.linalg.norm(np.roll(root,-1,axis=0)-root,axis=1);u=np.r_[0,np.cumsum(edge[:-1])]/edge.sum();area=(q0[:,0]*np.roll(q0[:,1],-1)-q0[:,1]*np.roll(q0[:,0],-1)).sum();sign=np.sign(area)
phase=np.arctan2(q0[0,1],q0[0,0]);theta=phase+sign*2*np.pi*u;q1=np.column_stack([np.cos(theta),np.sin(theta)])*outer
t0=(hem-rc)*.8;t1=axis*length*.5
def raw(t):
 blend=t*t*(3-2*t);center=(2*t**3-3*t*t+1)*rc+(t**3-2*t*t+t)*t0+(-2*t**3+3*t*t)*hem+(t**3-t*t)*t1
 frame=Rotation.from_rotvec(turn*(angle*blend)).as_matrix()@frame0
 return center+(q0*(1-blend)+q1*blend)@frame.T
initial=(raw(1e-6)-root)/(length*1e-6);desired=initial-rootWN*np.sum(initial*rootWN,axis=1)[:,None];den=desired@axis0;assert den.min()>.1;desired*=((initial@axis0)/den)[:,None];correction=desired-initial
V=[];UV=[];F=[];parts=[];rings=[];params=[];heldNormal={};rows=np.r_[0,.006,.014,np.linspace(.025,1,39)];uniform=np.arange(192)/192;denseU=np.arange(4096)/4096
def add_ring(points,uu,v,part=0):
 ids=np.arange(len(V),len(V)+len(points));V.extend(points);UV.extend(np.column_stack([.03+.94*uu,np.full(len(points),v)]));return ids
def stitch(aa,ua,bb,ub,part):
 i=k=0;na=len(aa);nb=len(bb)
 while i<na or k<nb:
  ai=aa[i%na];bk=bb[k%nb];an=ua[i+1]if i+1<na else 1.;bn=ub[k+1]if k+1<nb else 1.
  if i<na and(k==nb or an<=bn):F.append([ai,aa[(i+1)%na],bk]);i+=1
  else:F.append([ai,bb[(k+1)%nb],bk]);k+=1
  parts.append(part)
for ri,t in enumerate(rows):
 arc=t*length;ss=min(arc/.045,1.);weight=.045*(ss-6*ss**3+8*ss**4-3*ss**5);rr=raw(t)+correction*weight
 if ri==0:rr=root.copy()
 if ri<2:uu=u
 else:
  dense=np.column_stack([np.interp(denseU,np.r_[u,1],np.r_[rr[:,k],rr[0,k]])for k in range(3)]);perim=np.linalg.norm(np.roll(rr,-1,axis=0)-rr,axis=1).sum();smooth=gaussian_filter1d(dense,.003/perim*len(dense),axis=0,mode='wrap');cc=dense.mean(0);smooth=cc+(smooth-cc)*np.sqrt(np.sum((dense-cc)**2)/np.sum((smooth-cc)**2));a0=np.clip((arc-.001)/.014,0,1);a0=a0*a0*(3-2*a0);a1=np.clip((length-arc)/.012,0,1);a1=a1*a1*(3-2*a1);dense+=(smooth-dense)*a0*a1;rr=CubicSpline(np.r_[denseU,1],np.vstack([dense,dense[0]]),bc_type='periodic')(uniform);uu=uniform
  if ri==len(rows)-1:rr=hem+(np.column_stack([np.cos(phase+sign*2*np.pi*uu),np.sin(phase+sign*2*np.pi*uu)])*outer)@frame1.T
 ids=add_ring(rr,uu,.02+.67*t);rings.append(ids);params.append(uu)
 if ri==0:
  for k,nn in zip(ids,rootWN):heldNormal[int(k)]=nn
guideStart=len(V);guides=[];guideSteps=[]
for k in range(n):
 kk=(k+1)%n;con=z['root_forward_conormal'][k];ax=con@axis0;assert ax>.1;first=np.array(V)[rings[1]];available=min((first[k]-root[k])@axis0,(first[kk]-root[kk])@axis0);step=min(.00035,.25*available,.18*edge[k]);assert step>1e-7
 G=(root[k]+root[kk])/2+con*(step/ax);gi=len(V);guides.append(gi);V.append(G);UV.append([.03+.94*(u[k]+edge[k]/edge.sum()/2),.02+.67*step/length]);tri=z['root_support_triangles'][k];ab=np.linalg.lstsq(np.column_stack([tri[1]-tri[0],tri[2]-tri[0]]),G-tri[0],rcond=None)[0];nn=np.r_[1-ab.sum(),ab]@z['root_support_corner_normals'][k];nn/=np.linalg.norm(nn);heldNormal[gi]=nn;guideSteps.append(step)
for k,gg in enumerate(guides):
 aa=rings[0][k];bb=rings[0][(k+1)%n];cc=rings[1][(k+1)%n];dd=rings[1][k];F.extend([[aa,bb,gg],[bb,cc,gg],[cc,dd,gg],[dd,aa,gg]]);parts.extend([0]*4)
for ri in range(1,len(rings)-1):stitch(rings[ri],params[ri],rings[ri+1],params[ri+1],0)
# Wool return rolls toward the skin, then continues to a recessed backing.
uu=uniform;circle=np.column_stack([np.cos(phase+sign*2*np.pi*uu),np.sin(phase+sign*2*np.pi*uu)]);last=rings[-1];profile=[]
for a in np.linspace(0,np.pi,9)[1:]:profile.append((.029-.0009*np.sin(a),outer-.0009*(1-np.cos(a))))
profile.extend([(.034,outer-.0018),(.041,outer-.0020),(.046,outer-.0028),(.046,knitOuter+.0005)])
for ri,(level,radius)in enumerate(profile):
 center=hem+prox*(level-.029);rr=center+(circle*radius)@frame1.T;ids=add_ring(rr,uu,.71+.12*ri/(len(profile)-1));stitch(last,uu,ids,uu,0);last=ids
# Independent thin knitted tube with rounded distal/proximal hems.
krings=[];knitProfile=[];radius=(knitInner+knitOuter)/2;roll=.00055
for a in np.linspace(0,np.pi,9):knitProfile.append((.017-roll*np.sin(a),radius+roll*np.cos(a)))
knitProfile.extend([(.023,knitInner),(.035,knitInner),(.043,knitInner)])
for a in np.linspace(np.pi,2*np.pi,9)[1:]:knitProfile.append((.043-roll*np.sin(a),radius+roll*np.cos(a)))
knitProfile.extend([(.035,knitOuter),(.023,knitOuter)])
for ri,(level,radius0)in enumerate(knitProfile):krings.append(add_ring(hem+prox*(level-.029)+(circle*radius0)@frame1.T,uu,.02+.94*ri/len(knitProfile)))
for ri in range(len(krings)):stitch(krings[ri],uu,krings[(ri+1)%len(krings)],uu,1)
V=np.array(V);UV=np.array(UV);F=np.array(F,dtype=np.int64);parts=np.array(parts);tri=V[F];gn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);ar=np.linalg.norm(gn,axis=1);assert ar.min()>1e-16;gn/=ar[:,None];N=np.zeros_like(V)
for k in range(3):
 x=tri[:,(k+1)%3]-tri[:,k];y=tri[:,(k+2)%3]-tri[:,k];x/=np.linalg.norm(x,axis=1)[:,None];y/=np.linalg.norm(y,axis=1)[:,None];a=np.arccos(np.clip(np.sum(x*y,axis=1),-1,1));np.add.at(N,F[:,k],gn*a[:,None])
assert np.linalg.norm(N,axis=1).min()>1e-12;N/=np.linalg.norm(N,axis=1)[:,None]
residual=np.zeros_like(N);fixed=np.ones(len(V),bool)
for ri,t in enumerate(rows):
 if ri>0 and t*length<.045:fixed[rings[ri]]=False
for i,nn in heldNormal.items():residual[i]=nn-N[i]
ed=np.unique(np.sort(np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),axis=1),axis=0);w=1/np.maximum(np.linalg.norm(V[ed[:,0]]-V[ed[:,1]],axis=1),1e-8);adj=coo_matrix((np.r_[w,w],(np.r_[ed[:,0],ed[:,1]],np.r_[ed[:,1],ed[:,0]])),shape=(len(V),len(V))).tocsr();L=diags(np.asarray(adj.sum(1)).ravel())-adj;free=np.flatnonzero(~fixed);held=np.flatnonzero(fixed);residual[free]=spsolve(L[free][:,free],-L[free][:,held]@residual[held]);N+=residual;N/=np.linalg.norm(N,axis=1)[:,None]
CG=np.array([[1.,0,0],[0,0,-1],[0,1,0]]);P=(V@CG-M[:3,3])@np.linalg.inv(M[:3,:3]).T;LN=(N@CG)@M[:3,:3];LN/=np.linalg.norm(LN,axis=1)[:,None];P[:n]=rootP;LN[:n]=rootN
mi=len(j['materials']);j['materials'].extend([{'name':'Green grip sleeve159 diagnostic wool','pbrMetallicRoughness':{'baseColorFactor':[.028,.18,.095,1],'metallicFactor':0,'roughnessFactor':.82},'doubleSided':False},{'name':'Green grip sleeve159 diagnostic knit','pbrMetallicRoughness':{'baseColorFactor':[.016,.02,.019,1],'metallicFactor':0,'roughnessFactor':.88},'doubleSided':False}]);attributes={}
for key,value,typ in [('POSITION',P,'VEC3'),('NORMAL',LN,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attributes[key],b=append_accessor(j,b,value.astype('float32'),typ,34962)
start=len(j['meshes'][0]['primitives'])
for part in [0,1]:
 index,b=append_accessor(j,b,F[parts==part].astype('uint32'),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attributes.copy(),'indices':index,'material':mi+part,'mode':4})
out=R/'Green_grip_sleeve159_body.glb';write_glb(out,j,b);np.savez_compressed(R/'audit/grip_sleeve159_binding.npz',world_positions=V,triangles=F,parts=parts,root_world=root,root_local=rootP,root_normal_local=rootN,hem_center=hem,hem_frame=frame1,skin_radii=skinr,knit_inner_radii=knitInner,knit_outer_radii=knitOuter,outer_radii=outer)
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'new_primitives':[start,start+1],'new_triangles':len(F),'root_nodes':n,'root_positions_normals_exact':True,'uniform_interior_ring_nodes':192,'source_conormal_forward_min':float((z['root_forward_conormal']@axis0).min()),'guide_step_min_max_m':[min(guideSteps),max(guideSteps)],'root_to_hem_length_m':float(length),'skin_section_levels_m':levels,'section_samples':len(samples),'skin_ellipse_radii_m':skinr.tolist(),'actual_section_ellipse_max':float(np.sqrt(np.sum((qq/skinr)**2,axis=1).max())),'coat_hem_proximal_offset_m':.029,'knit_distal_proximal_offsets_m':[.017,.043],'deep_backing_offset_m':.046,'status':'Unadopted geometric layered sleeve. Exact new-surface/root/seam/contact and actual shape views required. Charts/materials are diagnostic.'};(R/'audit/grip_sleeve159_body.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
