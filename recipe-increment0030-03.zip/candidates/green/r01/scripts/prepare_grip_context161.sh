#!/usr/bin/env bash
set -euo pipefail
R=clue-recovery-20261004/candidates/green/r01
bash "$R/scripts/run_heavy_stage.sh" props160 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/extract_placed_props160.py" > "$R/logs/props160.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" grip_context161 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python "$R/scripts/merge_exact_components.py" Green_grip_context161 Green_grip_sleeve159_body Green_openhand_depth68 Green_grip_wrist154 Green_props160_placed > "$R/logs/grip_context161.log" 2>&1
