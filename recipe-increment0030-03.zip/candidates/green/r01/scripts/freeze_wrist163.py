"""Freeze verified body151 and wrist154 recipes/evidence, excluding ongoing sleeve159."""
import pathlib,json,hashlib,ast,datetime
R=pathlib.Path(__file__).resolve().parents[1];ROOT=R.parents[2];out=ROOT/'component_snapshots/green-wrist-body-20261005-0005';out.mkdir(parents=True,exist_ok=True)
scripts=['attribute_body_dimples149.py','probe_body_controls150.py','rebuild_grip_body151.py','probe_grip_wrist153.py','build_grip_wrist154.py','audit_grip_wrist156.py','render_wrist157.py','probe_grip_sleeve158.py','freeze_wrist163.py']
reports=['body_dimples149.json','body_controls150.json','grip_body151.json','Green_grip_body151_v4_compact135.json','grip_wrist153.json','grip_wrist154.json','grip_wrist156_v4.json','grip_sleeve158.json']
selected=[R/'scripts'/p for p in scripts]+[R/'audit'/p for p in reports]
selected += [R/'audit'/p for p in ['body_controls150.npz','grip_wrist154_binding.npz','grip_sleeve158_binding.npz']]
for folder,tags in [('grip_body151',['body_bridge_side141_clay','grip_source_front123_clay','grip_source_back123_clay']),('grip_wrist157',['grip_wrist157_front_clay','grip_wrist157_opposite_clay','grip_pose157_front_clay'])]:
 for tag in tags:
  for ext in ['.png','.json']:selected.append(R/'renders'/folder/(tag+ext))
records=[]
for p in selected:
 assert p.is_file(),p
 if p.suffix=='.py':ast.parse(p.read_text(),filename=str(p))
 rel=p.relative_to(ROOT);dst=out/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes()
 if dst.exists():assert dst.read_bytes()==data
 else:dst.write_bytes(data)
 records.append({'relative_path':str(rel),'snapshot_path':str(dst),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
report={'scope':'Public-safe WIP recovery increment. Verified bounded body and wrist changes; whole character still unfinished.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'depends_on':['green-combined-recipes-20261004-1830','green-sleeve75-eye60-20261004-2020','green-grip-case-20261004-2210','green-body-bridge-20261004-2330'],'build_order':['Restore prior source/donor/recipe increments. Body151 uses the same source137domain as138 and the frozen visibility table150;150 can be reproduced from the original exact source and domain.','Run attribute_body_dimples149.py only as a diagnostic; it uses the exact saved body_bridge_side141 camera. Run probe_body_controls150.py, then rebuild_grip_body151.py and audit_grip_body135.py Green_grip_body151.','Reproduce painted98 and rigid placement143 from earlier increments. Run probe_grip_wrist153.py, build_grip_wrist154.py, audit_grip_wrist156.py. All distal P/N/UV/T and unchanged triangle records are asserted exact.','Render actual154 using render_wrist157.py; render151 with the earlier render_grip_source123.py and render_body_bridge141.py.','Probe158 describes a forward-supported142edge root only. Sleeve159 is intentionally not included or accepted. All heavy launches acquire the external shared flock with BLAS/OMP1 and release per view/stage.'],'results':{'body151':{'sha256':'f2b1bb4285518dac8a1e61c1806d837a36a7a9d74b5ab304af6f749b640d061e','triangles':110895,'status':'Bridge gap and side dimples improved in actual front/back/side clay. Open right sleeve and retained source marks remain.'},'wrist154':{'sha256':'26cf41cab66403df2f7561fa921f1eb959da88b127f83147e8c5247f778df3bc','triangles':60940,'status':'Closed Euler2, zero selected V4 crossings/copies/collapse, held distal attrs/triangles exact. Actual front/opposite clay continuous. New extension paint/chart and final sleeve/contact remain pending.'}},'files':records,'total_bytes':sum(x['bytes']for x in records),'verification':'Exact copy/hash and Python AST checks, plus preserved actual proof reports. No clean-room whole-chain replay.'}
(out/'MANIFEST.json').write_text(json.dumps(report,indent=2));print(out/'MANIFEST.json');print(len(records),report['total_bytes'])
