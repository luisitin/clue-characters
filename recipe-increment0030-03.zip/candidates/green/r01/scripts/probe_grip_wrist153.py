"""Measure complete posed skin sections on Green's own native wrist-bone axis."""
import pathlib,json,hashlib,numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip88_painted98.glb';j,b,A=read_glb(src);pj,pb,PA=read_glb(R/'Green_grip_case143_pose.glb');M=np.array(pj['nodes'][0]['matrix']).reshape((4,4),order='F');p=j['meshes'][0]['primitives'][0];P=A(p['attributes']['POSITION']).astype('float32');N=A(p['attributes']['NORMAL']).astype(float);F=A(p['indices']).astype(np.int64).reshape(-1,3);W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];WN=(N@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];WN/=np.linalg.norm(WN,axis=1)[:,None];fit=json.loads((R/'audit/grip_fit143.json').read_text());wrist=np.array(fit['wrist_world']);prox=np.array(fit['native_forearm_proximal_world']);U,g=np.unique(W,axis=0,return_inverse=True);reports=[];bindings={}
for level in [.004,.006,.008,.010,.012]:
 C=wrist+prox*level;d=(W-C)@prox;ids=np.flatnonzero((d[F].min(1)<0)&(d[F].max(1)>0));cache={};seg=[];norms=[]
 for fi in ids:
  hit=[]
  for a,c in zip(F[fi],np.roll(F[fi],-1)):
   if d[a]*d[c]<0:
    key=tuple(sorted((int(g[a]),int(g[c]))));t=d[a]/(d[a]-d[c]);q=cache.setdefault(key,W[a]+t*(W[c]-W[a]));nn=WN[a]+t*(WN[c]-WN[a]);nn/=np.linalg.norm(nn);hit.append(q);norms.append(nn)
  assert len(hit)==2;seg.append(hit)
 Q,inv=np.unique(np.array(seg).reshape(-1,3),axis=0,return_inverse=True);E=inv.reshape(-1,2);degree=np.bincount(E.ravel(),minlength=len(Q));rr=np.r_[E[:,0],E[:,1]];cc=np.r_[E[:,1],E[:,0]];nc,lab=connected_components(coo_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(Q),len(Q))),directed=False);norms=np.array(norms);axial=1-(norms@prox)**2;reports.append({'proximal_offset_m':level,'plane_origin_world':C.tolist(),'plane_normal_proximal_world':prox.tolist(),'components':nc,'vertices':len(Q),'degree_histogram':{str(k):int((degree==k).sum())for k in np.unique(degree)},'tangent_axial_denominator_min':float(axial.min()),'maximum_normal_axial_cosine':float(abs(norms@prox).max()),'bounds_world':[Q.min(0).tolist(),Q.max(0).tolist()]});key=str(round(level*1000));bindings['segments_'+key]=np.array(seg)
rep={'source_hand_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'placement_sha256':hashlib.sha256((R/'Green_grip_case143_pose.glb').read_bytes()).hexdigest(),'sections':reports,'status':'Read-only whole-section measurements. Choose a single closed non-cap skin section before continuation; no source hand, contact or atlas has changed.'};(R/'audit/grip_wrist153.json').write_text(json.dumps(rep,indent=2));np.savez_compressed(R/'audit/grip_wrist153.npz',**bindings);print(rep,flush=True)
