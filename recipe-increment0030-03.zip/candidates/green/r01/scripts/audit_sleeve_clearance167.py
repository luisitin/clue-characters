"""Exact current layer boundary distances; prior162 establishes disjointness."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from mathutils import Vector
from mathutils.bvhtree import BVHTree
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_context164.glb';sha=hashlib.sha256(src.read_bytes()).hexdigest();proof=json.loads((R/'audit/grip_sleeve162_v4.json').read_text());dedup=json.loads((R/'audit/context164.json').read_text());assert proof['source_sha256']==dedup['source_sha256']and dedup['candidate_sha256']==sha;assert proof['new_crossings']==proof['new_coplanar']==0
j,b,A=read_glb(src)
def geometry(nodeIndex,primitiveIds=None):
 node=j['nodes'][nodeIndex]
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:
  M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 ps=[];fs=[];off=0
 for pi,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
  if primitiveIds is not None and pi not in primitiveIds:continue
  p=A(pr['attributes']['POSITION']).astype(float);f=A(pr['indices']).astype(np.int64).reshape(-1,3);used,inv=np.unique(f,return_inverse=True);p=p[used];f=inv.reshape(-1,3)
  ps.append((p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]);fs.append(f+off);off+=len(p)
 p=np.vstack(ps);f=np.vstack(fs);u,g=np.unique(p,axis=0,return_inverse=True);f=g[f];edges=np.unique(np.sort(np.vstack([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]]),axis=1),axis=0);return u,f,edges
code=(R/'scripts/audit_grip_clearance106.py').read_text();body=code[code.index('assert len(objects)==2'):code.index("rep={'source_sha256'")]
body=body.replace('for i in range(len(e1)):',"for i in range(len(e1)):\n if i%20000==0:print({'edge':i,'of':len(e1),'best_m':best},flush=True)")
exec('def measure(objects):\n'+''.join(' '+line+'\n'for line in body.splitlines())+' return best,where,vf,tested\n')
name=sys.argv[sys.argv.index('--')+1]if '--'in sys.argv else sys.argv[-1]
targets={'knit_skin':[(0,[9]),(2,None)],'wool_skin':[(0,[8]),(2,None)],'wool_knit':[(0,[8]),(0,[9])],'hand_handle':[(2,None),(3,None)]};assert name in targets
objects=[geometry(n,p)for n,p in targets[name]];print({'pair':name,'triangles':[len(o[1])for o in objects]},flush=True);d,where,vf,tested=measure(objects)
report={'source_sha256':sha,'pair':name,'minimum_mesh_boundary_clearance_m':d,'closest_feature':where,'vertex_face_checks':vf,'candidate_edge_edge_pairs_tested':tested,'scope':'Complete vertex/face both ways and conservative finite edge/edge minima on exact current assembled coordinates. Float64 segments/BVH float32 nearest faces. Geometric separation does not imply visual seating or garment finish.'};(R/'audit'/('sleeve_clearance167_'+name+'.json')).write_text(json.dumps(report,indent=2));print(report,flush=True)
