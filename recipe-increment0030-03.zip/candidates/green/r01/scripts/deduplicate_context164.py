import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/deduplicate_context146.py').read_text()
code=code.replace('Green_grip_context144','Green_grip_context161').replace('Green_grip_context146','Green_grip_context164').replace('context146.json','context164.json')
code=code.replace('The right lower sleeve/skin continuation are intentionally absent in this placement study; this is not the complete-character candidate.','The new right sleeve and skin are now present, with diagnostic material finish. Root shape/contact and whole-character gates remain pending.')
exec(compile(code,'deduplicate_context164','exec'))
