"""Extend a measured native-axis skin section, preserving the held distal grip exactly.
Method adapted from the independently checked Plum continuation201; all sections,
frames, attributes and contact obligations below are Green's own.
"""
import pathlib,json,hashlib,collections,numpy as np
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1]
source=R/'Green_grip88_painted98.glb';j,b,A=read_glb(source)
pj,pb,PA=read_glb(R/'Green_grip_case143_pose.glb')
M=np.array(pj['nodes'][0]['matrix']).reshape((4,4),order='F')
j['nodes'][0]={**j['nodes'][0],'matrix':M.T.ravel().tolist()}
for key in ['translation','rotation','scale']:j['nodes'][0].pop(key,None)
pr=j['meshes'][0]['primitives'][0]
attrs={k:A(v).astype(float)for k,v in pr['attributes'].items()}
original={k:v.copy()for k,v in attrs.items()}
F=A(pr['indices']).astype(np.int64).reshape(-1,3)
P=attrs['POSITION'];W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]
fit=json.loads((R/'audit/grip_fit143.json').read_text());prox=np.array(fit['native_forearm_proximal_world']);TA=-prox
C=np.array(fit['wrist_world'])+prox*.008
U,groups=np.unique(W,axis=0,return_inverse=True);DS=(U-C)@TA
cache={};geomCache={};values={k:v.tolist()for k,v in attrs.items()};outFaces=[];parents=[];cut=0

def local_position(p):
    gl=p[[0,2,1]]*[1,1,-1]
    return (gl-M[:3,3])@np.linalg.inv(M[:3,:3]).T

def split_edge(a,c):
    key=tuple(sorted((int(a),int(c))))
    if key in cache:return cache[key]
    ga,gc=int(groups[a]),int(groups[c]);gkey=tuple(sorted((ga,gc)))
    if gkey not in geomCache:
        x,y=gkey;t=-DS[x]/(DS[y]-DS[x]);geomCache[gkey]=local_position(U[x]+t*(U[y]-U[x]))
    t=-DS[ga]/(DS[gc]-DS[ga]);record={k:(1-t)*v[a]+t*v[c]for k,v in attrs.items()}
    record['POSITION']=geomCache[gkey]
    record['NORMAL']/=np.linalg.norm(record['NORMAL'])
    if'TANGENT'in record:
        assert attrs['TANGENT'][a,3]==attrs['TANGENT'][c,3]
        tangent=record['TANGENT'][:3];normal=record['NORMAL'];tangent-=normal*(tangent@normal)
        assert np.linalg.norm(tangent)>1e-6
        record['TANGENT'][:3]=tangent/np.linalg.norm(tangent)
        record['TANGENT'][3]=attrs['TANGENT'][a,3]
    index=len(values['POSITION'])
    for key,value in record.items():values[key].append(value.tolist())
    cache[tuple(sorted((int(a),int(c))))]=index
    return index

for fi,f in enumerate(F):
    d=DS[groups[f]]
    if d.min()>=0:outFaces.append(f.tolist());parents.append(fi);continue
    if d.max()<=0:continue
    polygon=[]
    for a,c in zip(f,np.roll(f,-1)):
        da,dc=DS[groups[[a,c]]]
        if da>=0:polygon.append(int(a))
        if da*dc<0:polygon.append(split_edge(int(a),int(c)))
    assert len(polygon)in(3,4)
    for k in range(1,len(polygon)-1):outFaces.append([polygon[0],polygon[k],polygon[k+1]]);parents.append(fi)
    cut+=1
attrs={k:np.array(v)for k,v in values.items()};FF=np.array(outFaces,dtype=np.int64)
world=(attrs['POSITION']@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]
normal=(attrs['NORMAL']@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];normal/=np.linalg.norm(normal,axis=1)[:,None]
used=np.unique(FF);QU,first,inv=np.unique(world[used],axis=0,return_index=True,return_inverse=True)
lookup=np.full(len(world),-1,int);lookup[used]=inv;physical=lookup[FF]
edges=collections.defaultdict(list)
for fi,f in enumerate(physical):
    for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append((fi,int(a),int(c)))
boundary=[v[0][1:]for v in edges.values()if len(v)==1];assert len(boundary)==162,len(boundary)
succ={a:c for a,c in boundary};assert len(succ)==len(boundary)
order=[min(succ)]
while succ[order[-1]]!=order[0]:
    nxt=succ[order[-1]];assert nxt not in order;order.append(nxt)
assert len(order)==162
representatives=used[first[np.array(order)]];Q=QU[order];QN=normal[representatives]
assert abs((Q-C)@TA).max()<1e-8
# A real section centroid and native side-surface tangent define an aligned continuation.
U0=np.array([1.,0,0])-TA*TA[0];U0/=np.linalg.norm(U0);V0=np.cross(TA,U0)
xy=(Q-C)@np.column_stack([U0,V0]);cr=xy[:,0]*np.roll(xy[:,1],-1)-xy[:,1]*np.roll(xy[:,0],-1);area=cr.sum()/2
assert abs(area)>1e-5
centerXY=((xy+np.roll(xy,-1,axis=0))*cr[:,None]).sum(0)/(6*area);HC=C+U0*centerXY[0]+V0*centerXY[1]
derivative=TA[None]-QN*(QN@TA)[:,None];axial=derivative@TA;assert axial.min()>.8
endDerivative=derivative/axial[:,None];height=.040;bottom=HC-height*TA+(Q-HC)*1.05
n=len(Q);nr=28;EP=[];EU=[]
arc=np.r_[0,np.cumsum(np.linalg.norm(np.roll(Q,-1,axis=0)-Q,axis=1))];u=arc/arc[-1]
for row,t in enumerate(np.linspace(0,1,nr)):
    h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t
    ring=h00*bottom+h10*height*TA+h01*Q+h11*height*endDerivative
    EP.extend(np.vstack([ring,ring[0]]));EU.extend(np.column_stack([.03+.94*u,np.full(n+1,.03+.70*t)]))
EP=np.array(EP);EU=np.array(EU);EF=[]
for row in range(nr-1):
    for k in range(n):
        a=row*(n+1)+k;c=a+1;d=c+n+1;e=a+n+1;EF.extend([[a,c,d],[a,d,e]])
EF=np.array(EF,dtype=np.int64);tri=EP[EF];gn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);EN=np.zeros_like(EP)
for k in range(3):np.add.at(EN,EF[:,k],gn)
EN=EN.reshape(nr,n+1,3);EN[:,0]+=EN[:,-1];EN[:,-1]=EN[:,0];EN=EN.reshape(-1,3);EN/=np.linalg.norm(EN,axis=1)[:,None]
EN[(nr-1)*(n+1):]=np.vstack([QN,QN[0]])
# Separate planar cap corners retain a proper hard normal and reserved unique chart.
base=len(EP);EP=np.vstack([EP,bottom,HC-height*TA]);EN=np.vstack([EN,np.tile(-TA,(n+1,1))]);radius=np.max(np.linalg.norm(xy-centerXY,axis=1));capUV=np.array([.5,.87])+(xy-centerXY)/radius*.09;EU=np.vstack([EU,capUV,[.5,.87]])
cap=np.array([[base+n,base+(k+1)%n,base+k]for k in range(n)],dtype=np.int64);EF=np.vstack([EF,cap])
capGN=np.cross(EP[cap[:,1]]-EP[cap[:,0]],EP[cap[:,2]]-EP[cap[:,0]]);assert np.all(capGN@(-TA)>0),'Section is not star-shaped for a fan cap'
LP=np.array([local_position(p)for p in EP]);LN=(EN[:,[0,2,1]]*[1,1,-1])@M[:3,:3];LN/=np.linalg.norm(LN,axis=1)[:,None]
for k,index in enumerate(representatives):
    LP[(nr-1)*(n+1)+k]=attrs['POSITION'][index];LN[(nr-1)*(n+1)+k]=attrs['NORMAL'][index]
LP[nr*(n+1)-1]=LP[(nr-1)*(n+1)];LN[nr*(n+1)-1]=LN[(nr-1)*(n+1)]
newAttrs={}
for name,value in attrs.items():newAttrs[name],b=append_accessor(j,b,value.astype('float32'),'VEC'+str(value.shape[1]),34962)
pr['attributes']=newAttrs;pr['indices'],b=append_accessor(j,b,FF.astype('uint32'),'SCALAR',34963)
mi=len(j['materials']);j['materials'].append({'name':'Green aligned wrist154 diagnostic skin','pbrMetallicRoughness':{'baseColorFactor':[.56,.30,.19,1],'roughnessFactor':.60,'metallicFactor':0},'doubleSided':False})
ext={}
for key,value,kind in [('POSITION',LP,'VEC3'),('NORMAL',LN,'VEC3'),('TEXCOORD_0',EU,'VEC2')]:ext[key],b=append_accessor(j,b,value.astype('float32'),kind,34962)
ix,b=append_accessor(j,b,EF.astype('uint32'),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':ext,'indices':ix,'material':mi,'mode':4})
out=R/'Green_grip_wrist154.glb';write_glb(out,j,b)
assert all(np.array_equal(attrs[k][:len(v)].astype('float32'),v.astype('float32'))for k,v in original.items())
monotone=float(abs((EP[:nr*(n+1)]-HC)@TA-np.repeat(np.linspace(-height,0,nr),n+1)).max())
rep={'source_hand_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_placement_sha256':hashlib.sha256((R/'Green_grip_case143_pose.glb').read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_attribute_prefix_exact':True,'cut_source_faces':cut,'retained_clipped_hand_triangles':len(FF),'extension_triangles':len(EF),'section_vertices':n,'section_origin_world':C.tolist(),'section_area_center_world':HC.tolist(),'distal_axis_world':TA.tolist(),'extension_height_m':height,'proximal_radius_factor':1.05,'axial_monotonicity_error_m':monotone,'endpoint_tangent_axial_denominator_min':float(axial.min()),'minimum_new_triangle_area_m2':float(np.linalg.norm(np.cross(EP[EF[:,1]]-EP[EF[:,0]],EP[EF[:,2]]-EP[EF[:,0]]),axis=1).min()/2),'status':'Unadopted skin continuation. Distal grip remains held; exact self/seam/contact and appearance checks are required. New extension chart/material are diagnostic and need their own paint/UV/tangent proof.'}
(R/'audit/grip_wrist154.json').write_text(json.dumps(rep,indent=2));np.savez_compressed(R/'audit/grip_wrist154_binding.npz',retained_source_faces=np.array(parents),section_world=Q,section_local=attrs['POSITION'][representatives],section_normal_world=QN,extension_world=EP,extension_triangles=EF,section_native_UV=attrs['TEXCOORD_0'][representatives]);print(rep,flush=True)
