"""Measure the exact retained arm root and true wrist-axis sleeve support."""
import pathlib,json,hashlib,collections,numpy as np
from scipy.spatial.transform import Rotation
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_body151.glb';j,b,A=read_glb(src)
node=j['nodes'][0];M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
CG=np.array([[1.,0,0],[0,0,-1],[0,1,0]])
pr=j['meshes'][0]['primitives'][6];P=A(pr['attributes']['POSITION']).astype(float);N=A(pr['attributes']['NORMAL']).astype(float);F=A(pr['indices']).astype(np.int64).reshape(-1,3)
W=(P@M[:3,:3].T+M[:3,3])@CG.T;WN=(N@np.linalg.inv(M[:3,:3]))@CG.T;WN/=np.linalg.norm(WN,axis=1)[:,None]
U,first,g=np.unique(W,axis=0,return_index=True,return_inverse=True);edges=collections.defaultdict(list)
for fi,f in enumerate(g[F]):
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append((fi,int(a),int(c)))
boundary=[v[0]for v in edges.values()if len(v)==1 and abs(U[list(v[0][1:]),2]-.16).max()<1e-6]
assert len(boundary)==142,len(boundary)
succ={c:a for _,a,c in boundary};support={(c,a):fi for fi,a,c in boundary};order=[min(succ)]
while succ[order[-1]]!=order[0]:
 nxt=succ[order[-1]];assert nxt not in order;order.append(nxt)
assert len(order)==142
Q=U[order];ids=first[order];SN=WN[ids];SF=np.array([support[(a,c)]for a,c in zip(order,np.roll(order,-1))]);tri=W[F[SF]];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);GN/=np.linalg.norm(GN,axis=1)[:,None]
fit=json.loads((R/'audit/grip_fit143.json').read_text());prox=np.array(fit['native_forearm_proximal_world']);axis=-prox;wrist=np.array(fit['wrist_world']);con=np.cross(GN,np.roll(Q,-1,axis=0)-Q);con/=np.linalg.norm(con,axis=1)[:,None]
stored=axis-SN*(SN@axis)[:,None];storedDot=stored@axis
q=np.linalg.norm(np.roll(Q,-1,axis=0)-Q,axis=1)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'physical_root_edges':len(Q),'geometric_conormal_forward_min':float((con@axis).min()),'geometric_conormal_forward_max':float((con@axis).max()),'stored_normal_projected_axis_min':float(storedDot.min()),'edge_length_min_max_m':[float(q.min()),float(q.max())],'source_root_center_world':Q.mean(0).tolist(),'proximal_axis_world':prox.tolist(),'wrist_world':wrist.tolist(),'status':'Measured support only, no construction or appearance clearance.'}
(R/'audit/grip_sleeve158.json').write_text(json.dumps(report,indent=2));np.savez_compressed(R/'audit/grip_sleeve158_binding.npz',root_world=Q,root_local=P[ids],root_normal_world=SN,root_normal_local=N[ids],root_support_face_ids=SF,root_support_triangles=tri,root_support_corner_normals=WN[F[SF]],root_geometric_normal=GN,root_forward_conormal=con,node_matrix=M)
print(report,flush=True)
