import pathlib,json,hashlib
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_case143_pose.glb';j,b,A=read_glb(src)
assert all(not n.get('children')for n in j['nodes']);assert j['nodes'][0]['mesh']==0
assert sorted(n['mesh']for n in j['nodes'])==list(range(len(j['meshes'])))
held=j['nodes'][1:];j['nodes']=held;j['meshes']=j['meshes'][1:]
for n in j['nodes']:n['mesh']-=1
for scene in j['scenes']:scene['nodes']=[i-1 for i in scene['nodes']if i!=0]
out=R/'Green_props160_placed.glb';write_glb(out,j,b)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_hand_removed':True,'all_prop_buffers_transforms_materials_held':True,'triangles':sum(len(A(p['indices']))//3 for m in j['meshes']for p in m['primitives']),'status':'Exact placed handle/case component, with the old hand excluded for154 integration.'}
(R/'audit/props160_placed.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
