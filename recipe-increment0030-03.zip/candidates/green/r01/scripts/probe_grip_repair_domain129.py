"""Propose bounded body-side bridge repair domains; report exact welded boundary topology."""
import pathlib,json,hashlib,numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_sleeve75_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);F=A(pr['indices']).reshape(-1,3);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);W=(P*scale+translation)[:,[0,2,1]]*[1,-1,1];Q,g=np.unique(P,axis=0,return_inverse=True);QW=(Q*scale+translation)[:,[0,2,1]]*[1,-1,1];G=g[F];mid=W[F].mean(1);arm=np.zeros(len(F),bool);arm[np.load(R/'audit/grip_ownership125.npz')['selected_faces']]=True;edges={}
for fi,f in enumerate(G):
 for a,bb in zip(f,np.roll(f,-1)):edges.setdefault(tuple(sorted((int(a),int(bb)))),[]).append(fi)
reports=[];bindings={}
for trial,(yl,yh,zl,zh,xmin)in enumerate([(.072,.148,.003,.157,.245),(.063,.157,-.005,.157,.245),(.055,.165,-.010,.158,.24)]):
 patch=(mid[:,0]>xmin)&(mid[:,1]>yl)&(mid[:,1]<yh)&(mid[:,2]>zl)&(mid[:,2]<zh)&~arm;selected=arm|patch;boundary=[];nonman=[]
 for edge,faces in edges.items():
  states=selected[faces]
  if states.any()and(~states).any():
   boundary.append(edge)
   if len(faces)!=2:nonman.append({'edge':edge,'faces':faces,'selected':states.tolist()})
 E=np.array(boundary);vs,inv=np.unique(E,return_inverse=True);e=inv.reshape(-1,2);rr=np.r_[e[:,0],e[:,1]];cc=np.r_[e[:,1],e[:,0]];nc,labels=connected_components(coo_matrix((np.ones(len(rr)),(rr,cc)),shape=(len(vs),len(vs))),directed=False);deg=np.bincount(e.ravel(),minlength=len(vs));loops=[]
 for k in range(nc):
  take=labels==k;pts=QW[vs[take]];loops.append({'component':k,'vertices':int(take.sum()),'degree_histogram':{str(x):int((deg[take]==x).sum())for x in np.unique(deg[take])},'bounds_world':[pts.min(0).tolist(),pts.max(0).tolist()]})
 reports.append({'trial':trial,'domain_yz_xmin':[yl,yh,zl,zh,xmin],'body_faces':int(patch.sum()),'arm_faces':int(arm.sum()),'boundary_components':loops,'nonmanifold_boundary_edges':nonman});bindings[f'trial{trial}_body_faces']=np.flatnonzero(patch);bindings[f'trial{trial}_selected_faces']=np.flatnonzero(selected);bindings[f'trial{trial}_boundary_edges_world']=QW[E]
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'trials':reports,'status':'Topology-only bounded domain proposals; no shape edit or source deletion. Arm root is still the original triangle selection and must be clipped at the measured plane. Body boundaries need ordered projection and source-surface support checks.'};(R/'audit/grip_repair_domain129.json').write_text(json.dumps(rep,indent=2));np.savez_compressed(R/'audit/grip_repair_domain129.npz',**bindings);print([{k:v for k,v in r.items()if k!='nonmanifold_boundary_edges'}|{'nonmanifold_boundary_edges':len(r['nonmanifold_boundary_edges'])}for r in reports],flush=True)
