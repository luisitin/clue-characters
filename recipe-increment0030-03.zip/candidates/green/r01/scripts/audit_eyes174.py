import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_grip_sleeve162.py').read_text()
code=code.replace('Green_grip_context161','Green_full_context173_fp32').replace("new=(own[:,0]==0)&np.isin(own[:,1],[8,9])","new=(own[:,0]==len(j['nodes'])-1)")
code=code.replace('grip_sleeve162_v4.json','eyes174_v4.json').replace('sleeve','eye').replace('Every new159wool/knit/lining triangle against exact assembly161 conservative AABB targets.','Every transferred eye60 triangle against exact assembly173 conservative AABB targets, after explicit source float32 position encoding.')
exec(compile(code,'audit_eyes174','exec'))
