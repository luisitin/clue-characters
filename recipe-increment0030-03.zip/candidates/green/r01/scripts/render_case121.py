import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/render_exact.py').read_text()
extra="""
regions['case_context112']=((.375,.065,-.34),.64,-11,.04)
regions['case_front112']=((.375,.065,-.43),.56,270,.04)
regions['case_back112']=((.375,.065,-.43),.56,90,.04)
regions['case_top112']=((.375,.065,-.29),.54,-11,50)
regions['case_under112']=((.375,.065,-.58),.54,-11,-50)
regions['case_frontcorner121']=((.326,-.131,-.304),.085,235,1.2)
regions['case_catch121']=((.350,-.088,-.285),.085,-11,3)
regions['case_catch_opposite121']=((.350,.218,-.285),.085,169,3)
"""
assert code.count('target,scale,angle,elev=regions[tag];')==1
code=code.replace('target,scale,angle,elev=regions[tag];',extra+'target,scale,angle,elev=regions[tag];');exec(compile(code,'render_case121','exec'))
