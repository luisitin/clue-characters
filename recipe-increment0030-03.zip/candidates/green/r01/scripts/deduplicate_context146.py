"""Share duplicate encoded images, preserving both core and observed extension image bindings."""
import pathlib,json,hashlib,copy
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_context144.glb';j,b,A=read_glb(src);old=copy.deepcopy(j);images=[];mapping={};seen={};hashes=[]
for i,im in enumerate(j.get('images',[])):
 assert 'bufferView'in im;v=j['bufferViews'][im['bufferView']];data=bytes(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]);digest=hashlib.sha256(data).hexdigest();key=(im.get('mimeType'),digest)
 if key not in seen:seen[key]=len(images);images.append(im)
 mapping[i]=seen[key];hashes.append(digest)
bindings=[]
for ti,t in enumerate(j.get('textures',[])):
 targets=[]
 if'source'in t:targets.append(('core',t))
 for name,ex in t.get('extensions',{}).items():
  assert name in ['EXT_texture_webp','KHR_texture_basisu','MSFT_texture_dds'],('Unknown texture image extension',name)
  assert'source'in ex;targets.append((name,ex))
 assert targets
 for name,obj in targets:
  before=hashes[obj['source']];obj['source']=mapping[obj['source']];bindings.append({'texture':ti,'binding':name,'encoded_image_sha256':before})
j['images']=images;out=R/'Green_grip_context146.glb';write_glb(out,j,b);jj,bb,B=read_glb(out);assert bytes(bb)==bytes(b)
for row in bindings:
 t=jj['textures'][row['texture']];obj=t if row['binding']=='core'else t['extensions'][row['binding']];im=jj['images'][obj['source']];v=jj['bufferViews'][im['bufferView']];assert hashlib.sha256(bb[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]).hexdigest()==row['encoded_image_sha256']
for key in ['nodes','scenes','meshes','materials','accessors','bufferViews','samplers']:assert old.get(key)==jj.get(key),key
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'old_image_count':len(old['images']),'new_image_count':len(images),'all_geometry_corner_attributes_material_definitions_node_transforms_exact':True,'BIN_bytes_exact':True,'active_texture_bindings':bindings,'status':'Unapproved assembly-context image deduplication. The right lower sleeve/skin continuation are intentionally absent in this placement study; this is not the complete-character candidate.'};(R/'audit/context146.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
