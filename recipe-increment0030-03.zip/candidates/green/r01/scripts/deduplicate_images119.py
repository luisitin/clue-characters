"""Deduplicate identical encoded images without touching primitive/material semantics."""
import pathlib,json,hashlib,copy
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_case116.glb';j,b,A=read_glb(src);old=copy.deepcopy(j);images=[];mapping={};seen={};hashes=[]
for i,im in enumerate(j.get('images',[])):
 assert 'bufferView'in im and not im.get('extensions');v=j['bufferViews'][im['bufferView']];data=bytes(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]);digest=hashlib.sha256(data).hexdigest();key=(im.get('mimeType'),digest)
 if key not in seen:seen[key]=len(images);images.append(im)
 mapping[i]=seen[key];hashes.append(digest)
before=[]
for t in j.get('textures',[]):
 assert 'source'in t and not t.get('extensions');before.append(hashes[t['source']]);t['source']=mapping[t['source']]
j['images']=images;out=R/'Green_grip_case119.glb';write_glb(out,j,b);jj,bb,B=read_glb(out);assert bytes(bb)==bytes(b);after=[]
for t in jj['textures']:
 im=jj['images'][t['source']];v=jj['bufferViews'][im['bufferView']];after.append(hashlib.sha256(bb[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]).hexdigest())
assert before==after
for key in ['nodes','scenes','meshes','materials','accessors','bufferViews','samplers']:assert old.get(key)==jj.get(key),key
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'old_image_count':len(old['images']),'new_image_count':len(images),'all_texture_encoded_image_hashes_exact':before==after,'all_geometry_corner_attributes_material_definitions_node_transforms_exact':True,'BIN_bytes_exact':True,'image_index_mapping':mapping,'status':'Image deduplication only. Old unused encoded bytes remain in BIN for exact source preservation; active samplers/materials/maps are unchanged.'};(R/'audit/image_dedup119.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
