"""Lossless referenced-data repack. Preserve raw accessor scalars and image bytes."""
import pathlib,sys,json,copy,hashlib,numpy as np
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];stem=sys.argv[1];dststem=sys.argv[2];src=R/(stem+'.glb');old,ob,A=read_glb(src);j=copy.deepcopy(old);buf=b'';j['bufferViews']=[];j['accessors']=[];j['materials']=[];j['textures']=[];j['images']=[]
assert not any(old.get(k)for k in ['skins','animations']);assert all(not n.get('weights')for n in old['nodes']);ac={};mc={};tc={};ic={};imageHashes={};checks=[]
def view(data,target=None):
 global buf
 buf+=b'\0'*((-len(buf))%4);v={'buffer':0,'byteOffset':len(buf),'byteLength':len(data)}
 if target is not None:v['target']=target
 index=len(j['bufferViews']);j['bufferViews'].append(v);buf+=data;return index
def accessor(index):
 if index in ac:return ac[index]
 a=old['accessors'][index];assert not a.get('sparse');v=old['bufferViews'][a['bufferView']];dtype={5126:'<f4',5125:'<u4',5123:'<u2',5121:'u1',5122:'<i2',5120:'i1'}[a['componentType']];dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];size=np.dtype(dtype).itemsize;raw=np.ndarray((a['count'],dim),dtype=dtype,buffer=ob,offset=v.get('byteOffset',0)+a.get('byteOffset',0),strides=(v.get('byteStride',dim*size),size)).copy().tobytes();aa=copy.deepcopy(a);aa['bufferView']=view(raw,v.get('target'));aa.pop('byteOffset',None);out=len(j['accessors']);j['accessors'].append(aa);ac[index]=out;checks.append({'source':index,'output':out,'raw_scalar_sha256':hashlib.sha256(raw).hexdigest()});return out
def image(index):
 if index in ic:return ic[index]
 im=old['images'][index];assert'bufferView'in im;v=old['bufferViews'][im['bufferView']];raw=bytes(ob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]);key=(im.get('mimeType'),hashlib.sha256(raw).hexdigest())
 if key in imageHashes:ic[index]=imageHashes[key];return ic[index]
 out=len(j['images']);new=copy.deepcopy(im);new['bufferView']=view(raw);j['images'].append(new);ic[index]=out;imageHashes[key]=out;return out
def texture(index):
 if index in tc:return tc[index]
 t=copy.deepcopy(old['textures'][index])
 if'source'in t:t['source']=image(t['source'])
 for name,extension in t.get('extensions',{}).items():
  assert name in ['EXT_texture_webp','KHR_texture_basisu','MSFT_texture_dds'];extension['source']=image(extension['source'])
 out=len(j['textures']);j['textures'].append(t);tc[index]=out;return out
def material(index):
 if index in mc:return mc[index]
 m=copy.deepcopy(old['materials'][index])
 def walk(obj):
  if isinstance(obj,dict):
   for key,val in obj.items():
    if key.endswith('Texture')and isinstance(val,dict)and'index'in val:val['index']=texture(val['index'])
    else:walk(val)
  elif isinstance(obj,list):
   for val in obj:walk(val)
 walk(m);out=len(j['materials']);j['materials'].append(m);mc[index]=out;return out
for mesh in j['meshes']:
 for p in mesh['primitives']:
  assert not p.get('targets')and not p.get('extensions');p['attributes']={k:accessor(v)for k,v in p['attributes'].items()};p['indices']=accessor(p['indices']);p['material']=material(p['material'])
out=R/(dststem+'.glb');write_glb(out,j,buf);new,nb,B=read_glb(out)
for row in checks:
 assert np.array_equal(A(row['source']),B(row['output'])),row
assert old['nodes']==new['nodes']and old['scenes']==new['scenes'];triangles=sum(new['accessors'][p['indices']]['count']//3 for m in new['meshes']for p in m['primitives'])
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_bytes':src.stat().st_size,'candidate_bytes':out.stat().st_size,'triangles':triangles,'all_referenced_accessor_raw_scalar_bytes_preserved':True,'node_scene_transforms_exact':True,'accessors':checks,'encoded_images':[{'mimeType':k[0],'sha256':k[1],'output':v}for k,v in imageHashes.items()],'scope':'Referenced-data repack only; numeric accessors, corner ordering, active material semantics and image bytes held. No geometry or appearance improvement claimed.'};(R/'audit'/(dststem+'_repack.json')).write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k not in ['accessors','encoded_images']},flush=True)
