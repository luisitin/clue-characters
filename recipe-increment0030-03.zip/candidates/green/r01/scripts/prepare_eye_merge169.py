"""Transfer held eye60 into current body by exact source-index provenance."""
import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];body=R/'Green_grip_context168_compact.glb';eye=R/'Green_physical_eyes60_clean_paint_body.glb';source=R/'Green_sleeve38_body.glb'
j,b,A=read_glb(body);e,eb,E=read_glb(eye);s,sb,S=read_glb(source);bp=j['meshes'][0]['primitives'][0];ep=e['meshes'][0]['primitives'][0];sp=s['meshes'][0]['primitives'][0]
for name in ['POSITION','NORMAL','TEXCOORD_0']:assert np.array_equal(A(bp['attributes'][name]),E(ep['attributes'][name]))and np.array_equal(E(ep['attributes'][name]),S(sp['attributes'][name])),name
assert j['nodes'][0]==e['nodes'][0]
sourceF=S(sp['indices']).astype(np.int64).reshape(-1,3);eyeF=E(ep['indices']).astype(np.int64).reshape(-1,3);held={tuple(f)for f in eyeF};removed={tuple(f)for f in sourceF if tuple(f)not in held};assert len(removed)==529
bodyF=A(bp['indices']).astype(np.int64).reshape(-1,3);drop=np.array([tuple(f)in removed for f in bodyF]);assert drop.sum()==529
P=A(bp['attributes']['POSITION']);node=j['nodes'][0];world=(P[np.unique(bodyF[drop])]*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];assert world[:,2].min()>.65
bp['indices'],b=append_accessor(j,b,bodyF[~drop].astype('uint32'),'SCALAR',34963);cut=R/'Green_eye_cut169_body.glb';write_glb(cut,j,b)
e['meshes']=[{'name':'Held Green eye60 components','primitives':copy.deepcopy(e['meshes'][0]['primitives'][5:11])}];e['nodes']=[copy.deepcopy(e['nodes'][0])];e['nodes'][0]['mesh']=0;e['scenes']=[{'nodes':[0]}];e['scene']=0;out=R/'Green_eyes169_raw_component.glb';write_glb(out,e,eb)
report={'body_source_sha256':hashlib.sha256(body.read_bytes()).hexdigest(),'eye_source_sha256':hashlib.sha256(eye.read_bytes()).hexdigest(),'body_cut_sha256':hashlib.sha256(cut.read_bytes()).hexdigest(),'eye_component_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_original_triangle_records':529,'source_head_attribute_arrays_exact':True,'source_node_transform_exact':True,'removed_world_bounds':[world.min(0).tolist(),world.max(0).tolist()],'transferred_primitives':[5,6,7,8,9,10],'status':'Held eye50 geometry plus60 paint transferred exactly; final assembled eye/body appearance and bounded geometric regression still pending. Other source head/skin defects remain.'};(R/'audit/eye_merge169.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
