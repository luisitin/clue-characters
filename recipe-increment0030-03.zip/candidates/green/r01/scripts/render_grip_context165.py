import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/render_exact.py').read_text()
extra="""
regions['grip_cuff165_front']=((.365,.143,.09),.28,-11,.02)
regions['grip_cuff165_opposite']=((.365,.143,.09),.28,169,.02)
regions['grip_cuff165_under']=((.372,.139,.041),.19,79,-3)
regions['grip_cuff165_side']=((.365,.143,.09),.28,79,.02)
"""
assert code.count('target,scale,angle,elev=regions[tag];')==1
code=code.replace('target,scale,angle,elev=regions[tag];',extra+'target,scale,angle,elev=regions[tag];')
exec(compile(code,'render_grip_context165','exec'))
