"""Independently compare actual merged corner attributes and material/image semantics."""
import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];dst=R/'Green_full_context170.glb';j,b,A=read_glb(dst)
def semantics(j,b,material):
 m=copy.deepcopy(j['materials'][material])
 def tex(index):
  t=copy.deepcopy(j['textures'][index])
  def im(i):
   a=j['images'][i];v=j['bufferViews'][a['bufferView']];return {'mimeType':a.get('mimeType'),'encoded_sha256':hashlib.sha256(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]).hexdigest()}
  if'source'in t:t['source']=im(t['source'])
  if'sampler'in t:t['sampler']=j['samplers'][t['sampler']]
  for ex in t.get('extensions',{}).values():
   if'source'in ex:ex['source']=im(ex['source'])
  return t
 def walk(obj):
  if isinstance(obj,dict):
   for k,v in obj.items():
    if k.endswith('Texture')and isinstance(v,dict)and'index'in v:v['index']=tex(v['index'])
    else:walk(v)
  elif isinstance(obj,list):
   for v in obj:walk(v)
 walk(m);return m
rows=[];nodeOffset=0
for stem in ['Green_eye_cut169_body','Green_eyes169_component']:
 p=R/(stem+'.glb');s,sb,S=read_glb(p);triangles=0;primcount=0
 for ni,node in enumerate(s['nodes']):
  current=j['nodes'][nodeOffset+ni];aa=copy.deepcopy(node);bb=copy.deepcopy(current);aa.pop('mesh',None);bb.pop('mesh',None);assert aa==bb
  if'mesh'not in node:continue
  oldpr=s['meshes'][node['mesh']]['primitives'];newpr=j['meshes'][current['mesh']]['primitives'];assert len(oldpr)==len(newpr)
  for sourcePr,destPr in zip(oldpr,newpr):
   ff=S(sourcePr['indices']).astype(np.int64).reshape(-1,3);gg=A(destPr['indices']).astype(np.int64).reshape(-1,3);assert np.array_equal(ff,gg);assert sourcePr['attributes'].keys()==destPr['attributes'].keys()
   for key in sourcePr['attributes']:assert np.array_equal(S(sourcePr['attributes'][key])[ff],A(destPr['attributes'][key])[gg]),(stem,ni,key)
   assert semantics(s,sb,sourcePr['material'])==semantics(j,b,destPr['material']);triangles+=len(ff);primcount+=1
 rows.append({'source':stem,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nodes':len(s['nodes']),'primitives':primcount,'triangles':triangles,'all_ordered_corner_attributes_indices_material_semantics_and_active_encoded_maps_exact':True});nodeOffset+=len(s['nodes'])
assert nodeOffset==len(j['nodes']);report={'candidate_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'components':rows,'triangle_total':sum(x['triangles']for x in rows),'scope':'Actual final-byte source-to-assembly P/N/UV/T corner comparison, topology order, transforms and canonical material/active-image semantics. This is transfer fidelity, not shape or appearance acceptance.'};(R/'audit/context_equivalence171.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
