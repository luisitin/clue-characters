import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parents[1]
for side in ['R','L']:
 env=dict(os.environ,SIDE=side)
 with (r/'checks'/f'cuff37_{side}_audit.log').open('w')as f:subprocess.run(['flock',os.environ.get('CHARACTER_BUILD_LOCK','/tmp/character-build-heavy.lock'),'bash','-c','date -u +START_%FT%TZ; "$@"; s=$?; date -u +END_%FT%TZ; exit $s','white_cuff37','python',str(r/'scripts/audit_cuff37.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
