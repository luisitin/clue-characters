"""Bounded source cut study: retain raw-face provenance, widen past old skin and folded cuffs."""
import pathlib,os,json,numpy as np,collections
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','left');sgn=-1 if side=='left' else 1;s=np.load(r/'checks'/f'source01_{side}.npz');P=s['P'];F=s['F'];W=s['W'];raw=s['raw_face_ids'];U,iv=np.unique(P,axis=0,return_inverse=True);G=iv[F];C=W[F].mean(1);center=np.array([sgn*.345,.02,.276]);axis=np.array([-sgn*.8,0,-.6]);d=(W-center)@axis
selected=(d[F].max(1)>-.03)&(C[:,0]*sgn>.17)&(C[:,2]>.10)&(C[:,2]<.365)&(C[:,1]<.15)&(C[:,1]>-.15)&((C[:,2]<.275)|(C[:,0]*sgn>.25))
edges={};vf=collections.defaultdict(set)
for fi,face in enumerate(G):
 for v in face:vf[int(v)].add(fi)
 for a,b in zip(face,np.roll(face,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
bound=[e for e,fs in edges.items()if any(selected[fs])and not all(selected[fs])];front=set(v for e in bound for v in e);candidates=set()
for _ in range(3):
 new=set(f for v in front for f in vf[v]);candidates|=new;front=set(v for f in new for v in G[f])
varfaces=sorted(candidates);fiid={f:i for i,f in enumerate(varfaces)};active=[(e,fs)for e,fs in edges.items()if any(f in candidates for f in fs)or(any(selected[fs])and not all(selected[fs]))];verts=sorted(set(v for e,fs in active for v in e));vid={v:i for i,v in enumerate(verts)};nf=len(varfaces);ne=len(active);nv=len(verts);n=nf+2*ne+nv;rr=[];cc=[];vv=[];lo=[];hi=[]
def row(entries,l,h):
 k=len(lo);lo.append(l);hi.append(h)
 for j,v in entries:rr.append(k);cc.append(j);vv.append(v)
ved=collections.defaultdict(list)
for i,(e,fs)in enumerate(active):
 a=nf+i;y=nf+ne+i;fixed=sum(selected[f] for f in fs if f not in fiid);var=[(fiid[f],1)for f in fs if f in fiid];row(var+[(a,-len(fs)),(y,1)],-fixed,-fixed);row([(a,1),(y,-1)],0,np.inf);row(var+[(a,-1)],-fixed,np.inf)
 for v in e:ved[v].append(y)
for v in verts:row([(j,1)for j in ved[v]]+[(nf+2*ne+vid[v],-2)],0,0)
area=np.linalg.norm(np.cross(W[F[:,1]]-W[F[:,0]],W[F[:,2]]-W[F[:,0]]),axis=1)*.5;cost=np.zeros(n);cost[:nf]=(1-2*selected[varfaces].astype(float))*(1+area[varfaces]/max(float(np.median(area[varfaces])),1e-10));A=coo_matrix((vv,(rr,cc)),shape=(len(lo),n)).tocsc();print({'side':side,'candidate_faces':nf,'variables':n,'initial_faces':int(selected.sum())},flush=True);res=milp(cost,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(A,np.array(lo),np.array(hi)),options={'time_limit':60,'mip_rel_gap':0});report={'side':side,'solver_status':int(res.status),'solver_message':res.message,'success':bool(res.success),'scope':'Unpromoted source-domain study, wider at old skin/cuffs. No held model changed.'}
if res.x is not None:
 added=np.array([f for f,i in fiid.items()if res.x[i]>.5 and not selected[f]],int);removed=np.array([f for f,i in fiid.items()if res.x[i]<.5 and selected[f]],int);assert np.all(abs(res.x-np.rint(res.x))<1e-5);chosen=selected.copy();chosen[added]=True;chosen[removed]=False;boundary=[e for e,fs in edges.items()if any(chosen[fs])and not all(chosen[fs])];deg=collections.Counter(v for e in boundary for v in e);assert set(deg.values())=={2};assert all(sum(not chosen[f]for f in edges[e])==1 for e in boundary);adj=collections.defaultdict(list)
 for a,b in boundary:adj[a].append(b);adj[b].append(a)
 left=set(adj);loops=[]
 while left:
  start=min(left);loop=[start];prev=None;cur=start
  while True:
   nxt=next(v for v in adj[cur]if v!=prev)
   if nxt==start:break
   assert nxt not in loop;loop.append(nxt);prev,cur=cur,nxt
  left-=set(loop);loops.append(loop)
 UW=(U*s['node_scale']+s['node_translation'])[:,[0,2,1]]*[1,-1,1];report.update({'selected_faces':int(chosen.sum()),'retreated_faces':len(removed),'added_faces':len(added),'boundary_degree_two':True,'one_retained_face_per_edge':True,'interfaces':[{'vertices':len(l),'center':UW[l].mean(0).tolist(),'min':UW[l].min(0).tolist(),'max':UW[l].max(0).tolist()}for l in loops]});np.savez_compressed(r/'checks'/f'domain32_{side}.npz',selected_faces=np.flatnonzero(chosen),raw_ids=raw[chosen],added_faces=added,retreated_faces=removed,boundary_edges=np.array(boundary),loop_offsets=np.cumsum([0]+[len(l)for l in loops]),loop_vertices=np.concatenate(loops),unique_local_positions=U,unique_world_positions=UW)
(r/'checks'/f'domain32_{side}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
