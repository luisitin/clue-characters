"""Read-only selected/retained ownership and actual geometric seam direction checks."""
import pathlib,json,numpy as np,collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
r=pathlib.Path(__file__).resolve().parents[1];report={}
for side in ['left','right']:
 d=np.load(r/'checks'/f'domain32_{side}.npz');s=np.load(r/'checks'/f'source01_{side}.npz');rgb=np.load(r/'checks'/f'source03_{side}_colors.npz')['RGB'];F=s['F'];U,iv=np.unique(s['P'],axis=0,return_inverse=True);G=iv[F];mask=np.zeros(len(F),bool);mask[d['selected_faces']]=True;edges=collections.defaultdict(list)
 for fi,t in enumerate(G):
  for x,y in zip(t,np.roll(t,-1)):edges[tuple(sorted((int(x),int(y))))].append(fi)
 labels={};counts={}
 for state in [False,True]:
  pairs=np.array([(a,b)for fs in edges.values()for a in fs for b in fs if a<b and mask[a]==state and mask[b]==state],int);mat=coo_matrix((np.ones(len(pairs)),(pairs[:,0],pairs[:,1])),shape=(len(F),len(F)));_,labs=connected_components(mat,directed=False);labels[state]=labs;counts[state]=collections.Counter(labs[mask==state])
 tri=s['W'][F];N=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-20);loops=[]
 for k,(a,b)in enumerate(zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])):
  ids=d['loop_vertices'][a:b];P=d['unique_world_positions'][ids];held=[];gone=[]
  for x,y in zip(ids,np.roll(ids,-1)):
   fs=edges[tuple(sorted((int(x),int(y))))];held.extend(f for f in fs if not mask[f]);gone.extend(f for f in fs if mask[f])
  q={'loop':k,'vertices':len(ids),'center':P.mean(0).tolist(),'retained_rgb_mean':rgb[held].mean(0).tolist(),'retained_rgb_skin_like_count':int(((rgb[held,0]>rgb[held,1]*1.2)&(rgb[held,1]>rgb[held,2]*1.1)).sum()),'minimum_retained_outboard_normal_component':float((N[held,0]*(-1 if side=='left'else 1)).min()),'components':{}}
  for state,fs in [(False,held),(True,gone)]:
   groups=[]
   for lab in set(labels[state][fs]):
    use=np.flatnonzero((labels[state]==lab)&(mask==state));groups.append({'faces':len(use),'raw_ids':s['raw_face_ids'][use].tolist()if len(use)<500 else None,'rgb_mean':rgb[use].mean(0).tolist()})
   q['components']['selected'if state else'retained']=groups
  loops.append(q)
 report[side]={'loops':loops,'scope':'Read-only ownership. Small components are not automatically restored or deleted; actual source geometry/material remains the basis for any change.'}
(r/'checks/domains36_ownership.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
