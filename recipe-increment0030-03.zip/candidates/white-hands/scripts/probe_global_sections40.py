"""Read-only global source plane sections, separating relevant forearm component from other anatomy."""
import pathlib,numpy as np,json,collections
r=pathlib.Path(__file__).resolve().parents[1];pose=json.load((r/'checks/fist_seed25.json').open())['hands'];out={}
for side,hand,sgn in [('left','R',-1),('right','L',1)]:
 s=np.load(r/'checks'/f'source01_{side}.npz');d=np.load(r/'checks'/f'domain32_{side}.npz');loops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];L=next(l for l in loops if abs(d['unique_world_positions'][l].mean(0)[0])>.25);B=d['unique_world_positions'][L];C=B.mean(0);U,iv=np.unique(s['P'],axis=0,return_inverse=True);P=d['unique_world_positions'];G=iv[s['F']];axis=np.array(pose[hand]['forward']);axis/=np.linalg.norm(axis);u=np.array(pose[hand]['thumbward']);u-=axis*(u@axis);u/=np.linalg.norm(u);v=np.cross(axis,u);base=(P-C)@axis;mind=float(((B-C)@axis).min());reports=[];best=None
 for oi,offset in enumerate(mind-.001337-np.arange(0,.0161,.004)):
  D=base-offset;fs=np.flatnonzero((D[G].min(1)<0)&(D[G].max(1)>0));points={};segments=[];adj=collections.defaultdict(list)
  for fi in fs:
   cut=[]
   for x,y in zip(G[fi],np.roll(G[fi],-1)):
    if D[x]*D[y]<0:
     key=tuple(sorted((int(x),int(y))));a,b=key
     if key not in points:points[key]=P[a]+(P[b]-P[a])*(-D[a]/(D[b]-D[a]))
     cut.append(key)
   assert len(cut)==2;ei=len(segments);segments.append((cut[0],cut[1],int(fi)));adj[cut[0]].append((cut[1],ei));adj[cut[1]].append((cut[0],ei))
  remaining=set(adj);comps=[]
  while remaining:
   seed=min(remaining);verts=set();es=set();todo=[seed]
   while todo:
    a=todo.pop()
    if a in verts:continue
    verts.add(a)
    for b,ei in adj[a]:es.add(ei);todo.append(b)
   remaining-=verts;wp=np.array([points[k]for k in verts]);center=wp.mean(0)
   if center[0]*sgn<.20 or np.linalg.norm(center-C)>.15:continue
   degree=collections.Counter(len(adj[k])for k in verts);rep={'vertices':len(verts),'edges':len(es),'center':center.tolist(),'bounds':[wp.min(0).tolist(),wp.max(0).tolist()],'degree_histogram':dict(degree),'source_cut_raw_ids':s['raw_face_ids'][[segments[i][2]for i in sorted(es)]].tolist(),'simple':False}
   if set(degree)=={2}:
    start=min(verts);ll=[start];prev=None;cur=start
    while True:
     nxt=next(k for k,_ in adj[cur]if k!=prev)
     if nxt==start:break
     assert nxt not in ll;ll.append(nxt);prev,cur=cur,nxt
    assert len(ll)==len(verts);wp=np.array([points[k]for k in ll]);q=(wp-C)@np.array([u,v]).T;n=len(q);a=q;b=np.roll(q,-1,axis=0);ii,jj=np.triu_indices(n,2);keep=~((ii==0)&(jj==n-1));ii,jj=ii[keep],jj[keep]
    def cross(x,y):return x[:,0]*y[:,1]-x[:,1]*y[:,0]
    p1=cross(b[ii]-a[ii],a[jj]-a[ii]);p2=cross(b[ii]-a[ii],b[jj]-a[ii]);q1=cross(b[jj]-a[jj],a[ii]-a[jj]);q2=cross(b[jj]-a[jj],b[ii]-a[jj]);count=int(((p1*p2<-1e-22)&(q1*q2<-1e-22)).sum());rep['proper_projected_crossings']=count;rep['minimum_edge_m']=float(np.linalg.norm(b-a,axis=1).min());rep['simple']=count==0 and rep['minimum_edge_m']>1e-7
    if rep['simple'] and best is None:
     best={'plane':oi,'offset_m':float(offset),**rep};np.savez_compressed(r/'checks'/f'sleeve40_{side}.npz',C=C,axis=axis,offset=np.array(offset),loop_world_points=wp,loop_source_physical_edges=np.array(ll),cut_faces=np.array([segments[i][2]for i in sorted(es)]),cut_raw_ids=s['raw_face_ids'][[segments[i][2]for i in sorted(es)]],basis_u=u,basis_v=v,held_old_boundary_minimum_plane_coordinate=np.array(mind))
   comps.append(rep)
  reports.append({'offset_m':float(offset),'whole_source_cut_faces':len(fs),'relevant_components':comps})
 out[side]={'center':C.tolist(),'axis':axis.tolist(),'old_boundary_minimum_coordinate_m':mind,'best':best,'planes':reports,'scope':'Read-only whole-source section search. Projected simplicity does not establish safe clipping, exact stored-float segment contact or final skin/cloth clearance.'}
(r/'checks/sleeve40_global_search.json').write_text(json.dumps(out,indent=2));print({s:{'best':q['best'],'components':[[{k:v for k,v in z.items()if k!='source_cut_raw_ids'}for z in p['relevant_components']]for p in q['planes']]}for s,q in out.items()},flush=True)
