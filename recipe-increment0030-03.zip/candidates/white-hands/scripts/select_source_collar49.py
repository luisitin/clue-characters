"""Select a source collar annulus between exact old ownership and a conforming plane ring.
Candidate polygons are clipped original source triangles; no new body shape is invented.
"""
import pathlib,os,json,numpy as np,collections
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','left');hand='R'if side=='left'else'L';s=np.load(r/'checks'/f'source01_{side}.npz');d=np.load(r/'checks'/('domain41_left.npz'if side=='left'else'cuff37_L_final_source_domain.npz'));search=json.load((r/'checks/sleeve47_owned_search.json').open())[side];pi=3 if side=='left'else 4;offset=float(search['planes'][pi]['offset_m']);C=np.array(search['center']);axis=np.array(search['axis']);U,iv=np.unique(s['P'],axis=0,return_inverse=True);W=d['unique_world_positions'];F=s['F'];G=iv[F];raw=s['raw_face_ids'];chosen=np.zeros(len(F),bool);chosen[d['selected_faces']if side=='left'else d['removed_faces']]=True;oldloops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];oldroot=next(l for l in oldloops if abs(W[l].mean(0)[0])>.25);sourceedges=collections.defaultdict(list)
for fi,t in enumerate(G):
 for u,v in zip(t,np.roll(t,-1)):sourceedges[tuple(sorted((int(u),int(v))))].append((int(u),int(v),fi))
oldrequired={};heldSupport={}
for a,b in zip(oldroot,np.roll(oldroot,-1)):
 edge=tuple(sorted((int(a),int(b))));keep=[q for q in sourceedges[edge]if not chosen[q[2]]];assert len(keep)==1;u,v,fi=keep[0];oldrequired[edge]=-1 if u<v else 1;heldSupport[edge]=fi
D=(W-C)@axis-offset;assert D[oldroot].max()<0;points=list(W);intersection={};polys=[];bary=[];orig=[];areas=[];cutEdges=[];cutRaw=[]
def point_on_edge(a,b):
 edge=tuple(sorted((int(a),int(b))))
 if edge not in intersection:
  u,v=edge;t=-D[u]/(D[v]-D[u]);intersection[edge]=len(points);points.append(W[u]+(W[v]-W[u])*t)
 return intersection[edge]
for fi in np.flatnonzero(chosen&(D[G].min(1)<0)):
 seq=[];bc=[]
 for k in range(3):
  kk=(k+1)%3;a,b=G[fi,k],G[fi,kk];e=np.eye(3)[k];en=np.eye(3)[kk]
  if D[a]<0:seq.append(int(a));bc.append(e)
  if D[a]*D[b]<0:
   t=-D[a]/(D[b]-D[a]);seq.append(point_on_edge(a,b));bc.append((1-t)*e+t*en)
 if len(seq)<3:continue
 p=np.array([points[k]for k in seq]);area=sum(np.linalg.norm(np.cross(p[k]-p[0],p[k+1]-p[0]))*.5 for k in range(1,len(p)-1))
 if area<1e-16:continue
 polys.append(seq);bary.append(bc);orig.append(int(fi));areas.append(area)
 for a,b in zip(seq,seq[1:]+seq[:1]):
  if a>=len(W) and b>=len(W):cutEdges.append(tuple(sorted((a,b))));cutRaw.append(int(raw[fi]))
P=np.array(points);n=len(polys);assert n;planeAdj=collections.defaultdict(set)
for ei,(a,b)in enumerate(cutEdges):planeAdj[a].add(ei);planeAdj[b].add(ei)
active=set(range(len(cutEdges)));queue=collections.deque(v for v,es in planeAdj.items()if len(es)==1);peeled=[]
while queue:
 v=queue.popleft();es=planeAdj[v]&active
 if len(es)!=1:continue
 ei=next(iter(es));active.remove(ei);peeled.append(ei)
 for u in cutEdges[ei]:
  if len(planeAdj[u]&active)==1:queue.append(u)
coreAdj=collections.defaultdict(list)
for ei in active:
 a,b=cutEdges[ei];coreAdj[a].append(b);coreAdj[b].append(a)
assert coreAdj and all(len(v)==2 for v in coreAdj.values()),('Section core is not simple cycles',side,collections.Counter(map(len,coreAdj.values())))
left=set(coreAdj);cycles=[]
while left:
 start=min(left);seq=[start];prev=None;cur=start
 while True:
  nxt=next(v for v in coreAdj[cur]if v!=prev)
  if nxt==start:break
  assert nxt not in seq;seq.append(nxt);prev,cur=cur,nxt
 left-=set(seq);cycles.append(seq)
newroot=max(cycles,key=len);up=np.array([0.,0.,1.]);up-=axis*(up@axis);up/=np.linalg.norm(up);across=np.cross(axis,up);plane=P[newroot]@np.array([up,across]).T;area2=np.sum(plane[:,0]*np.roll(plane[:,1],-1)-plane[:,1]*np.roll(plane[:,0],-1))
# The retained collar boundary runs clockwise viewed toward the distal normal.
if area2>0:newroot=newroot[::-1]
newrequired={tuple(sorted((a,b))):(1 if a<b else-1)for a,b in zip(newroot,newroot[1:]+newroot[:1])};allplane=set(cutEdges);pedges=collections.defaultdict(list)
for i,poly in enumerate(polys):
 for a,b in zip(poly,poly[1:]+poly[:1]):pedges[tuple(sorted((a,b)))].append((i,1 if a<b else-1))
assert set(oldrequired)<=set(pedges) and set(newrequired)<=set(pedges);internal=[e for e in pedges if e not in oldrequired and e not in allplane];edgevar={e:n+i for i,e in enumerate(internal)};total=n+len(internal);rr=[];cc=[];vv=[];lower=[];upper=[]
def row(entries,lo,hi):
 k=len(lower);lower.append(lo);upper.append(hi)
 for col,value in entries:rr.append(k);cc.append(col);vv.append(value)
for e,fs in pedges.items():
 entries=[(i,1)for i,_ in fs];signed=[(i,sgn)for i,sgn in fs]
 if e in oldrequired or e in newrequired:
  required=oldrequired[e]if e in oldrequired else newrequired[e];row(entries,1,1);row(signed,required,required)
 elif e in allplane:row(entries,0,0)
 else:row(entries+[(edgevar[e],-2)],0,0);row(signed,0,0)
boundsHi=np.ones(total);norm=np.cross(s['W'][F[:,1]]-s['W'][F[:,0]],s['W'][F[:,2]]-s['W'][F[:,0]]);norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-20);forbidden=[]
for edge,held in heldSupport.items():
 for i,_ in pedges[edge]:
  dot=float(norm[orig[i]]@norm[held])
  if dot<=0:boundsHi[i]=0;forbidden.append([int(raw[orig[i]]),int(raw[held]),dot])
cost=np.zeros(total);cost[:n]=np.array(areas)/np.median(areas)+np.arange(n)*1e-9;A=coo_matrix((vv,(rr,cc)),shape=(len(lower),total)).tocsc();print({'side':side,'candidate_source_fragments':n,'plane_ring_vertices':len(newroot),'peeled_section_spur_segments':len(peeled),'variables':total,'constraints':len(lower),'forbidden_backward_supports':len(forbidden)},flush=True);res=milp(cost,integrality=np.ones(total),bounds=Bounds(np.zeros(total),boundsHi),constraints=LinearConstraint(A,np.array(lower),np.array(upper)),options={'time_limit':90,'mip_rel_gap':0});report={'side':side,'plane_index':pi,'plane_offset_m':offset,'candidate_source_fragments':n,'new_plane_ring_vertices':len(newroot),'peeled_spur_raw_faces':[cutRaw[i]for i in peeled],'forbidden_backward_supports':forbidden,'solver_status':int(res.status),'solver_message':res.message,'optimal':bool(res.success),'scope':'Source-fragment annulus selection only. No held model altered; geometry, tangent and source-contact checks remain mandatory.'}
if res.x is not None:
 take=np.flatnonzero(res.x[:n]>.5);assert np.max(abs(res.x-np.rint(res.x)))<1e-5;keep=set(take);pe={e:[(i,sign)for i,sign in fs if i in keep]for e,fs in pedges.items()};pe={e:fs for e,fs in pe.items()if fs};assert all(len(fs)==(1 if e in oldrequired or e in newrequired else 2)for e,fs in pe.items());assert all(sum(sign for _,sign in fs)==0 for e,fs in pe.items()if len(fs)==2);adj=collections.defaultdict(set)
 for e,fs in pe.items():
  if len(fs)==2:a,b=fs[0][0],fs[1][0];adj[a].add(b);adj[b].add(a)
 reached=set();todo=[int(take[0])]
 while todo:
  i=todo.pop()
  if i in reached:continue
  reached.add(i);todo.extend(adj[i]-reached)
 verts=set(v for i in take for v in polys[i]);euler=len(verts)-len(pe)+len(take);report.update(selected_fragments=len(take),selected_raw_faces=raw[np.array(orig)[take]].tolist(),connected=len(reached)==len(take),euler_characteristic=euler,old_boundary_edges=len(oldrequired),new_boundary_edges=len(newrequired));assert len(reached)==len(take) and euler==0,report
 # Triangulate each original clipped polygon with retained winding; per-corner source barycentrics remain exact.
 T=[];BC=[];FI=[]
 for i in take:
  for k in range(1,len(polys[i])-1):T.append([polys[i][0],polys[i][k],polys[i][k+1]]);BC.append([bary[i][0],bary[i][k],bary[i][k+1]]);FI.append(orig[i])
 np.savez_compressed(r/'checks'/f'collar49_{side}.npz',P=P,T=np.array(T),source_faces=np.array(FI),source_raw_ids=raw[np.array(FI)],source_barycentric=np.array(BC),old_root_physical_ids=np.array(oldroot),new_root_physical_ids=np.array(newroot),axis=axis,plane_C=C,plane_offset=np.array(offset),original_selected_faces=np.flatnonzero(chosen),chosen_fragment_source_faces=np.array(orig)[take],candidate_fragment_source_faces=np.array(orig),peeled_spur_raw_faces=np.array([cutRaw[i]for i in peeled]));report['triangles']=len(T)
(r/'checks'/f'collar49_{side}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
