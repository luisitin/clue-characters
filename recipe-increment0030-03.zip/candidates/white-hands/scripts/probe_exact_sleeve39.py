"""Read-only exact source triangle plane-section search. No source cuts or model writes."""
import pathlib,numpy as np,json,collections
r=pathlib.Path(__file__).resolve().parents[1];out={}
for side,hand,sgn in [('left','R',-1),('right','L',1)]:
 s=np.load(r/'checks'/f'source01_{side}.npz');d=np.load(r/'checks'/f'cuff37_{hand}_final_source_domain.npz');meta=json.load((r/'checks'/f'domain38_{side}.json').open());loops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];L=next(l for l in loops if abs(d['unique_world_positions'][l].mean(0)[0])>.25);B=d['unique_world_positions'][L];C=B.mean(0);W=np.array(meta['native_wrist_center']);axis=W-C;axis/=np.linalg.norm(axis);u=np.array([0.,0.,1.]);u-=axis*(u@axis);u/=np.linalg.norm(u);v=np.cross(axis,u);U,iv=np.unique(s['P'],axis=0,return_inverse=True);P=d['unique_world_positions'];G=iv[s['F']];tri=P[G];cent=tri.mean(1);region=(cent[:,0]*sgn>.245)&(cent[:,2]>.24)&(cent[:,2]<.46)&(np.linalg.norm(cent-C,axis=1)<.19);base=(P-C)@axis;mind=float(((B-C)@axis).min());reports=[];best=None
 for offset in mind-.001337-np.arange(0,.0251,.002):
  D=base-offset;fs=np.flatnonzero(region&(D[G].min(1)<0)&(D[G].max(1)>0));points={};segments=[];source=[]
  for fi in fs:
   cut=[]
   for x,y in zip(G[fi],np.roll(G[fi],-1)):
    if D[x]*D[y]<0:
     key=tuple(sorted((int(x),int(y))));a,b=key
     if key not in points:points[key]=P[a]+(P[b]-P[a])*(-D[a]/(D[b]-D[a]))
     cut.append(key)
   assert len(cut)==2;segments.append(tuple(cut));source.append(int(fi))
  degree=collections.Counter(k for e in segments for k in e);duplicates=len(segments)-len(set(tuple(sorted(e))for e in segments));rep={'offset_m':float(offset),'cut_faces':len(fs),'degree_histogram':dict(collections.Counter(degree.values())),'duplicate_segments':duplicates,'simple_planar_loop':False}
  if degree and set(degree.values())=={2} and not duplicates:
   adj=collections.defaultdict(list)
   for a,b in segments:adj[a].append(b);adj[b].append(a)
   remaining=set(adj);rings=[]
   while remaining:
    start=min(remaining);ll=[start];prev=None;cur=start
    while True:
     nxt=next(x for x in adj[cur]if x!=prev)
     if nxt==start:break
     assert nxt not in ll;ll.append(nxt);prev,cur=cur,nxt
    remaining-=set(ll);rings.append(ll)
   rep['loops']=[len(l)for l in rings]
   if len(rings)==1:
    ll=rings[0];wp=np.array([points[k]for k in ll]);q=(wp-C)@np.array([u,v]).T;n=len(q);a=q;b=np.roll(q,-1,axis=0);ii,jj=np.triu_indices(n,2);valid=~((ii==0)&(jj==n-1));ii,jj=ii[valid],jj[valid]
    def cross(x,y):return x[:,0]*y[:,1]-x[:,1]*y[:,0]
    a1=cross(b[ii]-a[ii],a[jj]-a[ii]);a2=cross(b[ii]-a[ii],b[jj]-a[ii]);b1=cross(b[jj]-a[jj],a[ii]-a[jj]);b2=cross(b[jj]-a[jj],b[ii]-a[jj]);crosses=int(((a1*a2<-1e-22)&(b1*b2<-1e-22)).sum());rep['projected_crossings']=crosses;rep['minimum_edge_m']=float(np.linalg.norm(b-a,axis=1).min());rep['maximum_plane_error_m']=float(abs((wp-C)@axis-offset).max());rep['simple_planar_loop']=crosses==0 and rep['minimum_edge_m']>1e-7
    if rep['simple_planar_loop'] and best is None:
     best=rep.copy();np.savez_compressed(r/'checks'/f'sleeve39_{side}.npz',C=C,axis=axis,offset=np.array(offset),loop_world_points=wp,loop_source_physical_edges=np.array(ll),cut_faces=np.array(fs),cut_raw_ids=s['raw_face_ids'][fs],basis_u=u,basis_v=v,held_old_boundary_minimum_plane_coordinate=np.array(mind))
  reports.append(rep)
 out[side]={'center':C.tolist(),'axis':axis.tolist(),'old_boundary_minimum_coordinate_m':mind,'best':best,'planes':reports,'scope':'Read-only plane feasibility. A simple plane section does not authorize a source cut or establish tangent continuity/clearance.'}
(r/'checks/sleeve39_plane_search.json').write_text(json.dumps(out,indent=2));print(out,flush=True)
