import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white'
for label,angle in [('front',0),('rear',180),('left_side',-90),('right_side',90)]:
 env=dict(os.environ,GLB=str(r/'models/white33_cuff_fit_diagnostic.glb'),OUT=str(r/'renders'/f'white33_cuff_fit_{label}.png'),MODE='pbr',TARGET='[0.00319,-0.04,0.16]',SCALE='.78',ANGLE=str(angle),ELEV='0',RES='768',SAMPLES='12');env.pop('CAMERA_META',None);env.pop('WORLD_ENV',None)
 with (r/'checks'/f'cuff33_{label}.log').open('w')as f:subprocess.run(['flock',os.environ.get('CHARACTER_BUILD_LOCK','/tmp/character-build-heavy.lock'),'bash','-c','date -u +START_%FT%TZ; "$@"; s=$?; date -u +END_%FT%TZ; exit $s','white_cuff33','blender','-b','-t','2','--python-exit-code','1','--python',str(owner/'scripts/render_exact.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
