"""Independent White sleeve guides, wrist-normal folded cuffs, and capped skin forearms.
Adapts tangent-guide and physical-arc fairing infrastructure from Green69/74;
no Green geometry, pose, paint, or approval is transferred.
"""
import pathlib,sys,json,numpy as np,collections,hashlib,os
from scipy.spatial.transform import Rotation
from scipy.ndimage import gaussian_filter1d
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb,append_accessor,write_glb
src=r.parent/'scarlett-white/models/white_25_continuous_neck_paint_trial.glb';j,buf,a=read_glb(src);q=j['meshes'][0]['primitives'][0];Fsrc=a(q['indices']).reshape(-1,3);held=np.ones(len(Fsrc),bool);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);pose=json.load((r/'checks/fist_seed25.json').open())['hands'];materials=[];report={}
for name,color,rough in [('Continued sleeve',[.026,.022,.019,1],.8),('Folded cuff',[.80,.775,.72,1],.78),('Native hand and forearm',[.57,.28,.145,1],.62)]:
 materials.append(len(j['materials']));j['materials'].append({'name':name+'48','pbrMetallicRoughness':{'baseColorFactor':color,'roughnessFactor':rough,'metallicFactor':0}})
def edges(T):
 out=collections.defaultdict(list)
 for fi,t in enumerate(T):
  for x,y in zip(t,np.roll(t,-1)):out[tuple(sorted((int(x),int(y))))].append((int(x),int(y),fi))
 return out
def order(directed):
 adj={a:b for a,b in directed};assert len(adj)==len(directed);out=[min(adj)]
 while adj[out[-1]]!=out[0]:out.append(adj[out[-1]]);assert len(out)<=len(adj)
 assert len(out)==len(adj);return np.array(out,int)
def normals(P,T):
 un,iv=np.unique(P,axis=0,return_inverse=True);tri=P[T];fn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);assert np.linalg.norm(fn,axis=1).min()>1e-16;N=np.zeros_like(un)
 for k in range(3):np.add.at(N,iv[T[:,k]],fn)
 N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-20);return N[iv]
def pack(P,T,UV,mi,N=None):
 global buf
 use,back=np.unique(T,return_inverse=True);P=P[use];UV=UV[use];T=back.reshape(-1,3);N=normals(P,T)if N is None else N[use];gp=(P[:,[0,2,1]]*[1,1,-1]-translation)/scale;gn=N[:,[0,2,1]]*[1,1,-1];attrs={}
 for name,v,kind in [('POSITION',gp,'VEC3'),('NORMAL',gn,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],buf=append_accessor(j,buf,v.astype(np.float32),kind,34962)
 ix,buf=append_accessor(j,buf,T.astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4})
parts=os.environ.get('PARTS','left').split(',')
for side,hand,domain in [('left','R','41'),('right','L','44')]:
 if side not in parts:continue
 d=np.load(r/'checks'/f'domain{domain}_{side}.npz');s=np.load(r/'checks'/f'source01_{side}.npz');U,iv=np.unique(s['P'],axis=0,return_inverse=True);G=iv[s['F']];se=edges(G);mask=np.ones(len(Fsrc),bool);mask[d['selected_faces']]=False;held&=mask;loops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];eligible=[l for l in loops if abs(d['unique_world_positions'][l].mean(0)[0])>.25];assert len(eligible)==1;rawloop=eligible[0];direct=[]
 for u,v in zip(rawloop,np.roll(rawloop,-1)):
  keep=[q for q in se[tuple(sorted((int(u),int(v))))]if mask[q[2]]];assert len(keep)==1;direct.append(keep[0][:2])
 L=order(direct)[::-1];root=d['unique_world_positions'][L];n=len(root);rootc=root.mean(0);axis=d['axis'];axis/=np.linalg.norm(axis);support=[];rootN=[]
 for u,v in zip(L,np.roll(L,-1)):
  f=next(t[2]for t in se[tuple(sorted((int(u),int(v))))]if mask[t[2]]);support.append(f);at=int(np.where(G[f]==u)[0][0]);rootN.append(s['N'][s['F'][f,at]][[0,2,1]]*[1,-1,1])
 rootN=np.array(rootN);rootN/=np.linalg.norm(rootN,axis=1)[:,None];st=s['W'][s['F'][support]];gN=np.cross(st[:,1]-st[:,0],st[:,2]-st[:,0]);gN/=np.linalg.norm(gN,axis=1)[:,None];ev=np.roll(root,-1,axis=0)-root;conormal=np.cross(gN,ev);conormal/=np.linalg.norm(conormal,axis=1)[:,None];scores=conormal@axis;assert scores.min()>.015
 h=np.load(r/'checks'/f'fist_seed27_{hand}.npz');hp=h['P'];ht=h['T'];he=edges(ht);hi=order([x[0][:2]for x in he.values()if len(x)==1]);wrist=hp[hi];W=wrist.mean(0);endaxis=np.array(pose[hand]['forward']);endaxis/=np.linalg.norm(endaxis);endc=W-endaxis*.009
 up=np.array([0.,0.,1.]);up-=axis*(up@axis);up/=np.linalg.norm(up);across=np.cross(axis,up);frame0=np.column_stack([up,across]);turn=np.cross(axis,endaxis);angle=np.arccos(np.clip(axis@endaxis,-1,1));turn/=max(np.linalg.norm(turn),1e-15)
 def rotation(t):return Rotation.from_rotvec(turn*angle*t).as_matrix()if angle>1e-10 else np.eye(3)
 frame1=rotation(1)@frame0;section=(wrist-W)@frame1;outerR=np.maximum(np.max(abs(section),axis=0)+[.012,.011],[.036,.026]);wall=.0024;innerR=outerR-wall;length=np.linalg.norm(endc-rootc);t0=axis*length*.70;t1=endaxis*length*.45
 def center(t):return (2*t**3-3*t*t+1)*rootc+(t**3-2*t*t+t)*t0+(-2*t**3+3*t*t)*endc+(t**3-t*t)*t1
 edgeLength=np.linalg.norm(ev,axis=1);uu=np.r_[0,np.cumsum(edgeLength[:-1])]/edgeLength.sum();q0=(root-rootc)@frame0;area=np.sum(q0[:,0]*np.roll(q0[:,1],-1)-q0[:,1]*np.roll(q0[:,0],-1))*.5;assert area>0;angle0=np.arctan2(q0[:,1],q0[:,0]);theta=uu*2*np.pi+np.angle(np.sum(np.exp(1j*(angle0-uu*2*np.pi))));shape=np.c_[np.sign(np.cos(theta))*abs(np.cos(theta))**.62,np.sign(np.sin(theta))*abs(np.sin(theta))**.62]
 def rawring(t):
  blend=t*t*(3-2*t);rel=(1-blend)*(root-rootc)+blend*((shape*outerR)@frame0.T);return center(t)+rel@rotation(blend).T
 fractions=np.array([0,.007,.015,.03,.05,.08,.12,.18,.25,.33,.42,.52,.62,.72,.8,.86,.91,.95,.98,1.]);rings=[];maxfair=0.;denseU=np.arange(1024)/1024
 initial=(rawring(1e-5)-root)/(length*1e-5);direction=conormal+np.roll(conormal,1,axis=0);direction/=np.linalg.norm(direction,axis=1)[:,None];desired=direction*np.linalg.norm(initial,axis=1)[:,None];den=desired@axis;assert den.min()>0,('non-forward averaged conormal',side,float(den.min()));correction=desired-initial;assert np.linalg.norm(correction,axis=1).max()<1.5
 for row,t in enumerate(fractions):
  arc=t*length;s0=min(arc/.04,1.);weight=.04*(s0-6*s0**3+8*s0**4-3*s0**5);p=rawring(t)+correction*weight
  if row==0:p=root.copy()
  if 1<row<len(fractions)-1:
   dense=np.column_stack([np.interp(denseU,np.r_[uu,1],np.r_[p[:,k],p[0,k]])for k in range(3)]);perimeter=np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1).sum();smooth=gaussian_filter1d(dense,.003/perimeter*len(dense),axis=0,mode='wrap');cen=dense.mean(0);smooth=cen+(smooth-cen)*np.sqrt(np.sum((dense-cen)**2)/max(np.sum((smooth-cen)**2),1e-20));a0=np.clip((arc-.0015)/.018,0,1);a1=np.clip((length-arc)/.012,0,1);a0=a0*a0*(3-2*a0);a1=a1*a1*(3-2*a1);smooth=dense+(smooth-dense)*a0*a1;fresh=np.column_stack([np.interp(uu,np.r_[denseU,1],np.r_[smooth[:,k],smooth[0,k]])for k in range(3)]);maxfair=max(maxfair,float(np.linalg.norm(fresh-p,axis=1).max()));p=fresh
  rings.append(p)
 P=np.concatenate(rings);UV=np.array([[uu[k],.58*t]for t in fractions for k in range(n)]);T=[];part=[];guideStart=len(P);guide=[]
 for k in range(n):
  available=min(float((rings[1][k]-root[k])@axis),float((rings[1][(k+1)%n]-root[(k+1)%n])@axis));assert available>0;distance=min(.00035,.12*edgeLength[k],.25*available/scores[k]);assert distance>1e-7;guide.append((root[k]+root[(k+1)%n])/2+conormal[k]*distance)
 P=np.vstack([P,guide]);UV=np.vstack([UV,np.c_[uu,np.full(n,.001)]])
 for row in range(len(rings)-1):
  for k in range(n):
   a0=row*n+k;b0=row*n+(k+1)%n;c0=(row+1)*n+(k+1)%n;d0=(row+1)*n+k;mi=0 if fractions[row+1]<=.42 else 1
   fs=[[a0,b0,guideStart+k],[b0,c0,guideStart+k],[c0,d0,guideStart+k],[d0,a0,guideStart+k]]if row==0 else [[a0,b0,c0],[a0,c0,d0]];T.extend(fs);part.extend([mi]*len(fs))
 last=(len(rings)-1)*n
 # Rolled cuff lip. Separate capped forearm avoids a false skin/fabric welded crease.
 lastids=np.arange(last,last+n)
 profiles=[(endc+endaxis*(wall*.5*np.sin(ph)),frame1,outerR-wall*.5*(1-np.cos(ph)))for ph in np.linspace(np.pi/6,np.pi,6)]
 for t,rad in [(.78,innerR),(.55,innerR*.93),(.35,innerR*.82)]:profiles.append((center(t),rotation(t*t*(3-2*t))@frame0,rad))
 for row,(cen,fr,rad)in enumerate(profiles):
  p=cen+(shape*rad)@fr.T;ids=np.arange(len(P),len(P)+n);P=np.vstack([P,p]);UV=np.vstack([UV,np.c_[uu,np.full(n,.60+.03*row)]])
  for k in range(n):a0=lastids[k];b0=lastids[(k+1)%n];c0=ids[(k+1)%n];d0=ids[k];T.extend([[a0,b0,c0],[a0,c0,d0]]);part.extend([1,1])
  lastids=ids
 capRoot=P[lastids].mean(0);capRelative=P[lastids]-capRoot;capDirection=center(.35)-center(.55);capDirection/=np.linalg.norm(capDirection)
 for ci,ph in enumerate(np.linspace(np.pi/12,5*np.pi/12,5)):
  fresh=capRoot+capDirection*.006*np.sin(ph)+capRelative*np.cos(ph);ids=np.arange(len(P),len(P)+n);P=np.vstack([P,fresh]);UV=np.vstack([UV,np.c_[uu,np.full(n,.86+.015*ci)]])
  for k in range(n):a0=lastids[k];b0=lastids[(k+1)%n];c0=ids[(k+1)%n];d0=ids[k];T.extend([[a0,b0,c0],[a0,c0,d0]]);part.extend([1,1])
  lastids=ids
 cap=len(P);P=np.vstack([P,capRoot+capDirection*.006]);UV=np.vstack([UV,[[.5,.95]]])
 for k in range(n):T.append([cap,lastids[k],lastids[(k+1)%n]]);part.append(1)
 T=np.array(T,int);part=np.array(part,int);cuffN=normals(P,T);cuffN[:n]=rootN
 # Closed native skin forearm: four gradual rings and a proximal planar cap inside the cuff.
 radial=(wrist-W)@frame1;axial=(wrist-W)@endaxis;skinRoot=center(.56);skinrings=[wrist]
 for t in [.18,.4,.65,1.]:skinrings.append(W+(skinRoot-W)*t+(radial*(1+.12*t))@frame1.T+(axial*(1-t)**2)[:,None]*endaxis)
 SP=np.concatenate(skinrings);m=len(wrist);ST=[];SUV=np.array([[k/m,row/len(skinrings)]for row in range(len(skinrings))for k in range(m)])
 for row in range(len(skinrings)-1):
  for k in range(m):a0=row*m+k;b0=row*m+(k+1)%m;c0=(row+1)*m+k;d0=(row+1)*m+(k+1)%m;ST.extend([[a0,c0,b0],[b0,c0,d0]])
 lastids=np.arange((len(skinrings)-1)*m,len(skinrings)*m);capRelative=SP[lastids]-skinRoot;skinCapDirection=skinRoot-W;skinCapDirection/=np.linalg.norm(skinCapDirection)
 for ci,ph in enumerate(np.linspace(np.pi/12,5*np.pi/12,5)):
  fresh=skinRoot+skinCapDirection*.006*np.sin(ph)+capRelative*np.cos(ph);ids=np.arange(len(SP),len(SP)+m);SP=np.vstack([SP,fresh]);SUV=np.vstack([SUV,np.c_[np.arange(m)/m,np.full(m,.82+.03*ci)]])
  for k in range(m):a0=lastids[k];b0=lastids[(k+1)%m];c0=ids[k];d0=ids[(k+1)%m];ST.extend([[a0,c0,b0],[b0,c0,d0]])
  lastids=ids
 sc=len(SP);SP=np.vstack([SP,skinRoot+skinCapDirection*.006]);SUV=np.vstack([SUV,[[.5,1.]]])
 for k in range(m):ST.append([sc,lastids[(k+1)%m],lastids[k]])
 ST=np.array(ST,int);combinedP=np.vstack([SP,hp]);combinedT=np.vstack([ST,ht+len(SP)]);jointN=normals(combinedP,combinedT);skinN=jointN[:len(SP)];handN=h['N'].copy();handN[hi]=jointN[len(SP)+hi];allP=np.vstack([P,SP,hp]);allT=np.vstack([T,ST+len(P),ht+len(P)+len(SP)]);np.savez_compressed(r/'checks'/f'cuff48_{hand}.npz',P=P,T=T,UV=UV,part=part,N=cuffN,skinP=SP,skinT=ST,skinUV=SUV,skinN=skinN,allP=allP,allT=allT,source_interface_points=root,source_interface_physical_ids=L,source_support_raw_ids=s['raw_face_ids'][support],removed_raw_ids=d['raw_ids'],root_axis=axis,wrist_axis=endaxis,root_guide_points=np.array(guide),native_wrist_ids=hi,hand_normal_changed_ids=hi)
 for mi in [0,1]:pack(P,T[part==mi],UV,materials[mi],cuffN)
 pack(SP,ST,SUV,materials[2],skinN);uv=h['UVcorner'].copy();uv[:,:,1]=1-uv[:,:,1];unique,back=np.unique(np.c_[ht.ravel(),uv.reshape(-1,2)],axis=0,return_inverse=True);sv=unique[:,0].astype(int);pack(hp[sv],back.reshape(-1,3),unique[:,1:],materials[2],handN[sv]);report[side]={'domain':domain,'cuff_triangles':len(T),'skin_forearm_triangles':len(ST),'root_vertices':n,'minimum_forward_conormal':float(scores.min()),'minimum_geometric_tangent_forward':float(den.min()),'root_tangent_method':'Mean of measured outgoing edge conormals, preserving physical speed; forward axial advance may slow. Edge guide triangles remain exactly in each retained face plane.','maximum_tangent_correction':float(np.linalg.norm(correction,axis=1).max()),'maximum_interior_fair_displacement_m':maxfair,'root_to_wrist_axis_degrees':float(np.degrees(angle)),'cuff_mouth_behind_native_wrist_m':.009,'source_boundary_positions_held':True,'native_hand_positions_UVs_held':True,'native_hand_normals_changed_only_at_wrist':hi.tolist(),'closed_skin_component':True,'cloth_has_hidden_interior_cap':True,'hidden_caps':'Six-mm sheared half-ellipsoid closures with five intermediate rings, aligned to the existing tube continuation.','scope':'Unapproved geometry trial. Actual stored-float V4, cloth/skin/body clearance, UVs, materials and all-angle appearance remain required. Body returns remain open.'}
q['indices'],buf=append_accessor(j,buf,Fsrc[held].astype(np.uint32),'SCALAR',34963);composition='both'if len(parts)==2 else parts[0];out=r/'models'/f'white48_guided_cuff_{composition}_diagnostic.glb';report['component_sides']=parts;write_glb(out,j,buf);report['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest();report['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();(r/'checks/cuff48.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
