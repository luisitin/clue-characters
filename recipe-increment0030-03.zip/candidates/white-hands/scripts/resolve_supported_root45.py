"""Bounded source root selection with explicit forward geometric support; no model edits."""
import pathlib,os,json,numpy as np,collections
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
r=pathlib.Path(__file__).resolve().parents[1];side=os.environ.get('SIDE','left');hand='R'if side=='left'else'L';s=np.load(r/'checks'/f'source01_{side}.npz');d=np.load(r/'checks'/f'cuff37_{hand}_final_source_domain.npz');P=s['P'];F=s['F'];W=s['W'];raw=s['raw_face_ids'];U,iv=np.unique(P,axis=0,return_inverse=True);G=iv[F];UW=d['unique_world_positions'];selected=np.zeros(len(F),bool);selected[d['removed_faces']]=True;loops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];root=next(l for l in loops if abs(UW[l].mean(0)[0])>.25);body=set(v for l in loops if not np.array_equal(l,root)for v in l);C=UW[root].mean(0);wc=np.array(json.load((r/'checks'/f'domain38_{side}.json').open())['native_wrist_center']);axis=wc-C;axis/=np.linalg.norm(axis);loBox=UW[root].min(0)-.025;hiBox=UW[root].max(0)+.025;edges={};vf=collections.defaultdict(set)
for fi,t in enumerate(G):
 for v in t:vf[int(v)].add(fi)
 for a,b in zip(t,np.roll(t,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
front=set(root);candidates=set()
for _ in range(5):
 new=set(f for v in front for f in vf[v]);candidates|=new;front=set(v for f in new for v in G[f])
protect=set(f for v in body for f in vf[v]);candidates={f for f in candidates if f not in protect and np.all(W[F[f]]>=loBox)and np.all(W[F[f]]<=hiBox)};varfaces=sorted(candidates);fiid={f:i for i,f in enumerate(varfaces)};active=[(e,fs)for e,fs in edges.items()if any(f in candidates for f in fs)or(any(selected[fs])and not all(selected[fs]))];verts=sorted(set(v for e,fs in active for v in e));vid={v:i for i,v in enumerate(verts)};nf=len(varfaces);ne=len(active);n=nf+2*ne+len(verts);rr=[];cc=[];vv=[];lo=[];hi=[]
def row(entries,l,h):
 k=len(lo);lo.append(l);hi.append(h)
 for j,v in entries:rr.append(k);cc.append(j);vv.append(v)
ved=collections.defaultdict(list);tri=W[F];fn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);fn/=np.maximum(np.linalg.norm(fn,axis=1)[:,None],1e-20);badConstraints=[]
for i,(edge,fs)in enumerate(active):
 a=nf+i;y=nf+ne+i;fixed=sum(selected[f]for f in fs if f not in fiid);var=[(fiid[f],1)for f in fs if f in fiid];row(var+[(a,-len(fs)),(y,1)],-fixed,-fixed);row([(a,1),(y,-1)],0,np.inf);row(var+[(a,-1)],-fixed,np.inf)
 for v in edge:ved[v].append(y)
 # At a new root boundary, the sole held face must support extension toward the wrist.
 if any(f in candidates for f in fs):
  for f in fs:
   if f not in candidates and any(v in body for v in G[f]):continue
   g=G[f];ia=int(np.where(g==edge[0])[0][0]);ib=int(np.where(g==edge[1])[0][0]);ev=UW[edge[1]]-UW[edge[0]]
   if(ib-ia)%3!=1:ev=-ev
   co=np.cross(ev,fn[f]);co/=max(np.linalg.norm(co),1e-20);score=float(co@axis)
   if score<=.015:
    if f in fiid:row([(fiid[f],1),(y,-1)],0,np.inf)
    else:row([(y,1)],-np.inf,int(selected[f]))
    badConstraints.append([int(raw[f]),score])
for v in verts:row([(j,1)for j in ved[v]]+[(nf+2*ne+vid[v],-2)],0,0)
area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)*.5;cost=np.zeros(n);cost[:nf]=(1-2*selected[varfaces].astype(float))*(1+area[varfaces]/max(float(np.median(area[varfaces])),1e-10));A=coo_matrix((vv,(rr,cc)),shape=(len(lo),n)).tocsc();print({'side':side,'candidate_faces':nf,'variables':n,'forbidden_unsupported_boundary_choices':len(badConstraints)},flush=True);res=milp(cost,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(A,np.array(lo),np.array(hi)),options={'time_limit':60,'mip_rel_gap':0});report={'side':side,'solver_status':int(res.status),'solver_message':res.message,'optimal':bool(res.success),'axis':axis.tolist(),'candidate_band_rings':5,'root_box_margin_m':.025,'candidate_faces':nf,'forbidden_unsupported_boundary_choices':len(badConstraints),'scope':'Read-only bounded root-domain support solve; geometry, source-contact, shading and actual views remain required.'}
if res.x is not None:
 assert np.all(abs(res.x-np.rint(res.x))<1e-5);chosen=selected.copy();chosen[varfaces]=res.x[:nf]>.5;boundary=[e for e,fs in edges.items()if any(chosen[fs])and not all(chosen[fs])];deg=collections.Counter(v for e in boundary for v in e);assert set(deg.values())=={2};assert all(sum(not chosen[f]for f in edges[e])==1 for e in boundary);adj=collections.defaultdict(list)
 for a,b in boundary:adj[a].append(b);adj[b].append(a)
 left=set(adj);rings=[]
 while left:
  start=min(left);ll=[start];prev=None;cur=start
  while True:
   nxt=next(v for v in adj[cur]if v!=prev)
   if nxt==start:break
   assert nxt not in ll;ll.append(nxt);prev,cur=cur,nxt
  left-=set(ll);rings.append(ll)
 newbody=set(v for l in rings if abs(UW[l].mean(0)[0])<.25 for v in l);assert newbody==body;rootnew=next(l for l in rings if abs(UW[l].mean(0)[0])>.25);scores=[];support=[]
 for a,b in zip(rootnew,np.roll(rootnew,-1)):
  fs=edges[tuple(sorted((int(a),int(b))))];f=next(f for f in fs if not chosen[f]);g=G[f];ia=int(np.where(g==a)[0][0]);ib=int(np.where(g==b)[0][0]);ev=UW[b]-UW[a]
  if(ib-ia)%3!=1:ev=-ev
  co=np.cross(ev,fn[f]);co/=max(np.linalg.norm(co),1e-20);scores.append(float(co@axis));support.append(int(raw[f]))
 assert min(scores)>.015;added=np.flatnonzero(chosen&~selected);retreated=np.flatnonzero(~chosen&selected);report.update(selected_faces=int(chosen.sum()),added_raw_ids=raw[added].tolist(),retreated_raw_ids=raw[retreated].tolist(),minimum_retained_conormal_axis_dot=min(scores),body_boundary_vertex_set_exactly_held=True,interfaces=[{'vertices':len(l),'center':UW[l].mean(0).tolist()}for l in rings]);np.savez_compressed(r/'checks'/f'domain45_{side}.npz',selected_faces=np.flatnonzero(chosen),raw_ids=raw[chosen],added_faces=added,retreated_faces=retreated,boundary_edges=np.array(boundary),loop_offsets=np.cumsum([0]+[len(l)for l in rings]),loop_vertices=np.concatenate(rings),unique_local_positions=U,unique_world_positions=UW,root_support_raw_ids=np.array(support),root_support_conormal_dots=np.array(scores),axis=axis)
(r/'checks'/f'domain45_{side}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
