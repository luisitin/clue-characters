"""Source-boundary to native-wrist loft. Diagnostic only until full contact/appearance checks."""
import pathlib,sys,json,numpy as np,collections,hashlib
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb,append_accessor,write_glb
src=r.parent/'scarlett-white/models/white_25_continuous_neck_paint_trial.glb';j,buf,a=read_glb(src);q=j['meshes'][0]['primitives'][0];F=a(q['indices']).reshape(-1,3);held=np.ones(len(F),bool);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);report={};materials=[]
for name,color,rough in [('Continued black sleeve',[.026,.022,.019,1],.8),('Fitted cuff fabric',[.80,.775,.72,1],.78),('Provisional hand skin',[.57,.28,.145,1],.62)]:
 materials.append(len(j['materials']));j['materials'].append({'name':name+'35','pbrMetallicRoughness':{'baseColorFactor':color,'roughnessFactor':rough,'metallicFactor':0}})
def boundaries(T):
 e=collections.defaultdict(list)
 for fi,t in enumerate(T):
  for x,y in zip(t,np.roll(t,-1)):e[tuple(sorted((int(x),int(y))))].append((int(x),int(y),fi))
 return e
def ordered(edges):
 adj={a:b for a,b in edges};assert len(adj)==len(edges);out=[min(adj)]
 while adj[out[-1]]!=out[0]:
  out.append(adj[out[-1]]);assert len(out)<=len(edges)
 assert len(out)==len(edges);return np.array(out,int)
def pack(P,T,UV,mi,N=None):
 global buf
 used,back=np.unique(T,return_inverse=True);P=P[used];UV=UV[used];T=back.reshape(-1,3)
 if N is not None:N=N[used]
 if N is None:
  fn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);N=np.zeros_like(P)
  for k in range(3):np.add.at(N,T[:,k],fn)
  N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-20)
 gp=P[:,[0,2,1]]*[1,1,-1];gp=(gp-translation)/scale;gn=N[:,[0,2,1]]*[1,1,-1];attrs={}
 for name,v,kind in [('POSITION',gp,'VEC3'),('NORMAL',gn,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],buf=append_accessor(j,buf,v.astype(np.float32),kind,34962)
 ix,buf=append_accessor(j,buf,T.astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4})
for side,hand in [('left','R'),('right','L')]:
 d=np.load(r/'checks'/f'domain32_{side}.npz');s=np.load(r/'checks'/f'source01_{side}.npz');U,iv=np.unique(s['P'],axis=0,return_inverse=True);G=iv[s['F']];e=boundaries(G);mask=np.ones(len(F),bool);mask[d['selected_faces']]=False;held&=mask
 loops=[d['loop_vertices'][a:b]for a,b in zip(d['loop_offsets'][:-1],d['loop_offsets'][1:])];eligible=[l for l in loops if abs(d['unique_world_positions'][l].mean(0)[0])>.25];assert len(eligible)==1,[(len(l),d['unique_world_positions'][l].mean(0))for l in eligible];L=eligible[0];direct=[];retained=[]
 for x,y in zip(L,np.roll(L,-1)):
  fs=[z for z in e[tuple(sorted((int(x),int(y))))]if mask[z[2]]];assert len(fs)==1;direct.append(fs[0][:2]);retained.append(fs[0][2])
 L=ordered(direct);retained=[next(z[2]for z in e[tuple(sorted((int(x),int(y))))]if mask[z[2]])for x,y in zip(L,np.roll(L,-1))];source=d['unique_world_positions'][L];z=np.load(r/'checks'/f'fist_seed27_{hand}.npz');hp=z['P'];ht=z['T'];he=boundaries(ht);hloop=ordered([v[0][:2]for v in he.values()if len(v)==1]);# Reverse native boundary so the connecting patch uses opposite directions.
 hloop=hloop[::-1];wrist=hp[hloop];C=source.mean(0);W=wrist.mean(0);axis=W-C;length=np.linalg.norm(axis);axis/=length;Uax=np.array([0.,0.,1.]);Uax-=axis*(Uax@axis);Uax/=np.linalg.norm(Uax);Vax=np.cross(axis,Uax)
 stheta=np.unwrap(np.arctan2((source-C)@Vax,(source-C)@Uax));delta=np.diff(np.r_[stheta,stheta[0]+np.sign(np.median(np.diff(stheta)))*2*np.pi]);direction=np.sign(np.median(delta));angular_backtrack=float((delta*direction).min());edge_lengths=np.linalg.norm(np.roll(source,-1,axis=0)-source,axis=1);phase0=direction*2*np.pi*np.r_[0,np.cumsum(edge_lengths[:-1])]/edge_lengths.sum();phase=np.angle(np.sum(np.exp(1j*(stheta-phase0))));stheta=phase0+phase
 # The source-directed sleeve and reversed native wrist must wind consistently.
 htheta=np.unwrap(np.arctan2((wrist-W)@Vax,(wrist-W)@Uax));hdelta=np.diff(np.r_[htheta,htheta[0]+direction*2*np.pi]);assert (hdelta*direction).min()>-1e-7,('inconsistent wrist winding',side)
 theta=stheta;rx=np.max(abs((wrist-W)@Uax))+.004;ry=np.max(abs((wrist-W)@Vax))+.004;n=len(source);rings=[source];labels=[];uv=[]
 # A gentle narrowing sleeve, then a turned fabric edge and inner cuff, terminating on exact native skin.
 stations=[(.12,1.25,0),(.30,1.22,0),(.44,1.18,0),(.46,1.17,1),(.64,1.10,1),(.88,1.07,1),(1.10,1.13,1),(1.12,1.10,1),(1.10,1.03,1),(.98,1.03,1)]
 radial=source-C;long=radial@axis;radial-=long[:,None]*axis;target=rx*np.cos(theta)[:,None]*Uax+ry*np.sin(theta)[:,None]*Vax
 for t,blend,mi in stations:
  f=min(t/.64,1.);smooth=f*f*(3-2*f);shape=radial*(1-smooth)+target*smooth*blend;center=C+(W-C)*t;ring=center+shape+(1-smooth)*long[:,None]*axis;rings.append(ring);labels.append(mi)
 P=np.concatenate(rings);T=[];mat=[]
 for row in range(len(rings)-1):
  for k in range(n):
   a0=row*n+k;a1=row*n+(k+1)%n;b0=(row+1)*n+k;b1=(row+1)*n+(k+1)%n;T.extend([[a0,b0,a1],[a1,b0,b1]]);mat.extend([labels[row]]*2)
 # Join the final 83/variable-count cuff ring to the native 40-edge wrist by circular angular order.
 start=len(P);P=np.vstack([P,wrist]);A=(len(rings)-1)*n;aa=(theta*direction)%(2*np.pi);bb=(htheta*direction)%(2*np.pi);ia=np.argsort(aa);ib=np.argsort(bb);# Sorted coordinates are only for choosing a cyclic start; face ordering remains the original directed loops.
 ia=np.roll(np.arange(n),-int(ia[0]));ib=np.roll(np.arange(len(wrist)),-int(ib[0]));av=np.unwrap(theta[ia]*direction);bv=np.unwrap(htheta[ib]*direction);av-=2*np.pi*np.floor(av[0]/(2*np.pi));bv-=2*np.pi*np.floor(bv[0]/(2*np.pi));i=k=0
 while i<n or k<len(wrist):
  an=av[(i+1)%n]+(2*np.pi if i+1>=n else 0)if i<n else np.inf;bn=bv[(k+1)%len(wrist)]+(2*np.pi if k+1>=len(wrist)else 0)if k<len(wrist)else np.inf
  va=A+ia[i%n];vb=start+ib[k%len(wrist)]
  if an<bn:T.append([va,vb,A+ia[(i+1)%n]]);i+=1
  else:T.append([va,vb,start+ib[(k+1)%len(wrist)]]);k+=1
  mat.append(2)
 T=np.array(T,int);mat=np.array(mat,int);# Correct last zipper B-step orientation shares each diagonal in opposite direction.
 # Both step types above carry the same strip boundary orientation.
 pUV=np.zeros((len(P),2));pUV[:len(rings)*n]=np.array([[((theta[k]*direction-theta[0]*direction)/(2*np.pi)),row/(len(rings)+1)]for row in range(len(rings))for k in range(n)]);pUV[start:]=np.c_[((htheta*direction-theta[0]*direction)/(2*np.pi))%1,np.ones(len(wrist))];
 off=len(P);allP=np.vstack([P,hp]);allT=np.vstack([T,ht+off]);np.savez_compressed(r/'checks'/f'cuff35_{hand}.npz',P=P,T=T,material=mat,UV=pUV,allP=allP,allT=allT,source_interface_points=source,source_interface_physical_ids=L,native_wrist_ids=hloop,raw_removed_ids=d['raw_ids'],retained_interface_raw_ids=s['raw_face_ids'][retained]);
 for mi in range(3):
  faces=T[mat==mi]
  if len(faces):pack(P,faces,pUV,materials[mi])
 # Hold native hand corner UV identity, including every seam.
 uvh=z['UVcorner'].copy();uvh[:,:,1]=1-uvh[:,:,1];unique,back=np.unique(np.c_[ht.ravel(),uvh.reshape(-1,2)],axis=0,return_inverse=True);sv=unique[:,0].astype(int);pack(hp[sv],back.reshape(-1,3),unique[:,1:],materials[2],z['N'][sv]);report[side]={'source_loop_vertices':n,'source_projection_minimum_angular_step_radians':angular_backtrack,'loop_parameterization':'Exact source boundary retained; arclength-ordered cross sections with least-squares circular phase. Convexity is not assumed.','native_wrist_vertices':len(wrist),'loft_triangles':len(T),'length_m':float(length),'source_boundary_array_exact':True,'hand27_positions_and_native_corner_UVs_held_in_arrays':True,'remaining_non_sleeve_source_loops':len(loops)-1,'wrist_radius_plus_margin_m':[float(rx),float(ry)],'scope':'Unapproved cuff fit. Body returns remain open; source/cuff collision, UV seams, exact serialized closure and appearance pending.'}
q['indices'],buf=append_accessor(j,buf,F[held].astype(np.uint32),'SCALAR',34963);out=r/'models/white35_cuff_fit_diagnostic.glb';write_glb(out,j,buf);report['source_sha256']=hashlib.sha256(src.read_bytes()).hexdigest();report['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();(r/'checks/cuff35.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
