import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white';src=r/'models/fist_seed34.glb'
for label,ang,el in [('front',0,0),('rear',180,0),('top',0,5),('under',0,-5)]:
 env=dict(os.environ,GLB=str(src),OUT=str(r/'renders'/f'fist34_R_macro_{label}_pbr.png'),MODE='pbr',TARGET='[-0.25,0,0.205]',SCALE='.20',ANGLE=str(ang),ELEV=str(el),RES='768',SAMPLES='16');env.pop('CAMERA_META',None);env.pop('WORLD_ENV',None)
 with (r/'checks'/f'seed34_{label}.log').open('w')as f:subprocess.run(['flock',os.environ.get('CHARACTER_BUILD_LOCK','/tmp/character-build-heavy.lock'),'bash','-c','date -u +START_%FT%TZ; "$@"; s=$?; date -u +END_%FT%TZ; exit $s','white_fist_seed','blender','-b','-t','2','--python-exit-code','1','--python',str(owner/'scripts/render_exact.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(label,flush=True)
