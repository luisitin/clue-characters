"""Clean, stronger military jacket blockout. Authored geometry replaces fused coat source.
This is an incomplete fit/shape candidate, with neutral materials and no promotion.
"""
import bpy,numpy as np,math,json,os
from pathlib import Path
from mathutils import Vector
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from strength_field292 import deform,jacobian
D=Path(__file__).resolve().parents[1];bpy.ops.wm.read_factory_settings(use_empty=True)
def mat(name,col,rough=.8,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
wool=mat('New mustard wool blockout',(.64,.34,.055));cotton=mat('Ivory cotton blockout',(.78,.75,.66));leather=mat('Chestnut leather blockout',(.09,.037,.015),.62);gold=mat('Brass blockout',(.54,.35,.09),.33,.75)
def mesh(name,P,T,material):
 me=bpy.data.meshes.new(name);me.from_pydata(np.asarray(P).tolist(),[],T);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);o.data.materials.append(material)
 for p in me.polygons:p.use_smooth=True
 return o
# Smooth tailored torso with a defined waist and flared skirt.
levels=np.array([[-.175,.267,.164],[-.11,.265,.166],[0,.249,.171],[.13,.239,.170],[.20,.241,.177],[.35,.284,.185],[.49,.308,.176],[.58,.300,.151],[.63,.250,.125]])
angles=np.arange(96)*2*np.pi/96;P=[]
for z,rx,ry in levels:
 for t in angles:
  x=.0064+rx*np.sign(np.cos(t))*abs(np.cos(t))**(2/3);y=.045+ry*np.sign(np.sin(t))*abs(np.sin(t))**(2/3)
  # Small fitted vertical cloth channels, not random displacement noise.
  skirt=max(0,min(1,(.13-z)/.25));y+=.003*skirt*np.cos(4*t);P.append([x,y,z])
T=[]
for j in range(len(levels)-1):
 for i in range(96):a=j*96+i;b=j*96+(i+1)%96;c=(j+1)*96+(i+1)%96;d=(j+1)*96+i;T.append([a,b,c,d])
T.extend([list(reversed(range(96))),list(range((len(levels)-1)*96,len(levels)*96))]);torso=mesh('Clean tailored torso',P,T,wool)
bpy.context.view_layer.objects.active=torso;torso.select_set(True);sub=torso.modifiers.new('Torso continuous form','SUBSURF');sub.levels=2;bpy.ops.object.modifier_apply(modifier=sub.name);torso.select_set(False)
Hpoint=np.array([.383,-.108,.25]);Fpoint=np.array([.9004954087497044,-.4002201816665353,.1700935772082775]);HP=deform(Hpoint[None])[0];FP=jacobian(Hpoint[None])[0]@Fpoint;FP/=np.linalg.norm(FP)
r=json.loads((D/'audit/grip210_registration.json').read_text());HG0=np.array(r['world_anchor']);FG0=np.array(r['world_forward']);HG=deform(HG0[None])[0];FG=jacobian(HG0[None])[0]@FG0;FG/=np.linalg.norm(FG)
def sleeve(name,shoulder,elbow,H,F,radius):
 shoulder=np.array(shoulder);elbow=np.array(elbow);end=H-.006*F
 # Quadratic passes around the elbow; end tangent is constrained to the hand axis.
 outer=np.array([.272,.040,.570]) if shoulder[0]>0 else np.array([-.300,.055,.575]);controls=np.array([shoulder,outer,elbow,end-.080*F,end]);ts=np.linspace(0,1,65)
 from scipy.interpolate import CubicSpline
 spl=CubicSpline([0,.23,.55,.78,1],controls,axis=0,bc_type=((1,controls[1]-controls[0]),(1,.25*F)))
 path=spl(ts);tan=spl(ts,1);tan/=np.linalg.norm(tan,axis=1,keepdims=True);p=[];n=64;previous=None
 for k,t in enumerate(ts):
  v=np.cross(tan[k],[0,1,0])
  if np.linalg.norm(v)<.05:v=np.cross(tan[k],[1,0,0])
  v/=np.linalg.norm(v)
  if previous is not None and v@previous<0:v=-v
  previous=v;u=np.cross(v,tan[k]);rad=np.interp(t,[0,.3,.56,.8,1],[radius,radius*.96,radius*.91,.073,.062])
  for a in np.arange(n)*2*np.pi/n:
   fold=.0035*np.sin(4*np.pi*t+2*a)*np.sin(np.pi*t)**2
   p.append(path[k]+(rad+fold)*(np.cos(a)*u+np.sin(a)*v))
 faces=[]
 for k in range(len(ts)-1):
  for i in range(n):a=k*n+i;b=k*n+(i+1)%n;c=(k+1)*n+(i+1)%n;d=(k+1)*n+i;faces.append([a,b,c,d])
 faces.extend([list(reversed(range(n))),list(range((len(ts)-1)*n,len(ts)*n))]);o=mesh(name,p,faces,wool);return o
arms=[sleeve('Stronger pointing sleeve',[.150,.045,.470],[.407,.060,.270],HP,FP,.085),sleeve('Stronger cane sleeve',[-.150,.045,.470],[-.410,.048,.300],HG,FG,.092)]
# Remesh only freshly authored garment volumes; no source face/head is remeshed.
for o in [torso]+arms:o.select_set(True)
bpy.context.view_layer.objects.active=torso;bpy.ops.object.join();o=torso;rem=o.modifiers.new('Clean garment union','REMESH');rem.mode='VOXEL';rem.voxel_size=.0035;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name);sm=o.modifiers.new('Relax authored union','SMOOTH');sm.factor=.45;sm.iterations=3;bpy.ops.object.modifier_apply(modifier=sm.name)
def bore(name,center,axis,radius,depth,scale_xy=None):
 bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=radius,depth=depth,location=center);c=bpy.context.object;c.name=name;c.rotation_euler=Vector(axis).to_track_quat('Z','Y').to_euler()
 if scale_xy:c.scale.x=scale_xy[0];c.scale.y=scale_xy[1]
 bpy.context.view_layer.objects.active=c;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);bpy.context.view_layer.objects.active=o;bo=o.modifiers.new(name,'BOOLEAN');bo.operation='DIFFERENCE';bo.solver='EXACT';bo.object=c;bpy.ops.object.modifier_apply(modifier=bo.name);bpy.data.objects.remove(c,do_unlink=True)
bore('Neckline opening',[.005,.09,.69],[0,0,1],.099,.24, (1.04,1))
for name,H,F in [('Pointing cuff opening',HP,FP),('Cane cuff opening',HG,FG)]:bore(name,H-.022*F,F,.057,.130)
# Intentional front construction and pockets are separate tailored pieces.
def block(name,loc,scale,material,bevel=.006):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);b=bpy.context.object;b.name=name;b.dimensions=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);b.data.materials.append(material);mod=b.modifiers.new('Soft sewn edges','BEVEL');mod.width=bevel;mod.segments=3;bpy.context.view_layer.objects.active=b;bpy.ops.object.modifier_apply(modifier=mod.name)
 for f in b.data.polygons:f.use_smooth=True
 return b
from mathutils.bvhtree import BVHTree
bpy.context.view_layer.update();coatmesh=o.data;coatmesh.calc_loop_triangles();bvh=BVHTree.FromPolygons([v.co[:] for v in coatmesh.vertices],[t.vertices[:] for t in coatmesh.loop_triangles],all_triangles=True)
def panel(name,cx,cz,width,height,bulge,taper=0):
 p=[];faces=[];nx=21;nz=25
 for j,v in enumerate(np.linspace(-1,1,nz)):
  for i,u in enumerate(np.linspace(-1,1,nx)):
   x=cx+width*.5*u*(1-taper*(v+1)/2);z=cz+height*.5*v;hit,n,fi,dd=bvh.ray_cast(Vector((x,-2,z)),Vector((0,1,0)),4);assert hit is not None,(name,x,z)
   if n.y>0:n=-n
   off=.002+bulge*(1-u*u)*(1-v*v);p.append(np.array(hit)+np.array(n)*off)
 for j in range(nz-1):
  for i in range(nx-1):a=j*nx+i;faces.append([a,a+1,a+nx+1,a+nx])
 ob=mesh(name,p,faces,wool);bpy.context.view_layer.objects.active=ob;sol=ob.modifiers.new('Cloth panel thickness','SOLIDIFY');sol.thickness=.0012;sol.offset=-1;bpy.ops.object.modifier_apply(modifier=sol.name);bev=ob.modifiers.new('Sewn edge softness','BEVEL');bev.width=.0006;bev.segments=2;bev.limit_method='ANGLE';bpy.ops.object.modifier_apply(modifier=bev.name)
 return ob
for x in [-.145,.155]:panel('Seated lower bellows pocket',x,-.011,.175,.206,.006,.18);panel('Seated lower pocket flap',x,.083,.160,.038,.003)
panel('Seated chest pocket',.165,.405,.155,.130,.005);panel('Seated chest flap',.165,.470,.165,.035,.003)
# The shirt underlay is a geometric semantic region of the authored front.
cotton_index=len(o.data.materials);o.data.materials.append(cotton)
for f in o.data.polygons:
 c=f.center
 if .425<c.z<.641 and f.normal.y<-.6 and abs(c.x-.005)<.005+.085*(c.z-.425)/.216:f.material_index=cotton_index
from mathutils.geometry import tessellate_polygon

def fitted_lapel(name,poly):
 vectors=[Vector((x,z,0)) for x,z in poly];ears=tessellate_polygon([vectors]);positions=[];tri=[];lookup={};n=18
 def point(xz):
  key=tuple(np.round(xz,10))
  if key in lookup:return lookup[key]
  x,z=key;hit,nn,fi,dd=bvh.ray_cast(Vector((x,-2,z)),Vector((0,1,0)),4);assert hit is not None,(name,key)
  if nn.y>0:nn=-nn
  idx=len(positions);positions.append(np.array(hit)+np.array(nn)*.0045);lookup[key]=idx;return idx
 for ear in ears:
  v=np.array([[vectors[int(p)].x,vectors[int(p)].y] if isinstance(p,int) else [p.x,p.y] for p in ear]);ids={}
  for i in range(n+1):
   for j in range(n+1-i):ids[i,j]=point(v[0]*(1-(i+j)/n)+v[1]*i/n+v[2]*j/n)
  for i in range(n):
   for j in range(n-i):
    tri.append([ids[i,j],ids[i+1,j],ids[i,j+1]])
    if i+j<n-1:tri.append([ids[i+1,j],ids[i+1,j+1],ids[i,j+1]])
 pp=np.array(positions);tt=np.array(tri);gn=np.cross(pp[tt[:,1]]-pp[tt[:,0]],pp[tt[:,2]]-pp[tt[:,0]])
 if gn[:,1].mean()>0:tt=tt[:,[0,2,1]]
 ob=mesh(name,pp,tt.tolist(),wool);bpy.context.view_layer.objects.active=ob;so=ob.modifiers.new('Lapel cloth thickness','SOLIDIFY');so.thickness=.002;so.offset=-1;bpy.ops.object.modifier_apply(modifier=so.name);be=ob.modifiers.new('Lapel rolled edge','BEVEL');be.width=.0006;be.segments=2;be.limit_method='ANGLE';bpy.ops.object.modifier_apply(modifier=be.name)
 return ob
left=[(-.080,.622),(-.205,.595),(-.221,.564),(-.150,.548),(.002,.424),(-.030,.598)]
fitted_lapel('Left notched military lapel',left);fitted_lapel('Right notched military lapel',[(.010-x,z) for x,z in left[::-1]])
# Leather belt follows the actual torso within a bounded radial ray window.
cen=np.array([.0064,.045,0.]);count=160;rows=[];profiles=[(.139,.0010),(.1385,.0024),(.139,.0038),(.198,.0038),(.1985,.0024),(.198,.0010)]
for zz,off in profiles:
 ring=[];rx=np.interp(zz,levels[:,0],levels[:,1]);ry=np.interp(zz,levels[:,0],levels[:,2])
 for th in np.arange(count)*2*np.pi/count:
  d=np.array([np.cos(th),np.sin(th),0]);guess=((abs(d[0])/rx)**3+(abs(d[1])/ry)**3)**(-1/3);c=cen.copy();c[2]=zz;hit,nn,fi,dist=bvh.ray_cast(Vector(c+d*(guess+.018)),Vector(-d),.044);assert hit is not None,('Belt support',zz,th)
  if np.dot(nn,d)<0:nn=-nn
  ring.append(np.array(hit)+np.array(nn)*off)
 rows.append(ring)
bp=np.concatenate(rows);bf=[]
for j in range(len(rows)):
 for i in range(count):a=j*count+i;b=j*count+(i+1)%count;c=((j+1)%len(rows))*count+(i+1)%count;d=((j+1)%len(rows))*count+i;bf.append([a,b,c,d])
mesh('Fitted waist leather belt',bp,bf,leather)
# A closed rectangular brass buckle with an actual opening.
hit,nn,fi,dd=bvh.ray_cast(Vector((.005,-2,.169)),Vector((0,1,0)),4);assert hit is not None
front=hit.y-.012;back=hit.y-.004;corners=[(-1,-1),(1,-1),(1,1),(-1,1)];p=[]
for yy in [front,back]:
 for w,h in [(.055,.050),(.039,.034)]:
  for x,z in corners:p.append([.005+x*w/2,yy,.169+z*h/2])
f=[]
for i in range(4):j=(i+1)%4;f.extend([[i,j,4+j,4+i],[8+i,12+i,12+j,8+j],[i,8+i,8+j,j],[4+i,4+j,12+j,12+i]])
b=mesh('Brass belt buckle',p,f,gold);bpy.context.view_layer.objects.active=b;be=b.modifiers.new('Buckle edge softness','BEVEL');be.width=.0015;be.segments=3;bpy.ops.object.modifier_apply(modifier=be.name)
# Export the complete clean jacket blockout; further lapel/collar/strap/detail work follows.
for ob in bpy.context.scene.objects:ob.select_set(ob.type=='MESH')
out=D/'inputs/jacket317_blockout.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_texcoords=True,export_normals=True,export_materials='EXPORT',export_yup=True)
import hashlib
meshes=[]
for ob in bpy.context.scene.objects:
 if ob.type=='MESH':ob.data.calc_loop_triangles();meshes.append({'name':ob.name,'triangles':len(ob.data.loop_triangles)})
r={'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':sum(x['triangles'] for x in meshes),'parts':meshes,'pointing_anchor':HP.tolist(),'pointing_axis':FP.tolist(),'grip_anchor':HG.tolist(),'grip_axis':FG.tolist(),'voxel_scope':'Only freshly authored clean torso/sleeve primitives are union-remeshed; no original source/head/hands are remeshed.','voxel_size_m':.0035,'scope':'Unapproved clean tailored jacket blockout with stronger torso/arms, cuff bores and pockets. Lapels, collars, belt/strap, military details, final paint and full skin/garment contact are pending. No whole-character promotion.'};(D/'audit/jacket317.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
