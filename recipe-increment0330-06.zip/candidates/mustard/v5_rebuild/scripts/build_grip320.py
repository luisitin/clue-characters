"""Stronger grip/forearm volume with held circular cane and measured coat clearance.
The same monotone radial map moves skin and cotton; the hand/cane pair then
moves forward together only as far as the actual new jacket requires.
"""
from pathlib import Path
import sys,copy,json,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from glb_io import GLB
from mathutils import Vector,Quaternion
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parents[1];reg=json.loads((D/'audit/grip210_registration.json').read_text());C=np.array(reg['shaft_center']);A=np.array(reg['shaft_axis']);L=np.diag([1.12,1.075,1.]);shift=np.array([.0064*(1-1.12),.05*(1-1.075),0]);CN=L@C+shift;la=L@A;stretch=np.linalg.norm(la);AN=la/stretch;r0=.014;bulk=.25
v=np.cross(A,AN);c=A@AN;K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]);Rot=np.eye(3)+K+K@K/(1+c);PM=Rot@(np.eye(3)+(stretch-1)*np.outer(A,A));dy=0.
def grip(P):
 q=P@L.T+shift;d=q-CN;s=d@AN;rad=d-s[:,None]*AN;r=np.linalg.norm(rad,axis=1);assert r.min()>r0*.99,r.min();f=1+bulk-bulk*r0/r;out=CN+s[:,None]*AN+f[:,None]*rad;er=rad/r[:,None];perp=np.eye(3)-np.outer(AN,AN);J=f[:,None,None]*perp[None]+(1+bulk-f)[:,None,None]*np.einsum('ni,nj->nij',er,er)+np.outer(AN,AN)[None];J=J@L;out[:,1]-=dy;return out,J

def prop(P):
 out=(P-C)@PM.T+CN;out[:,1]-=dy;return out,np.broadcast_to(PM,(len(P),3,3)).copy()
def read_part(g,node=0,pi=0):
 nd=g.j['nodes'][node];assert 'matrix' not in nd and 'rotation' not in nd;pr=g.j['meshes'][nd['mesh']]['primitives'][pi];S=np.array(nd.get('scale',[1,1,1]));Tr=np.array(nd.get('translation',[0,0,0]));p=g.read(pr['attributes']['POSITION']).astype('f8');P=(p*S+Tr)[:,[0,2,1]]*[1,-1,1];T=g.read(pr['indices']).reshape(-1,3);return P,T
pg=GLB(D/'inputs/prop_registered209.glb');PP,PT=read_part(pg);hg=GLB(D/'inputs/grip_registered210.glb');HP,HT=read_part(hg);HPnew,_=grip(HP)
# Build a geometry-only BVH for all jacket layers, respecting every node transform.
jg=GLB(D/'inputs/jacket317_blockout.glb');parent={ch:i for i,n in enumerate(jg.j['nodes']) for ch in n.get('children',[])};matrix_cache={}
def matrix(i):
 if i in matrix_cache:return matrix_cache[i]
 n=jg.j['nodes'][i]
 if 'matrix' in n:m=np.array(n['matrix']).reshape(4,4).T
 else:
  quat=n.get('rotation',[0,0,0,1]);rot=np.array(Quaternion((quat[3],*quat[:3])).to_matrix());m=np.eye(4);m[:3,:3]=rot@np.diag(n.get('scale',[1,1,1]));m[:3,3]=n.get('translation',[0,0,0])
 if i in parent:m=matrix(parent[i])@m
 matrix_cache[i]=m;return m
bp=[];bt=[];offset=0
for i,node in enumerate(jg.j['nodes']):
 if 'mesh' not in node:continue
 M=matrix(i)
 for pr in jg.j['meshes'][node['mesh']]['primitives']:
  p=jg.read(pr['attributes']['POSITION']).astype('f8');p=p@M[:3,:3].T+M[:3,3];p=p[:,[0,2,1]]*[1,-1,1];t=jg.read(pr['indices']).reshape(-1,3).astype('i8');bp.extend(p.tolist());bt.extend((t+offset).tolist());offset+=len(p)
bp=np.array(bp);bvh=BVHTree.FromPolygons(bp.tolist(),bt,all_triangles=True);lo=bp.min(0);hi=bp.max(0)
# Dense shaft circumference/length plus actual cap corners and face centres.
wood_ids=np.unique(PT);s=(PP[wood_ids]-C)@A;rad=PP[wood_ids]-C-s[:,None]*A;eu=rad[np.argmax(np.linalg.norm(rad,axis=1))];eu/=np.linalg.norm(eu);ev=np.cross(A,eu);ss=np.linspace(s.min(),s.max(),145);aa=np.arange(96)*2*np.pi/96;shell=(C+ss[:,None,None]*A+ r0*(np.cos(aa)[None,:,None]*eu+np.sin(aa)[None,:,None]*ev)).reshape(-1,3);propT=np.concatenate([pg.read(pr['indices']).reshape(-1,3) for pr in pg.j['meshes'][pg.j['nodes'][0]['mesh']]['primitives']]);ps=np.vstack((PP,PP[propT].mean(1),shell));ps=prop(ps)[0];oldH=np.array(reg['world_anchor']);oldF=np.array(reg['world_forward']);skin_faces=np.flatnonzero(np.min((HP[HT]-oldH)@oldF,axis=1)>.018);hs=np.vstack((HPnew[np.unique(HT[skin_faces])],HPnew[HT[skin_faces]].mean(1)));fit=[]
for label,points in [('cane',ps),('exposed_hand',hs)]:
 eligible=(points[:,0]>=lo[0])&(points[:,0]<=hi[0])&(points[:,2]>=lo[2])&(points[:,2]<=hi[2])&(points[:,1]>=lo[1]-.002);points=points[eligible];maximum_required=0.;hit_count=0;worst=None
 for k,p in enumerate(points):
  hit,n,fi,dd=bvh.ray_cast(Vector((p[0],-1.5,p[2])),Vector((0,1,0)),3)
  if hit is None:continue
  delta=float(p[1]-hit.y+.001)
  if delta>maximum_required:worst={'point':p.tolist(),'jacket_hit':list(hit),'required_forward_m':delta}
  maximum_required=max(maximum_required,delta);hit_count+=1
  if k%10000==0:print('FORWARD_FIT',label,k,len(points),maximum_required,flush=True)
 fit.append({'part':label,'tested_surface_samples':len(points),'jacket_hits':hit_count,'required_forward_m':maximum_required,'worst':worst})
dy=max(x['required_forward_m'] for x in fit);assert dy<.12,('Depth correction too large for automatic fit',fit);reports=[]

def export(srcname,outname,fn,only_pi=None):
 g=GLB(D/f'inputs/{srcname}.glb');nd=g.j['nodes'][0];S=np.array(nd.get('scale',[1,1,1]));Tr=np.array(nd.get('translation',[0,0,0]));prims=g.j['meshes'][nd['mesh']]['primitives'];selected=prims if only_pi is None else [prims[only_pi]];groups={}
 for pr in selected:groups.setdefault(tuple(sorted(pr['attributes'].items())),[]).append(pr)
 determinant=[];disp=[];vertices=0
 for key,pss in groups.items():
  at=dict(key);T=np.concatenate([g.read(p['indices']).reshape(-1,3) for p in pss]);used=np.unique(T);rawP=g.read(at['POSITION'],False)[used];P=(rawP.astype('f8')*S+Tr)[:,[0,2,1]]*[1,-1,1];Q,J=fn(P);det=np.linalg.det(J);assert det.min()>0;determinant.extend([float(det.min()),float(det.max())]);disp.append(float(np.linalg.norm(Q-P,axis=1).max()));vertices+=len(P);N=(g.read(at['NORMAL'],False)[used].astype('f8')/S)[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1,keepdims=True);NN=np.einsum('ni,nij->nj',N,np.linalg.inv(J));NN/=np.linalg.norm(NN,axis=1,keepdims=True);localN=(NN[:,[0,2,1]]*[1,1,-1])*S;localN/=np.linalg.norm(localN,axis=1,keepdims=True);attrs={'POSITION':g.append((((Q[:,[0,2,1]]*[1,1,-1]-Tr)/S)).astype('f4'),'VEC3',5126,34962),'NORMAL':g.append(localN.astype('f4'),'VEC3',5126,34962)}
  for k,ai in at.items():
   if k in attrs:continue
   data=g.read(ai,False)[used].copy();acc=g.j['accessors'][ai]
   if k=='TANGENT':
    t=(data[:,:3].astype('f8')*S)[:,[0,2,1]]*[1,-1,1];t=np.einsum('nij,nj->ni',J,t);t-=NN*np.sum(t*NN,axis=1,keepdims=True);t/=np.linalg.norm(t,axis=1,keepdims=True);t=(t[:,[0,2,1]]*[1,1,-1])/S;t-=localN*np.sum(t*localN,axis=1,keepdims=True);t/=np.linalg.norm(t,axis=1,keepdims=True);data[:,:3]=t.astype('f4')
   attrs[k]=g.append(data,acc['type'],acc['componentType'],34962)
   if acc.get('normalized'):g.j['accessors'][attrs[k]]['normalized']=True
  for pr in pss:
   it=g.read(pr['indices']).reshape(-1,3);pr['indices']=g.append(np.searchsorted(used,it).astype('u4').ravel(),'SCALAR',5125,34963);pr['attributes']=attrs.copy()
 g.j['meshes'][nd['mesh']]['primitives']=selected;nd['name']=outname;sha=g.save(D/f'inputs/{outname}.glb');reports.append({'source':srcname,'source_sha256':GLB(D/f'inputs/{srcname}.glb').sha256,'output':outname,'sha256':sha,'vertices':vertices,'determinant_range':[min(determinant),max(determinant)],'maximum_displacement_m':max(disp),'UV_material_texture_values_held':True})
export('grip_registered210','grip_stronger320',grip);export('grip_cuff235','grip_cotton320',grip,2);export('prop_registered209','prop_stronger320',prop)
Hnew,JH=grip(oldH[None]);Fnew=JH[0]@oldF;Fnew/=np.linalg.norm(Fnew);Cnew=CN.copy();Cnew[1]-=dy
r={'jacket317_sha256':jg.sha256,'components':reports,'forward_translation_m':dy,'forward_fit':fit,'world_anchor':Hnew[0].tolist(),'world_forward':Fnew.tolist(),'shaft_center':Cnew.tolist(),'shaft_axis':AN.tolist(),'shaft_radius_m':r0,'axial_scale':float(stretch),'radial_bulk_formula':'r_new = 14mm + 1.25*(r_after_body_affine - 14mm); skin/cotton share one monotone map outside the shaft. Circular cane radius is held.','scope':'Stronger hand/wrist/cotton and held circular cane, seated forward against dense actual jacket surface probes. Exposed-hand fit excludes the proximal wrist allowed inside its sleeve. Exact self/cuff/cane/body intersections and whole-character appearance remain pending; new coat wrist endpoint must use this reported anchor/axis.'};(D/'audit/grip320.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
