"""Held lower-body extraction with a concealed trouser extension under the new jacket."""
from pathlib import Path
import sys,copy,json,collections,numpy as np
from glb_io import GLB
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2];sys.path.insert(0,str(ROOT/'shared_tools/triangle_lib'));import triangle
src=GLB(D/'inputs/mustard_stronger298.glb');P,T,N,UV=src.native(0);sp=src.primitive(0);R={k:src.read(v,False) for k,v in sp['attributes'].items()};assert set(R)=={'POSITION','NORMAL','TEXCOORD_0'};S=np.array(src.j['nodes'][0]['scale']);Tr=np.array(src.j['nodes'][0]['translation']);cutz=-.200;topz=-.125;sd=P[:,2]-cutz;U,G=np.unique(P,axis=0,return_inverse=True);lists={k:v.tolist() for k,v in R.items()};cache={};physical={};cuts=set();faces=[];parent=[]
def cut(a,b):
 key=tuple(sorted((int(a),int(b))))
 if key in cache:return cache[key]
 gk=tuple(sorted((int(G[a]),int(G[b]))));f=sd[a]/(sd[a]-sd[b])
 if gk not in physical:
  aa,bb=(a,b) if G[a]<G[b] else (b,a);ff=sd[aa]/(sd[aa]-sd[bb]);physical[gk]=(R['POSITION'][aa].astype('f8')+ff*(R['POSITION'][bb].astype('f8')-R['POSITION'][aa])).astype('f4')
 values={k:(v[a].astype('f8')+f*(v[b].astype('f8')-v[a])) for k,v in R.items()};values['POSITION']=physical[gk];values['NORMAL']/=np.linalg.norm(values['NORMAL']);i=len(lists['POSITION'])
 for k,v in values.items():lists[k].append(v.tolist())
 cache[key]=i;cuts.add(i);return i
for fi,tr in enumerate(T):
 if sd[tr].min()>0:continue
 if sd[tr].max()<=0:faces.append(tr.tolist());parent.append(fi);continue
 poly=[]
 for k,b in enumerate(tr):
  a=tr[k-1];ia=sd[a]<=0;ib=sd[b]<=0
  if ia!=ib:poly.append(cut(a,b))
  if ib:poly.append(int(b))
 for k in range(1,len(poly)-1):faces.append([poly[0],poly[k],poly[k+1]]);parent.append(fi)
A={k:np.array(v,'f4') for k,v in lists.items()};F=np.array(faces,'i8');world=(A['POSITION'].astype('f8')*S+Tr)[:,[0,2,1]]*[1,-1,1];UU,GG=np.unique(world,axis=0,return_inverse=True);edges=collections.defaultdict(list)
for fi,tr in enumerate(GG[F]):
 for a,b in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(a),int(b))))].append((fi,int(a),int(b)))
cutgroups=set(GG[list(cuts)]);boundary={e:fs[0] for e,fs in edges.items() if len(fs)==1 and set(e)<=cutgroups};adj=collections.defaultdict(set)
for a,b in boundary:adj[a].add(b);adj[b].add(a)
left=set(adj);loops=[]
while left:
 root=min(left);seen={root};todo=[root]
 while todo:
  a=todo.pop()
  for b in adj[a]:
   if b not in seen:seen.add(b);todo.append(b)
 left-=seen;assert all(len(adj[v])==2 for v in seen),('Branched trouser cut',collections.Counter(len(adj[v]) for v in seen));order=[];v=min(seen);prev=None
 while not order or v!=order[0]:order.append(v);nxt=min(adj[v]-({prev} if prev is not None else set()));prev,v=v,nxt
 directions=[]
 for a,b in zip(order,np.roll(order,-1)):
  _,aa,bb=boundary[tuple(sorted((int(a),int(b))))];directions.append(1 if (a,b)==(aa,bb) else -1)
 assert len(set(directions))==1
 if directions[0]==1:order=order[::-1]
 loops.append(order)
assert loops,'No new trouser boundary';AF={k:v.tolist() for k,v in A.items()};wall=[];caps=[];counts=[]
for order in loops:
 q=UU[order];M=len(q);rootids=[]
 for v in order:
  rootids.append(int(np.flatnonzero(GG==v)[0]))
 rows=[rootids];center=q.mean(0)
 for zz in [-.170,topz]:
  rr=[]
  for i,p in enumerate(q):
   w=p.copy();w[2]=zz;raw=((w[[0,2,1]]*[1,1,-1]-Tr)/S).astype('f4');n=w-center;n[2]=0;n/=np.linalg.norm(n);rn=(n[[0,2,1]]*[1,1,-1])*S;rn/=np.linalg.norm(rn);ix=len(AF['POSITION']);AF['POSITION'].append(raw.tolist());AF['NORMAL'].append(rn.tolist());AF['TEXCOORD_0'].append(A['TEXCOORD_0'][rootids[i]].tolist());rr.append(ix)
  rows.append(rr)
 for r in range(2):
  for i in range(M):j=(i+1)%M;wall.extend([[rows[r][i],rows[r][j],rows[r+1][j]],[rows[r][i],rows[r+1][j],rows[r+1][i]]])
 xy=q[:,:2];segments=np.c_[np.arange(M),np.roll(np.arange(M),-1)].astype('i4');res=triangle.triangulate({'vertices':xy,'segments':segments},'pQY');mapping=[]
 for x,y in res['vertices']:
  w=np.array([x,y,topz]);raw=((w[[0,2,1]]*[1,1,-1]-Tr)/S).astype('f4');ix=len(AF['POSITION']);AF['POSITION'].append(raw.tolist());AF['NORMAL'].append([0,1,0]);AF['TEXCOORD_0'].append([0,0]);mapping.append(ix)
 ct=np.array(mapping)[res['triangles']];cw=np.array(AF['POSITION'])[ct];ww=(cw*S+Tr)[:,:,[0,2,1]]*[1,-1,1];gn=np.cross(ww[:,1]-ww[:,0],ww[:,2]-ww[:,0]);ct[gn[:,2]<0]=ct[gn[:,2]<0][:,[0,2,1]];caps.extend(ct.tolist());counts.append({'nodes':M,'bounds':[q.min(0).tolist(),q.max(0).tolist()]})
g=GLB(ROOT/'sources/prelod-cd4c20d/sus-mustard.glb');assert g.j['nodes'][0]['scale']==src.j['nodes'][0]['scale'];allF=np.vstack((F,np.array(wall),np.array(caps)));used=np.unique(allF);A={k:np.array(v,'f4')[used] for k,v in AF.items()};pantsF=np.searchsorted(used,np.vstack((F,np.array(wall)))).astype('u4');capF=np.searchsorted(used,np.array(caps)).astype('u4');attrs={k:g.append(v,'VEC'+str(v.shape[1]),5126,34962) for k,v in A.items()};pr=copy.deepcopy(g.primitive());pr['attributes']=attrs;pr['indices']=g.append(pantsF.ravel(),'SCALAR',5125,34963);mi=len(g.j['materials']);g.j['materials'].append({'name':'Concealed trouser interior','pbrMetallicRoughness':{'baseColorFactor':[.25,.14,.035,1],'roughnessFactor':1,'metallicFactor':0}});cap={'attributes':attrs.copy(),'indices':g.append(capF.ravel(),'SCALAR',5125,34963),'material':mi,'mode':4};g.j['meshes']=[{'name':'Held lower body319','primitives':[pr,cap]}];node=copy.deepcopy(g.j['nodes'][0]);node.update(mesh=0,name='Held lower body with concealed trouser extension319');node.pop('children',None);g.j['nodes']=[node];g.j['scenes']=[{'nodes':[0]}];g.j['scene']=0;sha=g.save(D/'inputs/lower_body319.glb');report={'source298_sha256':src.sha256,'output_sha256':sha,'cut_z':cutz,'concealed_extension_top_z':topz,'retained_and_clipped_triangles':len(F),'extension_triangles':len(wall),'concealed_cap_triangles':len(caps),'loops':counts,'triangles':len(allF),'scope':'Lower-body source geometry/paint held below the cut, with a short trouser extension and hidden cap under the replacement jacket. Source boot/gaiter defects and final paint remain; new seam/contact and actual assembly checks pending.'};(D/'audit/lower_body319.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
