"""Read-only larger neck/collar replacement domain: preserve head above a tilted under-jaw plane."""
from pathlib import Path
import json,collections,numpy as np
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/mustard_stronger293.glb');P,T,N,UV=g.native(0);C=np.array([-.045,.035,.71]);forward=np.array([-.6,-.8,0.]);pn=np.array([0.,0.,1.])+.18*forward;pn/=np.linalg.norm(pn);s=(P-C)@pn;U,grp=np.unique(P,axis=0,return_inverse=True);world=P.tolist();normal=N.tolist();uv=UV.tolist();cuts={};attributes={};faces=[];parent=[]
def cut(a,b):
 key=tuple(sorted((int(a),int(b))))
 if key in attributes:return attributes[key]
 ga,gb=int(grp[a]),int(grp[b]);gk=tuple(sorted((ga,gb)))
 if gk not in cuts:
  aa,bb=(a,b) if ga<gb else (b,a);t=s[aa]/(s[aa]-s[bb]);cuts[gk]=P[aa]+t*(P[bb]-P[aa])
 t=s[a]/(s[a]-s[b]);nn=N[a]+t*(N[b]-N[a]);nn/=np.linalg.norm(nn);uu=UV[a]+t*(UV[b]-UV[a]);i=len(world);world.append(cuts[gk]);normal.append(nn);uv.append(uu);attributes[key]=i;return i
for fi,tr in enumerate(T):
 if s[tr].max()<0:continue
 if s[tr].min()>=0:faces.append(tr);parent.append(fi);continue
 poly=[]
 for k,b in enumerate(tr):
  a=tr[k-1];ia=s[a]>=0;ib=s[b]>=0
  if ia!=ib:poly.append(cut(a,b))
  if ib:poly.append(int(b))
 for k in range(1,len(poly)-1):faces.append([poly[0],poly[k],poly[k+1]]);parent.append(fi)
W=np.array(world);F=np.array(faces);parent=np.array(parent);UU,G=np.unique(W,axis=0,return_inverse=True);FT=G[F];edges=collections.defaultdict(list)
for i,tr in enumerate(FT):
 for a,b in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(a),int(b))))].append(i)
adj=collections.defaultdict(set)
for fs in edges.values():
 for a in fs:
  adj[a].update(set(fs)-{a})
seed=int(np.argmax(W[F].mean(1)[:,2]));seen={seed};todo=[seed]
while todo:
 a=todo.pop()
 for b in adj[a]:
  if b not in seen:seen.add(b);todo.append(b)
sel=np.array(sorted(seen));H=F[sel];HE=collections.defaultdict(list)
for i,tr in enumerate(G[H]):
 for a,b in zip(tr,np.roll(tr,-1)):HE[tuple(sorted((int(a),int(b))))].append(i)
bound=[e for e,v in HE.items() if len(v)==1];ba=collections.defaultdict(set)
for a,b in bound:ba[a].add(b);ba[b].add(a)
left=set(ba);loops=[]
while left:
 root=min(left);ss={root};qq=[root]
 while qq:
  v=qq.pop()
  for b in ba[v]:
   if b not in ss:ss.add(b);qq.append(b)
 left-=ss;simple=all(len(ba[v])==2 for v in ss);order=[]
 if simple:
  v=min(ss);prev=None
  while not order or v!=order[0]:
   order.append(v);nxt=min(ba[v]-({prev} if prev is not None else set()));prev,v=v,nxt
 else:order=sorted(ss)
 q=UU[order];loops.append({'nodes':len(q),'simple':simple,'degree_histogram':dict(collections.Counter(len(ba[v]) for v in ss)),'bounds':[q.min(0).tolist(),q.max(0).tolist()],'max_distance_to_cut_plane_m':float(np.abs((q-C)@pn).max()),'positions':q.tolist(),'groups':order})
r={'source_sha256':g.sha256,'plane_center':C.tolist(),'plane_normal':pn.tolist(),'construction':'Connected above-plane head surface seeded at crown; tilted plane stays below chin in front and rises toward nape. Spatial geometry/connectivity only, no RGB selection. No edit/export performed.','head_triangles':len(H),'other_above_plane_triangles':len(F)-len(H),'head_bounds':[W[H].min((0,1)).tolist(),W[H].max((0,1)).tolist()],'nonmanifold_head_edges':sum(len(x)>2 for x in HE.values()),'boundary_components':loops,'scope':'Read-only neck replacement measurement. Source under-jaw boundary and complete seam still require actual diagnostic/geometry review before head extraction.'};(D/'audit/neck297_domain.json').write_text(json.dumps(r,indent=2));np.savez_compressed(D/'inputs/neck297_domain.npz',P=W,T=H,N=np.array(normal),UV=np.array(uv),PARENT_BODY_FACE=parent[sel]);print({k:v for k,v in r.items() if k!='boundary_components'},[(x['nodes'],x['simple'],x['degree_histogram'],x['max_distance_to_cut_plane_m']) for x in loops],flush=True)
