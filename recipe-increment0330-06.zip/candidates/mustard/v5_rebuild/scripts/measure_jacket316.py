from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/mustard_stronger298.glb');P,T,N,UV=g.native();q=P[T];rows=[]
for z in [.15,.30,.45,.54,.58,.60,.62,.64]:
 ids=np.flatnonzero((q[:,:,2].min(1)<=z)&(q[:,:,2].max(1)>=z));pts=[]
 for tr in q[ids]:
  for a,b in zip(tr,np.roll(tr,-1,axis=0)):
   if (a[2]-z)*(b[2]-z)<0:
    p=a+(z-a[2])/(b[2]-a[2])*(b-a)
    if -.12<=p[1]<=.27:pts.append(p)
 pts=np.array(pts);rows.append({'z':z,'point_count':len(pts),'x_quantiles':np.quantile(pts[:,0],[0,.005,.025,.975,.995,1]).tolist(),'y_bounds':[float(pts[:,1].min()),float(pts[:,1].max())]})
r={'source298_sha256':g.sha256,'sections':rows,'scope':'Read-only front/body breadth guide, restrictingY to[-.12,.27] to reduce the old prop contribution. It is a fit guide, not a semantic source extraction or quality pass.'};(D/'audit/jacket316_measurements.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
