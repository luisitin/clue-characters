"""Joint body/hand/cuff refinement of the stronger-build field.
Every coincident physical edge is split in the same global pre-warp topology,
including edges between separate material/node components. No T-junction is
introduced by independently refined component boundaries.
"""
from pathlib import Path
import numpy as np,json
from glb_io import GLB
from strength_field292 import deform,jacobian,gl_to_world,world_to_gl
from refine_strength293 import refine
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/pointing_context151.glb');parts=[];AA=[];TT=[];partface=[];at=0
for ni,node in enumerate(g.j['nodes']):
 if 'mesh' not in node:continue
 assert not any(k in node for k in ['matrix','rotation']);S=np.array(node.get('scale',[1,1,1.]));Tr=np.array(node.get('translation',[0,0,0.]));prims=g.j['meshes'][node['mesh']]['primitives'];groups={}
 for pi,pr in enumerate(prims):groups.setdefault(tuple(sorted(pr['attributes'].items())),[]).append(pi)
 for key,pis in groups.items():
  attrs=dict(key);raw={k:g.read(v,False) for k,v in attrs.items()};assert set(raw)<={'POSITION','NORMAL','TEXCOORD_0','TANGENT'};P=gl_to_world(raw['POSITION'].astype('f8'),S,Tr);N=(raw['NORMAL'].astype('f8')/S)[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1,keepdims=True)
  if 'TANGENT' in raw:tan=raw['TANGENT'].astype('f8').copy();tan[:,:3]=(tan[:,:3]*S)[:,[0,2,1]]*[1,-1,1]
  else:
   axis=np.tile([1.,0.,0.],(len(P),1));axis[np.abs(N[:,0])>.9]=[0.,1.,0.];t=axis-N*np.sum(axis*N,axis=1,keepdims=True);t/=np.linalg.norm(t,axis=1,keepdims=True);tan=np.c_[t,np.ones(len(t))]
  part=len(parts);groupF=[];groupM=[]
  for pi in pis:
   t=g.read(prims[pi]['indices']).reshape(-1,3).astype('i8');groupF.append(t+at);groupM.append(np.full(len(t),pi,'i4'))
  T=np.concatenate(groupF);pi_ids=np.concatenate(groupM);parts.append({'node':ni,'pis':pis,'start':at,'count':len(P),'S':S,'Tr':Tr,'raw':raw,'name':node.get('name'),'old_T':T-at,'face_start':sum(len(x) for x in TT),'face_pi':pi_ids});AA.append({'POSITION':P,'NORMAL':N,'TEXCOORD_0':raw['TEXCOORD_0'].astype('f8'),'TANGENT':tan});TT.append(T);partface.append(np.full(len(T),part,'i4'));at+=len(P)
A={k:np.concatenate([a[k] for a in AA]) for k in AA[0]};F0=np.concatenate(TT);partface=np.concatenate(partface);sourceP=A['POSITION'].copy();A,F,lineage,history=refine(A,F0,'whole298');P=A['POSITION'];Q=deform(P);J=jacobian(P);N=A['NORMAL'];NN=np.einsum('ni,nij->nj',N,np.linalg.inv(J));NN/=np.linalg.norm(NN,axis=1,keepdims=True);TN=np.einsum('nij,nj->ni',J,A['TANGENT'][:,:3]);TN-=NN*np.sum(TN*NN,axis=1,keepdims=True);TN/=np.linalg.norm(TN,axis=1,keepdims=True);newpart=partface[lineage];reports=[];all_pre=[];all_actual=[]
for part,desc in enumerate(parts):
 faceids=np.flatnonzero(newpart==part);used=np.unique(F[faceids]);newF=np.searchsorted(used,F[faceids]);S=desc['S'];Tr=desc['Tr'];raw=desc['raw'];world=Q[used];NW=NN[used];new={'POSITION':world_to_gl(world,S,Tr).astype('f4'),'NORMAL':(NW[:,[0,2,1]]*[1,1,-1])*S,'TEXCOORD_0':A['TEXCOORD_0'][used].astype('f4')};new['NORMAL']/=np.linalg.norm(new['NORMAL'],axis=1,keepdims=True);new['NORMAL']=new['NORMAL'].astype('f4');isold=(used>=desc['start'])&(used<desc['start']+desc['count']);oldids=used[isold]-desc['start'];held=(np.all(Q[used]==P[used],axis=1))&isold;heldids=used[held]-desc['start'];new['POSITION'][held]=raw['POSITION'][heldids];new['NORMAL'][held]=raw['NORMAL'][heldids];assert np.array_equal(new['TEXCOORD_0'][isold],raw['TEXCOORD_0'][oldids])
 if 'TANGENT' in raw:
  t=(TN[used][:,[0,2,1]]*[1,1,-1])/S;n=new['NORMAL'].astype('f8');n/=np.linalg.norm(n,axis=1,keepdims=True);t-=n*np.sum(t*n,axis=1,keepdims=True);t/=np.linalg.norm(t,axis=1,keepdims=True);new['TANGENT']=np.c_[t,A['TANGENT'][used,3]].astype('f4');new['TANGENT'][held]=raw['TANGENT'][heldids]
 actual=gl_to_world(new['POSITION'].astype('f8'),S,Tr);tri=P[used][newF];q=actual[newF];gn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);pred=np.einsum('ni,nij->nj',gn,np.linalg.inv(jacobian(tri.mean(1))));gg=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);area=np.linalg.norm(gg,axis=1);dot=np.sum(pred*gg,axis=1)/(np.linalg.norm(pred,axis=1)*area);assert dot.min()>.99
 attrs={k:g.append(v,'VEC'+str(v.shape[1]),5126,34962) for k,v in new.items()};prims=g.j['meshes'][g.j['nodes'][desc['node']]['mesh']]['primitives'];pim=desc['face_pi'][lineage[faceids]-desc['face_start']]
 for pi in desc['pis']:prims[pi]['attributes']=attrs.copy();prims[pi]['indices']=g.append(newF[pim==pi].ravel().astype('u4'),'SCALAR',5125,34963)
 all_pre.append(P[used]);all_actual.append(actual);np.savez_compressed(D/f'inputs/stronger298_part{part}_binding.npz',PREWARP_P=P[used],PREWARP_N=N[used],T=newF,SOURCE_FACE=lineage[faceids]-desc['face_start'],PRIMITIVE=pim)
 reports.append({'node':desc['node'],'name':desc['name'],'original_triangles':len(desc['old_T']),'triangles':len(newF),'vertices':len(used),'minimum_export_orientation_cosine':float(dot.min()),'minimum_double_area_m2':float(area.min()),'old_UVs_exact':True,'held_old_vertices':int(held.sum())})
pre=np.concatenate(all_pre);post=np.concatenate(all_actual);U,G=np.unique(pre,axis=0,return_inverse=True);joint_unique=np.unique(np.column_stack((G,post)),axis=0);assert len(joint_unique)==len(U),'Cross-component positional split after export';sha=g.save(D/'inputs/mustard_stronger298.glb');r={'source151_sha256':GLB(D/'inputs/pointing_context151.glb').sha256,'output_sha256':sha,'triangles':sum(x['triangles'] for x in reports),'joint_refinement':True,'global_exact_position_equivalence_after_export':True,'all_shared_edge_knots_propagated_across_components':True,'refinement_history':history,'components':reports,'scope':'Coherent stronger-build study using the292 field, now with globally conforming body/cuff shared edges. Old grip/cane, original garment/neck/face defects remain. User-directed neck/collar reconstruction and newer grip integration are next; actual appearance and contact regressions remain open.'};(D/'audit/stronger298.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
