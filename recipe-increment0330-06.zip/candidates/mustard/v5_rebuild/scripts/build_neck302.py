"""Bounded neck silhouette prototype beneath a held under-jaw head section.
Large explicit replacement component, not a head voxel rebuild. No assembly promotion.
"""
from pathlib import Path
import numpy as np,json,copy
from glb_io import GLB
D=Path(__file__).resolve().parents[1];s=json.loads((D/'audit/neck299_section.json').read_text());q=np.array(s['polygons'][0]['positions']);M=len(q);q2=q[:,:2];signed=.5*np.sum(q2[:,0]*np.roll(q2[:,1],-1)-q2[:,1]*np.roll(q2[:,0],-1))
if signed<0:q=q[::-1]
center=q.mean(0);e=np.linalg.norm(np.roll(q,-1,axis=0)-q,axis=1);u=np.r_[0,np.cumsum(e[:-1])]/e.sum();a0=np.arctan2(q[0,1]-center[1],q[0,0]-center[0]);theta=a0+2*np.pi*u;basecenter=np.array([-.058,.090,.626]);base=basecenter+np.c_[.077*np.cos(theta),.074*np.sin(theta),np.zeros(M)];rows=[];ts=np.r_[0,.025,.055,.10,.17,.26,.38,.52,.68,.83,1.]
for t in ts:
 # Broad convex neck volume tapers from the jaw into the shirt; top stays exact.
 # More of the jaw-to-neck narrowing happens just below the jaw, then becomes upright.
 w=1-(1-t)**1.8;P=q*(1-w)+base*w;P[:,2]=q[:,2]*(1-t)+base[:,2]*t;rows.append(P)
P=np.concatenate(rows);T=[]
for r in range(len(rows)-1):
 for i in range(M):
  j=(i+1)%M;a=r*M+i;b=r*M+j;c=(r+1)*M+j;d=(r+1)*M+i;T.extend([[a,c,b],[a,d,c]])
T=np.array(T,'u4');gn=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);areas=np.linalg.norm(gn,axis=1);assert areas.min()>1e-12;N=np.zeros_like(P)
for k in range(3):np.add.at(N,T[:,k],gn)
N/=np.linalg.norm(N,axis=1,keepdims=True);UV=np.c_[np.tile(u,len(rows)),np.repeat(ts,M)]
# Standalone neck diagnostic uses a neutral skin material; final skin maps pending.
g=object.__new__(GLB);g.bin=bytearray();g.j={'asset':{'version':'2.0','generator':'Bounded neck302 prototype'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'meshes':[],'nodes':[{'mesh':0,'name':'Unapproved anatomical neck302'}],'scenes':[{'nodes':[0]}],'scene':0,'materials':[{'name':'Provisional neck skin','pbrMetallicRoughness':{'baseColorFactor':[.68,.43,.29,1.],'roughnessFactor':.78,'metallicFactor':0},'doubleSided':False}]};attrs={'POSITION':g.append((P[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962),'NORMAL':g.append((N[:,[0,2,1]]*[1,1,-1]).astype('f4'),'VEC3',5126,34962),'TEXCOORD_0':g.append((UV*[1,-1]+[0,1]).astype('f4'),'VEC2',5126,34962)};g.j['meshes']=[{'primitives':[{'attributes':attrs,'indices':g.append(T.ravel(),'SCALAR',5125,34963),'material':0,'mode':4}]}];sha=g.save(D/'inputs/neck_skin302.glb');np.savez_compressed(D/'inputs/neck_skin302.npz',P=P,T=T,N=N,UV=UV,TOP=q,BASE=base)
# Export the exact clipped held head alone, preserving its source maps/lineage.
source=GLB(D/'inputs/mustard_stronger293.glb');z=np.load(D/'inputs/neck297_domain.npz');W=z['P'];HT=z['T'];HN=z['N'];HUV=z['UV'];used=np.unique(HT);local=np.searchsorted(used,HT);node=source.j['nodes'][0];S=np.array(node.get('scale',[1,1,1]));Tr=np.array(node.get('translation',[0,0,0]));rp=((W[used][:,[0,2,1]]*[1,1,-1]-Tr)/S).astype('f4');rn=(HN[used][:,[0,2,1]]*[1,1,-1])*S;rn/=np.linalg.norm(rn,axis=1,keepdims=True);pr=source.primitive();pr['attributes']={'POSITION':source.append(rp,'VEC3',5126,34962),'NORMAL':source.append(rn.astype('f4'),'VEC3',5126,34962),'TEXCOORD_0':source.append((HUV[used]*[1,-1]+[0,1]).astype('f4'),'VEC2',5126,34962)};pr['indices']=source.append(local.ravel().astype('u4'),'SCALAR',5125,34963);source.j['meshes']=[source.j['meshes'][node['mesh']]];node['mesh']=0;source.j['nodes']=[node];source.j['scenes']=[{'nodes':[0]}];source.j['scene']=0;hsha=source.save(D/'inputs/held_head302.glb')
r={'head_source293_sha256':GLB(D/'inputs/mustard_stronger293.glb').sha256,'held_head_sha256':hsha,'neck_sha256':sha,'neck_triangles':len(T),'top_boundary_nodes':M,'base_center':basecenter.tolist(),'base_radii':[.077,.074],'minimum_double_area_m2':float(areas.min()),'scope':'Unapproved silhouette prototype. Largest planar exterior attachment from299; residual source branches/head holes, exact top seam conformance, source/neck collision and final skin/collar integration are not cleared. No body replacement performed.'};(D/'audit/neck302.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
