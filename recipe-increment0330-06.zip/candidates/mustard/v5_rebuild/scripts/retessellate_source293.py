"""Quality triangulation confined to each unchanged original source triangle.
No source surface, UV field, outer boundary point, or original crease is moved.
Every refined source-edge segment and every supplied point must survive exactly.
"""
import collections,numpy as np
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'shared_tools/triangle_lib'))
import triangle

def boundary(T):
 edge=collections.Counter(tuple(sorted((int(a),int(b))))for f in T for a,b in zip(f,np.roll(f,-1)));assert max(edge.values())<=2;return {e for e,n in edge.items()if n==1}


def retessellate(P,F,lineage,baseP,baseF):
 order=np.argsort(lineage,kind='stable');groups=np.split(order,np.flatnonzero(np.diff(lineage[order]))+1);out=[];parents=[];changed=0;max_area_relative_error=0;minimum_quality=1.
 for group in groups:
  parent=int(lineage[group[0]])
  if len(group)==1:out.append(F[group]);parents.append(np.array([parent]));continue
  attr=np.unique(F[group]);points,first,alias=np.unique(P[attr],axis=0,return_index=True,return_inverse=True);canonical=attr[first];localmap={int(v):int(k)for v,k in zip(attr,alias)};old=np.array([[localmap[int(v)]for v in f]for f in F[group]],int);orig=baseP[baseF[parent]];X=orig[1]-orig[0];X/=np.linalg.norm(X);N=np.cross(orig[1]-orig[0],orig[2]-orig[0]);source_area=np.linalg.norm(N)/2;N/=2*source_area;Y=np.cross(N,X);xy=np.column_stack([(points-orig[0])@X,(points-orig[0])@Y]);scale=np.max(np.linalg.norm(orig-np.roll(orig,-1,axis=0),axis=1));chart=xy/scale;segments=np.array(sorted(boundary(old)),np.int32);result=triangle.triangulate({'vertices':chart,'segments':segments},'pQYYS0C');output=result['vertices'];lookup={tuple(x):k for k,x in enumerate(chart)};assert len(lookup)==len(chart);assert len(output)==len(chart) and all(tuple(x)in lookup for x in output),('Triangulator moved or added points',parent);mapping=np.array([lookup[tuple(x)]for x in output],int);tri=mapping[result['triangles']];area2=(xy[tri[:,1],0]-xy[tri[:,0],0])*(xy[tri[:,2],1]-xy[tri[:,0],1])-(xy[tri[:,1],1]-xy[tri[:,0],1])*(xy[tri[:,2],0]-xy[tri[:,0],0]);flip=area2<0;tri[flip]=tri[flip][:,[0,2,1]];area2=abs(area2);assert area2.min()>1e-20,('Degenerate new source triangulation',parent)
  assert boundary(old)==boundary(tri),('Source-face boundary segments changed',parent,len(points),len(boundary(old)),len(boundary(tri)))
  assert len(np.unique(tri))==len(points),('Triangulator omitted a source sample',parent)
  rel=abs(area2.sum()/2-source_area)/source_area;assert rel<1e-8,('Source planar area changed',parent,rel);max_area_relative_error=max(max_area_relative_error,float(rel));ed=points[tri]-np.roll(points[tri],-1,axis=1);minimum_quality=min(minimum_quality,float(np.min(area2/np.sum(ed*ed,axis=(1,2)))));out.append(canonical[tri]);parents.append(np.full(len(tri),parent,int));changed+=1
 return np.vstack(out),np.concatenate(parents),{'source_triangle_domains_retessellated':changed,'maximum_relative_source_plane_area_error':max_area_relative_error,'minimum_double_area_over_squared_edges':minimum_quality,'all_refined_outer_segments_and_points_preserved':True}
