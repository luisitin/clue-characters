"""Read-only polygonized under-jaw section, separating exterior contour from source branches."""
from pathlib import Path
import numpy as np,json,collections
D=Path(__file__).resolve().parents[1];z=np.load(D/'inputs/neck297_domain.npz');P=z['P'];T=z['T'];r=json.loads((D/'audit/neck297_domain.json').read_text());C=np.array(r['plane_center']);N=np.array(r['plane_normal']);U=np.cross([0,0,1.],N);U/=np.linalg.norm(U);V=np.cross(N,U);Q=(P-C)@np.c_[U,V];s=(P-C)@N;W,G=np.unique(P,axis=0,return_inverse=True);E=collections.defaultdict(list)
for i,tr in enumerate(G[T]):
 for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append(i)
cutedges=[e for e,f in E.items() if len(f)==1 and np.abs((W[list(e)]-C)@N).max()<1e-8];segments=np.array([(W[list(e)]-C)@np.c_[U,V] for e in cutedges]);fractions=[{0.,1.} for _ in segments]
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
for i,(a,b) in enumerate(segments):
 d=b-a
 for j in range(i+1,len(segments)):
  c,e=segments[j];v=e-c;den=cross(d,v)
  if abs(den)>1e-18:
   t=cross(c-a,v)/den;u=cross(c-a,d)/den
   if -1e-10<=t<=1+1e-10 and -1e-10<=u<=1+1e-10:fractions[i].add(float(np.clip(t,0,1)));fractions[j].add(float(np.clip(u,0,1)))
  elif abs(cross(c-a,d))<1e-14:
   for p in [c,e]:
    t=(p-a)@d/(d@d)
    if -1e-10<=t<=1+1e-10:fractions[i].add(float(np.clip(t,0,1)))
   for p in [a,b]:
    t=(p-c)@v/(v@v)
    if -1e-10<=t<=1+1e-10:fractions[j].add(float(np.clip(t,0,1)))
points=[];lookup={};edges=set()
def node(p):
 key=tuple(np.round(p,12))
 if key not in lookup:lookup[key]=len(points);points.append(np.array(key))
 return lookup[key]
for (a,b),fr in zip(segments,fractions):
 ids=[node(a+t*(b-a)) for t in sorted(fr)]
 for x,y in zip(ids,ids[1:]):
  if x!=y:edges.add(tuple(sorted((x,y))))
xyall=np.array(points);adj=collections.defaultdict(list)
for a,b in edges:adj[a].append(b);adj[b].append(a)
for a in adj:adj[a].sort(key=lambda b:np.arctan2(*(xyall[b]-xyall[a])[::-1]))
visited=set();polys=[]
for a,b in sorted(edges):
 for start in [(a,b),(b,a)]:
  if start in visited:continue
  cur=start;cycle=[]
  while cur not in visited:
   visited.add(cur);v,w=cur;cycle.append(v);order=adj[w];prev=order.index(v);cur=(w,order[(prev-1)%len(order)])
  assert cur==start
  q=xyall[cycle];area=.5*np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1))
  if area>1e-12:polys.append((area,cycle))
reports=[]
for area,cycle in sorted(polys,reverse=True):
 xy=xyall[cycle];xyz=C+xy[:,0,None]*U+xy[:,1,None]*V;reports.append({'area_m2':float(area),'simple_vertex_cycle':len(cycle)==len(set(cycle)),'exterior_nodes':len(xy),'bounds':[xy.min(0).tolist(),xy.max(0).tolist()],'positions':xyz.tolist(),'xy':xy.tolist()})
out={'source297_hash':r['source_sha256'],'section_edges':len(cutedges),'plane_center':C.tolist(),'plane_normal':N.tolist(),'axis_u':U.tolist(),'axis_v':V.tolist(),'polygons':reports,'scope':'Read-only plane-section union. Largest exterior is only a proposed anatomical neck attachment; discarded internal branches and upper-boundary source coverage still require explicit classification. No geometry is edited.'};(D/'audit/neck299_section.json').write_text(json.dumps(out,indent=2));print({k:v for k,v in out.items() if k!='polygons'},[{k:v for k,v in p.items() if k not in ['xy','positions']} for p in reports],flush=True)
