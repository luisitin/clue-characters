"""Small reusable components retaining exact source attributes and their original maps."""
from pathlib import Path
import copy,json,numpy as np
from glb_io import GLB
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2];strong=GLB(D/'inputs/mustard_stronger298.glb');head=GLB(D/'inputs/held_head302.glb');reports=[]
def extract(template,source,source_node,source_pi,template_pi,outname):
 g=GLB(template);sn=source.j['nodes'][source_node];tn=g.j['nodes'][0]
 for k in ['matrix','rotation','scale','translation']:assert sn.get(k)==tn.get(k),(k,sn.get(k),tn.get(k))
 sp=source.j['meshes'][sn['mesh']]['primitives'][source_pi];tp=copy.deepcopy(g.j['meshes'][tn['mesh']]['primitives'][template_pi]);T=source.read(sp['indices']).reshape(-1,3);used=np.unique(T);newT=np.searchsorted(used,T).astype('u4');attrs={}
 for key,ai in sp['attributes'].items():
  a=source.j['accessors'][ai];arr=source.read(ai,False)[used];new=g.append(arr,a['type'],a['componentType'],34962)
  if a.get('normalized'):g.j['accessors'][new]['normalized']=True
  attrs[key]=new
 tp['attributes']=attrs;tp['indices']=g.append(newT.ravel(),'SCALAR',5125,34963);g.j['meshes']=[{'name':outname,'primitives':[tp]}];tn=copy.deepcopy(tn);tn.update(mesh=0,name=outname);tn.pop('children',None);g.j['nodes']=[tn];g.j['scenes']=[{'nodes':[0]}];g.j['scene']=0;sha=g.save(D/f'inputs/{outname}.glb');check=GLB(D/f'inputs/{outname}.glb');cp=check.primitive()
 for key,ai in sp['attributes'].items():assert np.array_equal(check.read(cp['attributes'][key],False),source.read(ai,False)[used])
 reports.append({'output':outname+'.glb','sha256':sha,'source_sha256':source.sha256,'material_template':Path(template).name,'triangles':len(T),'vertices':len(used),'all_selected_attributes_exact':True,'material_images_held_in_template_BIN':True})
extract(ROOT/'sources/prelod-cd4c20d/sus-mustard.glb',head,0,0,0,'held_head318')
extract(D/'inputs/pointing_painted136.glb',strong,1,0,0,'pointing_stronger318')
extract(D/'inputs/pointing_cuff95.glb',strong,2,2,2,'pointing_cotton318')
(D/'audit/components318.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2),flush=True)
