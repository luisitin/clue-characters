from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/mustard_stronger298.glb');P,T,N,UV=g.native();q=P[T];rows=[]
for z in [-.175,-.11,0,.13,.20,.35,.49,.58,.63,.65]:
 ids=np.flatnonzero((q[:,:,2].min(1)<=z)&(q[:,:,2].max(1)>=z));pts=[]
 for tr in q[ids]:
  for a,b in zip(tr,np.roll(tr,-1,axis=0)):
   if (a[2]-z)*(b[2]-z)<0:
    p=a+(z-a[2])/(b[2]-a[2])*(b-a)
    if abs(p[0]-.0064)<.16:pts.append(p)
 pts=np.unique(np.round(np.array(pts),10),axis=0);rows.append({'z':z,'point_count':len(pts),'x_quantiles':np.quantile(pts[:,0],[0,.005,.025,.975,.995,1]).tolist(),'y_quantiles':np.quantile(pts[:,1],[0,.005,.025,.5,.975,.995,1]).tolist()})
r={'source298_sha256':g.sha256,'sections':rows,'scope':'Read-only central torso posture guide, restricting absolute X offset to160mm and deduplicating section points. Extreme prop/tie/collar samples still need anatomical classification. It is a fit guide, not a semantic source extraction or quality pass.'};(D/'audit/torso321_measurements.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
