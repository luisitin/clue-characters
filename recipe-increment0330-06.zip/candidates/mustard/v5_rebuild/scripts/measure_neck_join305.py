from pathlib import Path
import numpy as np,json
from scipy.spatial import cKDTree
from glb_io import GLB
D=Path(__file__).resolve().parents[1];h=GLB(D/'inputs/held_head302.glb');HP,HT,HN,HU=h.native();z=np.load(D/'inputs/neck_skin302.npz');q=z['TOP'];dist,ids=cKDTree(HP).query(q);r={'head_sha256':h.sha256,'neck_sha256':GLB(D/'inputs/neck_skin302.glb').sha256,'top_nearest_head_vertex_max_m':float(dist.max()),'unmatched_over_50nm':np.flatnonzero(dist>5e-8).tolist(),'unmatched_details':[{'index':int(i),'point':q[i].tolist(),'nearest':HP[ids[i]].tolist(),'distance_m':float(dist[i])} for i in np.flatnonzero(dist>5e-8)],'join_position_distances_m':dist.tolist(),'join_head_vertex_ids':ids.tolist()};(D/'audit/neck305_correspondence.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k not in ['join_position_distances_m','join_head_vertex_ids']},flush=True)
