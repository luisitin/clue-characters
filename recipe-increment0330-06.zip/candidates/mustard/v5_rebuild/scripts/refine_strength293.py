"""Conforming source-plane refinement for the stronger-build nonlinear field.
Adapted from Plum174/173: no source surface deletion; exact physical shared
edge knots and original corner attribute fields survive the refinement.
"""
from pathlib import Path
import numpy as np,json
from strength_field292 import deform,jacobian
from retessellate_source293 import retessellate
D=Path(__file__).resolve().parents[1]
def refine(attrs,F,label):
 attrs={k:v.copy() for k,v in attrs.items()};baseP=attrs['POSITION'].copy();baseF=F.copy();lineage=np.arange(len(F));history=[]
 for iteration in range(12):
  P=attrs['POSITION'];Q=deform(P);J=jacobian(P);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];badkeys=set();maxchord=0.;maxangle=0.;mindet=float(np.linalg.det(J).min());badfaces=0
  active=np.flatnonzero(np.any(np.linalg.norm(Q-P,axis=1)[F]>1e-10,axis=1))
  for start in range(0,len(active),1000):
   ids=active[start:start+1000];T=P[F[ids]];TQ=Q[F[ids]];cent=T.mean(1);mid=(T+np.roll(T,-1,axis=1))/2;Y=deform(mid.reshape(-1,3)).reshape(mid.shape);JJ=jacobian(cent);mindet=min(mindet,float(np.linalg.det(JJ).min()));edgeerr=np.linalg.norm(Y-(TQ+np.roll(TQ,-1,axis=1))/2,axis=2);g0=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);g1=np.cross(TQ[:,1]-TQ[:,0],TQ[:,2]-TQ[:,0]);expected=np.einsum('ni,nij->nj',g0,np.linalg.inv(JJ));dot=np.sum(expected*g1,axis=1)/(np.linalg.norm(expected,axis=1)*np.linalg.norm(g1,axis=1));ang=np.degrees(np.arccos(np.clip(dot,-1,1)));assert np.isfinite(ang).all();maxchord=max(maxchord,float(edgeerr.max()));maxangle=max(maxangle,float(ang.max()));bad=(edgeerr.max(1)>.00005)|(ang>5);badfaces+=int(bad.sum())
   for fi in ids[bad]:
    for k in range(3):badkeys.add(tuple(sorted((int(UF[fi,k]),int(UF[fi,(k+1)%3])))))
  row={'iteration':iteration,'triangles':len(F),'vertices':len(P),'active_faces':len(active),'maximum_chord_error_m':maxchord,'maximum_geometry_normal_error_degrees':maxangle,'minimum_jacobian_determinant':mindet,'bad_faces':badfaces,'split_edges':len(badkeys)};history.append(row);print(label,row,flush=True);(D/f'audit/stronger293_{label}_progress.json').write_text(json.dumps(history,indent=2));assert mindet>.4
  if not badkeys:return attrs,F,lineage,history
  assert iteration<11 and len(F)<250000,'Refinement limit; no GLB'
  lists={k:v.tolist() for k,v in attrs.items()};cache={};geo={};newF=[];newL=[]
  def midpoint(aa,bb):
   key=tuple(sorted((int(aa),int(bb))))
   if key in cache:return cache[key]
   gk=tuple(sorted((int(iv[aa]),int(iv[bb]))))
   if gk not in geo:geo[gk]=(U[gk[0]]+U[gk[1]])/2
   values={k:(v[aa]+v[bb])/2 for k,v in attrs.items()};values['POSITION']=geo[gk]
   if 'NORMAL' in values:values['NORMAL']/=np.linalg.norm(values['NORMAL'])
   if 'TANGENT' in values:
    assert attrs['TANGENT'][aa,3]==attrs['TANGENT'][bb,3],'Tangent sign change along a single attribute edge';values['TANGENT'][:3]/=np.linalg.norm(values['TANGENT'][:3])
   ix=len(lists['POSITION'])
   for k,v in values.items():lists[k].append(v.tolist())
   cache[key]=ix;return ix
  for fi,f in enumerate(F):
   chosen=[k for k in range(3) if tuple(sorted((int(UF[fi,k]),int(UF[fi,(k+1)%3])))) in badkeys]
   if not chosen:newF.append(f.tolist());newL.append(int(lineage[fi]));continue
   if len(chosen)==1:
    k=chosen[0];aa,bb,cc=map(int,[f[k],f[(k+1)%3],f[(k+2)%3]]);mm=midpoint(aa,bb);tris=[[aa,mm,cc],[mm,bb,cc]]
   elif len(chosen)==3:
    aa,bb,cc=map(int,f);ab=midpoint(aa,bb);bc=midpoint(bb,cc);ca=midpoint(cc,aa);tris=[[aa,ab,ca],[ab,bb,bc],[ca,bc,cc],[ab,bc,ca]]
   else:
    unsplit=next(k for k in range(3) if k not in chosen);aa=int(f[(unsplit+1)%3]);bb=int(f[(unsplit+2)%3]);cc=int(f[unsplit]);ab=midpoint(aa,bb);bc=midpoint(bb,cc);small=[bb,bc,ab];options=[[[aa,ab,bc],[aa,bc,cc]],[[aa,ab,cc],[ab,bc,cc]]]
    def quality(tris):
     xyz=np.array([[lists['POSITION'][v] for v in tri] for tri in tris]);e=xyz-np.roll(xyz,-1,axis=1);a=np.linalg.norm(np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]),axis=1);return float(np.min(a/np.sum(e*e,axis=(1,2))))
    tris=[small]+max(options,key=quality)
   newF.extend(tris);newL.extend([int(lineage[fi])]*len(tris))
  attrs={k:np.array(v) for k,v in lists.items()};F=np.array(newF,'i8');lineage=np.array(newL,'i8');F,lineage,retopo=retessellate(attrs['POSITION'],F,lineage,baseP,baseF);print(label,'RETESSELLATE',retopo,flush=True)
 raise AssertionError('No converged surface')
