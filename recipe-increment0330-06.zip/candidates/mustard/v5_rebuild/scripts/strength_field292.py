"""User-directed whole-build proportion study, with a shared smooth spatial field.
This is a reversible, coherent before/after study. It does not clear retained
source surface/paint defects, nor integrate the separate new grip/cane yet.
"""
from pathlib import Path
import numpy as np,json,hashlib
from glb_io import GLB
D=Path(__file__).resolve().parents[1]
H=np.array([.383,-.108,.25]);F=np.array([.9004954087497044,-.4002201816665353,.1700935772082775])
def smooth(x):
 x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))
def deform(P):
 P=np.asarray(P,dtype='f8');Q=P.copy();z=P[:,2]
 # Upper torso and shoulders gain breadth/depth. Head, lower legs and boots held.
 w=smooth((z+.10)/.30)*(1-smooth((z-.62)/.14))
 Q[:,0]=.0064+(P[:,0]-.0064)*(1+.12*w)
 Q[:,1]=.05+(P[:,1]-.05)*(1+.075*w)
 # Add radial palm/finger/wrist substance, blending through the forearm.
 # A position-based common field moves shared hand/cotton/coat coordinates
 # identically; the broad outer wool bell is not given the same extra bulk.
 d=P-H;s=d@F;rad=d-s[:,None]*F;r=np.linalg.norm(rad,axis=1)
 distal=smooth((s+.115)/.085);region=smooth((P[:,0]-.19)/.13)*(1-smooth((r-.05)/.055))
 bulk=distal*region
 Q+=.16*bulk[:,None]*rad
 return Q

def jacobian(P):
 eps=1e-6;J=np.empty((len(P),3,3))
 for k in range(3):
  d=np.zeros(3);d[k]=eps;J[:,:,k]=(deform(P+d)-deform(P-d))/(2*eps)
 return J

def gl_to_world(p,scale,tr):return (p*scale+tr)[:,[0,2,1]]*[1,-1,1]
def world_to_gl(p,scale,tr):return ((p[:,[0,2,1]]*[1,1,-1])-tr)/scale
