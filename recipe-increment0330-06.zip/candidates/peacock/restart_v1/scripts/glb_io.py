"""Small GLB accessor reader/writer. Original BIN bytes stay unchanged when appending."""
import json,struct,hashlib
from pathlib import Path
import numpy as np
DT={5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
class GLB:
    def __init__(self,path):
        self.path=Path(path);raw=self.path.read_bytes();self.sha256=hashlib.sha256(raw).hexdigest()
        magic,v,n=struct.unpack_from('<III',raw);assert magic==0x46546c67 and v==2 and n==len(raw)
        at=12;self.bin=bytearray()
        while at<len(raw):
            n,t=struct.unpack_from('<II',raw,at);chunk=raw[at+8:at+8+n];at+=8+n
            if t==0x4e4f534a:self.j=json.loads(chunk)
            elif t==0x004e4942:self.bin=bytearray(chunk)
    def read(self,i,normalize=True):
        a=self.j['accessors'][i];assert 'sparse' not in a
        v=self.j['bufferViews'][a['bufferView']];dt=np.dtype(DT[a['componentType']]);nc=NC[a['type']]
        off=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',dt.itemsize*nc)
        x=np.ndarray((a['count'],nc),dtype=dt,buffer=self.bin,offset=off,strides=(stride,dt.itemsize)).copy()
        if normalize and a.get('normalized'):
            info=np.iinfo(dt);x=x.astype('f8')/info.max
            if info.min<0:x=np.maximum(x,-1)
        return x[:,0] if nc==1 else x
    def append(self,arr,typ,component=5126,target=None):
        arr=np.ascontiguousarray(arr,dtype=DT[component]);self.bin.extend(b'\0'*((-len(self.bin))%4));off=len(self.bin)
        self.bin.extend(arr.tobytes());view={'buffer':0,'byteOffset':off,'byteLength':arr.nbytes}
        if target:view['target']=target
        vi=len(self.j['bufferViews']);self.j['bufferViews'].append(view)
        a={'bufferView':vi,'componentType':component,'count':len(arr),'type':typ}
        if typ=='VEC3':a.update(min=arr.min(axis=0).astype(float).tolist(),max=arr.max(axis=0).astype(float).tolist())
        ai=len(self.j['accessors']);self.j['accessors'].append(a);return ai
    def save(self,path):
        self.j['buffers'][0]['byteLength']=len(self.bin)
        js=json.dumps(self.j,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
        b=bytes(self.bin)+b'\0'*((-len(self.bin))%4)
        raw=struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(b))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(b),0x004e4942)+b
        Path(path).write_bytes(raw);return hashlib.sha256(raw).hexdigest()
    def primitive(self,node=0):return self.j['meshes'][self.j['nodes'][node]['mesh']]['primitives'][0]
    def native(self,node=0):
        n=self.j['nodes'][node];assert 'matrix' not in n and 'rotation' not in n
        pr=self.primitive(node);at=pr['attributes'];p=self.read(at['POSITION']).astype('f8')
        p=p*np.array(n.get('scale',[1,1,1]))+np.array(n.get('translation',[0,0,0]));p=p[:,[0,2,1]]*np.array([1,-1,1])
        normal=self.read(at['NORMAL']).astype('f8')/np.array(n.get('scale',[1,1,1]));normal=normal[:,[0,2,1]]*np.array([1,-1,1])
        normal/=np.maximum(np.linalg.norm(normal,axis=1,keepdims=True),1e-30)
        uv=self.read(at['TEXCOORD_0']).astype('f8');uv[:,1]=1-uv[:,1]
        t=self.read(pr['indices']).reshape(-1,3).astype('i8')
        return p,t,normal,uv
