"""Prepare clean skin parts for integration, with explicit hidden proximal caps."""
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np,json,hashlib
from mesh_clip350 import clip_plane,plane_boundary
R=Path(__file__).resolve().parents[1]
def load(name):
 with np.load(R/f'inputs/{name}.npz')as z:return {k:z[k].copy()for k in z.files}
def indexed(D,key,flip=False):
 uv=D[key].copy()
 if flip:uv[:,:,1]=1-uv[:,:,1]
 keys=np.column_stack([D['tri'].ravel(),uv.reshape(-1,2)]);unique,inv=np.unique(keys,axis=0,return_inverse=True);ids=unique[:,0].astype(int)
 return {'pos':D['pos'][ids],'normal':D['normal'][ids],'uv':unique[:,1:],'tri':inv.reshape(-1,3),'material':np.zeros(len(D['tri']),int)}
body=indexed(load('torso_upperarms349'),'corner_uv_native',True);body,upper=clip_plane(body,[0,0,1],.565,False);body,lower=clip_plane(body,[0,0,1],.205,True);GP,neckloops,neckreport=plane_boundary(body,[0,0,1],.565);assert neckreport['healthy_ordered_cycles']and len(neckloops)==1
P,N,U,T=[body[k]for k in ['pos','normal','uv','tri']];GP,G=np.unique(P,axis=0,return_inverse=True);F=G[T];E=defaultdict(list)
for fi,tr in enumerate(F):
 for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append((int(a),int(b),int(fi)))
be=[v[0]for v in E.values()if len(v)==1];nxt={a:b for a,b,_ in be};assert len(nxt)==len(be)and set(nxt)==set(nxt.values());remain=set(nxt);loops=[]
while remain:
 start=min(remain);loop=[start]
 while nxt[loop[-1]]!=start:loop.append(nxt[loop[-1]]);assert len(loop)<=len(nxt)
 remain-=set(loop);loops.append(np.array(loop,int))
pp=list(P);nn=list(N);uu=list(U);tt=list(T);mat=list(body['material']);caprows=[];position_index={tuple(p):i for i,p in enumerate(P)}
for loop in loops:
 q=GP[loop]
 if abs(q[:,2]-.565).max()<1e-10:continue
 center=q.mean(0);normal=np.cross(q-center,np.roll(q,-1,axis=0)-center).sum(0);normal/=np.linalg.norm(normal);waist=abs(q[:,2]-.205).max()<1e-10;pole=center-normal*(0 if waist else .012);pi=len(pp);pp.append(pole);nn.append(-normal);uu.append([.5,.5]);start=len(tt)
 # Cap uses independent corner normals/UVs at the same physical boundary.
 axes=np.linalg.svd(q-center,full_matrices=False)[2][:2];xy=(q-center)@axes.T;extent=np.maximum(abs(xy).max(0),1e-9);capuv=.5+.45*xy/extent;rim=[]
 for p,uv in zip(q,capuv):rim.append(len(pp));pp.append(p);nn.append(-normal);uu.append(uv)
 for j in range(len(loop)):tt.append([rim[(j+1)%len(loop)],rim[j],pi]);mat.append(1)
 caprows.append({'name':'waist'if waist else('left_upperarm'if center[0]>-.065 else'right_upperarm'),'boundary_vertices':len(loop),'center':center.tolist(),'pole':pole.tolist(),'triangles':len(tt)-start,'requires_garment_containment':True})
bodyout=R/'inputs/torso_ready355.npz';np.savez_compressed(bodyout,pos=np.asarray(pp),normal=np.asarray(nn),uv=np.asarray(uu),tri=np.asarray(tt,int),material=np.asarray(mat,int),neck_boundary_world=GP[neckloops[0]])
arms=indexed(load('forearm_assemblies346'),'corner_uv_png');armsout=R/'inputs/arms_ready355.npz';np.savez_compressed(armsout,**arms)
report={'torso_sha256':hashlib.sha256(bodyout.read_bytes()).hexdigest(),'arms_sha256':hashlib.sha256(armsout.read_bytes()).hexdigest(),'torso_triangles':len(tt),'arm_triangles':len(arms['tri']),'neck_clip':upper,'waist_clip':lower,'neck_boundary':neckreport,'hidden_caps':caprows,'UV_scope':'Original native hand/body corner UVs are retained; forearm charts and independent cap charts use a uniform material field during integration. Unique painted atlas proof is not claimed.','status':'Integration parts only. Caps, final head-neck join, source removal, garment contact/containment, exact float32 export and appearance remain open.'};(R/'checks/skin_parts355.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
