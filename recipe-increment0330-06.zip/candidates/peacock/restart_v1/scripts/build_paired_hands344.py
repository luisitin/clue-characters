"""Coherent CC0 torso, two arms and hands; no layered old/new anatomy.
Official native weights and corner UVs are held. Wrist targets come from the
registered source silhouette; inferred elbow centers solve the two-bone reach.
This is a separate fitting source, not yet a completed character replacement.
"""
from pathlib import Path
import sys,json,hashlib,math
import bpy,numpy as np
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman'
with np.load(R/'inputs/female_donor331.npz')as z:D={k:z[k].copy()for k in z.files}
rigdata=json.loads((DROOT/'raw/default.mhskel').read_text());names=list(map(str,D['bone_names']));J=dict(zip(map(str,D['joint_names']),D['joint_positions']));native=D['pos'];F=D['body_quads'];UV=D['body_corner_uv'];weights=D['weights']
armnames=[n for n in names if n.startswith(('clavicle.','shoulder','upperarm','lowerarm','wrist.','metacarpal','finger'))];armcols=[names.index(n)for n in armnames];aw=weights[:,armcols].sum(1);upper_vertex=((native[:,1]>1.30)|(aw>.01))&(native[:,1]<5.65);handpart=np.full(len(F),-1,int)
for part,side in enumerate(['L','R']):
 wrist=J[f'wrist.{side}____head'];mid=np.mean([J[f'finger{i}-1.{side}____head']for i in range(2,6)],axis=0);direction=(mid-wrist)/np.linalg.norm(mid-wrist);projection=(native-wrist)@direction;sign=1 if side=='L' else -1;eligible=(projection>-.22)&(native[:,0]*sign>abs(wrist[0])-.65)&(native[:,1]<3.0);handpart[eligible[F].all(1)]=part
faceids=np.where(handpart>=0)[0];keep,inv=np.unique(F[faceids],return_inverse=True);quads=inv.reshape(-1,4)
scale=.1;translation=np.array([-.065,-.005,.015]);B=np.array([[1,0,0],[0,0,-1],[0,1,0]],float)
def world(p):return np.asarray(p)@B.T*scale+translation
V=world(native[keep]);JW={n:world(p)for n,p in J.items()}
weightnames=['torso']+armnames;W=np.zeros((len(keep),len(weightnames)))
for col,n in enumerate(names):W[:,weightnames.index(n) if n in armnames else 0]+=weights[keep,col]
assert np.max(abs(W.sum(1)-1))<1e-8
facialcols=[i for i,n in enumerate(names)if n.startswith(('oris','oculi','temporalis','risorius','levator','orbicularis','tongue'))];assert np.max(weights[keep][:,facialcols].sum(1))<1e-6, 'Donor face must not be retained'
bpy.ops.wm.read_factory_settings(use_empty=True);me=bpy.data.meshes.new('Peacock coherent upper body');me.from_pydata(V.tolist(),[],quads.tolist());me.update();
for part in range(2):me.materials.append(bpy.data.materials.new('Native hand '+str(part)))
for polygon,fi in zip(me.polygons,faceids):polygon.material_index=int(handpart[fi])
ob=bpy.data.objects.new('Peacock clean torso arms and hands',me);bpy.context.collection.objects.link(ob);uv=me.uv_layers.new(name='Native rest corner UV')
for p,coords in zip(me.polygons,UV[faceids]):
 for li,coord in zip(p.loop_indices,coords):uv.data[li].uv=coord
for p in me.polygons:p.use_smooth=True
rd=bpy.data.armatures.new('Official anatomical body rig');rig=bpy.data.objects.new('Peacock arm pose rig',rd);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bone=rd.edit_bones.new('torso');bone.head=(-.065,0,.15);bone.tail=(-.065,0,.55)
for n in armnames:
 d=rigdata['bones'][n];eb=rd.edit_bones.new(n);eb.head=JW[d['head']];eb.tail=JW[d['tail']]
 plane=rigdata['planes'][d['rotation_plane']];a,b,c=[JW[k]for k in plane];pn=np.cross(b-a,c-a)
 if np.linalg.norm(pn)>1e-10:eb.align_roll(Vector(pn.tolist()))
for n in armnames:
 parent=rigdata['bones'][n]['parent'];rd.edit_bones[n].parent=rd.edit_bones[parent if parent in armnames else 'torso'];rd.edit_bones[n].use_connect=False
bpy.ops.object.mode_set(mode='OBJECT')
for col,n in enumerate(weightnames):
 vg=ob.vertex_groups.new(name=n)
 for i,w in enumerate(W[:,col]):
  if w>0:vg.add([i],float(w),'REPLACE')
mod=ob.modifiers.new('Official normalized DQ skinning','ARMATURE');mod.object=rig;mod.use_deform_preserve_volume=False
rest={n:np.array(rd.bones[n].matrix_local)for n in weightnames}
def unit(v):return v/np.linalg.norm(v)
def frame(long,normal):
 x=unit(long);z=normal-x*(x@normal);z=unit(z);y=np.cross(z,x);return np.column_stack([x,y,z])
def rigid(rotation,origin,target):
 a=np.eye(4);a[:3,:3]=rotation;a[:3,3]=target-rotation@origin;return a
def rotate_at(origin,axis,angle):
 x,y,z=unit(axis);t=math.radians(angle);c=math.cos(t);s=math.sin(t);K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]]);rot=np.eye(3)+s*K+(1-c)*(K@K);return rigid(rot,origin,origin)
def assign(n,a):rig.pose.bones[n].matrix=Matrix((a@rest[n]).tolist());bpy.context.view_layer.update()
landmarks={x['name']:x['hits'][0]for x in json.loads((R/'checks/body_landmarks332.json').read_text())['landmarks']}
settings={'L':{'wrist':np.array([.376,-.131,.472]),'pole':np.array([0.,.08,-1.]),'long':np.array([.13,-.025,.025]),'palmar':np.array(landmarks['raised_palm_surface']['authored_normal']),'angles':{1:[0,0,0],2:[3,12,5],3:[5,14,6],4:[7,16,7],5:[9,18,8]}},'R':{'wrist':np.array([-.258,-.158,.479]),'pole':np.array([-.121,-.050,-.164]),'long':np.array([.113,-.045,.047]),'palmar':-np.array(landmarks['collar_palm_surface']['authored_normal']),'angles':{1:[0,5,3],2:[5,10,4],3:[7,12,5],4:[9,14,6],5:[11,15,7]}}}
report={'source_component_sha256':hashlib.sha256((R/'inputs/female_donor331.npz').read_bytes()).hexdigest(),'scale_m_per_native_unit':scale,'translation':translation.tolist(),'source_surface_landmarks':'checks/body_landmarks332.json','body_source_quads':len(faceids),'native_neck_cut_max_y':5.65,'donor_lower_face_excluded':True,'palmar_convention':'L cross(index-pinky) is palmar; mirrored R has opposite sign, matching validated Mustard/Green native-hand helpers','all_metacarpal_bones_follow_same_hand_transform':True,'prior333_rejected':'Metacarpal weights were incorrectly collapsed into torso, leaving held palm tissue; fixed here before any integration.','normalized_weight_max_error':float(abs(W.sum(1)-1).max()),'skinning':'Standard LBS; DQ339 rejected with505 true crossings and14 sharp folds','collar_wrist_registration':'Depth moved to the actual forward wrist/hand region, avoiding the older dorsal forearm landmark; finger axis retained toward the measured collar fingertips','poses':{}}
for side,s in settings.items():
 shoulder=JW[f'upperarm01.{side}____head'];elbow0=JW[f'lowerarm01.{side}____head'];wrist0=JW[f'wrist.{side}____head'];target=s['wrist'];l1=np.linalg.norm(elbow0-shoulder);l2=np.linalg.norm(wrist0-elbow0);direction=unit(target-shoulder);distance=np.linalg.norm(target-shoulder);assert abs(l1-l2)<distance<l1+l2;a=(l1*l1-l2*l2+distance*distance)/(2*distance);h=math.sqrt(l1*l1-a*a);pole=unit(s['pole']-direction*(s['pole']@direction));elbow=shoulder+a*direction+h*pole;bend0=unit(np.cross(elbow0-shoulder,wrist0-elbow0));bend=unit(np.cross(elbow-shoulder,target-elbow));RU=frame(elbow-shoulder,bend)@frame(elbow0-shoulder,bend0).T;RF=frame(target-elbow,bend)@frame(wrist0-elbow0,bend0).T;AU=rigid(RU,shoulder,shoulder);AF=rigid(RF,elbow0,elbow)
 for name in [f'upperarm01.{side}',f'upperarm02.{side}']:assign(name,AU)
 for name in [f'lowerarm01.{side}',f'lowerarm02.{side}']:assign(name,AF)
 mids=np.mean([JW[f'finger{i}-1.{side}____head']for i in range(2,6)],axis=0);L0=mids-wrist0;A0=JW[f'finger2-1.{side}____head']-JW[f'finger5-1.{side}____head'];N0=unit(np.cross(L0,A0));native_palmar=N0*(1 if side=='L' else -1);desired_frame_n=s['palmar']*(1 if side=='L' else -1);RH=frame(s['long'],desired_frame_n)@frame(L0,N0).T;AH=rigid(RH,wrist0,target);assign(f'wrist.{side}',AH)
 # Distribute hand pronation through the two native forearm twist bones.
 faxis=unit(target-elbow);before=RF@native_palmar;after=RH@native_palmar;before=unit(before-faxis*(before@faxis));after=unit(after-faxis*(after@faxis));twist=math.degrees(math.atan2(faxis@np.cross(before,after),before@after))
 for k,fraction in [(1,.25),(2,.75)]:assign(f'lowerarm0{k}.{side}',rotate_at(elbow,faxis,twist*fraction)@AF)
 assign(f'wrist.{side}',AH)
 for k in range(1,5):assign(f'metacarpal{k}.{side}',AH)
 for fi in range(1,6):
  current=AH.copy()
  for k,angle in enumerate(s['angles'][fi],1):
   name=f'finger{fi}-{k}.{side}';bone=rigdata['bones'][name];head=JW[bone['head']];tail=JW[bone['tail']];axis0=unit(np.cross(tail-head,native_palmar));origin=current[:3,:3]@head+current[:3,3];axis=current[:3,:3]@axis0;current=rotate_at(origin,axis,angle)@current;assign(name,current)
 report['poses'][side]={'shoulder_center':shoulder.tolist(),'elbow_center_inferred':elbow.tolist(),'wrist_center_inferred':target.tolist(),'native_upperarm_length_m':float(l1),'native_forearm_length_m':float(l2),'finger_flex_degrees':s['angles'],'long_direction':unit(s['long']).tolist(),'palmar_direction':unit(s['palmar']).tolist(),'forearm_pronation_degrees':float(twist),'rotation_determinants':[float(np.linalg.det(r))for r in [RU,RF,RH]],'joint_scale_one':all(np.max(abs(np.array(rig.pose.bones[n].scale)-1))<1e-6 for n in armnames if n.endswith('.'+side))}
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_apply(modifier=mod.name);posed=np.array([v.co[:]for v in me.vertices]);sub=ob.modifiers.new('Anatomical surface detail','SUBSURF');sub.levels=2;sub.render_levels=2;bpy.ops.object.modifier_apply(modifier=sub.name);me=ob.data;me.calc_loop_triangles();P=np.array([v.co[:]for v in me.vertices]);T=np.array([t.vertices[:]for t in me.loop_triangles]);C=np.array([uv.uv[:]for uv in me.uv_layers.active.data]);cornerUV=np.array([C[np.array(t.loops)]for t in me.loop_triangles]);N=np.array([v.normal[:]for v in me.vertices]);out=R/'inputs/paired_hands344.npz';np.savez_compressed(out,pos=P,normal=N,tri=T,corner_uv_native=cornerUV,hand_part=np.array([me.polygons[t.polygon_index].material_index for t in me.loop_triangles],int),donor_vertex_ids=keep,donor_body_quad_ids=faceids,lowres_rest_world=V,lowres_posed_world=posed,lowres_quads=quads,normalized_weights=W,weight_names=np.array(weightnames))
report.update(component_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),triangles=len(T),vertices=len(P),pose_bounds=[P.min(0).tolist(),P.max(0).tolist()],status='Two native hands with verified proximal extraction domains; forearm continuations and source integration remain pending. No source character replacement/export yet. Whole-arm crossings, local folds, source likeness/contact, neck/waist junctions and material gates remain open. No original anatomy is layered into this component.');(R/'checks/paired_hands344.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
