"""Exact narrow phase for triangle coordinates represented by binary floating-point values.
Used only after a fast broad/numerical filter. No plane-distance tolerance creates endpoints.
"""
from fractions import Fraction as F
from functools import lru_cache
import math
@lru_cache(maxsize=8192)
def rational_triangle(flat):return tuple(tuple(F(float(flat[3*i+j])) for j in range(3)) for i in range(3))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),F(0))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def cross2(a,b):return a[0]*b[1]-a[1]*b[0]
def cut(T,distances):
    points=[]
    for i in range(3):
        j=(i+1)%3;di,dj=distances[i],distances[j]
        if di==0:points.append(T[i])
        if (di<0<dj)or(dj<0<di):points.append(add(T[i],mul(sub(T[j],T[i]),di/(di-dj))))
    return list(dict.fromkeys(points))
def barycentric(T,p,normal):
    drop=max(range(3),key=lambda k:abs(normal[k]));axes=[k for k in range(3) if k!=drop]
    q=[tuple(v[k]-T[0][k] for k in axes) for v in T];x=tuple(p[k]-T[0][k] for k in axes);den=cross2(sub(q[1],q[0]),sub(q[2],q[0]));a=cross2(sub(q[1],x),sub(q[2],x))/den;b=cross2(sub(q[2],x),sub(q[0],x))/den;return (a,b,1-a-b)
def planar_area(A,B,normal):
    drop=max(range(3),key=lambda k:abs(normal[k]));axes=[k for k in range(3) if k!=drop];origin=A[0];A=[tuple(p[k]-origin[k] for k in axes) for p in A];B=[tuple(p[k]-origin[k] for k in axes) for p in B];sgn=1 if cross2(sub(B[1],B[0]),sub(B[2],B[0]))>0 else -1;poly=A
    for k in range(3):
        edge=sub(B[(k+1)%3],B[k]);out=[]
        for i in range(len(poly)):
            x,y=poly[i-1],poly[i];dx=sgn*cross2(edge,sub(x,B[k]));dy=sgn*cross2(edge,sub(y,B[k]));ix,iy=dx>=0,dy>=0
            if ix!=iy:out.append(add(x,mul(sub(y,x),dx/(dx-dy))))
            if iy:out.append(y)
        poly=out
        if not poly:return F(0)
    return abs(sum((cross2(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly))),F(0)))/2
def exact_pair(A,B):
    A=rational_triangle(tuple(float(x) for p in A for x in p));B=rational_triangle(tuple(float(x) for p in B for x in p));NA=cross(sub(A[1],A[0]),sub(A[2],A[0]));NB=cross(sub(B[1],B[0]),sub(B[2],B[0]))
    if NA==(0,0,0) or NB==(0,0,0):return {'kind':'degenerate'}
    dA=[dot(sub(p,B[0]),NB) for p in A];dB=[dot(sub(p,A[0]),NA) for p in B]
    if min(dA)>0 or max(dA)<0 or min(dB)>0 or max(dB)<0:return {'kind':'none'}
    direction=cross(NA,NB)
    if direction==(0,0,0):
        if any(dA):return {'kind':'none'}
        area=planar_area(A,B,NA);return {'kind':'coplanar_overlap' if area>0 else 'contact','projected_area':float(area)}
    ca,cb=cut(A,dA),cut(B,dB)
    if len(ca)<2 or len(cb)<2:return {'kind':'contact'}
    axis=max(range(3),key=lambda k:abs(direction[k]));lo=max(min(p[axis] for p in ca),min(p[axis] for p in cb));hi=min(max(p[axis] for p in ca),max(p[axis] for p in cb))
    if hi<lo:return {'kind':'none'}
    if hi==lo:return {'kind':'contact'}
    start=add(ca[0],mul(direction,(lo-ca[0][axis])/direction[axis]));end=add(ca[0],mul(direction,(hi-ca[0][axis])/direction[axis]));mid=mul(add(start,end),F(1,2));ba=barycentric(A,mid,NA);bb=barycentric(B,mid,NB);assert min(ba)>=0 and min(bb)>=0,(ba,bb)
    return {'kind':'proper','length':math.sqrt(sum(float(x-y)**2 for x,y in zip(start,end))),'midpoint':[float(x) for x in mid],'barycentric_A':[float(x) for x in ba],'barycentric_B':[float(x) for x in bb],'boundary_only':min(ba)==0 or min(bb)==0,'exact_float_coordinate_predicate':True}
