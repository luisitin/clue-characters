"""Attribute-preserving linear-plane clipping with exact positional seam groups."""
import numpy as np
from collections import defaultdict

def clip_field(data,field):
 P,N,U,T,M=[data[k] for k in ['pos','normal','uv','tri','material']];signed=np.asarray(field(P),float)
 inside=signed>=0;allin=inside[T].all(1);allout=(~inside[T]).all(1);cross=np.where(~allin&~allout)[0];points=list(P);normals=list(N);uvs=list(U);triangles=list(T[allin]);materials=list(M[allin]);parents=list(np.where(allin)[0]);cache={};poscache={}
 def cut(a,b):
  if signed[a]==0:return int(a)
  if signed[b]==0:return int(b)
  key=tuple(sorted((int(a),int(b))))
  if key in cache:return cache[key]
  a,b=key;t=signed[a]/(signed[a]-signed[b]);pkey=tuple(sorted((tuple(P[a]),tuple(P[b]))))
  if pkey not in poscache:
   aa,bb=map(np.asarray,pkey);da=float(field(aa));db=float(field(bb));tt=da/(da-db);poscache[pkey]=aa+tt*(bb-aa)
  normal=(1-t)*N[a]+t*N[b];normal/=np.linalg.norm(normal);idx=len(points);points.append(poscache[pkey]);normals.append(normal);uvs.append((1-t)*U[a]+t*U[b]);cache[key]=idx;return idx
 for fi in cross:
  tr=T[fi];poly=[]
  for a,b in zip(tr,np.roll(tr,-1)):
   if inside[a]:poly.append(int(a))
   if inside[a]!=inside[b]:poly.append(cut(a,b))
  clean=[]
  for v in poly:
   if not clean or v!=clean[-1]:clean.append(v)
  if len(clean)>1 and clean[0]==clean[-1]:clean.pop()
  for k in range(1,len(clean)-1):triangles.append([clean[0],clean[k],clean[k+1]]);materials.append(M[fi]);parents.append(int(fi))
 PP=np.asarray(points);NN=np.asarray(normals);UU=np.asarray(uvs);TT=np.asarray(triangles,int);MM=np.asarray(materials,int);used,inv=np.unique(TT,return_inverse=True)
 return {'pos':PP[used],'normal':NN[used],'uv':UU[used],'tri':inv.reshape(-1,3),'material':MM,'parent_face':np.asarray(parents,int),'cut_vertex_mask':used>=len(P)}, {'unchanged_triangles':int(allin.sum()),'removed_triangles':int(allout.sum()),'cut_triangles':len(cross),'new_attribute_vertices':len(points)-len(P),'new_physical_positions':len(poscache),'anatomical_field_clipping':True}
