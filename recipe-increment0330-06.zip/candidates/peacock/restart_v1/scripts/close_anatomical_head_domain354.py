"""Grow only the explicit neck reconstruction boundary past branched source edges.
Removed boundary faces are reconstruction-domain expansion, not asserted
redundant overlays. The original face/ear regions are protected by position.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib,numpy as np
R=Path(__file__).resolve().parents[1];parent=R/'inputs/held_head353_665.npz'
with np.load(parent)as z:D={k:z[k].copy()for k in z.files}
P,T,N,U,M=[D[k]for k in ['pos','tri','normal','uv','material']];GP,G=np.unique(P,axis=0,return_inverse=True);F=G[T];seed=np.zeros(len(GP),bool);np.logical_or.at(seed,G,D['cut_vertex_mask']);keep=np.ones(len(T),bool);history=[];success=False;lastloops=[]
for iteration in range(30):
 E=defaultdict(list);VF=defaultdict(list)
 for fi in np.where(keep)[0]:
  for v in F[fi]:VF[int(v)].append(int(fi))
  for a,b in zip(F[fi],np.roll(F[fi],-1)):E[tuple(sorted((int(a),int(b))))].append((int(a),int(b),int(fi)))
 boundary=[(e,v[0])for e,v in E.items()if len(v)==1];adj=defaultdict(list)
 for(a,b),_ in boundary:adj[a].append(b);adj[b].append(a)
 startset=set(np.where(seed)[0])&set(adj);region=set(startset);stack=list(startset)
 while stack:
  a=stack.pop()
  for b in adj[a]:
   if b not in region:region.add(b);stack.append(b)
 assert region
 bad={i for i in region if len(adj[i])!=2};row={'iteration':iteration,'remaining_triangles':int(keep.sum()),'boundary_nodes':len(region),'bad_degree_histogram':dict(Counter(len(adj[i])for i in bad))}
 if not bad:
  remaining=set(region);loops=[]
  while remaining:
   start=min(remaining);loop=[start];prev=None;cur=start
   while True:
    nxt=adj[cur][0]if adj[cur][0]!=prev else adj[cur][1]
    if nxt==start:break
    loop.append(nxt);prev,cur=cur,nxt;assert len(loop)<=len(region)
   remaining-=set(loop);loops.append(np.array(loop,int))
  row['cycles']=[len(q)for q in loops];history.append(row);lastloops=loops;success=len(loops)==1;break
 drop=sorted({fi for v in bad for fi in VF[v]});q=P[T[drop]];protected=(q[:,:,2]>.705).any(1)|((q[:,:,1]<-.100)&(q[:,:,2]>.645)).any(1)
 if protected.any():row['blocked_protected_triangles']=[int(drop[i])for i in np.where(protected)[0]];history.append(row);break
 row['removed_faces']=len(drop);row['removed_bounds']=[q.min((0,1)).tolist(),q.max((0,1)).tolist()];history.append(row);keep[drop]=False;seed[np.unique(F[drop])]=True
report={'parent_sha256':hashlib.sha256(parent.read_bytes()).hexdigest(),'iterations':history,'success_one_healthy_undirected_cycle':success,'removed_extra_source_faces':np.where(~keep)[0].tolist(),'removed_parent295_faces':D['parent_face'][~keep].tolist(),'scope':'Explicit bounded neck-domain reconstruction. No color-based deletion or backing-redundancy claim. Facial source triangle corners outside the expanded domain remain held; source winding, fitted neck and visual/source ownership checks remain open.'}
if success:
 loop=lastloops[0];used,inv=np.unique(T[keep],return_inverse=True);out=R/'inputs/held_head354.npz';np.savez_compressed(out,pos=P[used],normal=N[used],uv=U[used],tri=inv.reshape(-1,3),material=M[keep],parent_face=D['parent_face'][keep],boundary_world=GP[loop]);report['sha256']=hashlib.sha256(out.read_bytes()).hexdigest();report['boundary_bounds']=[GP[loop].min(0).tolist(),GP[loop].max(0).tolist()];report['boundary_vertices']=len(loop)
(R/'checks/anatomical_head354.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
