"""Separate old flared collar from the retained head using anatomical position.
The front chin stays protected; the raised side/back threshold removes the
fused old collar. Color is not used as a geometry-deletion criterion.
"""
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np,json,hashlib
from mesh_clip_field353 import clip_field
R=Path(__file__).resolve().parents[1]
with np.load(R/'inputs/face_oppositepaint295.npz')as z:D={k:z[k].copy()for k in z.files}
def smooth(x):x=np.clip(x,0,1);return x*x*x*(10-15*x+6*x*x)
rows=[]
for high in [.655,.665,.675]:
 def field(q):
  q=np.asarray(q);x,y,z=q[...,0],q[...,1],q[...,2];r=np.sqrt(((x+.062)/.045)**2+(np.maximum(y+.025,0)/.025)**2);radial=smooth((r-.75)/.90);frontguard=smooth((y+.100)/.04);floor=.590+(high-.590)*radial*frontguard;return z-floor
 C,r=clip_field(D,field);P,T=C['pos'],C['tri'];GP,G=np.unique(P,axis=0,return_inverse=True);F=G[T];cut=np.zeros(len(GP),bool);np.logical_or.at(cut,G,C['cut_vertex_mask']);E=defaultdict(list)
 for fi,tr in enumerate(F):
  for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append((int(a),int(b),fi))
 border=[(e,v[0])for e,v in E.items()if len(v)==1 and cut[e[0]]and cut[e[1]]];adj=defaultdict(list)
 for (a,b),_ in border:adj[a].append(b);adj[b].append(a)
 healthy=bool(adj)and all(len(v)==2 for v in adj.values());loops=[]
 if healthy:
  remain=set(adj)
  while remain:
   start=min(remain);loop=[start];last=None;cur=start
   while True:
    nxt=adj[cur][0]if adj[cur][0]!=last else adj[cur][1]
    if nxt==start:break
    loop.append(nxt);last,cur=cur,nxt;assert len(loop)<=len(adj)
   remain-=set(loop);loops.append(np.array(loop,int))
 count=r['unchanged_triangles'];inside=field(D['pos'])>=0;held=D['tri'][inside[D['tri']].all(1)];assert np.array_equal(C['pos'][C['tri'][:count]],D['pos'][held]);assert np.array_equal(C['normal'][C['tri'][:count]],D['normal'][held]);assert np.array_equal(C['uv'][C['tri'][:count]],D['uv'][held]);name=f'held_head353_{round(high*1000)}';extra={'boundary_world':GP[loops[0]]}if healthy and len(loops)==1 else{};np.savez_compressed(R/f'inputs/{name}.npz',**C,**extra)
 r.update(high_side_back_cut=high,front_throat_cut=.590,front_chin_protected_below_y=-.100,color_not_used=True,unchanged_triangle_corners_P_N_UV_exact=True,file=name,sha256=hashlib.sha256((R/f'inputs/{name}.npz').read_bytes()).hexdigest(),cut_boundary_edges=len(border),cut_node_degree_histogram=dict(Counter(len(v)for v in adj.values())),healthy_undirected_cycles=healthy,cycle_lengths=[len(q)for q in loops],bounds=[P.min(0).tolist(),P.max(0).tolist()],ring_bounds=[[GP[q].min(0).tolist(),GP[q].max(0).tolist()]for q in loops],status='Head retention trial. Exact cut ownership/appearance, ordered source-to-donor bridge, source winding and actual whole-character regression remain open.');rows.append(r)
(R/'checks/anatomical_head353.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
