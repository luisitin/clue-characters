"""Prepare pinned CC0 female body data for coherent arm/upper-body replacement.
This does not replace the original head or change any model geometry.
"""
from pathlib import Path
import sys,numpy as np,json,hashlib
R=Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
D=load_donor();V=D['positions'].copy();rest=V.copy();provenance=json.loads((R/'checks/female_body_targets329_provenance.json').read_text());used=[]
for name in ['caucasian-female-young.target','universal-female-young-averagemuscle-averageweight.target']:
 p=R/'inputs/sources'/name;lines=[line.split() for line in p.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')];data=np.array(lines,float).reshape(-1,4);ids=data[:,0].astype(int);assert len(np.unique(ids))==len(ids);V[ids]+=data[:,1:4];used.append({'name':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'weight':1.0,'delta_vertices':len(ids)})
J={name:V[ids].mean(0) for name,ids in D['rig']['joints'].items()};bodyids=D['body_face_ids'];F=np.array([D['faces'][i]for i in bodyids],int);FU=np.array([D['face_uv'][i]for i in bodyids],int);assert F.shape[1]==4
upper=V[F];chosen=(upper[:,:,1].min(1)>-.5)&(upper[:,:,1].max(1)<6.3)
jn=list(J);JP=np.array([J[n]for n in jn]);out=R/'inputs/female_donor331.npz';np.savez_compressed(out,pos=V,original_rest_pos=rest,body_quads=F,body_corner_uv=D['uv'][FU],body_source_faces=bodyids,bone_names=np.array(D['bone_names']),weights=D['weights_normalized'],joint_names=np.array(jn),joint_positions=JP)
rows={n:J[n].tolist()for n in jn if n.startswith(('upperarm','lowerarm','wrist','neck','spine','clavicle','shoulder'))}
report={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'target_data':used,'body_quads':len(F),'provisional_upper_quads':int(chosen.sum()),'native_unit_coordinates':rows,'status':'Unposed data only. Original face identity remains held; pose, source anatomical cuts, replacement and contact gates still open.'};(R/'checks/female_donor331.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
