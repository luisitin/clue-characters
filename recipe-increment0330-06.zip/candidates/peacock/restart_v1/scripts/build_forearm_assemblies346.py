"""Closed anatomical forearm/hand assemblies with held native fingers.
The failed elbow skin deformation is omitted. A smooth tapered forearm extends
from each genuine ordered wrist rim to a rounded proximal end inside the coat.
"""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib,numpy as np
R=Path(__file__).resolve().parents[1]
with np.load(R/'inputs/paired_hands344.npz')as z:D={k:z[k].copy()for k in z.files}
P=D['pos'].copy();T=D['tri'].copy();N=D['normal'].copy();UV=D['corner_uv_native'].copy();UV[:,:,1]=1-UV[:,:,1];part=D['hand_part'].copy();pout=list(P);tout=list(T);uvout=list(UV);parts=list(part);rows=[]
def unit(a):return a/np.linalg.norm(a)
def rotation(a,b):
 a=unit(a);b=unit(b);v=np.cross(a,b);c=a@b;s=np.linalg.norm(v)
 if s<1e-10:
  assert c>0;return np.eye(3)
 K=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]]);return np.eye(3)+K+K@K*((1-c)/(s*s))
settings={0:{'side':'L','proximal_center':[.250,-.080,.307],'proximal_radii':[.0305,.0265],'cap_length':.021},1:{'side':'R','proximal_center':[-.342,-.076,.307],'proximal_radii':[.0295,.0255],'cap_length':.021}}
for hp,s in settings.items():
 fs=np.where(part==hp)[0];E=defaultdict(list)
 for fi in fs:
  for a,b in zip(T[fi],np.roll(T[fi],-1)):E[tuple(sorted((int(a),int(b))))].append((int(a),int(b),int(fi)))
 border=[v[0]for v in E.values()if len(v)==1];assert all(len(v)<=2 for v in E.values());nxt={a:b for a,b,_ in border};assert len(nxt)==len(border) and set(nxt)==set(nxt.values());loop=[min(nxt)]
 while nxt[loop[-1]]!=loop[0]:loop.append(nxt[loop[-1]]);assert len(loop)<=len(border)
 assert len(loop)==len(border);loop=np.array(loop[::-1],int);no=len(loop);Q=P[loop];W=Q.mean(0);C=np.array(s['proximal_center']);prox=unit(C-W);axis=-prox;centered=Q-W;cov=centered.T@centered;_,eig=np.linalg.eigh(cov);normal=eig[:,0]
 if normal@axis<0:normal=-normal
 A=unit(eig[:,-1]-normal*(eig[:,-1]@normal));B=np.cross(normal,A);theta=np.arctan2(centered@B,centered@A);unwrapped=np.unwrap(np.r_[theta,theta[0]]);step=np.diff(unwrapped);assert (step>0).all()or(step<0).all(), 'Wrist cycle must be star-shaped and ordered'
 Rframe=rotation(normal,axis);A1=Rframe@A;B1=Rframe@B;ra,rb=s['proximal_radii'];R1=np.cos(theta)[:,None]*ra*A1+np.sin(theta)[:,None]*rb*B1;target=C+R1;long=C-W;length=np.linalg.norm(long)
 # Continue each retained wrist tangent. One common position is used for every
 # occurrence of a physical rim vertex; native hand positions stay byte-equal.
 nn=N[loop]/np.linalg.norm(N[loop],axis=1)[:,None];d0=long[None]-np.sum(nn*long,axis=1)[:,None]*nn;advance=d0@prox;assert advance.min()>.12*length;d0*=length/advance[:,None];d1=np.tile(long,(no,1));times=np.r_[0,.005,.012,.025,np.linspace(.045,1,40)];ringids=[loop];ringcenters=[W];ringUV=[np.column_stack([(unwrapped[:-1]-unwrapped[0])/(unwrapped[-1]-unwrapped[0]),np.zeros(no)])]
 for t in times[1:]:
  h00=2*t**3-3*t*t+1;h10=t**3-2*t*t+t;h01=-2*t**3+3*t*t;h11=t**3-t*t;X=h00*Q+h10*d0+h01*target+h11*d1
  # A small, smooth muscle-volume increase has zero endpoint derivative.
  bulge=.0025*np.sin(np.pi*t)**2;radial=np.cos(theta)[:,None]*A1+np.sin(theta)[:,None]*B1;X+=bulge*radial
  ids=np.arange(len(pout),len(pout)+no);pout.extend(X);ringids.append(ids);ringcenters.append(h00*W+h10*long+h01*C+h11*long);ringUV.append(np.column_stack([ringUV[0][:,0],np.full(no,t*.75)]))
 for a in np.linspace(0,np.pi/2,13)[1:-1]:
  X=C+prox*s['cap_length']*np.sin(a)+R1*np.cos(a);ids=np.arange(len(pout),len(pout)+no);pout.extend(X);ringids.append(ids);ringcenters.append(C+prox*s['cap_length']*np.sin(a));ringUV.append(np.column_stack([ringUV[0][:,0],np.full(no,.75+.25*a/(np.pi/2))]))
 first_new=len(tout)
 for k in range(len(ringids)-1):
  lo,hi=ringids[k],ringids[k+1]
  for j in range(no):
   n=(j+1)%no;uv0=ringUV[k][[j,n]].copy();uv1=ringUV[k+1][[j,n]].copy()
   if n==0:uv0[1,0]=1.;uv1[1,0]=1.
   tout.extend([[lo[j],lo[n],hi[n]],[lo[j],hi[n],hi[j]]]);uvout.extend([[uv0[0],uv0[1],uv1[1]],[uv0[0],uv1[1],uv1[0]]]);parts.extend([hp+2,hp+2])
 pole=len(pout);pout.append(C+prox*s['cap_length']);last=ringids[-1]
 for j in range(no):
  n=(j+1)%no;u0=ringUV[-1][j].copy();u1=ringUV[-1][n].copy()
  if n==0:u1[0]=1
  tout.append([last[j],last[n],pole]);uvout.append([u0,u1,[(u0[0]+u1[0])/2,1.]]);parts.append(hp+2)
 rows.append({'side':s['side'],'wrist_boundary_vertices':no,'wrist_center':W.tolist(),'proximal_center_inferred_from_original_arm':C.tolist(),'forearm_length_m':float(length),'new_triangles':len(tout)-first_new,'wrist_positions_held':True,'minimum_start_axis_advance_ratio':float(advance.min()/length),'proximal_radii_m':[ra,rb],'proximal_cap_length_m':s['cap_length'],'closed_cap_requires_actual_coat_containment':True})
Q=np.asarray(pout);F=np.asarray(tout,int);U=np.asarray(uvout);parts=np.asarray(parts,int);fn=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]]);area=np.linalg.norm(fn,axis=1);assert area.min()>1e-14;NN=np.zeros_like(Q)
for k in range(3):np.add.at(NN,F[:,k],fn)
NN/=np.maximum(np.linalg.norm(NN,axis=1)[:,None],1e-30);assert np.array_equal(Q[:len(P)],P)
counts=Counter(tuple(sorted((int(a),int(b))))for f in F for a,b in zip(f,np.roll(f,-1)));directed=Counter((int(a),int(b))for f in F for a,b in zip(f,np.roll(f,-1)));assert set(counts.values())=={2};assert all(directed[e]==1 and directed[e[::-1]]==1 for e in counts)
volumes={}
for hp in [0,1]:
 ff=F[(parts==hp)|(parts==hp+2)];volume=np.sum(Q[ff[:,0]]*np.cross(Q[ff[:,1]],Q[ff[:,2]]))/6;assert volume>0;volumes[settings[hp]['side']]=float(volume)
out=R/'inputs/forearm_assemblies346.npz';np.savez_compressed(out,pos=Q,normal=NN,tri=F,corner_uv_png=U,part=parts)
report={'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'native_hand_parent_sha256':hashlib.sha256((R/'inputs/paired_hands344.npz').read_bytes()).hexdigest(),'triangles':len(F),'vertices':len(Q),'minimum_triangle_area_m2':float(area.min()/2),'all_native_hand_positions_held':True,'all_edges_two_opposite_uses':True,'closed_positive_volume_m3':volumes,'forearms':rows,'status':'Closed forearm-hand replacement components. Fingers are held; forearm self/cross checks, exact source removal, wrist appearance, full character integration and buried-cap visibility remain open.'};(R/'checks/forearm_assemblies346.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
