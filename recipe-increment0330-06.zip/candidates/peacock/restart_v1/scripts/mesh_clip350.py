"""Attribute-preserving linear-plane clipping with exact positional seam groups."""
import numpy as np
from collections import defaultdict

def clip_plane(data,axis,offset,positive=True):
 P,N,U,T,M=[data[k] for k in ['pos','normal','uv','tri','material']];axis=np.asarray(axis,float);signed=P@axis-offset
 if not positive:signed=-signed
 inside=signed>=0;allin=inside[T].all(1);allout=(~inside[T]).all(1);cross=np.where(~allin&~allout)[0];points=list(P);normals=list(N);uvs=list(U);triangles=list(T[allin]);materials=list(M[allin]);parents=list(np.where(allin)[0]);cache={};poscache={}
 def cut(a,b):
  if signed[a]==0:return int(a)
  if signed[b]==0:return int(b)
  key=tuple(sorted((int(a),int(b))))
  if key in cache:return cache[key]
  a,b=key;t=signed[a]/(signed[a]-signed[b]);pkey=tuple(sorted((tuple(P[a]),tuple(P[b]))))
  if pkey not in poscache:
   aa,bb=map(np.asarray,pkey);da=aa@axis-offset;db=bb@axis-offset;tt=da/(da-db);poscache[pkey]=aa+tt*(bb-aa)
  normal=(1-t)*N[a]+t*N[b];normal/=np.linalg.norm(normal);idx=len(points);points.append(poscache[pkey]);normals.append(normal);uvs.append((1-t)*U[a]+t*U[b]);cache[key]=idx;return idx
 for fi in cross:
  tr=T[fi];poly=[]
  for a,b in zip(tr,np.roll(tr,-1)):
   if inside[a]:poly.append(int(a))
   if inside[a]!=inside[b]:poly.append(cut(a,b))
  clean=[]
  for v in poly:
   if not clean or v!=clean[-1]:clean.append(v)
  if len(clean)>1 and clean[0]==clean[-1]:clean.pop()
  for k in range(1,len(clean)-1):triangles.append([clean[0],clean[k],clean[k+1]]);materials.append(M[fi]);parents.append(int(fi))
 PP=np.asarray(points);NN=np.asarray(normals);UU=np.asarray(uvs);TT=np.asarray(triangles,int);MM=np.asarray(materials,int);used,inv=np.unique(TT,return_inverse=True)
 return {'pos':PP[used],'normal':NN[used],'uv':UU[used],'tri':inv.reshape(-1,3),'material':MM,'parent_face':np.asarray(parents,int)}, {'unchanged_triangles':int(allin.sum()),'removed_triangles':int(allout.sum()),'cut_triangles':len(cross),'new_attribute_vertices':len(points)-len(P),'new_physical_positions':len(poscache),'axis':axis.tolist(),'offset':offset,'positive':positive}

def plane_boundary(data,axis,offset,tol=1e-10):
 P,T=data['pos'],data['tri'];GP,G=np.unique(P,axis=0,return_inverse=True);F=G[T];E=defaultdict(list)
 for fi,tr in enumerate(F):
  for a,b in zip(tr,np.roll(tr,-1)):E[tuple(sorted((int(a),int(b))))].append((int(a),int(b),fi))
 plane=abs(GP@np.asarray(axis)-offset)<tol;border=[v[0] for e,v in E.items()if len(v)==1 and plane[e[0]]and plane[e[1]]];out=defaultdict(list);inc=defaultdict(list)
 for a,b,fi in border:out[a].append(b);inc[b].append(a)
 healthy=set(out)==set(inc) and all(len(x)==1 for x in out.values()) and all(len(x)==1 for x in inc.values());loops=[]
 if healthy:
  remain=set(out)
  while remain:
   start=min(remain);loop=[start]
   while out[loop[-1]][0]!=start:loop.append(out[loop[-1]][0]);assert len(loop)<=len(out)
   remain-=set(loop);loops.append(np.asarray(loop,int))
 return GP,loops,{'cut_boundary_edges':len(border),'healthy_ordered_cycles':healthy,'cycles':[len(q)for q in loops],'other_open_edges':sum(len(v)==1 for v in E.values())-len(border),'nonmanifold_edges':sum(len(v)>2 for v in E.values())}

if __name__=='__main__':
 P=np.array([[0.,0,0],[1,0,0],[0,1,0],[0,0,1]]);T=np.array([[0,2,1],[0,1,3],[0,3,2],[1,2,3]]);N=np.tile([0.,0.,1.],(4,1));D={'pos':P,'normal':N,'uv':P[:,:2].copy(),'tri':T,'material':np.zeros(4,int)};C,r=clip_plane(D,[0,0,1],.25,True);GP,loops,b=plane_boundary(C,[0,0,1],.25);assert b['healthy_ordered_cycles']and b['cycles']==[3];assert all((C['pos'][:,2]>=.25-1e-15));assert np.isfinite(C['normal']).all();print('Plane clipping tetrahedron and ordered-boundary fixture passed.')
