from pathlib import Path
import sys,json,hashlib,numpy as np
from audit_intersections_v4 import audit
R=Path(__file__).resolve().parents[1];name=sys.argv[1];mode=sys.argv[2]if len(sys.argv)>2 else'coarse';p=R/f'inputs/{name}.npz'
with np.load(p)as z:
 if mode=='coarse':P=z['lowres_posed_world'].copy();Q=z['lowres_quads'].copy();T=np.concatenate([Q[:,[0,1,2]],Q[:,[0,2,3]]])
 else:P=z['pos'].copy();T=z['tri'].copy()
r=audit(P,T);r.update(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),mode=mode,scope='Whole new upper-body self preflight only. Coarse mode does not replace the evaluated subdivided-surface check; neither clears retained-character contacts or actual appearance.');(R/f'checks/{name}_{mode}_v4.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:len(v)if isinstance(v,list)else v for k,v in r.items()},indent=2))
