"""Native-topology fist via bounded positive-radius arc deformation; unintegrated study."""
import bpy,sys,pathlib,json,hashlib,math,os,numpy as np
r=pathlib.Path(__file__).resolve().parents[1];root=r.parents[1];droot=root/'shared_sources/makehuman';sys.path.insert(0,str(droot/'scripts'));from load_donor import load_donor
from scipy.optimize import least_squares
D=load_donor();V=D['positions'].copy();Vbase=V.copy();UV=D['uv'];names=D['bone_names'];J0=D['joint_positions'];morph_reports=[]
for letter,side in [('r','R'),('l','L')]:
 wr=J0[f'wrist.{side}____head'];ff=J0[f'finger3-1.{side}____head']-wr;ff/=np.linalg.norm(ff);longitudinal=(Vbase-wr)@ff;envelope=np.clip((longitudinal+.15)/.30,0,1);envelope=envelope*envelope*(3-2*envelope)
 for label,amount in [('distance',.75),('diameter',.05)]:
  path=r/'sources/hand_targets70'/f'{letter}-hand-fingers-{label}-decr.target';delta=np.zeros_like(V)
  for line in path.read_text().splitlines():
   z=line.split()
   if not z or z[0].startswith('#'):continue
   idx=int(z[0]);delta[idx]=list(map(float,z[1:4]))
  V+=delta*amount*envelope[:,None];morph_reports.append({'side':side,'target':str(path),'amount':amount,'target_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'wrist_falloff':'Smooth zero at native wrist-back cutoff, full distal to 0.15 native units.'})
J={name:V[ids].mean(0)for name,ids in D['rig']['joints'].items()};bpy.ops.wm.read_factory_settings(use_empty=True);report={}
for side,sgn in [('R',-1),('L',1)]:
 wrist=J[f'wrist.{side}____head'];f=J[f'finger3-1.{side}____head']-wrist;f/=np.linalg.norm(f);s=J[f'finger2-1.{side}____head']-J[f'finger5-1.{side}____head'];s-=s@f*f;s/=np.linalg.norm(s);d=np.cross(f,s);F=np.array([-sgn*.86,-.08,-.51]);F/=np.linalg.norm(F);S=np.array([0.,0.,1.]);S-=S@F*F;S/=np.linalg.norm(S);N=np.cross(F,S);Dorsal=N if side=='R' else -N;R=np.column_stack([F,S,N])@np.column_stack([f,s,d]).T;scale=.088;anchor=np.array([sgn*.293,-.032 if side=='R' else -.006,.235 if side=='R' else .230]);world=lambda p:(np.asarray(p)-wrist)@R.T*scale+anchor;proj=(V-wrist)@f;dist=np.linalg.norm(V-wrist,axis=1);held=np.load(r/'checks'/f'fist_seed25_{side}.npz');chosen=held['donor_faces'].tolist();ids=held['donor_ids'];lookup={int(v):k for k,v in enumerate(ids)};faces=[[lookup[v]for v in D['faces'][i]]for i in chosen];rest=world(V[ids]);posed=rest.copy();weights=D['weights_normalized'][ids];digitW=np.stack([weights[:,[i for i,n in enumerate(names)if n.startswith(f'finger{digit}-')and n.endswith('.'+side)]].sum(1)for digit in range(1,6)],1);deformations=[]
 def rotate(axis,degrees):
  axis=np.asarray(axis,float);axis/=np.linalg.norm(axis);t=math.radians(float(degrees));x,y,z=axis;K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]]);return np.eye(3)*math.cos(t)+(1-math.cos(t))*np.outer(axis,axis)+math.sin(t)*K
 def finger_map(points,C,axis,length,dor,lat,joint_positions=None):
  # Rounded MCP/PIP/DIP hinges with an inner-pad compression correction. The
  # negative palm interval gives the metacarpal cup space needed by a closed fist.
  q=points-C;x=q@axis;y=q@lat;z=q@dor;pip,dip=joint_positions
  xx=np.linspace(-.032,length,2401)
  def turn(center,width,degrees):
   t=np.clip((xx-center)/width+.5,0,1);v=t*t*(3-2*t);k=np.where((t>0)&(t<1),6*t*(1-t)/width,0);return np.radians(degrees)*v,np.radians(degrees)*k
  a0,k0=turn(-.005,.034,90.);a1,k1=turn(pip,.024,110.);a2,k2=turn(dip,.016,60.);angle=a0+a1+a2;kappa=k0+k1+k2;dx=np.diff(xx);cx=np.r_[xx[0],xx[0]+np.cumsum(.5*(np.cos(angle[:-1])+np.cos(angle[1:]))*dx)];cz=np.r_[0,np.cumsum(-.5*(np.sin(angle[:-1])+np.sin(angle[1:]))*dx)];xc=np.clip(x,xx[0],xx[-1]);ang=np.interp(xc,xx,angle);kap=np.interp(xc,xx,kappa);centerx=np.interp(xc,xx,cx)+np.minimum(x-xx[0],0)+np.maximum(x-length,0)*np.cos(ang);centerz=np.interp(xc,xx,cz)-np.maximum(x-length,0)*np.sin(ang);limit=.65/np.maximum(kap,1e-12);ze=np.where(z<0,-limit*np.tanh(-z/limit),z);mapped=C+axis[None,:]*(centerx+ze*np.sin(ang))[:,None]+lat[None,:]*y[:,None]+dor[None,:]*(centerz+ze*np.cos(ang))[:,None];jac=1+kap*ze;return mapped,jac
 frames={};landmarks={}
 for digit in [2,3,4,5]:
  C=world(J[f'finger{digit}-1.{side}____head']);tip=world(J[f'finger{digit}-3.{side}____tail']);axis=tip-C;length=np.linalg.norm(axis);axis/=length;dor=Dorsal-axis*(Dorsal@axis);dor/=np.linalg.norm(dor);lat=np.cross(axis,dor);k=math.radians(230)/length;hinges=tuple(float((world(J[f'finger{digit}-{seg}.{side}____head'])-C)@axis)for seg in[2,3]);frames[digit]=(C,axis,length,dor,lat,k,hinges)
  points=np.array([world(J[f'finger{digit}-{segment}.{side}____tail'])for segment in [1,2,3]]);landmarks[digit],_=finger_map(points,C,axis,length,dor,lat,hinges)
 for digit in [2,3,4,5]:
  C,axis,length,dor,lat,k,hinges=frames[digit];mapped,radialJac=finger_map(rest,C,axis,length,dor,lat,hinges);old=landmarks[digit];targetS=(old@S-landmarks[3]@S)*.68+landmarks[3]@S;proximal=old[0]-C;proximal/=np.linalg.norm(proximal)
  def matrix(a):return rotate(Dorsal,a[0])@rotate(proximal,a[1])
  def residual(a):
   pts=C+(old-C)@matrix(a).T;delta=pts-old;return np.r_[pts@S-targetS,.15*(delta@F),.15*(delta@Dorsal),a*.000005]
  def jac(a):
   columns=[]
   for k1 in [0,1]:
    ap=a.copy();am=a.copy();ap[k1]=min(25,ap[k1]+.2);am[k1]=max(-25,am[k1]-.2);columns.append((residual(ap)-residual(am))/(ap[k1]-am[k1]))
   return np.column_stack(columns)
  if digit!=3:fit=least_squares(residual,np.zeros(2),jac=jac,bounds=(-25,25),x_scale=10,max_nfev=80,ftol=1e-9,xtol=1e-9,gtol=1e-9);params=fit.x
  else:params=np.zeros(2)
  transform=matrix(params);mapped=C+(mapped-C)@transform.T;w=digitW[:,digit-1];posed+=w[:,None]*(mapped-rest);actual=C+(old-C)@transform.T;deformations.append({'digit':digit,'length':float(length),'MCP_flexion_degrees':90.,'PIP_flexion_degrees':110.,'DIP_flexion_degrees':60.,'terminal_flexion_degrees':260.,'joint_locations_m':list(hinges),'minimum_unblended_radial_jacobian_target':.35,'minimum_unblended_radial_jacobian_on_weighted_domain':float(radialJac[digitW[:,digit-1]>1e-4].min()),'palm_axis_rotation_degrees':float(params[0]),'posed_proximal_axis_twist_degrees':float(params[1]),'native_MCP_reference_held':True,'posed_MCP_center_cupped':True,'baseline_landmarks':old.tolist(),'actual_landmarks':actual.tolist(),'target_lateral_coordinates':targetS.tolist(),'actual_lateral_residual_m':(actual@S-targetS).tolist(),'method':'Measured static-surface phalanx spacing inspired by Mustard solve_stack175; no source pose settings copied.'})
 # Thumb opposition: broad arc with its pad kept behind the curled fingers.
 digit=1;C=world(J[f'finger1-1.{side}____head']);tip=world(J[f'finger1-3.{side}____tail']);oldAxis=tip-C;length=np.linalg.norm(oldAxis);oldAxis/=length;oldD=Dorsal-oldAxis*(Dorsal@oldAxis);oldD/=np.linalg.norm(oldD);oldLat=np.cross(oldAxis,oldD);goal=(np.array(deformations[0]['actual_landmarks'])[0]*.35+np.array(deformations[1]['actual_landmarks'])[0]*.65)-Dorsal*.009;Q1=oldAxis*.020;Q3=goal-C;Q2=Q3+S*.016
 u=np.linspace(0,1,2001);curve=3*(1-u)[:,None]**2*u[:,None]*Q1+3*(1-u)[:,None]*u[:,None]**2*Q2+u[:,None]**3*Q3;arclen=np.r_[0,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))];curve_length=float(arclen[-1]);arclen*=length/arclen[-1];deriv=3*(1-u)[:,None]**2*Q1+6*(1-u)[:,None]*u[:,None]*(Q2-Q1)+3*u[:,None]**2*(Q3-Q2);deriv/=np.linalg.norm(deriv,axis=1)[:,None]
 q=rest-C;x=q@oldAxis;y=q@oldLat;z=q@oldD;xx=np.clip(x,0,length);newC=np.column_stack([np.interp(xx,arclen,curve[:,k])for k in range(3)]);tangent=np.column_stack([np.interp(xx,arclen,deriv[:,k])for k in range(3)]);tangent/=np.linalg.norm(tangent,axis=1)[:,None];axisRot=np.cross(oldAxis,tangent);sine=np.linalg.norm(axisRot,axis=1);cosine=tangent@oldAxis;axisRot/=np.maximum(sine[:,None],1e-12);rad=y[:,None]*oldLat+z[:,None]*oldD;radRot=rad*cosine[:,None]+np.cross(axisRot,rad)*sine[:,None]+axisRot*np.sum(axisRot*rad,axis=1)[:,None]*(1-cosine)[:,None];radRot[sine<1e-12]=rad[sine<1e-12];mapped=C+newC+radRot+np.maximum(x-length,0)[:,None]*tangent;mapped[x<=0]=rest[x<=0];thumb_opposition=0.;w=digitW[:,0];posed+=w[:,None]*(mapped-rest);v=posed-C;angle_per_vertex=np.radians(thumb_opposition*w);c=np.cos(angle_per_vertex)[:,None];ss=np.sin(angle_per_vertex)[:,None];posed=C+v*c+np.cross(N,v)*ss+N[None,:]*(v@N)[:,None]*(1-c);deformations.append({'digit':1,'length':float(length),'bezier_controls_world_offsets':[Q1.tolist(),Q2.tolist(),Q3.tolist()],'sampled_arc_length_preserved':False,'curve_length_m':curve_length,'thumb_target_world':goal.tolist(),'thumb_target_method':'Measured index/middle proximal-phalanx endpoints, plus9mm palmar pad clearance.','CMC_opposition_degrees':thumb_opposition,'CMC_method':'Native-weight angle interpolation about the fixed anatomical opposition axis; radial distance from that axis is preserved pointwise.'})
 me=bpy.data.meshes.new(side+' anatomical arc fist84');me.from_pydata(posed.tolist(),[],faces);me.update();attr=me.attributes.new('native_face','INT','FACE');attr.data.foreach_set('value',np.array(chosen,dtype=np.int32));ob=bpy.data.objects.new('White '+side+' analytic fist84',me);bpy.context.collection.objects.link(ob);uv=me.uv_layers.new(name='NativeHandUV')
 for p,fi in zip(me.polygons,chosen):
  for li,ui in zip(p.loop_indices,D['face_uv'][fi]):uv.data[li].uv=UV[ui]
  p.use_smooth=True
 mat=bpy.data.materials.new(side+' provisional source-tone');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.57,.28,.145,1);bs.inputs['Roughness'].default_value=.62;me.materials.append(mat);bpy.context.view_layer.objects.active=ob;ob.select_set(True);sub=ob.modifiers.new('Anatomical surface','SUBSURF');sub.levels=1;sub.render_levels=1;bpy.ops.object.modifier_apply(modifier=sub.name);me=ob.data
 # Preserve the forty-point native wrist exactly after subdivision. Blend its
 # correction through two proximal edge rings; no old thenar sculpt is transferred.
 h27=np.load(r/'checks'/f'fist_seed27_{side}.npz');assert len(me.vertices)==len(h27['P']);me.calc_loop_triangles();tt=np.array([t.vertices[:]for t in me.loop_triangles]);edge={}
 for tri in tt:
  for a,b in zip(tri,np.roll(tri,-1)):edge.setdefault(tuple(sorted((int(a),int(b)))),[]).append(1)
 boundary=set(v for e,fs in edge.items()if len(fs)==1 for v in e);assert len(boundary)==40;adj={i:set()for i in range(len(me.vertices))}
 for a,b in edge:adj[a].add(b);adj[b].add(a)
 current=np.array([v.co[:]for v in me.vertices]);delta=h27['P']-current;front=set(boundary);seen=set(boundary)
 for i in boundary:me.vertices[i].co=__import__('mathutils').Vector(h27['P'][i])
 for weight in [.65,.25]:
  front=set(v for i in front for v in adj[i])-seen;seen|=front
  for i in front:me.vertices[i].co+=__import__('mathutils').Vector(delta[i]*weight)
 me.update();me.calc_loop_triangles();P=np.array([v.co[:]for v in me.vertices]);T=np.array([t.vertices[:]for t in me.loop_triangles]);UVC=np.array([[me.uv_layers.active.data[li].uv[:]for li in t.loops]for t in me.loop_triangles]);normals=np.array([v.normal[:]for v in me.vertices]);np.savez_compressed(r/'checks'/f'fist_seed84_{side}.npz',P=P,T=T,UVcorner=UVC,N=normals,donor_ids=ids,donor_faces=chosen,low=posed,rest=rest,weights=weights,source_face_ids=np.array([me.attributes['native_face'].data[t.polygon_index].value for t in me.loop_triangles]));report[side]={'deformations':deformations,'anchor':anchor.tolist(),'forward':F.tolist(),'thumbward':S.tolist(),'anatomical_dorsal':Dorsal.tolist(),'scale':scale,'triangles':len(T),'posed_bounds':[P.min(0).tolist(),P.max(0).tolist()]};ob.select_set(False)
(r/'checks/fist_seed84.json').write_text(json.dumps({'official_shape_targets':morph_reports,'hands':report,'scope':'Unintegrated fully opposed pose84. Finger adduction is measured against the middle ray and the thumb target is measured from posed index/middle phalanges. This is a volume-retopology input, not a native-topology intersection pass. Official native hand shape targets, anatomical MCP/PIP/DIP locations, rounded joint transitions and inner-pad compression are used. The native wrist is held; old thenar corrections are not copied. Exact intersection, fold, contact and actual appearance gates remain mandatory.'},indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(r/'models/fist_seed84.blend'),compress=True);bpy.ops.export_scene.gltf(filepath=str(r/'models/fist_seed84.glb'),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_tangents=True);print(report,flush=True)
