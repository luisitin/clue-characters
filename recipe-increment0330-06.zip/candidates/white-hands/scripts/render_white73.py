import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parents[1];owner=r.parent/'scarlett-white';views=[('whole_front',0,'[0.00319,-0.00726,0.00057]','2.16'),('waist_front',0,'[0.00319,-0.04,0.16]','.78'),('whole_rear',180,'[0.00319,-0.00726,0.00057]','2.16'),('whole_left',-90,'[0.00319,-0.00726,0.00057]','2.16'),('whole_right',90,'[0.00319,-0.00726,0.00057]','2.16')]
for label,angle,target,scale in views:
 if label not in os.environ.get('LABELS',','.join(v[0]for v in views)).split(','):continue
 env=dict(os.environ,GLB=str(r/'models/white73_coherent_garment_assembly.glb'),OUT=str(r/'renders'/f'white73_{label}.png'),MODE='pbr',TARGET=target,SCALE=scale,ANGLE=str(angle),ELEV='0',RES='900',SAMPLES='16');env.pop('CAMERA_META',None);env.pop('WORLD_ENV',None)
 with(r/'checks'/f'white73_{label}.log').open('w')as f:subprocess.run(['flock',os.environ.get('CHARACTER_BUILD_LOCK','/tmp/character-build-heavy.lock'),'bash','-c','date -u +START_%FT%TZ; "$@"; s=$?; date -u +END_%FT%TZ; exit $s','white73_view','blender','-b','-t','2','--python-exit-code','1','--python',str(owner/'scripts/render_exact.py')],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(label,flush=True)
