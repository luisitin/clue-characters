"""Coherent reference-proportioned White dress, apron and waist belt.
Own generated garment surfaces; fixed torso section/source raw lineage recorded.
Geometry, layered clearance, UV sampling and actual views still require checks.
"""
import pathlib,sys,io,json,hashlib,numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb,append_accessor,write_glb
source=r.parent/'scarlett-white/models/white_25_continuous_neck_paint_trial.glb';sj,sb,sa=read_glb(source);s=np.load(r/'checks/source01_left.npz');section=np.load(r/'checks/band60_z+0.342337_c1.npz');S=np.array(s['node_scale']);X=np.array(s['node_translation']);U,iv=np.unique(s['P'],axis=0,return_inverse=True);G=iv[s['F']];W=(U*S+X)[:,[0,2,1]]*[1,-1,1];root=section['P'].copy();sourceedges=section['source_physical_edges'].copy();area=np.sum(root[:,0]*np.roll(root[:,1],-1)-root[:,1]*np.roll(root[:,0],-1))
if area<0:root=root[::-1];sourceedges=sourceedges[::-1]
# Source lattice yields exactly shareable torso clipping coordinates.
root_local=np.rint(((root[:,[0,2,1]]*[1,1,-1]-X)/S)*32767).astype(np.int16);idealroot=root.copy();root=(root_local.astype(float)/32767*S+X)[:,[0,2,1]]*[1,-1,1];top=float(root[0,2]);assert np.ptp(root[:,2])==0
keys={tuple(sorted(map(int,e))):k for k,e in enumerate(sourceedges)};cutfaces={};rootuv=[];rootN=[];rootgN=[]
for fi in section['source_cut_faces']:
 tr=G[fi];hit=[]
 for a,b in zip(tr,np.roll(tr,-1)):
  e=tuple(sorted((int(a),int(b))))
  if e in keys:hit.append(keys[e])
 if len(hit)==2:cutfaces[tuple(sorted(hit))]=int(fi)
for k in range(len(root)):
 fi=cutfaces[tuple(sorted((k,(k+1)%len(root))))];a,b=sourceedges[k];kk=[int(np.where(G[fi]==v)[0][0])for v in [a,b]];t=(float(section['plane_z'])-W[a,2])/(W[b,2]-W[a,2]);uv=(1-t)*s['UV'][s['F'][fi,kk[0]]]+t*s['UV'][s['F'][fi,kk[1]]];nn=(1-t)*s['N'][s['F'][fi,kk[0]]]+t*s['N'][s['F'][fi,kk[1]]];rootuv.append(uv);rootN.append(nn[[0,2,1]]*[1,-1,1]);tr=s['W'][s['F'][fi]];rootgN.append(np.cross(tr[1]-tr[0],tr[2]-tr[0]))
rootN=np.array(rootN);rootN/=np.linalg.norm(rootN,axis=1)[:,None];rootgN=np.array(rootgN);rootgN/=np.linalg.norm(rootgN,axis=1)[:,None];rootuv=np.array(rootuv);avg=rootgN+np.roll(rootgN,1,axis=0);avg/=np.linalg.norm(avg,axis=1)[:,None];slope=-avg[:,:2]*avg[:,2,None]/np.maximum(np.sum(avg[:,:2]**2,axis=1)[:,None],.08);slope*=np.minimum(1,.9/np.maximum(np.linalg.norm(slope,axis=1),1e-12))[:,None]
edgelen=np.linalg.norm(np.roll(root,-1,axis=0)-root,axis=1);ru=np.r_[0,np.cumsum(edgelen[:-1])]/edgelen.sum();center0=(root.min(0)+root.max(0))*.5;theta=np.unwrap(np.arctan2(root[:,1]-center0[1],root[:,0]-center0[0]));assert theta[-1]-theta[0]>5.5;u=np.arange(256)/256;ang=np.interp(u,np.r_[ru,1],np.r_[theta,theta[0]+2*np.pi]);assert np.diff(ang).min()>0
lower_section=np.load(r/'checks/band60_z+0.322337_c1.npz')['P'];phiroot=np.arctan2(root[:,1]-center0[1],root[:,0]-center0[0]);philow=np.arctan2(lower_section[:,1]-center0[1],lower_section[:,0]-center0[0])
def basis(phi):return np.column_stack([np.ones(len(phi))]+[f(k*phi)for k in range(1,7)for f in[np.cos,np.sin]])
macro_root=np.linalg.lstsq(basis(phiroot),root[:,:2],rcond=None)[0];macro_lower=np.linalg.lstsq(basis(philow),lower_section[:,:2],rcond=None)[0];slope=basis(phiroot)@(macro_root-macro_lower)/.020;slope*=np.minimum(1,.65/np.maximum(np.linalg.norm(slope,axis=1),1e-12))[:,None]
Z=np.array([-.512,-.47,-.30,-.15,0,.10,.20,.25,.30,top]);RX=np.array([.355,.357,.320,.284,.241,.218,.185,.169,.172,(root[:,0].max()-root[:,0].min())*.5]);RY=np.array([.255,.255,.249,.235,.216,.191,.165,.154,.162,(root[:,1].max()-root[:,1].min())*.5]);CX=np.array([.014,.014,.012,.010,.007,.004,.002,.001,0,center0[0]]);CY=np.array([-.012,-.012,-.012,-.010,-.008,-.004,0,-.006,-.019,center0[1]]);fx,fy,fcx,fcy=[PchipInterpolator(Z,q)for q in[RX,RY,CX,CY]]
def surface(th,z):
 th,z=np.broadcast_arrays(np.asarray(th),np.asarray(z));cx,cy=fcx(z),fcy(z);radx,rady=fx(z),fy(z);v=(top-z)/(top+.512);lower=np.clip((.22-z)/.35,0,1);lower=lower*lower*(3-2*lower);wave=.0105*lower*(.55*np.cos(11*th+.65*v)+.30*np.cos(17*th-1.3*v)+.15*np.sin(7*th+1.5*v));return np.stack([cx+(radx+wave)*np.cos(th),cy+(rady+wave)*np.sin(th),z],axis=-1)
def radial(th):return np.stack([np.cos(th),np.sin(th),np.zeros_like(th)],axis=-1)
def normal(P,T):
 q=P[T];fn=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);out=np.zeros_like(P)
 for k in range(3):np.add.at(out,T[:,k],fn)
 out/=np.maximum(np.linalg.norm(out,axis=1)[:,None],1e-30);return out

def zipper(a,au,b,bu):
 ts=[];i=j=0;na,nb=len(a),len(b)
 while i<na or j<nb:
  an=au[i+1]if i+1<na else 1.;bn=bu[j+1]if j+1<nb else 1.;aa=a[i%na];bb=b[j%nb]
  if i<na and(j>=nb or an<bn-1e-12):ts.append([aa,bb,a[(i+1)%na]]);i+=1
  elif j<nb and(i>=na or bn<an-1e-12):ts.append([aa,bb,b[(j+1)%nb]]);j+=1
  else:ts.extend([[aa,bb,a[(i+1)%na]],[a[(i+1)%na],bb,b[(j+1)%nb]]]);i+=1;j+=1
 return ts

P=[root];T=[];params=[np.c_[ru,np.zeros(len(root))]];last=np.arange(len(root));lastu=ru;vcount=len(root)
def append_ring(q,uu,vv):
 global last,lastu,vcount
 ids=np.arange(vcount,vcount+len(q));T.extend(zipper(last,lastu,ids,uu));P.append(q);params.append(np.c_[uu,np.full(len(q),vv)]);vcount+=len(q);last,lastu=ids,uu
for depth in [.006,.014]:
 q=root.copy();q[:,:2]-=slope*depth;q[:,2]-=depth;append_ring(q,ru,.70*depth/(top+.512))
for z in np.linspace(top-.026,-.512,93):
 q=surface(ang,z);w=np.clip((top-z-.014)/.05,0,1);w=w*w*(3-2*w)
 if w<1:
  old=np.column_stack([np.interp(u,np.r_[ru,1],np.r_[root[:,k],root[0,k]])for k in range(3)]);ds=np.column_stack([np.interp(u,np.r_[ru,1],np.r_[slope[:,k],slope[0,k]])for k in range(2)]);old[:,:2]-=ds*(top-z);old[:,2]=z;q=old*(1-w)+q*w
 append_ring(q,u,.70*(top-z)/(top+.512))
outer_last=surface(ang,-.512);cloth=.0018
for phi in np.linspace(np.pi/6,np.pi,6):
 q=outer_last-radial(ang)*(cloth*.5*(1-np.cos(phi)));q[:,2]-=cloth*.5*np.sin(phi);append_ring(q,u,.70+.022*phi/np.pi)
for z in np.linspace(-.505,-.31,26):append_ring(surface(ang,z)-radial(ang)*cloth,u,.724+.17*(z+.505)/.195)
capcenter=np.array([float(fcx(-.31)),float(fcy(-.31)),-.31]);rel=P[-1]-capcenter
for phi in np.linspace(np.pi/12,5*np.pi/12,5):
 q=capcenter+rel*np.cos(phi);q[:,2]+=.035*np.sin(phi);append_ring(q,u,.90+.08*phi/(np.pi*.5))
cap=vcount;P.append((capcenter+[0,0,.035])[None]);params.append(np.array([[.5,1.]]));
for k in range(len(last)):T.append([last[k],cap,last[(k+1)%len(last)]])
bodyP=np.concatenate(P);bodyT=np.array(T);bodyUV=np.concatenate(params);bodyN=normal(bodyP,bodyT);bodyN[:len(root)]=rootN
# Front apron: a separate thin fabric panel with broad, quiet drape folds.
nu,nv=145,92;ss=np.linspace(-1,1,nu);tt=np.linspace(0,1,nv);ap=[];apuv=[]
for t in tt:
 width=1.18*(1-t)+1.075*t;th=-np.pi/2+ss*width;ztop=.279-.013*np.maximum(-np.sin(th),0)**2;z=(1-t)*ztop-.408*t-.022*(1-ss**2)*np.sin(np.pi*t)**1.4+.004*np.sin(np.pi*ss)*np.sin(np.pi*t);q=surface(th,z);ramp=np.clip((t-.10)/.25,0,1);ramp=ramp*ramp*(3-2*ramp);env=ramp*np.sin(np.pi*t)**1.2;drape=.0042+env*(.010+.026*(.5+.5*np.cos(9*ss+2.5*t))+.010*(.5+.5*np.cos(4*ss-7*t)));q+=radial(th)*drape[:,None];ap.append(q);apuv.extend([[.5*(x+1),.48*t]for x in ss])
ap=np.concatenate(ap);at=[]
for row in range(nv-1):
 for k in range(nu-1):a=row*nu+k;b=a+1;c=a+nu;d=c+1;at.extend([[a,c,b],[b,c,d]])
at=np.array(at);an=normal(ap,at);inner=ap-an*.0012;AP=np.vstack([ap,inner]);AT=np.vstack([at,at[:,::-1]+len(ap)]).tolist();AUV=np.vstack([np.array(apuv),np.c_[np.array(apuv)[:,0],.52+np.array(apuv)[:,1]]]);edge=__import__('collections').defaultdict(list)
for fi,tr in enumerate(at):
 for a,b in zip(tr,np.roll(tr,-1)):edge[tuple(sorted((int(a),int(b))))].append((int(a),int(b)))
for es in edge.values():
 if len(es)==1:a,b=es[0];AT.extend([[a,a+len(ap),b],[b,a+len(ap),b+len(ap)]])
AT=np.array(AT);AN=normal(AP,AT)
# Rounded closed waist belt, outside the apron where their layers overlap.
BP=[];Buv=[];n=256;belt_z=np.linspace(.285,.240,9)
for innerflag in[False,True]:
 for k,z in enumerate(belt_z if not innerflag else belt_z[::-1]):
  z0=z;z=z0-.013*np.maximum(-np.sin(ang),0)**2;front_angle=abs((ang+np.pi/2+np.pi)%(2*np.pi)-np.pi);f=np.clip((1.55-front_angle)/.22,0,1);f=f*f*(3-2*f);margin=.0032+.004*f;v=(.285-z0)/.045;margin+=.0017*np.sin(np.pi*v);margin-=.00115*innerflag;q=surface(ang,z)+radial(ang)*margin[:,None];BP.append(q);Buv.append(np.c_[u,np.full(n,(k+9*innerflag)/18)])
BP=np.concatenate(BP);Buv=np.concatenate(Buv);BT=[]
for row in range(18):
 a=np.arange(row*n,(row+1)*n);b=np.arange(((row+1)%18)*n,(((row+1)%18)+1)*n);BT.extend(zipper(a,u,b,u))
BT=np.array(BT);BN=normal(BP,BT)
# Standalone source-transform GLB, with source-lattice positions for future exact joins.
j={'asset':{'version':'2.0','generator':'White coherent garment72'},'extensionsUsed':['KHR_mesh_quantization'],'extensionsRequired':['KHR_mesh_quantization'],'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0,'scale':S.tolist(),'translation':X.tolist()}],'meshes':[{'primitives':[]}],'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'materials':[],'images':[],'textures':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':10497,'wrapT':33071}]};buf=b'';rng=np.random.default_rng(66);res=1024
# Native source texture colors across the exact torso section.
pr=sj['meshes'][0]['primitives'][0];tex=sj['textures'][sj['materials'][pr['material']]['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tex.get('source',tex.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));bv=sj['bufferViews'][sj['images'][ii]['bufferView']];im=np.array(Image.open(io.BytesIO(sb[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']])).convert('RGB'))/255.;h,w=im.shape[:2];rootcolors=im[(rootuv[:,1]*h).astype(int).clip(0,h-1),(rootuv[:,0]*w).astype(int).clip(0,w-1)];col=np.column_stack([np.interp((np.arange(res)+.5)/res,np.r_[ru,1],np.r_[rootcolors[:,k],rootcolors[0,k]])for k in range(3)]);noise=rng.normal(0,.002,(res,res,1));weave=(np.sin(np.arange(res)[None,:,None]*np.pi/2)+np.sin(np.arange(res)[:,None,None]*np.pi/2))*.001
for name,color,rough in [('dress',[.205,.200,.190],.86),('apron',[.845,.834,.806],.78),('belt',[.845,.834,.806],.77)]:
 arr=np.broadcast_to(np.array(color),(res,res,3)).copy()+noise+weave
 if name=='dress':
  v=(np.arange(res)+.5)/res;zz=top-(v/.70)*(top+.512);blend=np.clip((zz-.252)/.018,0,1);blend=blend*blend*(3-2*blend);arr=arr*(1-blend[:,None,None])+col[None]*blend[:,None,None]
 raw=io.BytesIO();Image.fromarray(np.clip(arr*255,0,255).astype('uint8')).save(raw,format='PNG');blob=raw.getvalue();buf+=b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(blob)});buf+=blob;j['images'].append({'bufferView':vi,'mimeType':'image/png'});j['textures'].append({'sampler':0,'source':len(j['images'])-1});j['materials'].append({'name':name+'66 provisional fabric','pbrMetallicRoughness':{'baseColorTexture':{'index':len(j['textures'])-1},'roughnessFactor':rough,'metallicFactor':0}})
def pack(P,T,N,UV,mi,wrap=True,wrap_v=False):
 global buf
 uvc=UV[T].copy()if UV.ndim==2 else UV.copy()
 if wrap:
  seam=np.ptp(uvc[:,:,0],axis=1)>.5;uvc[seam,:,0]=np.where(uvc[seam,:,0]<.5,uvc[seam,:,0]+1,uvc[seam,:,0])
 if wrap_v:
  seam=np.ptp(uvc[:,:,1],axis=1)>.5;uvc[seam,:,1]=np.where(uvc[seam,:,1]<.5,uvc[seam,:,1]+1,uvc[seam,:,1])
 if wrap and not wrap_v:
  poles=np.flatnonzero(np.sum(uvc[:,:,1]>.99999,axis=1)==1)
  for f in poles:
   k=int(np.argmax(uvc[f,:,1]));uvc[f,k,0]=np.mean(np.delete(uvc[f,:,0],k))
 unique,back=np.unique(np.c_[T.ravel(),uvc.reshape(-1,2)],axis=0,return_inverse=True);vi=unique[:,0].astype(int);lp=(P[vi][:,[0,2,1]]*[1,1,-1]-X)/S;qp=np.ascontiguousarray(np.rint(lp*32767).astype('<i2'));nn=N[vi][:,[0,2,1]]*[1,1,-1];attrs={};buf+=b'\0'*((-len(buf))%4);bv=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':qp.nbytes,'target':34962});buf+=qp.tobytes();ai=len(j['accessors']);j['accessors'].append({'bufferView':bv,'componentType':5122,'normalized':True,'count':len(qp),'type':'VEC3','min':qp.min(0).astype(int).tolist(),'max':qp.max(0).astype(int).tolist()});attrs['POSITION']=ai
 for name,val,kind in [('NORMAL',nn,'VEC3'),('TEXCOORD_0',unique[:,1:],'VEC2')]:attrs[name],buf=append_accessor(j,buf,val.astype(np.float32),kind,34962)
 ix,buf=append_accessor(j,buf,back.astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4})
AUV[:,0]=.02+.86*AUV[:,0];AUV[:len(ap),1]=.02+.44*(AUV[:len(ap),1]/.48);AUV[len(ap):,1]=.52+.44*((AUV[len(ap):,1]-.52)/.48);auc=AUV[AT].copy();boundary=[es[0]for es in edge.values()if len(es)==1];nxt={a:b for a,b in boundary};start=min(nxt);loop=[start]
while nxt[loop[-1]]!=start:loop.append(nxt[loop[-1]])
assert len(loop)==len(boundary);el=np.linalg.norm(ap[np.roll(loop,-1)]-ap[loop],axis=1);dist=np.r_[0,np.cumsum(el[:-1])]/el.sum();vlookup={v:float(t)for v,t in zip(loop,dist)}
for k,(a,b)in enumerate(boundary):
 va=vlookup[a];vb=vlookup[b]
 if vb<va:vb=1.
 ua,ub=.02+.96*va,.02+.96*vb;f0=2*len(at)+2*k;auc[f0]=[[.925,ua],[.99,ua],[.925,ub]];auc[f0+1]=[[.925,ub],[.99,ua],[.99,ub]]
AUV=auc
pack(bodyP,bodyT,bodyN,bodyUV,0);pack(AP,AT,AN,AUV,1,False);pack(BP,BT,BN,Buv,2,wrap_v=True);out=r/'models/coherent_garments72.glb';write_glb(out,j,buf);np.savez_compressed(r/'checks/coherent_garments72.npz',bodyP=bodyP,bodyT=bodyT,bodyN=bodyN,bodyUV=bodyUV,apronP=AP,apronT=AT,apronN=AN,apronUV=AUV,beltP=BP,beltT=BT,beltN=BN,beltUV=Buv,torso_root_ideal=idealroot,torso_root_world=root,torso_root_local_int16=root_local,torso_root_source_edges=sourceedges,torso_root_source_cut_faces=section['source_cut_faces'],torso_root_source_cut_raw_ids=s['raw_face_ids'][section['source_cut_faces']],source_scale=S,source_translation=X,profile_z=Z,profile_x_radius=RX,profile_y_radius=RY,profile_center_x=CX,profile_center_y=CY);rep={'model_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_torso_cut_ideal_z_m':float(section['plane_z']),'source_torso_cut_encoded_z_m':top,'root_vertices':len(root),'maximum_root_quantization_m':float(np.linalg.norm(root-idealroot,axis=1).max()),'body_triangles':len(bodyT),'apron_triangles':len(AT),'belt_triangles':len(BT),'root_tangent_fit':'Six Fourier modes of the measured 20mm torso-section displacement; individual noisy face-normal jets are not propagated. Exact221-point source interface held.','apron_perimeter_winding':'Closed edge-strip triangles reversed to oppose both front/back boundary directions.','source_proportions':'Waist and skirt widths/depths fitted to measured source sections. Garment style follows the black dress, warm white apron and waist belt in the provided reference.','scope':'Larger coherent garment construction, standalone and unvalidated. Source upper-body/leg integration, cuff/hand fit, bow/tails, stored-float intersections, layered clearance, UV sampling and all-angle actual views remain required.'};(r/'checks/coherent_garments72.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
