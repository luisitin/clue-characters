"""Owned cuff material cleanup, fitted buttons, and independent tied apron ribbons.
All source geometry is retained exactly; new garment accessories are explicit layers.
"""
import pathlib,sys,json,copy,hashlib,io,collections,numpy as np
from PIL import Image,ImageDraw
from scipy.interpolate import PchipInterpolator
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb,append_accessor,write_glb
src=r/'models/white78_coherent_garment_assembly.glb';j,b,a=read_glb(src);S=np.array(j['nodes'][0]['scale']);X=np.array(j['nodes'][0]['translation']);prims=j['meshes'][0]['primitives'];rep={'base':str(src),'base_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'details':[]};oldb=b

def image_tex(image):
 global b
 raw=io.BytesIO();image.save(raw,format='PNG');blob=raw.getvalue();b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(blob)});b+=blob;j['images'].append({'bufferView':vi,'mimeType':'image/png'});j['textures'].append({'source':len(j['images'])-1});return len(j['textures'])-1
# Repaint only the owned collar49 annuli. Existing positions/normals/UV corners
# remain untouched, including the full original triangles split from primitive0.
p0=prims[0];mat=copy.deepcopy(j['materials'][p0['material']]);tx=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tx.get('source',tx.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));bv=j['bufferViews'][j['images'][ii]['bufferView']];arr=np.array(Image.open(io.BytesIO(b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']])).convert('RGB'),dtype=np.float32)/255;lum=np.mean(arr,axis=2);weight=np.clip((lum-.27)/.25,0,1);weight=weight*weight*(3-2*weight);wanted=.17+.030*np.clip((lum-.27)/.73,0,1);fresh=arr*(1-weight[:,:,None])+arr/np.maximum(lum[:,:,None],1e-6)*wanted[:,:,None]*weight[:,:,None];ti=image_tex(Image.fromarray(np.uint8(np.clip(fresh*255,0,255))));mat['name']='Owned sleeve collars83 source-tone dark cloth';mat['pbrMetallicRoughness']['baseColorTexture']={'index':ti};mi=len(j['materials']);j['materials'].append(mat)
s=np.load(r/'checks/source01_left.npz');F=s['F'];full=set()
for side in ['left','right']:
 z=np.load(r/'checks'/f'collar52_{side}_lineage.npz');full.update(map(int,z['restored_full_source_faces']))
owned={tuple(map(int,F[i]))for i in full};BF=a(p0['indices']).reshape(-1,3);mask=np.array([tuple(map(int,f))in owned for f in BF]);idx,b=append_accessor(j,b,BF[mask].astype(np.uint32),'SCALAR',34963);prims.append({'attributes':copy.deepcopy(p0['attributes']),'indices':idx,'material':mi,'mode':4});p0['indices'],b=append_accessor(j,b,BF[~mask].astype(np.uint32),'SCALAR',34963)
for pi in [9,10]:prims[pi]['material']=mi
rep['owned_collar_repaint']={'full_original_faces':int(mask.sum()),'new_full_face_primitive':len(prims)-1,'clipped_primitives':[9,10],'original_positions_normals_uvs_exact':True,'original_white_cuff_paint':'Only bright pixels on the owned collar annuli are converted to continued dark sleeve; the rest of the source atlas and model retain their original material.'}

def normals(P,T):
 q=P[T];n=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);N=np.zeros_like(P)
 for k in range(3):np.add.at(N,T[:,k],n)
 N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30);return N

def pack(P,T,UV,material,name,uvcorner=False):
 global b
 N=normals(P,T);UVc=UV if uvcorner else UV[T];unique,back=np.unique(np.c_[T.ravel(),UVc.reshape(-1,2)],axis=0,return_inverse=True);vi=unique[:,0].astype(int);lp=(P[vi][:,[0,2,1]]*[1,1,-1]-X)/S;nn=N[vi][:,[0,2,1]]*[1,1,-1];attrs={}
 for key,val,kind in [('POSITION',lp,'VEC3'),('NORMAL',nn,'VEC3'),('TEXCOORD_0',unique[:,1:],'VEC2')]:attrs[key],b=append_accessor(j,b,np.asarray(val,np.float32),kind,34962)
 ix,b=append_accessor(j,b,back.astype(np.uint32),'SCALAR',34963);pi=len(prims);prims.append({'attributes':attrs,'indices':ix,'material':material,'mode':4});rep['details'].append({'name':name,'primitive':pi,'triangles':len(T)});np.savez_compressed(r/'checks'/f'detail83_{name}.npz',P=P,T=T,N=N,UVcorner=UVc);return pi

def ellipsoid(center,axes,radii,nu=64,nv=20):
 P=[center-axes[:,2]*radii[2]];uv=[[.5,0]]
 for v in range(1,nv):
  phi=-np.pi/2+np.pi*v/nv
  for k in range(nu):
   th=2*np.pi*k/nu;P.append(center+axes@np.array([radii[0]*np.cos(phi)*np.cos(th),radii[1]*np.cos(phi)*np.sin(th),radii[2]*np.sin(phi)]));uv.append([k/nu,v/nv])
 P.append(center+axes[:,2]*radii[2]);T=[]
 for k in range(nu):T.append([0,1+(k+1)%nu,1+k])
 for row in range(nv-2):
  for k in range(nu):aa=1+row*nu+k;bb=1+row*nu+(k+1)%nu;cc=aa+nu;dd=bb+nu;T.extend([[aa,bb,cc],[bb,dd,cc]])
 for k in range(nu):T.append([len(P)-1,1+(nv-2)*nu+k,1+(nv-2)*nu+(k+1)%nu])
 return np.array(P),np.array(T),np.array(uv)
# The buttons have a dedicated two-disk atlas, with quiet sewn holes/threads.
im=Image.new('RGB',(512,512),(34,29,26));draw=ImageDraw.Draw(im);cx,cy=128,256
for dx in [-26,26]:
 for dy in [-26,26]:draw.ellipse((cx+dx-9,cy+dy-16,cx+dx+9,cy+dy+16),fill=(8,7,6))
draw.line((cx-26,cy-26,cx+26,cy+26),fill=(114,106,89),width=3);draw.line((cx-26,cy+26,cx+26,cy-26),fill=(114,106,89),width=3);buttontex=image_tex(im);bm=len(j['materials']);j['materials'].append({'name':'Dark sewn cuff buttons83','pbrMetallicRoughness':{'baseColorTexture':{'index':buttontex},'roughnessFactor':.46,'metallicFactor':0}})
for hand,sign in [('R',-1),('L',1)]:
 z=np.load(r/'checks'/f'cuff54_{hand}.npz');n=len(z['source_interface_points']);candidates=np.arange(15*n,16*n);wanted=np.array([sign*.68,-.73,.0]);wanted/=np.linalg.norm(wanted);vi=int(candidates[np.argmax(z['N'][candidates]@wanted)]);anchor=z['P'][vi];nrm=z['N'][vi];up=np.array([0.,0.,1.]);up-=nrm*(up@nrm);up/=np.linalg.norm(up);across=np.cross(up,nrm);axes=np.column_stack([across,up,nrm]);P,T,U=ellipsoid(anchor+nrm*.0022,axes,[.0065,.0065,.00135]);local=(P-(anchor+nrm*.0022))@axes;uvc=[]
 for tr in T:
  top=np.mean(local[tr,2])>=0;coord=local[tr,:2]/.0065*.5+.5;coord[:,0]=(0 if top else .5)+.02+.46*coord[:,0];coord[:,1]=.02+.96*coord[:,1];uvc.append(coord)
 pack(P,T,np.array(uvc),bm,'button_'+hand,True)
 rep['details'][-1].update(anchor_world=anchor.tolist(),nominal_button_back_clearance_m=.00085)
# Apron bow and tails use the same fitted dress function, with positive layer offsets.
g=np.load(r/'checks/coherent_garments77.npz');Z=g['profile_z'];fx,fy,fcx,fcy=[PchipInterpolator(Z,g[k])for k in ['profile_x_radius','profile_y_radius','profile_center_x','profile_center_y']];top=float(Z[-1])
def surface(th,z):
 th,z=np.broadcast_arrays(np.asarray(th),np.asarray(z));cx,cy=fcx(z),fcy(z);rx,ry=fx(z),fy(z);v=(top-z)/(top+.512);lower=np.clip((.22-z)/.35,0,1);lower=lower*lower*(3-2*lower);wave=.024*lower*(.65*np.cos(9*th+.50*v)+.20*np.cos(14*th-1.0*v)+.15*np.sin(5*th+1.2*v));return np.stack([cx+(rx+wave)*np.cos(th),cy+(ry+wave)*np.sin(th),z],axis=-1)
white=prims[22]['material'];cz=.263;back=float(surface(np.pi/2,cz)[1]);knotC=np.array([float(fcx(cz)),back+.014,cz]);P,T,U=ellipsoid(knotC,np.eye(3),[.019,.010,.025],64,24);uc=U[T].copy();seam=np.ptp(uc[:,:,0],axis=1)>.5;uc[seam,:,0]=np.where(uc[seam,:,0]<.5,uc[seam,:,0]+1,uc[seam,:,0]);pack(P,T,uc,white,'knot',True)
for sign,label in [(-1,'left'),(1,'right')]:
 u=np.arange(128)/128;phi=2*np.pi*u;center=np.c_[knotC[0]+sign*(.0208+.041*(1-np.cos(phi))),back+.014+.027*(1-np.cos(phi))*.5+.003*np.sin(phi),cz+.010*np.sin(phi)];deriv=np.c_[sign*.041*np.sin(phi),.0135*np.sin(phi)+.003*np.cos(phi),.010*np.cos(phi)];tangent=deriv/np.linalg.norm(deriv,axis=1)[:,None];wide=np.array([0.,0.,1.])[None]-tangent*tangent[:,2,None];wide/=np.linalg.norm(wide,axis=1)[:,None];thin=np.cross(tangent,wide);P=[];UV=[];ns=20
 for row in range(len(u)):
  for k in range(ns):
   angle=2*np.pi*k/ns;P.append(center[row]+wide[row]*(.017*np.sin(angle))+thin[row]*(.00065*np.cos(angle)));UV.append([u[row],k/ns])
 T=[]
 for row in range(len(u)):
  for k in range(ns):aa=row*ns+k;bb=((row+1)%len(u))*ns+k;cc=row*ns+(k+1)%ns;dd=((row+1)%len(u))*ns+(k+1)%ns;T.extend([[aa,bb,cc],[cc,bb,dd]])
 P,T,UV=np.array(P),np.array(T),np.array(UV);uc=UV[T].copy()
 for axis in [0,1]:
  seam=np.ptp(uc[:,:,axis],axis=1)>.5;uc[seam,:,axis]=np.where(uc[seam,:,axis]<.5,uc[seam,:,axis]+1,uc[seam,:,axis])
 # Check volume sign: a ribbon loop is a closed thin tube and must face outward.
 if np.einsum('ij,ij->i',P[T[:,0]],np.cross(P[T[:,1]],P[T[:,2]])).sum()<0:T=T[:,::-1];uc=uc[:,::-1]
 pack(P,T,uc,white,'bow_'+label,True)
 # Solid thin hanging tail with its ends and perimeter explicitly closed.
 nt,nw=84,25;ss=np.linspace(-1,1,nw);front=[];uv=[]
 for t in np.linspace(0,1,nt):
  th=np.pi/2+sign*(.17+.12*t+.07*np.sin(np.pi*t));half=.016*(1+.4*np.sin(np.pi*t));angles=th+ss*half/float(fx(.236-.31*t));z=.236-.31*t+.008*ss*t*t;offset=.006+.012*np.exp(-8*t)+.006*np.sin(np.pi*t)*np.cos(3*ss+5*t);q=surface(angles,z)+np.c_[np.cos(angles),np.sin(angles),np.zeros(nw)]*offset[:,None]if isinstance(offset,np.ndarray)else surface(angles,z)+np.c_[np.cos(angles),np.sin(angles),np.zeros(nw)]*offset;front.append(q);uv.extend([[.5*(x+1),t]for x in ss])
 front=np.concatenate(front);T=[]
 for row in range(nt-1):
  for k in range(nw-1):aa=row*nw+k;bb=aa+1;cc=aa+nw;dd=cc+1;T.extend([[aa,cc,bb],[bb,cc,dd]])
 T=np.array(T);N=normals(front,T);P=np.vstack([front,front-N*.0011]);TT=np.vstack([T,T[:,::-1]+len(front)]).tolist();ee=collections.defaultdict(list)
 for tri in T:
  for aa,bb in zip(tri,np.roll(tri,-1)):ee[tuple(sorted((int(aa),int(bb))))].append((int(aa),int(bb)))
 for fs in ee.values():
  if len(fs)==1:aa,bb=fs[0];TT.extend([[aa,aa+len(front),bb],[bb,aa+len(front),bb+len(front)]])
 UV=np.vstack([np.array(uv)*[.46,.96]+[.02,.02],np.array(uv)*[.46,.96]+[.52,.02]]);pack(P,np.array(TT),UV,white,'tail_'+label)
assert b[:len(oldb)]==oldb;out=r/'models/white83_tailored_details_assembly.glb';write_glb(out,j,b);rep.update(output=str(out),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),base_binary_prefix_held=True,scope='Tailored accessory/paint assembly trial. Existing geometry, including exact source joins, is held; no accessory or collar-color acceptance follows without serialized contact and actual all-angle views. Closed hand replacement is separate.');(r/'checks/white83_details.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
