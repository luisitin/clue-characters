"""Cross-component exact contact checks on stored GLB geometry, plus explicitly sampled distances."""
import pathlib,sys,os,json,hashlib,collections,time,numpy as np
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb
path=r/'models/white73_coherent_garment_assembly.glb';j,b,a=read_glb(path);S=np.array(j['nodes'][0]['scale']);X=np.array(j['nodes'][0]['translation']);ps=[];ts=[];labels=[];groups=[];pn={};tn={}
group_for=lambda pi:0 if pi<11 or pi==19 else 1 if pi<15 else 2 if pi<19 else pi-17
names={0:'retained_source',1:'hand_cuff_R',2:'hand_cuff_L',3:'dress',4:'apron',5:'belt',6:'stocking_L',7:'stocking_R'}
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 p=(a(pr['attributes']['POSITION'])*S+X)[:,[0,2,1]]*[1,-1,1];t=a(pr['indices']).reshape(-1,3);pn[pi]=p;tn[pi]=t;ts.append(t+sum(len(q)for q in ps));ps.append(p);labels.extend([[pi,int(k)]for k in range(len(t))]);groups.extend([group_for(pi)]*len(t))
pair=tuple(map(int,os.environ['PAIR'].split(',')));P0=np.concatenate(ps);T0=np.concatenate(ts);groups0=np.array(groups);labels0=np.array(labels);tri=P0[T0];lo=tri.min(1);hi=tri.max(1);A=np.flatnonzero(groups0==pair[0]);B=np.flatnonzero(groups0==pair[1]);mn=np.maximum(lo[A].min(0),lo[B].min(0))-1e-7;mx=np.minimum(hi[A].max(0),hi[B].max(0))+1e-7;ids=np.r_[A[np.all(hi[A]>=mn,1)&np.all(lo[A]<=mx,1)],B[np.all(hi[B]>=mn,1)&np.all(lo[B]<=mx,1)]];groups=groups0[ids];labels=labels0[ids];use,back=np.unique(T0[ids],return_inverse=True);P=P0[use];T=back.reshape(-1,3);helper=r.parent/'mustard/v5_rebuild/scripts/audit_intersections_v4.py';sys.path.insert(0,str(helper.parent));source=helper.read_text().replace('from glb_io import GLB\n','').replace('def audit(P,T,tol=1e-8,bounds=None):','def audit(P,T,tol=1e-8,bounds=None,groups=None):');source=source.replace('selected=np.arange(len(T))','selected=np.flatnonzero(groups==groups[0])');needle='for j in js:';source=source.replace(needle,'if groups is not None:js=js[groups[js]!=groups[i]]\n        '+needle);ns={'__name__':'white76_contact','__file__':str(helper)};exec(compile(source,str(helper),'exec'),ns);print({'pair':pair,'roi_faces':len(T),'selected_faces':int(sum(groups==pair[0]))},flush=True)
if not len(T):
 (r/'checks'/f'white76_contact_{pair[0]}_{pair[1]}.json').write_text(json.dumps({'pair':pair,'model_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'disjoint_component_AABB':True}));sys.exit(0)
result=ns['audit'](P,T,tol=1e-8,groups=groups)
rep={k:[dict(z,primitive_face_pairs=labels[z['faces']].tolist(),component_pair=[names[int(v)]for v in groups[z['faces']]])for z in result[k]]for k in ['proper_crossings','positive_area_coplanar_pairs']};rep['position_triangle_copy_groups']=[z for z in result['position_triangle_copy_groups']if len(set(groups[z]))>1];rep['component_join_folds_over_105_degrees']=[z for z in result['manifold_edge_folds_over_105_degrees']if groups[z[0]]!=groups[z[1]]]
u,iv=np.unique(P,axis=0,return_inverse=True);G=iv[T];edges=collections.defaultdict(list)
for k,t in enumerate(G):
 for v,w in zip(t,np.roll(t,-1)):edges[tuple(sorted((int(v),int(w))))].append(k)
N=np.cross(P[T[:,1]]-P[T[:,0]],P[T[:,2]]-P[T[:,0]]);N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-30);joins=collections.defaultdict(list)
for fs in edges.values():
 if len(fs)==2 and groups[fs[0]]!=groups[fs[1]]:joins[tuple(sorted((int(groups[fs[0]]),int(groups[fs[1]]))))].append(fs)
join_summary=[]
for joinpair,fs in joins.items():
 fs=np.array(fs);angs=np.degrees(np.arccos(np.clip(np.einsum('ij,ij->i',N[fs[:,0]],N[fs[:,1]]),-1,1)));join_summary.append({'components':[names[x]for x in joinpair],'exact_shared_edges':len(fs),'maximum_angle_degrees':float(angs.max())})
counts=collections.Counter(tuple(z['component_pair'])for z in rep['proper_crossings']);rep.update(model=str(path),model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),component_names=names,crossings_by_pair=[{'components':list(k),'crossings':v}for k,v in counts.items()],exact_shared_interfaces=join_summary,seconds=result['seconds'],tested_nonadjacent_cross_component_candidates=result['tested_nonadjacent_candidates'],scope='Exact stored-position cross-component surface intersections, including retained-source contact. Same-component self checks omitted here and reported separately. Positive clearance, source appearance and finished approval remain separate.')
(r/'checks'/f'white76_contact_{pair[0]}_{pair[1]}.json').write_text(json.dumps(rep,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in rep.items()},flush=True)
