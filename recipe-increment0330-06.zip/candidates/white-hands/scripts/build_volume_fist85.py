"""Coherent closed-pose surface from a deliberately intersecting anatomical articulation.
Native 40-point wrist interface is held exactly; distal volume retopology is new.
This is an unvalidated geometry study, not a source/UV/paint acceptance.
"""
import bpy,bmesh,pathlib,json,collections,numpy as np,hashlib
from mathutils import Vector
r=pathlib.Path(__file__).resolve().parents[1];meta=json.loads((r/'checks/fist_seed84.json').read_text())['hands'];bpy.ops.wm.read_factory_settings(use_empty=True);report={}
def edges(T):
 e=collections.defaultdict(list)
 for fi,tr in enumerate(T):
  for a,b in zip(tr,np.roll(tr,-1)):e[tuple(sorted((int(a),int(b))))].append((int(a),int(b),fi))
 return e
def loop_from(T):
 ee=edges(T);boundary=[q[0][:2]for q in ee.values()if len(q)==1];nxt={a:b for a,b in boundary};assert len(nxt)==len(boundary);loop=[min(nxt)]
 while nxt[loop[-1]]!=loop[0]:loop.append(nxt[loop[-1]]);assert len(loop)<=len(nxt)
 assert len(loop)==len(nxt);return np.array(loop)
def zipper(a,au,b,bu):
 ts=[];i=j=0;na,nb=len(a),len(b)
 while i<na or j<nb:
  an=au[i+1]if i+1<na else 1.;bn=bu[j+1]if j+1<nb else 1.;aa=a[i%na];bb=b[j%nb]
  if i<na and(j>=nb or an<bn-1e-12):ts.append([aa,bb,a[(i+1)%na]]);i+=1
  elif j<nb and(i>=na or bn<an-1e-12):ts.append([aa,bb,b[(j+1)%nb]]);j+=1
  else:ts.extend([[aa,bb,a[(i+1)%na]],[a[(i+1)%na],bb,b[(j+1)%nb]]]);i+=1;j+=1
 return ts
for side in ['R','L']:
 src=np.load(r/'checks'/f'fist_seed84_{side}.npz');held=np.load(r/'checks'/f'fist_seed27_{side}.npz');P=src['P'];T=src['T'];native=loop_from(T);root=held['P'][native];rootc=root.mean(0);F=np.array(meta[side]['forward']);S=np.array(meta[side]['thumbward']);D=np.cross(F,S);cap=len(P);PP=np.vstack([P,rootc-F*.008]);TT=np.vstack([T,[[int(native[(k+1)%len(native)]),int(native[k]),cap]for k in range(len(native))]])
 me=bpy.data.meshes.new(side+' closed volume input84');me.from_pydata(PP.tolist(),[],TT.tolist());me.update();ob=bpy.data.objects.new('White '+side+' closed fist85',me);bpy.context.collection.objects.link(ob);bpy.context.view_layer.objects.active=ob;ob.select_set(True);me.remesh_voxel_size=.00065;me.use_remesh_preserve_volume=True;bpy.ops.object.voxel_remesh();sm=ob.modifiers.new('Quarter-millimetre surface fairing','SMOOTH');sm.factor=.28;sm.iterations=3;bpy.ops.object.modifier_apply(modifier=sm.name);dec=ob.modifiers.new('Anatomical volume retopology','DECIMATE');dec.ratio=.30;bpy.ops.object.modifier_apply(modifier=dec.name)
 bm=bmesh.new();bm.from_mesh(ob.data);plane=rootc+F*.004;bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=1e-9,plane_co=Vector(plane),plane_no=Vector(F),clear_inner=True,clear_outer=False);bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();me=ob.data;me.calc_loop_triangles();Q=np.array([v.co[:]for v in me.vertices]);U=np.array([t.vertices[:]for t in me.loop_triangles]);use,back=np.unique(U,return_inverse=True);Q=Q[use];U=back.reshape(-1,3);cut=loop_from(U)[::-1];rootids=native[::-1];R=held['P'][rootids]
 def parameter(loop):
  k=int(np.argmax((loop-loop.mean(0))@S));loop=np.roll(loop,-k,axis=0);ll=np.linalg.norm(np.roll(loop,-1,axis=0)-loop,axis=1);uu=np.r_[0,np.cumsum(ll[:-1])]/ll.sum();return loop,uu,k
 R,ru,rk=parameter(R);rootids=np.roll(rootids,-rk);C,cu,ck=parameter(Q[cut]);cut=np.roll(cut,-ck);ra=np.sum(np.cross(R-rootc,np.roll(R,-1,axis=0)-rootc)@F);ca=np.sum(np.cross(C-C.mean(0),np.roll(C,-1,axis=0)-C.mean(0))@F);assert ra*ca>0,(side,ra,ca)
 outP=[Q,R];outT=U.tolist();last=np.arange(len(Q),len(Q)+len(R));lastu=ru;count=len(Q)+len(R);u=np.arange(128)/128;interp=lambda q,t:np.column_stack([np.interp(u,np.r_[t,1],np.r_[q[:,k],q[0,k]])for k in range(3)]);RR=interp(R,ru);CC=interp(C,cu)
 for alpha in [.18,.40,.65,.85]:
  points=RR*(1-alpha)+CC*alpha;ids=np.arange(count,count+len(points));outP.append(points);outT.extend(zipper(last,lastu,ids,u));last,lastu=ids,u;count+=len(points)
 outT.extend(zipper(last,lastu,cut,cu));outP=np.concatenate(outP);outT=np.array(outT);ee=edges(outT);boundary=[e for e,fs in ee.items()if len(fs)==1];assert len(boundary)==40;assert sum(len(fs)>2 for fs in ee.values())==0;assert sum(len(fs)==2 and fs[0][:2]==fs[1][:2]for fs in ee.values())==0
 new=bpy.data.meshes.new(side+' coherent fist85');new.from_pydata(outP.tolist(),[],outT.tolist());new.update();ob.data=new
 for poly in new.polygons:poly.use_smooth=True
 # Diagnostic spherical atlas around the hand longitudinal axis. Production UV
 # unwrap and skin paint remain open and are not inferred from this preview.
 uv=new.uv_layers.new(name='DiagnosticCylinder');rel=outP-rootc;theta=np.arctan2(rel@D,rel@S)/(2*np.pi)+.5;long=rel@F;long=(long-long.min())/(long.max()-long.min())
 for poly in new.polygons:
  corners=np.array([[theta[v],long[v]]for v in poly.vertices]);
  if np.ptp(corners[:,0])>.5:corners[:,0]=np.where(corners[:,0]<.5,corners[:,0]+1,corners[:,0])
  for li,q in zip(poly.loop_indices,corners):uv.data[li].uv=q
 mat=bpy.data.materials.new(side+' diagnostic source-tone79');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.57,.28,.145,1);bs.inputs['Roughness'].default_value=.62;new.materials.append(mat);new.calc_loop_triangles();NP=np.array([v.co[:]for v in new.vertices]);NT=np.array([t.vertices[:]for t in new.loop_triangles]);NN=np.array([v.normal[:]for v in new.vertices]);UV=np.array([[uv.data[li].uv[:]for li in t.loops]for t in new.loop_triangles]);np.savez_compressed(r/'checks'/f'fist_seed85_{side}.npz',P=NP,T=NT,N=NN,UVcorner=UV,native_wrist_ids=np.arange(len(Q),len(Q)+40),native_wrist_source_ids=rootids,root_source_P=held['P'][rootids]);report[side]={'triangles':len(NT),'voxel_size_m':.00065,'surface_decimation_ratio':.30,'native_wrist_vertices':40,'native_wrist_positions_exact':bool(np.array_equal(NP[len(Q):len(Q)+40],held['P'][rootids])),'cut_forward_m':.004,'retopologized_surface':'Deliberate solid-volume union of closed anatomical articulation84, then an explicit native-wrist bridge. No input crossing clearance is claimed.','input84_sha256':hashlib.sha256((r/'checks'/f'fist_seed84_{side}.npz').read_bytes()).hexdigest()};ob.select_set(False)
bpy.ops.wm.save_as_mainfile(filepath=str(r/'models/fist_seed85.blend'),compress=True);bpy.ops.export_scene.gltf(filepath=str(r/'models/fist_seed85.glb'),export_format='GLB',export_yup=True,export_animations=False,export_cameras=False,export_lights=False,export_tangents=True);report['scope']='Unintegrated coherent closed-fist85 study. Self contact, native-wrist closure, cloth fit, volume anatomy, new UV unwrap and skin paint still require independent checks.';(r/'checks/fist_seed85.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
