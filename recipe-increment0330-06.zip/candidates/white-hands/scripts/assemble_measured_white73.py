"""Assemble the coherent lower garment on White25 lineage plus cuff56.
Retain exact original lower legs/shoes below a clean stocking cut; rebuild only
the short stocking tops hidden mainly by the dress. Preserve upper body/arms.
"""
import pathlib,sys,json,io,collections,hashlib,numpy as np
from PIL import Image
r=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(r.parent/'scarlett-white/scripts'));from glb_io import read_glb,append_accessor,write_glb
base=r/'models/white56_cuff_correction_diagnostic.glb';j,buf,a=read_glb(base);s=np.load(r/'checks/source01_left.npz');F=s['F'];W=s['W'];U,iv=np.unique(s['P'],axis=0,return_inverse=True);G=iv[F];UW=(U*s['node_scale']+s['node_translation'])[:,[0,2,1]]*[1,-1,1];S=np.array(s['node_scale']);X=np.array(s['node_translation']);section=np.load(r/'checks/band60_z+0.342337_c1.npz');top=float(section['plane_z']);lo=-.557663;q=j['meshes'][0]['primitives'][0];curF=a(q['indices']).reshape(-1,3);lookup={tuple(map(int,f)):i for i,f in enumerate(F)};assert len(lookup)==len(F);curids=np.array([lookup[tuple(map(int,f))]for f in curF]);active=set(curids[W[F[curids],2].min(1)<top]);edge=collections.defaultdict(list)
for fi in active:
 for u,v in zip(G[fi],np.roll(G[fi],-1)):
  if min(UW[u,2],UW[v,2])<top:edge[tuple(sorted((int(u),int(v))))].append(int(fi))
adj=collections.defaultdict(set)
for fs in edge.values():
 for f in fs:adj[f].update(k for k in fs if k!=f)
cross=curids[(W[F[curids],2].min(1)<top)&(W[F[curids],2].max(1)>top)];cent=W[F].mean(1);armseeds=[int(f)for f in cross if abs(cent[f,0])>.26];bodyseeds=[int(f)for f in section['source_cut_faces']if int(f)in active]
def flood(seeds):
 found=set();todo=list(seeds)
 while todo:
  f=todo.pop()
  if f in found:continue
  found.add(f);todo.extend(adj[f]-found)
 return found
arms=flood(armseeds);body=flood(bodyseeds);assert not arms&body,'Unexpected retained hand/arm to torso bridge';kept=set(map(int,curids))-active|arms;feet=set(map(int,np.flatnonzero(W[F,2].max(1)<lo)));kept|=feet;bodycuts=[int(f)for f in cross if int(f)not in arms];assert set(bodycuts)==set(map(int,section['source_cut_faces']));footcuts=np.flatnonzero((W[F,2].min(1)<lo)&(W[F,2].max(1)>lo));fragments=[];fraw=[];bcorners=[]
def clip(fi,z,sgn):
 ids=F[fi];values=W[ids,2]-z;seq=[]
 for k in range(3):
  kk=(k+1)%3;va,vb=values[k]*sgn,values[kk]*sgn
  if va>0:seq.append(np.eye(3)[k])
  if va*vb<0:
   t=-values[k]/(values[kk]-values[k]);seq.append((1-t)*np.eye(3)[k]+t*np.eye(3)[kk])
 for k in range(1,len(seq)-1):fragments.append(fi);fraw.append(int(s['raw_face_ids'][fi]));bcorners.append([seq[0],seq[k],seq[k+1]])
for fi in bodycuts:clip(fi,top,1)
for fi in footcuts:clip(int(fi),lo,-1)
cf=np.array(fragments);bc=np.array(bcorners);local=np.einsum('tci,tij->tcj',bc,s['P'][F[cf]]);normal=np.einsum('tci,tij->tcj',bc,s['N'][F[cf]]);normal/=np.linalg.norm(normal,axis=2)[:,:,None];uv=np.einsum('tci,tij->tcj',bc,s['UV'][F[cf]]);report={'base56_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'retained_source_arms_below_torso_plane':len(arms),'removed_source_body_component_below_plane':len(body),'removed_other_below_plane_fragments':len(active-arms-body),'restored_exact_source_foot_faces':len(feet),'body_source_cut_faces':len(bodycuts),'foot_source_cut_faces':len(footcuts),'source_clip_triangles':len(cf)}
def append_quant_local(local,N,UV,T,mi):
 global buf
 raw=np.ascontiguousarray(np.rint(local*32767).astype('<i2'));buf+=b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':raw.nbytes,'target':34962});buf+=raw.tobytes();ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5122,'normalized':True,'count':len(raw),'type':'VEC3','min':raw.min(0).astype(int).tolist(),'max':raw.max(0).astype(int).tolist()});attrs={'POSITION':ai}
 for name,v,kind in [('NORMAL',N,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],buf=append_accessor(j,buf,v.astype(np.float32),kind,34962)
 ix,buf=append_accessor(j,buf,T.astype(np.uint32),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':mi,'mode':4});return len(j['meshes'][0]['primitives'])-1
sourceclip=append_quant_local(local.reshape(-1,3),normal.reshape(-1,3),uv.reshape(-1,2),np.arange(3*len(cf)).reshape(-1,3),q['material']);q['indices'],buf=append_accessor(j,buf,F[sorted(kept)].astype(np.uint32),'SCALAR',34963)
# Append complete standalone garments without any source re-export.
gp=r/'models/coherent_garments72.glb';gj,gb,ga=read_glb(gp);mi0=len(j['materials']);im0=len(j['images']);tex0=len(j['textures']);samp0=len(j.setdefault('samplers',[]));j['samplers'].extend(gj['samplers'])
for im in gj['images']:
 v=gj['bufferViews'][im['bufferView']];blob=gb[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']];buf+=b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(blob)});buf+=blob;j['images'].append({'bufferView':vi,'mimeType':im['mimeType']})
for tx in gj['textures']:j['textures'].append({'source':tx['source']+im0,'sampler':tx['sampler']+samp0})
for mat in gj['materials']:
 mat=json.loads(json.dumps(mat));mat['pbrMetallicRoughness']['baseColorTexture']['index']+=tex0;j['materials'].append(mat)
garpr=[]
for pr in gj['meshes'][0]['primitives']:
 garpr.append(append_quant_local(ga(pr['attributes']['POSITION']),ga(pr['attributes']['NORMAL']),ga(pr['attributes']['TEXCOORD_0']),ga(pr['indices']).reshape(-1,3),mi0+pr['material']))
# Short fitted stocking tops. Their exact source lower loops and source-derived
# upper section shapes remain fixed; original feet and lower legs are unchanged.
def normals(P,T):
 tr=P[T];n=np.cross(tr[:,1]-tr[:,0],tr[:,2]-tr[:,0]);out=np.zeros_like(P)
 for k in range(3):np.add.at(out,T[:,k],n)
 out/=np.maximum(np.linalg.norm(out,axis=1)[:,None],1e-30);return out

def order_section(z,comp):
 d=np.load(r/'checks'/f'band61_z{z:+.6f}_c{comp}.npz');p=d['P'];edges=d['source_physical_edges'];area=np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1))
 if area<0:p=p[::-1];edges=edges[::-1]
 start=int(np.argmax(p[:,0]));p=np.roll(p,-start,axis=0);edges=np.roll(edges,-start,axis=0);p=(np.rint(((p[:,[0,2,1]]*[1,1,-1]-X)/S)*32767)/32767*S+X)[:,[0,2,1]]*[1,-1,1];length=np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1);uu=np.r_[0,np.cumsum(length[:-1])]/length.sum();return p,edges,uu,d['source_cut_faces']
def zip_up(a,au,b,bu):
 out=[];i=k=0;na,nb=len(a),len(b)
 while i<na or k<nb:
  an=au[i+1]if i+1<na else 1.;bn=bu[k+1]if k+1<nb else 1.;aa=a[i%na];bb=b[k%nb]
  if i<na and(k>=nb or an<bn-1e-12):out.append([aa,a[(i+1)%na],bb]);i+=1
  elif k<nb and(i>=na or bn<an-1e-12):out.append([aa,b[(k+1)%nb],bb]);k+=1
  else:out.extend([[aa,a[(i+1)%na],bb],[a[(i+1)%na],b[(k+1)%nb],bb]]);i+=1;k+=1
 return out
# Source image for a continuous stocking color around the retained loop.
tex=j['textures'][j['materials'][q['material']]['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tex.get('source',tex.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];image0=np.array(Image.open(io.BytesIO(buf[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB'))/255.;H,WW=image0.shape[:2];legreports=[]
for side,lowercomp,uppercomp in [('left',0,1),('right',1,2)]:
 lower,le,lu,lfs=order_section(lo,lowercomp);upper,ue,uu,ufs=order_section(-.447663,uppercomp);n=128;us=np.arange(n)/n;interp=lambda p,u:np.column_stack([np.interp(us,np.r_[u,1],np.r_[p[:,k],p[0,k]])for k in range(3)]);L=interp(lower,lu);Upp=interp(upper,uu);LP=[lower];LT=[];LUV=[np.c_[lu,np.zeros(len(lower))]];last=np.arange(len(lower));lastu=lu;count=len(lower)
 for t in np.linspace(.055,1,21):
  p=(1-t)*L+t*Upp;p[:,2]=(1-t)*lower[0,2]+t*upper[0,2];ids=np.arange(count,count+n);LT.extend(zip_up(last,lastu,ids,us));LP.append(p);LUV.append(np.c_[us,np.full(n,.72*t)]);last,lastu=ids,us;count+=n
 center=Upp.mean(0);relative=Upp-center
 for ph in np.linspace(np.pi/12,5*np.pi/12,5):
  p=center+relative*np.cos(ph);p[:,2]+=.027*np.sin(ph);ids=np.arange(count,count+n);LT.extend(zip_up(last,lastu,ids,us));LP.append(p);LUV.append(np.c_[us,np.full(n,.72+.25*ph/(np.pi*.5))]);last=ids;count+=n
 pole=count;LP.append((center+[0,0,.027])[None]);LUV.append(np.array([[.5,1.]]))
 for k in range(n):LT.append([last[k],last[(k+1)%n],pole])
 LP=np.concatenate(LP);LT=np.array(LT);LUV=np.concatenate(LUV);LN=normals(LP,LT);source_uv=[];source_nn=[]
 for p,(a0,b0)in zip(lower,le):
  match=next(int(f)for f in lfs if a0 in G[f]and b0 in G[f]);ka,kb=[int(np.where(G[match]==v0)[0][0])for v0 in[a0,b0]];t=(lo-UW[a0,2])/(UW[b0,2]-UW[a0,2]);sv=s['F'][match];source_uv.append((1-t)*s['UV'][sv[ka]]+t*s['UV'][sv[kb]]);nn=(1-t)*s['N'][sv[ka]]+t*s['N'][sv[kb]];source_nn.append(nn[[0,2,1]]*[1,-1,1])
 source_nn=np.array(source_nn);source_nn/=np.linalg.norm(source_nn,axis=1)[:,None];LN[:len(lower)]=source_nn;source_uv=np.array(source_uv);rgb=image0[(source_uv[:,1]*H).astype(int).clip(0,H-1),(source_uv[:,0]*WW).astype(int).clip(0,WW-1)];rgbu=np.column_stack([np.interp((np.arange(512)+.5)/512,np.r_[lu,1],np.r_[rgb[:,k],rgb[0,k]])for k in range(3)]);arr=np.broadcast_to(rgbu[None],(512,512,3)).copy();arr=arr*.98+.02*np.median(rgb,axis=0);png=io.BytesIO();Image.fromarray(np.clip(arr*255,0,255).astype('uint8')).save(png,format='PNG');blob=png.getvalue();buf+=b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(blob)});buf+=blob;j['images'].append({'bufferView':vi,'mimeType':'image/png'});j['textures'].append({'source':len(j['images'])-1,'sampler':samp0});mi=len(j['materials']);j['materials'].append({'name':'Source-matched '+side+' stocking top73','pbrMetallicRoughness':{'baseColorTexture':{'index':len(j['textures'])-1},'roughnessFactor':.84,'metallicFactor':0}});uvc=LUV[LT].copy();seam=np.ptp(uvc[:,:,0],axis=1)>.5;uvc[seam,:,0]=np.where(uvc[seam,:,0]<.5,uvc[seam,:,0]+1,uvc[seam,:,0]);poles=np.flatnonzero(np.sum(uvc[:,:,1]>.99999,axis=1)==1);
 for f in poles:
  k=int(np.argmax(uvc[f,:,1]));uvc[f,k,0]=np.mean(np.delete(uvc[f,:,0],k))
 unique,back=np.unique(np.c_[LT.ravel(),uvc.reshape(-1,2)],axis=0,return_inverse=True);ids=unique[:,0].astype(int);lp=(LP[ids][:,[0,2,1]]*[1,1,-1]-X)/S;nn=LN[ids][:,[0,2,1]]*[1,1,-1];pi=append_quant_local(lp,nn,unique[:,1:],back.reshape(-1,3),mi);np.savez_compressed(r/'checks'/f'stocking73_{side}.npz',P=LP,T=LT,N=LN,UV=LUV,lower_source_points=lower,lower_source_physical_edges=le,upper_source_profile=upper,lower_source_cut_faces=lfs,upper_source_cut_faces=ufs);legreports.append({'side':side,'primitive':pi,'triangles':len(LT),'lower_original_source_loop_vertices':len(lower),'source_lower_cut_ideal_z':lo,'encoded_lower_cut_z':float(lower[0,2]),'fitted_upper_profile_z':float(upper[0,2]),'scope':'Short stocking-top surface replacement between measured source loops; lower original legs and shoes remain exact. Cap is hidden inside the skirt.'})
keptarr=np.array(sorted(kept));np.savez_compressed(r/'checks/white73_source_lineage.npz',retained_source_faces=keptarr,retained_source_raw_ids=s['raw_face_ids'][keptarr],removed_source_faces=np.array(sorted(set(map(int,curids))-kept)),removed_source_raw_ids=s['raw_face_ids'][np.array(sorted(set(map(int,curids))-kept))],clipped_source_faces=cf,clipped_source_raw_ids=np.array(fraw),clipped_source_barycentric=bc,clipped_primitive=sourceclip,retained_arm_source_faces=np.array(sorted(arms)),exact_lower_leg_source_faces=np.array(sorted(feet)),torso_cut_plane=top,stocking_cut_plane=lo);report.update(garments72_sha256=hashlib.sha256(gp.read_bytes()).hexdigest(),garment_primitives=garpr,source_clip_primitive=sourceclip,stockings=legreports,source_face_corner_attributes_retained_exact=True,scope='Integrated structural trial73. Original lower garment and fused old hand/body pieces removed; upper body/arms retained, short stocking tops rebuilt to source profiles. Held hand27/cuff56 remain. Bow/tails, natural closed-hand pose, actual serialized geometry/contact/UV and all-angle appearance checks remain mandatory.');out=r/'models/white73_coherent_garment_assembly.glb';write_glb(out,j,buf);report['model_sha256']=hashlib.sha256(out.read_bytes()).hexdigest();(r/'checks/white73_assembly.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
