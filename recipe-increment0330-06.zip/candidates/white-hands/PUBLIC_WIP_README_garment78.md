# White coherent garment checkpoint

This is unfinished modeling work. No finished-character approval is recorded.

## Coherent candidates

- White73 is the recovered measured-torso assembly, with a continuous replacement dress, separate apron/belt, fitted stocking tops, and held hand27/cuff56 components. SHA256: fc1ffb137037b0b9bee78aa94c9f029ccba16ae83a3d6afcb385af7032a0fec6.
- White78 is the newer complete garment trial. It adds broader hanging dress folds, asymmetric apron drape, a bowed apron hem and physically rounded belt edges. SHA256: d869c2218211299ee821ad905dcac360d647de637d90770c72803acf5a3559bb.
- White32, in the adjacent scarlett-white workstream, merges White31 upper-source repairs onto White73 without changing its other primitives. SHA256: 52f517bc9cb329d2d26623803666c0df14764099fd26d1f3b5e428715453a324. It is a separate merge reference, not a merge of the newer78 garment.

The exact 221-point torso interface is held at encoded world Z 0.34234365119370036 m. Original lower legs/shoes, upper body and retained arms keep their original source attributes. New stocking tops meet exact 114/120-point lower source loops. Held cuff assemblies meet exact 129/109-point source loops.

## Actual model views

White73 and White78 each have front, rear, both sides, and waist-front renders under renders/, with exact model SHA256 and camera JSON beside every image. These are actual GLB reimport views. Both sets were inspected. White73 removes the former horizontal ridge below the bib; White78 has more visible cloth drape and softer belt edges. The garments still need richer fabric appearance, natural tied-apron detail, and an approved hand pose. Existing upper chest paint artifacts remain in73/78; the separate White32 merge addresses the held upper cleanup.

## Verified geometry and remaining defects

All seven White73 component self checks completed. Dress, apron, stockings and both cuff/hand groups have zero reported proper crossings, coplanar overlaps, copied triangles, degenerate faces, winding conflicts or nonmanifold edges. The apron winding correction is included. Its intended source boundaries remain open per component until the source is included.

White73's belt was closed and intersection-clean but had 46 adjacent bends above105 degrees, maximum107.804 degrees. White78's rounded belt has zero such bends and maximum48.079 degrees. Complete stored-position self checks on White78 dress/apron/belt are clean: zero crossings, overlaps, copies, degenerates, winding conflicts, nonmanifold edges or bends over105 degrees.

White76 reports check the significant73 component pairs. White80 reports cover all28 unordered component-group pairs on78, with disjoint AABBs recorded where applicable. White78's only reported cross-component defect is44 proper crossings between held left hand primitive18 and dress primitive20. White73 had32 at the same hand/dress contact. Other checked layer pairs are intersection-clean. Dress/source, cuff/source and stocking/source joins are exact, with maximum join angles40.083,38.722/16.020 and16.267/18.791 degrees respectively on73.

These results do not establish a positive minimum cloth clearance, an approved UV atlas, final paint, or whole-source topology clearance. Retained-source self geometry is outside the cross-component report. The garment, hands and source upper cleanup still require a combined independent review.

The73 self-check wrapper's two hand_cuff filenames use reversed left/right labels relative to its primitive groups. Primitive IDs are authoritative:11–14 are the negative-X anatomical right hand/cuff;15–18 are the positive-X anatomical left hand/cuff.

## New hand studies

Poses75/81/84 test stronger finger flexion and measured thumb placement. They are intermediate articulation inputs and have no native-topology intersection acceptance. Volume79 and85 replace the deliberately intersecting articulated surface with a coherent volume-remeshed surface and an explicit native-wrist bridge.85 has47,948/47,926 triangles and holds each40-point native wrist exactly in the saved arrays.

Four actual85 right-hand macro views are saved and were inspected. The front has a more compact fist silhouette; the palmar view still needs thumb/anatomy work, and the wrist bridge has visible faceting.85 is unintegrated, has only a provisional diagnostic UV chart and plain source-tone material, and has not received serialized intersection/contact checks. Do not substitute85 into a coherent character yet. Hand27 remains the held integrated component.

## Unexported accessory work

The83 recipe attempts source-safe recoloring of owned sleeve-collar annuli, fitted sewn cuff buttons, and back bow/tails. It stopped before GLB export because the ellipsoid helper omits the top pole UV row. No White83 model or actual views exist. Partial detail arrays are diagnostic only. Before a future retry, add that missing UV row and review the bow centerline/cross-section for tight-turn intersections. The script is preserved as unfinished work, not a validated accessory.

## Reconstruction order and provenance

1. Restore the pinned White25 source and the cuff56 base. Preserve their source data and hashes.
2. Use build_measured_garments72.py, then assemble_measured_white73.py for73.
3. Use build_draped_garments77.py, then assemble_draped_white78.py for78.
4. The adjacent merge_white_upper192.py applies the White25-to31 upper-source delta to73. For later bases, change only declared input/output/report paths and retain its exact-prefix/other-primitive assertions.
5. Render the exact GLB with render_white73.py or render_white78.py. Audit self components and the overlapping-AABB pair scripts separately. The intentionally stopped full-scene74 audit produced no final report and is not a pass.
6. To rebuild the newest hand85 from saved intermediate84 arrays, use build_volume_fist85.py. The complete84 anatomical recipe and official CC0 MakeHuman target references are also retained. Earlier inputs are included only as needed for reproducibility or diagnosis.

No original model or reference was overwritten. No remote publication is claimed by this local checkpoint. No jobs or lock waiters remain in this workstream.
