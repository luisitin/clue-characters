"""Replace the held head component by the complete orbital reconstruction."""
from pathlib import Path
from merge_glbs297 import merge
O=Path(__file__).resolve().parents[1]
names=['source_body322.glb','head_orbits328.glb','neck_loft299.glb','eyes_optical264.glb','spectacles_joined193.glb','hand_skin304.glb','cuff_colors304.glb','hair_closed301.glb']
print(merge([O/'components'/name for name in names],O/'components/plum_assembly332.glb'),flush=True)
