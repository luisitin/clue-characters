"""Material-only moist optical-surface study, retaining255 geometry and249 iris UVs."""
from pathlib import Path
import json,struct,hashlib
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];src=O/'components/eyes_cornea255.glb';j,b,a=read_glb(src);changed=[]
for i,m in enumerate(j['materials']):
 if m.get('name','').startswith('sclera'):
  m['pbrMetallicRoughness']['roughnessFactor']=.13;m.setdefault('extensions',{})['KHR_materials_ior']={'ior':1.376};m['name']='Plum moist iris-sclera surface264'+str(i);changed.append(i)
j['extensionsUsed']=sorted(set(j.get('extensionsUsed',[])+['KHR_materials_ior']));js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(b))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(b),0x004e4942)+b;dst=O/'components/eyes_optical264.glb';dst.write_bytes(raw);jj,bb,_=read_glb(dst);assert bb==b;r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'changed_materials':changed,'roughness':.13,'ior':1.376,'all_BIN_bytes_geometry_UV_normal_texture_exact':True,'scope':'Single dielectric moist surface study. No fake baked highlight, transparent extra shell, transmission or anatomical optical accuracy claimed. Actual matched light/profile views required.'};(O/'checks/eye_optical264.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
