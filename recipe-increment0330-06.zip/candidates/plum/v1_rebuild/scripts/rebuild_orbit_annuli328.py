"""Replace complete orbital sheets by constrained height-field annuli.
The actual128-node eye apertures stay exact. Healthy outer edges are densified to
0.5mm and conformingly split in each retained source triangle's physical plane.
No old orbital faces remain behind the new patches. New patch UVs occupy explicit
untextured study tiles; final unique skin-atlas painting is a separate gate.
"""
from pathlib import Path
import sys,json,hashlib,struct,collections,numpy as np
from scipy.spatial import cKDTree
from scipy.interpolate import RBFInterpolator
O=Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(R/'shared_tools/triangle_lib'));import triangle
from glb_io import read_glb,node_matrix
src=O/'components/head_clipped296.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];assert np.array_equal(node_matrix(j['nodes'][0]),np.eye(4));attrs={k:a(ai).astype(float)for k,ai in pr['attributes'].items()};assert set(attrs)=={'POSITION','NORMAL','TEXCOORD_0','COLOR_0'};z=np.load(O/'checks/orbit_annuli326.npz');P=z['source_positions'];F=z['source_faces'];U=z['unique_positions'];iv=z['source_to_unique'];domains=[]
for side in ['positive','negative']:domains.append({'side':side,'faces':z[side+'_selected_source_faces'],'outer':z[side+'_outer_unique_ids'],'inner':z[side+'_aperture_unique_ids'],'C':z[side+'_center'],'frame':z[side+'_frame']})
z.close();assert np.array_equal(F,a(pr['indices']).reshape(-1,3));remove=set(int(x)for d in domains for x in d['faces']);UF=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
sourceN=attrs['NORMAL'][:,[0,2,1]]*[1,-1,1];lists={k:v.tolist()for k,v in attrs.items()};knots={};geom={};cache={};patches=[];reports=[]
for d in domains:
 for aa,bb in zip(d['outer'],np.roll(d['outer'],-1)):
  key=tuple(sorted((int(aa),int(bb))));assert key not in knots;length=np.linalg.norm(U[aa]-U[bb]);knots[key]=int(np.ceil(length/.0005))

def knot(aa,bb,k,n):
 # k/n is always in the canonical physical-edge direction.
 key=tuple(sorted((int(iv[aa]),int(iv[bb]))));gkey=(key,k,n)
 if gkey not in geom:geom[gkey]=(U[key[0]]+(k/n)*(U[key[1]]-U[key[0]])).astype('<f4').astype(float)
 tag=(min(int(aa),int(bb)),max(int(aa),int(bb)),k,n)
 if tag in cache:return cache[tag]
 t=k/n if iv[aa]==key[0]else 1-k/n;row={s:(1-t)*v[aa]+t*v[bb]for s,v in attrs.items()};row['POSITION']=geom[gkey][[0,2,1]]*[1,1,-1];row['NORMAL']/=np.linalg.norm(row['NORMAL']);idx=len(lists['POSITION'])
 for s,v in row.items():lists[s].append(v.tolist())
 cache[tag]=idx;return idx

def directed_edge_vertices(aa,bb):
 key=tuple(sorted((int(iv[aa]),int(iv[bb]))));n=knots.get(key,1);seq=[int(aa)]
 for step in range(1,n):
  k=step if iv[aa]==key[0]else n-step;seq.append(knot(int(aa),int(bb),k,n))
 return seq

def inside(P,poly):
 out=np.zeros(len(P),bool)
 for aa,bb in zip(poly,np.roll(poly,-1,axis=0)):
  y=P[:,1];x=P[:,0];hit=(aa[1]>y)!=(bb[1]>y);xx=aa[0]+(y-aa[1])*(bb[0]-aa[0])/(bb[1]-aa[1]+1e-300);out^=hit&(x<xx)
 return out
# Retessellate only source triangles whose outer edges received extra knots.
retained=[];retained_parent=[];retess_count=0
for fi,f in enumerate(F):
 if fi in remove:continue
 perimeter=[]
 for aa,bb in zip(f,np.roll(f,-1)):perimeter.extend(directed_edge_vertices(aa,bb))
 if len(perimeter)==3:retained.append(f.tolist());retained_parent.append(fi);continue
 W=np.array(lists['POSITION'])[perimeter][:,[0,2,1]]*[1,-1,1];origin=P[f[0]];ex=P[f[1]]-origin;ex/=np.linalg.norm(ex);gn=np.cross(P[f[1]]-origin,P[f[2]]-origin);gn/=np.linalg.norm(gn);ey=np.cross(gn,ex);local=(W-origin)@np.array([ex,ey]).T;segments=np.c_[np.arange(len(local)),np.roll(np.arange(len(local)),-1)];tt=triangle.triangulate({'vertices':local,'segments':segments},'pYY');dist,ix=cKDTree(tt['vertices']).query(local);assert len(tt['vertices'])==len(local)and dist.max()==0 and len(set(ix))==len(local);back=np.empty(len(ix),int);back[ix]=np.arange(len(ix));assert {tuple(sorted(e))for e in back[tt['segments']]}=={tuple(sorted(e))for e in segments};tri=back[tt['triangles']];pp=np.array(perimeter)[tri];G=np.cross(W[tri[:,1]]-W[tri[:,0]],W[tri[:,2]]-W[tri[:,0]])
 if np.all(G@gn<0):pp=pp[:,::-1];G=-G
 assert np.all(G@gn>0);assert np.max(abs((W-origin)@gn))<8e-8;retained.extend(pp.tolist());retained_parent.extend([fi]*len(pp));retess_count+=1
# Whole-patch reconstruction, with exact boundary rows and dense real outside samples.
for di,d in enumerate(domains):
 C=d['C'];X,Y,D=d['frame'];frame=np.array([X,Y,D]);outer_ids=[];outside_samples=[];outside_front=[]
 for ua,ub in zip(d['outer'],np.roll(d['outer'],-1)):
  key=tuple(sorted((int(ua),int(ub))));outside=[fi for fi in edge[key]if fi not in remove];assert len(outside)==1;fi=outside[0];ff=F[fi];aa=int(ff[np.flatnonzero(iv[ff]==ua)[0]]);bb=int(ff[np.flatnonzero(iv[ff]==ub)[0]]);third=int(next(k for k in ff if iv[k]not in key));seq=directed_edge_vertices(aa,bb);outer_ids.extend(seq);g=np.cross(P[ff[1]]-P[ff[0]],P[ff[2]]-P[ff[0]]);g/=np.linalg.norm(g);outside_front.append(float(g@D));assert g@D>.02,'Outer retained sheet is not front-facing'
  for attr_id in seq:
   point=np.array(lists['POSITION'][attr_id])[[0,2,1]]*[1,-1,1];outside_samples.extend([.75*point+.25*P[third],.5*point+.5*P[third]])
 B=np.array(lists['POSITION'])[outer_ids][:,[0,2,1]]*[1,-1,1];BN=np.array(lists['NORMAL'])[outer_ids][:,[0,2,1]]*[1,-1,1];BC=np.array(lists['COLOR_0'])[outer_ids];inner=d['inner'];IB=U[inner];nb=len(B);ni=len(IB);outerXY=(B-C)@frame[:2].T;innerXY=(IB-C)@frame[:2].T;outside=np.array(outside_samples);outLocal=(outside-C)@frame.T;keep=~inside(outLocal[:,:2],outerXY);outside=outside[keep];outLocal=outLocal[keep];controls=np.vstack([B,IB,outside]);L=(controls-C)@frame.T;unique,inv=np.unique(L[:,:2],axis=0,return_inverse=True);dep=np.zeros(len(unique));counts=np.zeros(len(unique));spread=np.zeros(len(unique))
 for k in range(len(unique)):
  zz=L[inv==k,2];spread[k]=np.ptp(zz);dep[k]=zz.mean();counts[k]=len(zz)
 assert spread.max()<1e-8,'Multiple depth sheets entered the TPS controls';rbf=RBFInterpolator(unique/.04,dep,kernel='thin_plate_spline',degree=1,smoothing=0.);constraint_error=float(abs(rbf(L[:nb+ni,:2]/.04)-L[:nb+ni,2]).max());assert constraint_error<2e-8
 pts=np.vstack([outerXY,innerXY]);segments=np.vstack([np.c_[np.arange(nb),np.roll(np.arange(nb),-1)],np.c_[nb+np.arange(ni),nb+np.roll(np.arange(ni),-1)]]);hole=innerXY.mean(0);assert inside(hole[None],innerXY)[0];out=triangle.triangulate({'vertices':pts/.04,'segments':segments,'holes':[hole/.04]},'pYYq25a0.00025');uv=out['vertices']*.04;PF=out['triangles'].astype(np.int64);dist,lookup=cKDTree(uv).query(pts);assert dist.max()<1e-14 and len(set(lookup))==len(pts),'Boundary input/output mapping failed';mapping={int(k):i for i,k in enumerate(lookup)};actual=set()
 for aa,bb in out['segments']:
  assert int(aa)in mapping and int(bb)in mapping,'Triangle split a constrained boundary'
  actual.add(tuple(sorted((mapping[int(aa)],mapping[int(bb)]))))
 assert actual=={tuple(sorted(e))for e in segments};assert not inside(uv[PF].mean(1),innerXY).any(),'Patch filled the physical aperture'
 depth=rbf(uv/.04);PW=C+uv[:,0,None]*X+uv[:,1,None]*Y+depth[:,None]*D;PW[lookup[:nb]]=B;PW[lookup[nb:]]=IB;PW=PW.astype('<f4').astype(float);G=np.cross(PW[PF[:,1]]-PW[PF[:,0]],PW[PF[:,2]]-PW[PF[:,0]])
 if np.all(G@D<0):PF=PF[:,::-1];G=-G
 assert np.min(G@D)>1e-16,'Projected patch Jacobian failed';assert np.linalg.norm(G,axis=1).min()>1e-16;step=2e-5;gx=(rbf((uv+[step,0])/.04)-rbf((uv-[step,0])/.04))/(2*step);gy=(rbf((uv+[0,step])/.04)-rbf((uv-[0,step])/.04))/(2*step);PN=D-gx[:,None]*X-gy[:,None]*Y;PN/=np.linalg.norm(PN,axis=1)[:,None];PN[lookup[:nb]]=BN
 # Preserve existing provisional pigment through local nearest-point interpolation.
 old_ids=np.unique(F[d['faces']]);old_xy=(P[old_ids]-C)@frame[:2].T;dd,near=cKDTree(old_xy).query(uv,k=3);ww=1/np.maximum(dd,1e-8)**2;ww/=ww.sum(1)[:,None];PC=np.sum(attrs['COLOR_0'][old_ids[near]]*ww[:,:,None],axis=1);PC[lookup[:nb]]=BC;PUV=(uv-uv.min(0))/np.ptp(uv,axis=0);PUV[:,0]+=2+di;patches.append({'name':d['side'],'P':PW,'N':PN,'F':PF,'UV':PUV,'COLOR':PC,'outer_indices':lookup[:nb],'inner_indices':lookup[nb:]});reports.append({'side':d['side'],'removed_faces':len(d['faces']),'new_patch_faces':len(PF),'dense_outer_nodes':nb,'aperture_nodes':ni,'TPS_controls':len(unique),'outer_min_retained_geometric_dot_front':min(outside_front),'exact_boundary_constraint_error_m':constraint_error,'one_to_one_boundary_mapping':True,'depth_range_m':[float(depth.min()),float(depth.max())],'minimum_projected_double_area_m2':float((G@D).min()),'minimum_triangle_area_m2':float(np.linalg.norm(G,axis=1).min()/2),'outer_P_N_color_held':True,'aperture_P_held':True,'temporary_UV_tile':[2+di,3+di]});print('PATCH328',reports[-1],flush=True)
# Append retained and replacement primitives, keeping every old BIN byte intact.
payload=bytearray(b)
def append(A,typ,ct=5126,target=34962):
 A=np.ascontiguousarray(A);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':A.nbytes,'target':target});payload.extend(A.tobytes());ai=len(j['accessors']);rr={'bufferView':vi,'componentType':ct,'count':len(A),'type':typ}
 if typ=='VEC3':rr.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 j['accessors'].append(rr);return ai
newattrs={k:append(np.array(v,dtype='<f4'),'VEC'+str(len(v[0])))for k,v in lists.items()};rp=dict(pr);rp['attributes']=newattrs;rp['indices']=append(np.array(retained,dtype='<u4').ravel(),'SCALAR',5125,34963);prims=[rp];npz={'retained_source_face':np.array(retained_parent)}
for d in patches:
 at={'POSITION':append((d['P'][:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3'),'NORMAL':append((d['N'][:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3'),'TEXCOORD_0':append(d['UV'].astype('<f4'),'VEC2'),'COLOR_0':append(d['COLOR'].astype('<f4'),'VEC4')};prims.append({'attributes':at,'indices':append(d['F'].astype('<u4').ravel(),'SCALAR',5125,34963),'material':pr.get('material',0)});npz[d['name']+'_outer_indices']=d['outer_indices'];npz[d['name']+'_inner_indices']=d['inner_indices']
j['meshes'][0]['primitives']=prims;j['nodes'][0]['name']='Plum | coherent head with full orbital annuli328';j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/head_orbits328.glb';dst.write_bytes(raw);np.savez_compressed(O/'checks/orbit_annuli328_lineage.npz',**npz);report={'source296_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'removed_old_orbital_faces':len(remove),'retained_source_faces_retessellated':retess_count,'new_shared_geometric_edge_knots':len(geom),'all_old_positions_outside_removed_domains_held':True,'new_triangles':len(retained)+sum(len(d['F'])for d in patches),'eyes':reports,'scope':'Complete replacement of the old orbital sheets, not an added overlapping layer. Exact aperture and conforming healthy outer boundary constraints are retained. New patch geometry, inner-rim thickness/shape, all interface incidences/normals, UV atlas, contact and actual appearance remain unapproved until audit/render.'};(O/'checks/orbit_annuli328.json').write_text(json.dumps(report,indent=2));print('ANNULI328',report,flush=True)
