"""Lossless static GLB buffer compaction; no mesh/material/texture data changes.
Only unreferenced historic accessors/views/BIN ranges are omitted. Retained raw
accessor values, every embedded image and scene transform are verified exactly.
"""
from pathlib import Path
import argparse,json,hashlib,struct,copy,numpy as np
from glb_io import read_glb
pa=argparse.ArgumentParser();pa.add_argument('source');pa.add_argument('output');args=pa.parse_args();src=Path(args.source);dst=Path(args.output);j,b,a=read_glb(src);assert not j.get('skins')and not j.get('animations')and not j.get('cameras');used=set()
for mesh in j['meshes']:
 for p in mesh['primitives']:
  assert not p.get('extensions')and not p.get('targets');used.update(p['attributes'].values())
  if'indices'in p:used.add(p['indices'])
used=sorted(used);amap={old:i for i,old in enumerate(used)};views=set()
for old in used:
 ac=j['accessors'][old];assert not ac.get('sparse');views.add(ac['bufferView'])
for im in j.get('images',[]):assert'bufferView'in im;views.add(im['bufferView'])
views=sorted(views);vmap={old:i for i,old in enumerate(views)};out=copy.deepcopy(j);payload=bytearray();outviews=[]
for old in views:
 v=copy.deepcopy(j['bufferViews'][old]);assert v.get('buffer',0)==0;start=v.get('byteOffset',0);piece=b[start:start+v['byteLength']];assert len(piece)==v['byteLength'];payload.extend(b'\0'*((-len(payload))%4));v['byteOffset']=len(payload);v['buffer']=0;payload.extend(piece);outviews.append(v)
out['bufferViews']=outviews;out['accessors']=[copy.deepcopy(j['accessors'][old])for old in used]
for ac in out['accessors']:ac['bufferView']=vmap[ac['bufferView']]
for im in out.get('images',[]):im['bufferView']=vmap[im['bufferView']]
for mesh in out['meshes']:
 for p in mesh['primitives']:
  p['attributes']={k:amap[v]for k,v in p['attributes'].items()}
  if'indices'in p:p['indices']=amap[p['indices']]
out['buffers']=[{'byteLength':len(payload)}];js=json.dumps(out,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst.write_bytes(raw);jj,bb,aa=read_glb(dst)
for old,new in amap.items():assert np.array_equal(a(old,decode_normalized=False),aa(new,decode_normalized=False)),('Changed accessor',old,new)
for oldim,newim in zip(j.get('images',[]),jj.get('images',[])):
 v=j['bufferViews'][oldim['bufferView']];nv=jj['bufferViews'][newim['bufferView']];assert b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]==bb[nv.get('byteOffset',0):nv.get('byteOffset',0)+nv['byteLength']]
for key in ['nodes','scenes','materials','textures','samplers','extensionsUsed','extensionsRequired']:assert j.get(key)==jj.get(key),key
r={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(dst),'output_sha256':hashlib.sha256(raw).hexdigest(),'source_bytes':src.stat().st_size,'output_bytes':len(raw),'kept_accessors':len(used),'removed_unused_accessors':len(j['accessors'])-len(used),'kept_buffer_views':len(views),'removed_unused_views':len(j['bufferViews'])-len(views),'all_raw_accessor_values_exact':True,'all_image_payloads_exact':True,'all_nodes_scenes_materials_textures_samplers_exact':True,'triangles':sum(jj['accessors'][p['indices']]['count']//3 for m in jj['meshes']for p in m['primitives']),'scope':'Lossless static buffer compaction only. It does not clear shape/material issues or substitute for reimport/actual views.'};dst.with_suffix('.compact.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
