"""Promote only the already-inspected126 loft into a separately shaded component.
Geometry and normals remain exact; both current body298/head296 endpoints must
match the existing loft before assembly. Material is provisional native skin.
"""
from pathlib import Path
import json,hashlib,struct,numpy as np
from scipy.spatial import cKDTree
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];z=np.load(O/'checks/neck_loft126.npz');P=z['positions'];N=z['normals'];F=z['triangles'];z.close();report=json.loads((O/'checks/neck_loft126.json').read_text());matches=[]
for i,name in enumerate(['source_body298.glb','head_clipped296.glb']):
 j,b,a=read_glb(O/'components'/name);node=j['nodes'][0];M=node_matrix(node);pr=j['meshes'][node['mesh']]['primitives'][0];Q=a(pr['attributes']['POSITION']).astype(float);Q=(Q@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];ring=(P[:report['endpoints'][0]['count']]if i==0 else P[-report['endpoints'][1]['count']:]).astype('<f4').astype(float);dist,ix=cKDTree(Q).query(ring);assert dist.max()<8e-8;matches.append({'component':name,'sha256':hashlib.sha256((O/'components'/name).read_bytes()).hexdigest(),'endpoint_count':len(ring),'maximum_distance_m':float(dist.max())})
binary=bytearray();views=[];acs=[]
def acc(A,typ,ct=5126,target=34962):
 A=np.ascontiguousarray(A);binary.extend(b'\0'*((-len(binary))%4));vi=len(views);views.append({'buffer':0,'byteOffset':len(binary),'byteLength':A.nbytes,'target':target});binary.extend(A.tobytes());ai=len(acs);r={'bufferView':vi,'componentType':ct,'count':len(A),'type':typ}
 if typ=='VEC3':r.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 acs.append(r);return ai
at={'POSITION':acc((P[:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3'),'NORMAL':acc((N[:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3')};ix=acc(F.astype('<u4').ravel(),'SCALAR',5125,34963);j={'asset':{'version':'2.0','generator':'Plum held neck interface299'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'Plum | continuous fitted neck interface299','mesh':0}],'meshes':[{'primitives':[{'attributes':at,'indices':ix,'material':0}]}],'materials':[{'name':'Plum provisional native skin299','doubleSided':False,'pbrMetallicRoughness':{'baseColorFactor':[.78,.53,.34,1],'roughnessFactor':.6,'metallicFactor':0}}],'bufferViews':views,'accessors':acs,'buffers':[{'byteLength':len(binary)}]};js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary;dst=O/'components/neck_loft299.glb';dst.write_bytes(raw);r={'output_sha256':hashlib.sha256(raw).hexdigest(),'geometry_source_npz_sha256':hashlib.sha256((O/'checks/neck_loft126.npz').read_bytes()).hexdigest(),'geometry_and_normals_held_to126':True,'triangles':len(F),'endpoints':matches,'scope':'Exact existing neck bridge now in an explicit provisional skin material. No new shape repair; semantic skin/shirt boundary, whole merge and final paint remain open.'};(O/'checks/neck_loft299.json').write_text(json.dumps(r,indent=2));print('NECK299',r,flush=True)
