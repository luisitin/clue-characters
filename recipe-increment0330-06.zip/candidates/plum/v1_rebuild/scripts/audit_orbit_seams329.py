"""Read-only exact exported annulus edges, tangents and retained geometry checks."""
from pathlib import Path
import numpy as np,json,hashlib,collections
from scipy.spatial import cKDTree
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/head_orbits328.glb';j,b,a=read_glb(src);z=np.load(O/'checks/orbit_annuli328_lineage.npz');Ps=[];Ns=[];Fs=[];offset=0;gid=[];ranges=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 P=a(p['attributes']['POSITION']).astype(float);N=a(p['attributes']['NORMAL']).astype(float);F=a(p['indices']).reshape(-1,3).astype(int)
 for k,ai in p['attributes'].items():assert len(a(ai))==len(P)
 assert F.min()>=0 and F.max()<len(P);assert np.isfinite(P).all() and np.isfinite(N).all();ranges.append([offset,offset+len(P)]);Ps.append(P);Ns.append(N);Fs.append(F+offset);gid.extend([pi]*len(F));offset+=len(P)
P=np.vstack(Ps);N=np.vstack(Ns);F=np.vstack(Fs);gid=np.array(gid);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];G=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);area=np.linalg.norm(G,axis=1);assert area.min()>0;GN=G/area[:,None];edges=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for li,(aa,bb)in enumerate(zip(f,np.roll(f,-1))):edges[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb),li))
rows=[]
# Eye contacts are checked against all exact serialized eye edges in world coordinates.
ej,eb,ea=read_glb(O/'components/eyes_optical264.glb');EP=[];EF=[];eo=0
for nd in ej['nodes']:
 if 'mesh' not in nd:continue
 M=node_matrix(nd)
 for pr in ej['meshes'][nd['mesh']]['primitives']:
  p=ea(pr['attributes']['POSITION']).astype(float)@M[:3,:3].T+M[:3,3];f=ea(pr['indices']).reshape(-1,3);EP.append(p);EF.append(f+eo);eo+=len(p)
EP=np.vstack(EP);EF=np.vstack(EF);EU,eiv=np.unique(EP,axis=0,return_inverse=True);EE=set(tuple(sorted((int(aa),int(bb))))for f in eiv[EF]for aa,bb in zip(f,np.roll(f,-1)));tree=cKDTree(EU)
for pi,side in enumerate(['positive','negative'],1):
 outids=z[side+'_outer_indices']+ranges[pi][0];inids=z[side+'_inner_indices']+ranges[pi][0];expected=set();angles=[];normaldiff=[]
 for aa,bb in zip(outids,np.roll(outids,-1)):
  key=tuple(sorted((int(iv[aa]),int(iv[bb]))));expected.add(key);er=edges[key];assert len(er)==2 and set(gid[r[0]]for r in er)=={0,pi},('Bad outer incidence',side,key,er);assert er[0][1]==er[1][2] and er[0][2]==er[1][1],('Outer parity',side,key);angles.append(float(np.degrees(np.arccos(np.clip(GN[er[0][0]]@GN[er[1][0]],-1,1)))))
  for vv in key:
   vn=[N[F[r[0]][np.flatnonzero(UF[r[0]]==vv)[0]]]for r in er];normaldiff.append(float(np.degrees(np.arccos(np.clip(vn[0]@vn[1]/np.linalg.norm(vn[0])/np.linalg.norm(vn[1]),-1,1)))))
 actual={key for key,er in edges.items()if len(er)==2 and set(gid[r[0]]for r in er)=={0,pi}};assert actual==expected,('Unexpected outer edge',side,len(actual),len(expected))
 for aa,bb in zip(inids,np.roll(inids,-1)):
  er=edges[tuple(sorted((int(iv[aa]),int(iv[bb]))))];assert len(er)==1 and gid[er[0][0]]==pi
 d,ix=tree.query(P[inids]);assert d.max()<5e-8;eyeedges=[tuple(sorted((int(aa),int(bb))))for aa,bb in zip(ix,np.roll(ix,-1))];assert all(k in EE for k in eyeedges),('Eye edge mismatch',side)
 internal=[]
 for key,er in edges.items():
  if len(er)==2 and all(gid[r[0]]==pi for r in er):internal.append(float(np.degrees(np.arccos(np.clip(GN[er[0][0]]@GN[er[1][0]],-1,1)))))
 rows.append({'side':side,'outer_edges':len(expected),'outer_exact_complete_opposite_parity':True,'outer_geometric_angle_deg_max':max(angles),'outer_geometric_angle_deg_p95':float(np.percentile(angles,95)),'outer_shader_normal_angle_deg_max':max(normaldiff),'inner_boundary_edges':len(inids),'inner_eye_edge_set_complete':True,'inner_eye_max_position_distance_m':float(d.max()),'internal_angle_deg_max':max(internal),'internal_folds_over_105':int(np.sum(np.array(internal)>105))})
# Distinct full-position triangle coincidence test catches split-index and opposite copies.
_,copies=np.unique(np.sort(UF,axis=1),axis=0,return_counts=True);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'triangles':len(F),'minimum_triangle_area_m2':float(area.min()/2),'exact_position_triangle_copy_groups':int(np.sum(copies>1)),'eyes':rows,'attribute_indices_valid':True,'scope':'Serialized seam topology, physical eye edge match and tangent diagnostics. No intersection or appearance pass is implied.'};(O/'checks/orbit_seams329.json').write_text(json.dumps(report,indent=2));print('ORBIT_SEAMS329',report,flush=True)
