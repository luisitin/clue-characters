"""Plane-preserving, posterior-extended radial lower-neck study with a C2 axial fade.
The inspected source neck contour is matched by a smooth24-mode radial ratio;
the anterior face/index-contact region stays exact; posterior fade extends to110mm. No compressed short-loft fit.
"""
from pathlib import Path
import json,struct,hashlib,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];C=np.array([-.03,.08,.635]);NN=np.array([0.,-.45,1.]);NN/=np.linalg.norm(NN);U=np.array([1.,0.,0.]);V=np.cross(NN,U);AX=np.array([U,V,NN]);label='neck_t0.45_+0.635'
def ring(version,count):
 report=json.loads((O/f'checks/join_sections{version}.json').read_text());row=next(s for s in report['sections']if s['label']==label);entry=next(s for s in row['components']if s['nodes']==count and s['closed_simple_graph']);d=np.load(O/f'checks/join_sections{version}.npz');P=d[label+'_points'][entry['ordered_node_ids']];d.close();xy=(P-C)@AX[:2].T;cross=xy[:,0]*np.roll(xy[:,1],-1)-np.roll(xy[:,0],-1)*xy[:,1];area=cross.sum()/2;cent=np.sum((xy+np.roll(xy,-1,axis=0))*cross[:,None],axis=0)/(6*area)
 if area<0:P=P[::-1];xy=xy[::-1]
 angle=np.mod(np.arctan2(xy[:,1]-cent[1],xy[:,0]-cent[0]),2*np.pi);i=int(angle.argmin());xy=np.roll(xy,-i,axis=0);angle=np.roll(angle,-i);assert np.all(np.diff(angle)>0);return xy,cent,angle
S,cs,st=ring('078',129);D,cd,dt=ring('080',356);q=np.linspace(0,2*np.pi,256,endpoint=False)
def cyclic(P,t):
 xp=np.r_[t[-1]-2*np.pi,t,t[0]+2*np.pi];yp=np.vstack([P[-1],P,P[0]]);return np.column_stack([np.interp(q,xp,yp[:,k])for k in range(2)])
def polar(P,c,theta,target):
 X=P-c;ix=(np.searchsorted(theta,target,side='right')-1)%len(P);aa=X[ix];bb=X[(ix+1)%len(P)];direction=np.c_[np.cos(target),np.sin(target)];edge=bb-aa;den=direction[:,0]*edge[:,1]-direction[:,1]*edge[:,0];num=aa[:,0]*bb[:,1]-aa[:,1]*bb[:,0];radius=num/den;assert np.all(radius>0);point=radius[:,None]*direction;t=np.sum((point-aa)*edge,axis=1)/np.sum(edge*edge,axis=1);assert t.min()>-1e-9 and t.max()<1+1e-9;return point

sampleD=polar(D,cd,dt,q);sampleS=polar(S,cs,st,q);t=cs-cd;modes=24
angles=np.mod(np.arctan2(sampleD[:,1],sampleD[:,0]),2*np.pi);rawratio=np.linalg.norm(sampleS,axis=1)/np.linalg.norm(sampleD,axis=1)
def phi(theta):
 return np.column_stack([np.ones(len(theta))]+[f(k*theta)for k in range(1,modes+1)for f in (np.cos,np.sin)])
coeff=np.linalg.lstsq(phi(angles),rawratio,rcond=None)[0]
def ratio_field(theta):
 rr=phi(theta)@coeff;dd=np.zeros(len(theta))
 for k in range(1,modes+1):dd+=k*(-coeff[2*k-1]*np.sin(k*theta)+coeff[2*k]*np.cos(k*theta))
 return rr,dd
probe,_=ratio_field(np.linspace(0,2*np.pi,8192,endpoint=False));assert probe.min()>.5 and probe.max()<1.6
fitted,_=ratio_field(angles);residual=sampleD*fitted[:,None]-sampleS;assert np.linalg.norm(residual,axis=1).max()<.0015,'Base contour fit is too loose for the short join'
dets=[float(min(1.,probe.min())**2)];weights=[0.,1.]
src=O/'components/head_cornea255.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=a(pr['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];L=(P-C)@AX.T
def smooth01(t):
 t=np.clip(t,0,1);return t*t*t*(t*(t*6-15)+10)
def derivative01(t):
 t=np.clip(t,0,1);return 30*t*t*(t-1)**2

def field(local):
 radial=local[:,:2]-cd;radius2=np.sum(radial**2,axis=1);assert radius2.min()>1e-16;radius=np.sqrt(radius2);theta=np.arctan2(radial[:,1],radial[:,0]);sine=radial[:,1]/radius
 post=smooth01((sine-.1)/.8);radgate=smooth01((radius-.018)/.025)
 grad_sine=np.c_[-radial[:,0]*radial[:,1],radial[:,0]**2]/radius[:,None]**3
 grad_post=derivative01((sine-.1)/.8)[:,None]*grad_sine/.8
 grad_rad=derivative01((radius-.018)/.025)[:,None]*radial/radius[:,None]/.025
 extent=.050+.060*post*radgate;grad_extent=.060*(grad_post*radgate[:,None]+post[:,None]*grad_rad)
 fraction=np.clip(local[:,2]/extent,0,1);sd=derivative01(fraction);w=1-smooth01(fraction);dw=-sd/extent;grad_w=sd[:,None]*(local[:,2]/extent**2)[:,None]*grad_extent
 ratio,ratio_derivative=ratio_field(theta);grad_ratio=ratio_derivative[:,None]*np.c_[-radial[:,1],radial[:,0]]/radius2[:,None]
 delta_xy=radial*(ratio-1)[:,None]+t;result=local.copy();result[:,:2]+=w[:,None]*delta_xy;scale=1+w*(ratio-1)
 jac=np.zeros((len(local),3,3));jac[:,:2,:2]=scale[:,None,None]*np.eye(2)[None]+w[:,None,None]*radial[:,:,None]*grad_ratio[:,None,:]+delta_xy[:,:,None]*grad_w[:,None,:];jac[:,:2,2]=dw[:,None]*delta_xy;jac[:,2,2]=1
 held=local[:,2]>=extent;result[held]=local[held];jac[held]=np.eye(3)
 return result,jac,held
Q,J,fixed=field(L);newP=C+Q@AX;newP[fixed]=P[fixed];vertex_det=np.linalg.det(J);assert vertex_det.min()>.15,'Posterior transition Jacobian failed at a native vertex'
oldNL=N@AX.T;newNL=np.linalg.solve(J.transpose(0,2,1),oldNL[:,:,None])[:,:,0];newN=newNL@AX;newN/=np.linalg.norm(newN,axis=1)[:,None];newN[fixed]=N[fixed];assert np.array_equal(newP[fixed],P[fixed]);assert np.max(abs((newP-P)@NN))<1e-14
anchor=np.array([-.0745500773,-.0425513275,.6390333772]);anchorq=float((anchor-C)@NN);assert anchorq>.050;F=a(pr['indices']).reshape(-1,3).astype(np.int64);nearest=int(np.argmin(np.linalg.norm(P-anchor,axis=1)));contact_fan=np.unique(F[(F==nearest).any(1)]);assert fixed[contact_fan].all() and np.array_equal(newP[contact_fan],P[contact_fan]),'Held index-contact fan moved'
active=np.flatnonzero((L[F,2]<.110).any(1));sample_min=float(vertex_det.min());samples=0
for weights in ([1/3,1/3,1/3],[.5,.5,0],[.5,0,.5],[0,.5,.5]):
 for start in range(0,len(active),2048):
  ids=active[start:start+2048];points=np.einsum('k,ikj->ij',np.array(weights),L[F[ids]]);_,jac,_=field(points);sample_min=min(sample_min,float(np.linalg.det(jac).min()));samples+=len(points)
assert sample_min>.15,'Posterior transition Jacobian failed at an edge/centroid sample'
oldT=P[F];newT=newP[F];og=np.cross(oldT[:,1]-oldT[:,0],oldT[:,2]-oldT[:,0]);ng=np.cross(newT[:,1]-newT[:,0],newT[:,2]-newT[:,0]);dots=np.einsum('ij,ij->i',og,ng);assert np.all(dots>0);assert np.linalg.norm(ng,axis=1).min()>1e-16
payload=bytearray(b)
for semantic,values in [('POSITION',newP),('NORMAL',newN)]:
 values=(values[:,[0,2,1]]*[1,1,-1]).astype('<f4');payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':values.nbytes,'target':34962});payload.extend(values.tobytes());ai=len(j['accessors']);row={'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC3'}
 if semantic=='POSITION':row.update(min=values.min(0).tolist(),max=values.max(0).tolist())
 j['accessors'].append(row);pr['attributes'][semantic]=ai
j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/head_neck275.glb';dst.write_bytes(raw);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'plane_origin':C.tolist(),'plane_frame_U_V_N':AX.tolist(),'radial_fourier_modes':modes,'radial_ratio_coefficients':coeff.tolist(),'radial_ratio_range':[float(probe.min()),float(probe.max())],'base_center_translation_2d_m':t.tolist(),'anterior_blend_extent_m':.050,'posterior_blend_extent_m':.110,'posterior_extent_gate':'C2 posterior angular gate and18–43mm radial support; the field is constant near its axis.','base_fit_residual_max_m':float(np.linalg.norm(residual,axis=1).max()),'base_fit_residual_rms_m':float(np.sqrt(np.mean(np.sum(residual**2,axis=1)))),'minimum_vertex_edge_centroid_jacobian_determinant':sample_min,'additional_edge_centroid_samples':samples,'determinant_check':'Exact analytic Jacobian of the angular/radial fade, checked at every native vertex plus all active face centroids/edge midpoints. The posterior transition requires fresh exact surface intersections; no global analytic bijection is claimed.','index_contact_axial_coordinate_m':anchorq,'index_contact_region_and_face_held_exact':True,'changed_vertices':int((np.linalg.norm(newP-P,axis=1)>1e-10).sum()),'maximum_displacement_m_including_discarded_native_shoulders':float(np.linalg.norm(newP-P,axis=1).max()),'maximum_retained_neck_displacement_m':float(np.linalg.norm(newP-P,axis=1)[L[:,2]>=.006].max()),'all_source_planes_preserved':True,'all_face_orientation_dots_positive':True,'UVs_indices_and_original_BIN_unchanged':True,'normal_transform':'Exact inverse-transpose analytic deformation Jacobian in the orthonormal source-neck frame.','scope':'Analytic124 neck field composed onto current255 head. Exact old lower-boundary agreement, held shared eye aperture, new surface audit and joined appearance must still be proved; no implicit promotion.'};(O/'checks/lower_neck275.json').write_text(json.dumps(report,indent=2));print('NECK275',report,flush=True)
