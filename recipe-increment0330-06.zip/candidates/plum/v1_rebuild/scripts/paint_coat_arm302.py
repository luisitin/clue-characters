"""Bounded coat-material correction after explicit old-hand/head extraction.
The thinking-side retained source arm and shoulder are jacket cloth. Their old
projected skin/teal pixels are replaced with a calibrated AI wool swatch; the new
native skin/knit components and actual neck ring are excluded geometrically.
No triangles, positions, normals or UVs are deleted or deformed.
"""
from pathlib import Path
import json,hashlib,struct,io,copy,collections,numpy as np
from PIL import Image
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/source_body298.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);LP=a(pr['attributes']['POSITION']).astype(float);P=(LP@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];F=a(pr['indices']).reshape(-1,3).astype(np.int64);UV=a(pr['attributes']['TEXCOORD_0']).astype(float);C=P[F].mean(1);eligible=(C[:,0]<-.085)&(C[:,0]>-.37)&(C[:,2]>.25)&(C[:,2]<.645)&(C[:,1]>-.25)&(C[:,1]<.26)
# Select connected exterior region(s) reached from the real cuff neighborhood.
U,iv=np.unique(P,axis=0,return_inverse=True);edges=collections.defaultdict(list)
for fi in np.flatnonzero(eligible):
 for aa,bb in zip(iv[F[fi]],np.roll(iv[F[fi]],-1)):edges[tuple(sorted((int(aa),int(bb))))].append(int(fi))
adj=collections.defaultdict(set)
for fs in edges.values():
 for fi in fs:adj[fi].update(set(fs)-{fi})
seed=np.flatnonzero(eligible&(np.linalg.norm(C-np.array([-.143,-.042,.505]),axis=1)<.065));assert len(seed)>30;left=set(np.flatnonzero(eligible));selected=set();components=[]
while left:
 start=min(left);left.remove(start);group={start};todo=[start]
 while todo:
  fi=todo.pop()
  for other in adj[fi]&left:left.remove(other);group.add(other);todo.append(other)
 hit=bool(group&set(map(int,seed)));components.append({'faces':len(group),'reaches_cuff_neighborhood':hit})
 if hit:selected.update(group)
sel=np.zeros(len(F),bool);sel[list(selected)]=True;assert 1000<sel.sum()<25000;z=np.load(O/'checks/neck_loft126.npz');neck=z['positions'][:129];z.close();assert neck[:,0].min()>-.085,'Coat domain would overlap measured neck ring'
mat=j['materials'][pr['material']];texture=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];ii=texture.get('source',texture.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));im0=j['images'][ii];bv=j['bufferViews'][im0['bufferView']];raw=b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']];im=Image.open(io.BytesIO(raw)).convert('RGB');base=np.asarray(im);h,w=base.shape[:2];uv=UV[F[sel]].mean(1)%1;xy=np.rint(uv*[w-1,h-1]).astype(int);samples=base[xy[:,1],xy[:,0]].astype(float)/255;r,g,bb=samples.T;healthy=(bb>g*1.20)&(r>g*1.10)&(r<bb*1.45)&(g>.08)&(g<.65);assert healthy.sum()>500;target=np.median(samples[healthy],axis=0)
plate=Image.open(O/'inputs/ai_materials/plum_wool300.png').convert('RGB').resize((512,512),Image.Resampling.LANCZOS);cloth=np.asarray(plate).astype(float)/255;cloth=cloth/np.median(cloth.reshape(-1,3),axis=0)*target;cloth=np.clip(cloth,0,1);out=np.empty_like(base);changed=0;maxweight=0

def smooth(x):
 x=np.clip(x,0,1);return x*x*(3-2*x)
for y in range(0,h,256):
 old=base[y:y+256].astype(float)/255;r,g,bb=old.transpose(2,0,1);bright=smooth((np.maximum.reduce([r,g,bb])-.16)/.20);warm=smooth((r-g)/.20)*smooth((g-bb)/.12)*bright;teal=smooth((g-r)/.13)*smooth((g-bb)/.075)*bright;weight=np.maximum(warm,teal);tile=cloth[np.arange(y,min(y+256,h))%512][:,np.arange(w)%512];new=old*(1-weight[:,:,None])+tile*weight[:,:,None];out[y:y+len(old)]=np.rint(np.clip(new,0,1)*255).astype(np.uint8);changed+=int((weight>.05).sum());maxweight=max(maxweight,float(weight.max()))
texture_path=O/'inputs/ai_materials/coat_arm302.png';Image.fromarray(out).save(texture_path);encoded=texture_path.read_bytes();payload=bytearray(b);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':len(encoded)});payload.extend(encoded);imageindex=len(j['images']);j['images'].append({'bufferView':vi,'mimeType':'image/png','name':'Plum bounded coat-arm paint302'});ti=len(j['textures']);nt={'source':imageindex}
if 'sampler'in texture:nt['sampler']=texture['sampler']
j['textures'].append(nt);mi=len(j['materials']);nm=copy.deepcopy(mat);nm['name']='Plum coat arm302 | projected skin and old cuff paint removed';nm['pbrMetallicRoughness']['baseColorTexture']['index']=ti;j['materials'].append(nm);prims=[]
for mask,material in [(~sel,pr['material']),(sel,mi)]:
 inds=F[mask].astype('<u4').ravel();payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':inds.nbytes,'target':34963});payload.extend(inds.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':len(inds),'type':'SCALAR','min':[int(inds.min())],'max':[int(inds.max())]});part=copy.deepcopy(pr);part['indices']=ai;part['material']=material;prims.append(part)
j['meshes'][0]['primitives']=prims;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));rawglb=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_body302.glb';dst.write_bytes(rawglb);jj,bbb,aa=read_glb(dst);assert bbb[:len(b)]==b;np.savez_compressed(O/'checks/coat_arm302_lineage.npz',primitive0_source298_faces=np.flatnonzero(~sel),primitive1_source298_faces=np.flatnonzero(sel));report={'source298_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(rawglb).hexdigest(),'generated_wool300_sha256':hashlib.sha256((O/'inputs/ai_materials/plum_wool300.png').read_bytes()).hexdigest(),'new_base_image_sha256':hashlib.sha256(encoded).hexdigest(),'garment_domain':'Connected thinking-side coat arm/shoulder region reached from cuff neighborhood; x in[-.37,-.085],z in[.25,.645],y in[-.25,.26]. Actual129-node neck ring has minimumx−.078652 and is geometrically excluded. New native hand, cuff and knit are separate components.','selected_coat_faces':int(sel.sum()),'source_component_inventory':components,'healthy_coat_sample_count':int(healthy.sum()),'calibrated_target_sRGB':target.tolist(),'texture_global_pixels_with_weight_over0_05':changed,'texture_only_used_on_owned_coat_faces':True,'all_original_BIN_geometry_normals_UVs_material_inputs_held':True,'total_triangles_unchanged':len(F),'scope':'Bounded semantic arm paint correction; no geometry edit or removal. Warm/teal source projection is replaced only through a new material on the owned jacket region. Actual all-angle regression and final cloth/skin appearance remain required.'};(O/'checks/coat_arm302.json').write_text(json.dumps(report,indent=2));print('COAT302',report,flush=True)
