"""Close the source-shaped292 cap and transfer provisional original hair pigment.
The inner surface is supported by native scalp rays. Source pigment is sampled
only from the explicit235 hair-context triangles; no skin pixels define a cut.
Dense surface/head contact and inherited horn/root shapes remain open gates.
"""
from pathlib import Path
import json,hashlib,struct,collections,io,numpy as np,vtk
from PIL import Image
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];z=np.load(O/'checks/hair_outer292.npz');P=z['P'];F=z['F'];D=z['directions'];nr=z['native_radius'];B=z['boundary'];z.close();z=np.load(O/'checks/radial_envelope252.npz');C=z['center'];z.close();nv=len(P);inner=(C+D*(nr+.0005)[:,None]).astype('<f4').astype(float);Q=np.vstack([P,inner]);faces=[F,F[:,::-1]+nv];ed=collections.defaultdict(list)
for f in F:
 for aa,bb in zip(f,np.roll(f,-1)):ed[tuple(sorted((int(aa),int(bb))))].append((int(aa),int(bb)))
side=[]
for fs in ed.values():
 if len(fs)!=1:continue
 aa,bb=fs[0];side.extend([[bb,aa,aa+nv],[bb,aa+nv,bb+nv]])
assert len(side)==2*len(B);faces.append(np.array(side));T=np.vstack(faces);edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
assert all(len(x)==2 and x[0][1:]==x[1][1:][::-1]for x in edge.values());assert len(Q)-len(edge)+len(T)==2;volume=float(np.sum(np.einsum('ij,ij->i',Q[T[:,0]],np.cross(Q[T[:,1]],Q[T[:,2]])))/6);assert volume>0;G=np.cross(Q[T[:,1]]-Q[T[:,0]],Q[T[:,2]]-Q[T[:,0]]);assert np.linalg.norm(G,axis=1).min()>1e-16;N=np.zeros_like(Q)
for k in range(3):np.add.at(N,T[:,k],G)
N/=np.linalg.norm(N,axis=1)[:,None];assert np.isfinite(N).all()
# Closest triangle pigment transfer on source235, keeping source UV corner data.
src=O/'components/plum_strip_cleanup085.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);SP=a(pr['attributes']['POSITION']).astype(float);SP=(SP@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];SF=a(pr['indices']).reshape(-1,3).astype(np.int64);UV=a(pr['attributes']['TEXCOORD_0']).astype(float);z=np.load(O/'checks/source_hair_context235.npz');hair=z['face_ids'];z.close();HF=SF[hair];points=vtk.vtkPoints();points.SetData(numpy_to_vtk(SP,deep=True));cells=vtk.vtkCellArray();cells.SetCells(len(HF),numpy_to_vtkIdTypeArray(np.c_[np.full(len(HF),3),HF].ravel().astype(np.int64),deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);loc=vtk.vtkStaticCellLocator();loc.SetDataSet(poly);loc.BuildLocator();cp=[0.,0.,0.];ci=vtk.reference(0);si=vtk.reference(0);ds=vtk.reference(0.);nearest=np.empty(nv,int);closest=np.empty_like(P);dist=np.empty(nv)
for i,point in enumerate(P):
 loc.FindClosestPoint(point,cp,ci,si,ds);nearest[i]=int(ci);closest[i]=cp;dist[i]=np.sqrt(float(ds))
 if i%5000==0:print('PIGMENT301',i,nv,flush=True)
tri=SP[HF[nearest]];u=tri[:,1]-tri[:,0];v=tri[:,2]-tri[:,0];w=closest-tri[:,0];aa=np.sum(u*u,1);ab=np.sum(u*v,1);bb=np.sum(v*v,1);wa=np.sum(w*u,1);wb=np.sum(w*v,1);det=aa*bb-ab*ab;bu=(wa*bb-wb*ab)/det;bv=(wb*aa-wa*ab)/det;weights=np.c_[1-bu-bv,bu,bv];assert np.min(weights)>-1e-6;uv=np.einsum('ij,ijk->ik',weights,UV[HF[nearest]]);mat=j['materials'][pr['material']];tex=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tex.get('source',tex.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));im0=j['images'][ii];bv0=j['bufferViews'][im0['bufferView']];rawim=b[bv0.get('byteOffset',0):bv0.get('byteOffset',0)+bv0['byteLength']];im=np.asarray(Image.open(io.BytesIO(rawim)).convert('RGB')).astype(float)/255;xy=(uv%1)*[im.shape[1]-1,im.shape[0]-1];ij=np.floor(xy).astype(int);f=xy-ij;ix=ij[:,0];iy=ij[:,1];jx=np.minimum(ix+1,im.shape[1]-1);jy=np.minimum(iy+1,im.shape[0]-1);rgb=(im[iy,ix]*(1-f[:,0,None])+im[iy,jx]*f[:,0,None])*(1-f[:,1,None])+(im[jy,ix]*(1-f[:,0,None])+im[jy,jx]*f[:,0,None])*f[:,1,None];linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4);colors=np.c_[np.vstack([linear,linear*.65]),np.ones(len(Q))].astype('<f4')
binary=bytearray();views=[];acs=[]
def acc(A,typ,ct=5126,target=34962):
 A=np.ascontiguousarray(A);binary.extend(b'\0'*((-len(binary))%4));vi=len(views);views.append({'buffer':0,'byteOffset':len(binary),'byteLength':A.nbytes,'target':target});binary.extend(A.tobytes());ai=len(acs);r={'bufferView':vi,'componentType':ct,'count':len(A),'type':typ}
 if typ=='VEC3':r.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 acs.append(r);return ai
at={'POSITION':acc((Q[:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3'),'NORMAL':acc((N[:,[0,2,1]]*[1,1,-1]).astype('<f4'),'VEC3'),'COLOR_0':acc(colors,'VEC4')};ix=acc(T.astype('<u4').ravel(),'SCALAR',5125,34963);J={'asset':{'version':'2.0','generator':'Plum closed source-shaped hair301'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'Plum | closed source-shaped hair301, provisional pigment','mesh':0}],'meshes':[{'primitives':[{'attributes':at,'indices':ix,'material':0}]}],'materials':[{'name':'Plum provisional original copper pigment301','doubleSided':False,'pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0,'roughnessFactor':.62}}],'buffers':[{'byteLength':len(binary)}],'bufferViews':views,'accessors':acs};js=json.dumps(J,separators=(',',':')).encode();js+=b' '*((-len(js))%4);binary.extend(b'\0'*((-len(binary))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(binary),0x004e4942)+binary;dst=O/'components/hair_closed301.glb';dst.write_bytes(raw);r={'source_outer292_sha256':hashlib.sha256((O/'components/hair_outer292.glb').read_bytes()).hexdigest(),'source085_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_base_image_sha256':hashlib.sha256(rawim).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'triangles':len(T),'vertices':len(Q),'closed_two_face_edges_with_opposite_parity':True,'Euler_characteristic':2,'signed_volume_m3':volume,'outer_positions_exact_to292':True,'inner_pointwise_radial_skin_gap_m':.0005,'source_pigment_distance_m_quantiles':np.quantile(dist,[0,.5,.95,.99,1]).tolist(),'vertices_pigment_distance_over20mm':int((dist>.02).sum()),'scope':'Closed provisional source-shaped hair for coherent WIP assembly.126960tri with explicit scalp-root topology. This retains source side/rear horns and uses provisional vertex pigment; it is not a final shape/HD paint or head-contact pass. Complete exact intersections and actual views are next.'};(O/'checks/hair_closed301.json').write_text(json.dumps(r,indent=2));print('HAIR301',r,flush=True)
