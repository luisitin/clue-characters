"""Exact held-data checks for analytic neck124 composed on current head255."""
from pathlib import Path
import json,hashlib,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1]
def get(name):
 path=O/'components'/name;j,b,a=read_glb(path);p=j['meshes'][0]['primitives'][0];return j,b,a,p
j0,b0,a0,p0=get('head_cornea255.glb');j1,b1,a1,p1=get('head_neck275.glb');jn,bn,an,pn=get('head_neck124.glb');P0=a0(p0['attributes']['POSITION']);P1=a1(p1['attributes']['POSITION']);PN=an(pn['attributes']['POSITION']);N0=a0(p0['attributes']['NORMAL']);N1=a1(p1['attributes']['NORMAL']);assert j0['nodes']==j1['nodes'];assert all(np.array_equal(a0(ai),a1(p1['attributes'][s]))for s,ai in p0['attributes'].items()if s not in ['POSITION','NORMAL']);assert np.array_equal(a0(p0['indices']),a1(p1['indices']))
W=P1.astype(float)[:,[0,2,1]]*[1,-1,1];C=np.array([-.03,.08,.635]);AX=np.array([0.,-.45,1.]);AX/=np.linalg.norm(AX);q=(W-C)@AX;lower=q<.006002;assert np.array_equal(P1[lower],PN[lower]),'Existing loft lower-neck input changed'
ej,eb,ea=read_glb(O/'components/eyes_cornea255.glb');EP=[]
for n in ej['nodes']:
 if 'mesh'not in n:continue
 M=node_matrix(n)
 for p in ej['meshes'][n['mesh']]['primitives']:
  # Current eyes/head use glTF identity transforms; demand it explicitly.
  assert np.array_equal(M,np.eye(4));EP.extend(ea(p['attributes']['POSITION']).tolist())
assert all(np.array_equal(node_matrix(n),np.eye(4))for n in j0['nodes']);E=set(tuple(v)for v in EP);shared=np.array([i for i,p in enumerate(P0)if tuple(p)in E]);assert len(shared)>=256;assert np.array_equal(P0[shared],P1[shared])and np.array_equal(N0[shared],N1[shared]),'Eye seam changed'
r={'source255_sha256':hashlib.sha256((O/'components/head_cornea255.glb').read_bytes()).hexdigest(),'output275_sha256':hashlib.sha256((O/'components/head_neck275.glb').read_bytes()).hexdigest(),'existing_lower_neck124_sha256':hashlib.sha256((O/'components/head_neck124.glb').read_bytes()).hexdigest(),'lower_join_region_vertices_exact_to124':int(lower.sum()),'shared_eye_contact_vertices_P_N_exact_to255':len(shared),'all_other_attributes_indices_nodes_exact_to255':True,'scope':'Exact interface/attribute provenance only. New geometry in overlapping neck/face fades still requires actual exported local surface audit and coherent merged visual regression.'};(O/'checks/composed_head276.json').write_text(json.dumps(r,indent=2));print('COMPOSED276',r,flush=True)
