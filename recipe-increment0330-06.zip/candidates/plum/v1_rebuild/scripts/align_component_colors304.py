"""Material-only coherent WIP palette; held anatomy and all buffers stay exact."""
from pathlib import Path
import json,hashlib,struct,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];target=np.array(json.loads((O/'checks/coat_arm302.json').read_text())['calibrated_target_sRGB']);wool=np.where(target<=.04045,target/12.92,((target+.055)/1.055)**2.4).tolist();rows=[]
for name,out,kind in [('hand_wrist201.glb','hand_skin304.glb','skin'),('layered_cuff222.glb','cuff_colors304.glb','cloth')]:
 src=O/'components'/name;j,b,a=read_glb(src)
 for i,m in enumerate(j['materials']):
  p=m['pbrMetallicRoughness']
  if kind=='skin':p['baseColorFactor']=[.78,.53,.34,1];p['roughnessFactor']=.6;m['name']='Plum coherent provisional skin304 '+str(i)
  else:p['baseColorFactor']=(wool+[1])if i==0 else[.018,.095,.092,1];p['roughnessFactor']=.84;m['name']='Plum calibrated wool304'if i==0 else'Plum provisional teal knit304'
 js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(b))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(b),0x004e4942)+b;dst=O/'components'/out;dst.write_bytes(raw);jj,bb,aa=read_glb(dst);assert bb==b;rows.append({'source':name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':out,'output_sha256':hashlib.sha256(raw).hexdigest(),'all_BIN_geometry_normals_UVs_exact':True})
r={'outputs':rows,'skin_matches_head275_COLOR0_linear':[.78,.53,.34,1],'wool_calibrated_from_healthy_owned_coat_sRGB':target.tolist(),'wool_linear':wool,'scope':'Provisional material harmonization for coherent assembly. The gray wrist diagnostic band is removed; no geometry changes. Final skin/nails/knit weave and material regression remain open.'};(O/'checks/component_colors304.json').write_text(json.dumps(r,indent=2));print('COLORS304',r,flush=True)
