"""Select complete native orbital annuli for decisive surface replacement.
No mesh is edited. Each domain must have exactly the physical128-node aperture
and one healthy projected-simple outer boundary, no hidden boundary loops.
"""
from pathlib import Path
import numpy as np,json,hashlib,collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/head_clipped296.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];assert np.array_equal(node_matrix(j['nodes'][0]),np.eye(4));P=a(p['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append(fi)
assert all(len(fs)<=2 for fs in edge.values());EE=np.array(list(edge));length=np.linalg.norm(U[EE[:,0]]-U[EE[:,1]],axis=1);graph=coo_matrix((np.r_[length,length],(np.r_[EE[:,0],EE[:,1]],np.r_[EE[:,1],EE[:,0]])),shape=(len(U),len(U))).tocsr();UN=np.zeros_like(U);counts=np.zeros(len(U));np.add.at(UN,iv,N);np.add.at(counts,iv,1);UN/=counts[:,None];UN/=np.linalg.norm(UN,axis=1)[:,None]
def loops(edges):
 adj=collections.defaultdict(set)
 for aa,bb in edges:adj[aa].add(bb);adj[bb].add(aa)
 if not all(len(v)==2 for v in adj.values()):return None
 left=set(adj);out=[]
 while left:
  first=min(left);path=[first];prev=None;k=first
  while True:
   n=min(adj[k]-({prev}if prev is not None else set()))
   if n==first:break
   if n in path:return None
   path.append(n);prev,k=k,n
  left-=set(path);out.append(np.array(path,int))
 return out
def simple_ring(P):
 P=np.asarray(P,dtype=np.longdouble);n=len(P)
 def cross(A,B):return A[...,0]*B[...,1]-A[...,1]*B[...,0]
 for i in range(n):
  ids=np.arange(i+2,n)
  if i==0:ids=ids[ids!=n-1]
  if not len(ids):continue
  A=P[i];B=P[(i+1)%n];C=P[ids];D=P[(ids+1)%n];ok=np.all(np.maximum(A,B)>=np.minimum(C,D),axis=1)&np.all(np.maximum(C,D)>=np.minimum(A,B),axis=1);C=C[ok];D=D[ok]
  if not len(C):continue
  aa=cross(B-A,C-A);bb=cross(B-A,D-A);cc=cross(D-C,A-C);dd=cross(D-C,B-C)
  if np.any((aa*bb<=0)&(cc*dd<=0)):return False
 return True
def inside(P,poly):
 out=np.zeros(len(P),bool)
 for aa,bb in zip(poly,np.roll(poly,-1,axis=0)):
  y=P[:,1];x=P[:,0];hit=(aa[1]>y)!=(bb[1]>y);xhit=aa[0]+(y-aa[1])*(bb[0]-aa[0])/(bb[1]-aa[1]+1e-300);out^=hit&(x<xhit)
 return out
allloops=loops([e for e,fs in edge.items()if len(fs)==1]);assert allloops is not None;rows=[];data={};chosen=[]
for e in json.loads((O/'checks/regular_orbits033.json').read_text())['eyes']:
 X,Y,D=np.array(e['frame']);target=np.array(e['boundary_target_world']).mean(0);ring=min(allloops,key=lambda ids:np.linalg.norm(U[ids].mean(0)-target));assert len(ring)==128;C=U[ring].mean(0);XY=(U-C)@np.array([X,Y]).T;dist=dijkstra(graph,directed=False,indices=ring,min_only=True,limit=.030);candidates=[];accepted=None
 for radius in [.015,.017,.019,.021,.023]:
  ids=np.flatnonzero(np.mean(dist[UF],axis=1)<radius);SE=collections.defaultdict(list)
  for fi in ids:
   for aa,bb in zip(UF[fi],np.roll(UF[fi],-1)):SE[tuple(sorted((int(aa),int(bb))))].append(int(fi))
  boundary=[k for k,v in SE.items()if len(v)==1];loops0=loops(boundary);entry={'geodesic_radius_m':radius,'faces':len(ids),'boundary_edges':len(boundary),'boundary_loops':None if loops0 is None else[len(q)for q in loops0]};candidates.append(entry)
  if loops0 is None or len(loops0)!=2:continue
  holes=[q for q in loops0 if set(q)==set(ring)]
  if len(holes)!=1:continue
  outer=next(q for q in loops0 if set(q)!=set(ring));simple=simple_ring(XY[outer]);hole_inside=simple and inside(XY[ring],XY[outer]).all();marg=np.full(len(ring),np.inf)
  for aa,bb in zip(XY[outer],np.roll(XY[outer],-1,axis=0)):
   vv=bb-aa;t=np.clip(((XY[ring]-aa)@vv)/(vv@vv),0,1);marg=np.minimum(marg,np.linalg.norm(XY[ring]-aa-t[:,None]*vv,axis=1))
  entry.update(outer_projected_simple=bool(simple),aperture_strictly_inside=bool(hole_inside),minimum_aperture_outer_margin_m=float(marg.min()),outer_min_stored_normal_dot_front=float((UN[outer]@D).min()),outer_max_edge_m=float(np.linalg.norm(U[outer]-np.roll(U[outer],-1,axis=0),axis=1).max()),Euler_characteristic=int(len(np.unique(UF[ids]))-len(SE)+len(ids)))
  valid=simple and hole_inside and marg.min()>.004 and entry['outer_min_stored_normal_dot_front']>.05 and entry['Euler_characteristic']==0
  entry['candidate_valid']=bool(valid)
  if valid and radius>=.019 and accepted is None:accepted=(ids,outer,radius)
 assert accepted is not None,('No healthy annulus',e['side'],candidates);ids,outer,radius=accepted;assert not any(np.intersect1d(ids,other).size for other in chosen),'Two orbital domains overlap';chosen.append(ids);side=e['side'];data[side+'_selected_source_faces']=ids;data[side+'_outer_unique_ids']=outer;data[side+'_aperture_unique_ids']=ring;data[side+'_center']=C;data[side+'_frame']=np.array([X,Y,D]);rows.append({'side':side,'chosen_geodesic_radius_m':radius,'selected_faces':len(ids),'outer_nodes':len(outer),'aperture_nodes':len(ring),'candidates':candidates})
np.savez_compressed(O/'checks/orbit_annuli326.npz',source_positions=P,source_normals=N,source_faces=F,unique_positions=U,source_to_unique=iv,**data);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eyes':rows,'total_selected_faces':sum(len(q)for q in chosen),'all_source_geometry_unchanged':True,'scope':'Read-only complete annulus domain selection. The old orbital sheet is not removed until a complete constrained replacement exists with128-node aperture and a conforming healthy outer seam. Actual placement and full geometry/material QA remain required.'};(O/'checks/orbit_annuli326.json').write_text(json.dumps(r,indent=2));print('ANNULI326',r,flush=True)
