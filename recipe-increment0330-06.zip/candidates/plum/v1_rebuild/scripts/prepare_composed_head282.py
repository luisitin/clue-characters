"""Prepare exact255 changed-face audit against every possible assembly AABB neighbor.
No geometry rewrite. The union is conservative in actual exported world positions.
"""
from pathlib import Path
import json,hashlib,numpy as np,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1]
inputs=[('head_neck275.glb','head_cornea255.glb'),('eyes_optical264.glb',None),('spectacles_joined193.glb',None),('hand_wrist201.glb',None)]
Ps=[];Fs=[];selected=[];groups=[];sources=[];vo=0;fo=0
for name,old in inputs:
 path=O/'components'/name;j,b,a=read_glb(path)
 if old:oj,ob,oa=read_glb(O/'components'/old)
 sources.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'before':old})
 def visit(ni,parent):
  global vo,fo
  node=j['nodes'][ni];M=parent@node_matrix(node)
  if 'mesh'in node:
   for pi,p in enumerate(j['meshes'][node['mesh']]['primitives']):
    LP=a(p['attributes']['POSITION']).astype(float);P=(LP@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(np.int64)
    if old:
     op=oj['meshes'][node['mesh']]['primitives'][pi];oldLP=oa(op['attributes']['POSITION']).astype(float);assert np.array_equal(F,oa(op['indices']).reshape(-1,3));change=np.any(LP!=oldLP,axis=1);selected.extend((np.flatnonzero(change[F].any(1))+fo).tolist())
    Ps.append(P);Fs.append(F+vo);groups.append({'source':name,'node':node.get('name'),'primitive':pi,'global_face_start':fo,'global_face_stop':fo+len(F)});vo+=len(P);fo+=len(F)
  for child in node.get('children',[]):visit(child,M)
 for ni in j['scenes'][j.get('scene',0)]['nodes']:visit(ni,np.eye(4))
P=np.vstack(Ps);F=np.vstack(Fs);selected=np.unique(selected).astype(np.int64);T=P[F];lo=T.min(1);hi=T.max(1)
points=vtk.vtkPoints();points.SetData(numpy_to_vtk(P,deep=True));cells=vtk.vtkCellArray();cells.SetCells(len(F),numpy_to_vtkIdTypeArray(np.column_stack((np.full(len(F),3),F)).ravel().astype(np.int64),deep=True));poly=vtk.vtkPolyData();poly.SetPoints(points);poly.SetPolys(cells);locator=vtk.vtkStaticCellLocator();locator.SetDataSet(poly);locator.BuildLocator();hits=vtk.vtkIdList();keep=np.zeros(len(F),bool);keep[selected]=True
for step,fi in enumerate(selected):
 locator.FindCellsWithinBounds(np.column_stack((lo[fi]-1e-8,hi[fi]+1e-8)).ravel(),hits);ids=np.array([hits.GetId(k)for k in range(hits.GetNumberOfIds())],int);ids=ids[np.all(hi[ids]>=lo[fi]-1e-8,axis=1)&np.all(lo[ids]<=hi[fi]+1e-8,axis=1)];keep[ids]=True
 if step%5000==0:print('BROAD282',step,len(selected),int(keep.sum()),flush=True)
origfaces=np.flatnonzero(keep);Fkeep=F[origfaces];origverts,iv=np.unique(Fkeep,return_inverse=True);compactF=iv.reshape(-1,3);compactP=P[origverts];compactsel=np.searchsorted(origfaces,selected);assert np.array_equal(origfaces[compactsel],selected);dst=O/'checks/composed_head282.npz';np.savez_compressed(dst,P=compactP,F=compactF,selected=compactsel,source_global_faces=origfaces,source_global_vertices=origverts)
r={'sources':sources,'groups':groups,'source_triangles':len(F),'selected_changed_triangles':len(selected),'compact_triangles':len(Fkeep),'compact_vertices':len(compactP),'exact_selected_and_neighbors_retained':True,'broad_phase_pad_m':1e-8,'npz_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'tile_size':2000,'tiles':int(np.ceil(len(selected)/2000)),'scope':'Every actual275 neck-composition moved triangle is tested against all assembly triangles with overlapping padded AABBs. Unchanged distant pairs are excluded, not cleared. Geometry/normals/materials are untouched.'};(O/'checks/composed_head282.json').write_text(json.dumps(r,indent=2));print('PREPARED282',r,flush=True)
