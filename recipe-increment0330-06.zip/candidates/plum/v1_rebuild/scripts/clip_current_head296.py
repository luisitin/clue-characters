"""Clip current275 at the exact already-inspected upper neck plane.
Every corner semantic is extended consistently. No unrelated source body, eye,
hand or source character is changed. This is the first bounded assembly step.
"""
from pathlib import Path
import json,hashlib,struct,collections,numpy as np
from scipy.spatial import cKDTree
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/head_neck275.glb';j,b,a=read_glb(src);assert len(j['nodes'])==len(j['meshes'])==1 and np.array_equal(node_matrix(j['nodes'][0]),np.eye(4));pr=j['meshes'][0]['primitives'][0];attrs={k:a(ai).astype(float)for k,ai in pr['attributes'].items()};assert set(attrs)<= {'POSITION','NORMAL','TANGENT','TEXCOORD_0','TEXCOORD_1','COLOR_0'};F=a(pr['indices']).reshape(-1,3).astype(np.int64);ep=json.loads((O/'checks/neck_loft126.json').read_text())['endpoints'][1];C=np.array(ep['plane_origin'])[[0,2,1]]*[1,1,-1];N=np.array(ep['plane_normal'])[[0,2,1]]*[1,1,-1];P=attrs['POSITION'];U,iv=np.unique(P,axis=0,return_inverse=True);d=(U-C)@N;lists={k:v.tolist()for k,v in attrs.items()};edgecache={};geocache={};newfaces=[];parents=[];splitrows=[]
def cut(aa,bb):
 key=tuple(sorted((int(aa),int(bb))))
 if key in edgecache:return edgecache[key]
 ga,gb=map(int,iv[[aa,bb]]);gk=tuple(sorted((ga,gb)))
 if gk not in geocache:
  ia,ib=gk;t=-d[ia]/(d[ib]-d[ia]);geocache[gk]=U[ia]+t*(U[ib]-U[ia])
 t=-d[ga]/(d[gb]-d[ga]);row={k:(1-t)*v[aa]+t*v[bb]for k,v in attrs.items()};row['POSITION']=geocache[gk];row['NORMAL']/=np.linalg.norm(row['NORMAL'])
 if 'TANGENT'in row:
  assert attrs['TANGENT'][aa,3]==attrs['TANGENT'][bb,3];row['TANGENT'][3]=attrs['TANGENT'][aa,3];row['TANGENT'][:3]-=row['NORMAL']*(row['TANGENT'][:3]@row['NORMAL']);row['TANGENT'][:3]/=np.linalg.norm(row['TANGENT'][:3])
 ix=len(lists['POSITION'])
 for k,v in row.items():lists[k].append(v.tolist())
 edgecache[key]=ix;splitrows.append({'new_vertex':ix,'source_edge':[aa,bb],'t':float(t)});return ix
for fi,f in enumerate(F):
 dd=d[iv[f]]
 if dd.min()>=0:newfaces.append(f.tolist());parents.append(fi);continue
 if dd.max()<=0:continue
 poly=[]
 for aa,bb in zip(f,np.roll(f,-1)):
  da,db=d[iv[[aa,bb]]]
  if da>=0:poly.append(int(aa))
  if da*db<0:poly.append(cut(int(aa),int(bb)))
 assert len(poly)in(3,4)
 for k in range(1,len(poly)-1):newfaces.append([poly[0],poly[k],poly[k+1]]);parents.append(fi)
TF=np.array(newfaces,np.int64);A={k:np.array(v,dtype='<f4')for k,v in lists.items()};assert all(len(v)==len(A['POSITION'])for v in A.values());assert np.array_equal(A['POSITION'][:len(P)],P.astype('<f4'));Q=A['POSITION'].astype(float);G=np.cross(Q[TF[:,1]]-Q[TF[:,0]],Q[TF[:,2]]-Q[TF[:,0]]);assert np.linalg.norm(G,axis=1).min()>1e-16;W=Q[:,[0,2,1]]*[1,-1,1];GU,gv=np.unique(W,axis=0,return_inverse=True);edges=collections.defaultdict(list)
for fi,f in enumerate(gv[TF]):
 for aa,bb in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
cutedges=[e for e,fs in edges.items()if len(fs)==1 and np.max(abs((GU[list(e)]-np.array(ep['plane_origin']))@np.array(ep['plane_normal'])))<1e-7];adj=collections.defaultdict(set)
for aa,bb in cutedges:adj[aa].add(bb);adj[bb].add(aa)
assert len(cutedges)==ep['count']==353 and all(len(x)==2 for x in adj.values());z=np.load(O/'checks/neck_loft126.npz');loft=z['positions'];z.close();ring=loft[-ep['count']:].astype('<f4').astype(float);actual=GU[list(adj)];dist,match=cKDTree(actual).query(ring);assert dist.max()<8e-8 and len(set(match))==len(ring),'Loft boundary correspondence changed'
payload=bytearray(b)
def append(A,typ,ct=5126,target=34962):
 A=np.ascontiguousarray(A);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':A.nbytes,'target':target});payload.extend(A.tobytes());ai=len(j['accessors']);row={'bufferView':vi,'componentType':ct,'count':len(A),'type':typ}
 if typ=='VEC3':row.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 j['accessors'].append(row);return ai
for key,v in A.items():pr['attributes'][key]=append(v,'VEC'+str(v.shape[1]))
pr['indices']=append(TF.astype('<u4').ravel(),'SCALAR',5125,34963);j['nodes'][0]['name']='Plum | current face and fitted neck296';j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/head_clipped296.glb';dst.write_bytes(raw);np.savez_compressed(O/'checks/head_clipped296_lineage.npz',source275_face=np.array(parents),boundary_world=actual);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'triangles':len(TF),'cut_segments':len(cutedges),'new_attribute_vertices':len(Q)-len(P),'all_attributes_same_count':True,'held_source_positions_exact':True,'maximum_existing_loft126_endpoint_distance_m':float(dist.max()),'one_to_one_full_boundary_correspondence':True,'split_source_edges':splitrows,'scope':'Source-preserving current head at the already-inspected353-edge neck interface. It remains an open component until joined with existing loft/body; material and coherent all-angle appearance are not cleared.'};(O/'checks/head_clipped296.json').write_text(json.dumps(r,indent=2));print('HEAD296',{k:v for k,v in r.items()if k!='split_source_edges'},flush=True)
