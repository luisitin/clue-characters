"""Small coupled optical-depth study on the held face and both closed eyes.
The same monotone depth field moves skin/front/back contact positions; local XY,
gaze UVs, all topology and materials remain fixed. This is not a final cornea.
"""
from pathlib import Path
import json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];eyes=json.loads((O/'checks/regular_orbits033.json').read_text())['eyes'];X,Y,D=np.array(eyes[0]['frame']);centers=[np.array(r['globe_center_world'])for r in eyes];assert all(np.allclose(np.array(r['frame']),[X,Y,D])for r in eyes);amplitude=.0006;radius=.0105*1.20

def smooth(u):
 t=np.clip(u,0,1);return t*t*t*(t*(t*6-15)+10),30*t*t*(t-1)**2

def field(P):
 H=np.zeros(len(P));hx=np.zeros(len(P));hy=np.zeros(len(P))
 for C in centers:
  x=(P-C)@X-.007;y=(P-C)@Y-.001;s=np.maximum(1-(x*x+y*y)/radius**2,0);H+=amplitude*s**3;hx+=-6*amplitude*x/radius**2*s*s;hy+=-6*amplitude*y/radius**2*s*s
 depth=(P-centers[0])@D;g0,dg0=smooth((depth+.040)/.020);g1,dg1=smooth((.070-depth)/.025);g=g0*g1;gd=dg0/.020*g1-g0*dg1/.025;height=H*g;grad=(hx*g)[:,None]*X+(hy*g)[:,None]*Y+(H*gd)[:,None]*D;det=1+grad@D;return P+height[:,None]*D,height,grad,det

anchor=np.array([[-.0745500773,-.0425513275,.6390333772]]);assert field(anchor)[1][0]==0;outputs=[];oldP=[];newP=[]
for source,tag in [('head_mouth186.glb','head_cornea255'),('eyes_iris249.glb','eyes_cornea255')]:
 src=O/'components'/source;j,b,a=read_glb(src);payload=bytearray(b);visited_meshes=set();rows=[]
 def append(A):
  A=np.ascontiguousarray(A,dtype='<f4');payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':A.nbytes,'target':34962});payload.extend(A.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5126,'count':len(A),'type':'VEC3','min':A.min(0).tolist(),'max':A.max(0).tolist()});return ai
 def visit(ni,parent):
  node=j['nodes'][ni];M=parent@node_matrix(node)
  if 'mesh'in node:
   mi=node['mesh'];assert mi not in visited_meshes,'Shared transformed mesh needs explicit handling';visited_meshes.add(mi)
   for pi,p in enumerate(j['meshes'][mi]['primitives']):
    LP=a(p['attributes']['POSITION']).astype(float);LN=a(p['attributes']['NORMAL']).astype(float);P=(LP@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=(LN@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];F=a(p['indices']).reshape(-1,3).astype(int);Q,height,grad,det=field(P);changed=height>0;normal_changed=np.linalg.norm(grad,axis=1)>0;NN=N-grad*((N@D)/det)[:,None];NN/=np.linalg.norm(NN,axis=1)[:,None];PL=LP.copy();NL=LN.copy();PL[changed]=((Q[changed][:,[0,2,1]]*[1,1,-1])-M[:3,3])@np.linalg.inv(M[:3,:3]).T;temp=(NN[normal_changed][:,[0,2,1]]*[1,1,-1])@M[:3,:3];temp/=np.linalg.norm(temp,axis=1)[:,None];NL[normal_changed]=temp
    qf=PL.astype('<f4').astype(float);exportQ=(qf@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];oldP.append(P);newP.append(exportQ);assert np.array_equal(qf[~changed],LP.astype('<f4')[~changed]);assert np.array_equal(NL.astype('<f4')[~normal_changed],LN.astype('<f4')[~normal_changed]);assert height.max()<=amplitude+1e-12 and det.min()>.95
    affected=np.flatnonzero(changed[F].any(1));G0=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);G1=np.cross(exportQ[F[:,1]]-exportQ[F[:,0]],exportQ[F[:,2]]-exportQ[F[:,0]]);area=np.linalg.norm(G1,axis=1);dots=(G0*G1).sum(1)/(np.linalg.norm(G0,axis=1)*area);assert area.min()>1e-16 and dots.min()>.95;sample_min=float(det.min());max_chord=0
    for weights in [[1/3,1/3,1/3],[.5,.5,0],[.5,0,.5],[0,.5,.5]]:
     if not len(affected):continue
     S=np.einsum('k,ikj->ij',np.array(weights),P[F[affected]]);QS,_,_,DD=field(S);linear=np.einsum('k,ikj->ij',np.array(weights),exportQ[F[affected]]);max_chord=max(max_chord,float(np.linalg.norm(QS-linear,axis=1).max()));sample_min=min(sample_min,float(DD.min()))
    assert sample_min>.95 and max_chord<.000080
    p['attributes']['POSITION']=append(PL);p['attributes']['NORMAL']=append(NL);rows.append({'node':node.get('name'),'primitive':pi,'changed_vertices':int(changed.sum()),'affected_triangles':len(affected),'maximum_rise_m':float(height.max()),'minimum_vertex_edge_centroid_jacobian':sample_min,'maximum_chord_error_m':max_chord,'minimum_old_new_geometric_normal_dot':float(dots.min()),'held_head_local_XY_max_error_float64_m':float(np.max(abs((Q-P)@np.array([X,Y]).T))),'export_head_local_XY_max_error_m':float(np.max(abs((exportQ-P)@np.array([X,Y]).T))),'all_unaffected_P_N_exact':True})
  for child in node.get('children',[]):visit(child,M)
 for ni in j['scenes'][j.get('scene',0)]['nodes']:visit(ni,np.eye(4))
 j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components'/f'{tag}.glb';dst.write_bytes(raw);outputs.append({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'output':str(dst),'parts':rows})
P=np.concatenate(oldP);Q=np.concatenate(newP);U,iv=np.unique(P,axis=0,return_inverse=True);order=np.argsort(iv,kind='stable');starts=np.r_[0,np.flatnonzero(np.diff(iv[order]))+1];ref=Q[order[starts]];div=float(np.linalg.norm(Q-ref[iv],axis=1).max());assert div<8e-8;r={'outputs':outputs,'height_limit_m':amplitude,'support_radius_m':radius,'depth_gate_m':[-.040,-.020,.045,.070],'global_depth_derivative_lower_bound':.955,'all_exact_position_equivalence_groups_max_export_divergence_m':div,'index_chin_anchor_exactly_held':True,'topology_UVs_colors_materials_held':True,'scope':'Unapproved optical-depth study. Same analytic depth map moves eye fronts/backs and skin, with exact shared-position behavior and Jacobian normal transport. Not a validated anatomical cornea or final eye. New exact local intersections, glasses clearance and grazing/profile/refraction appearance remain required; head tangent-space normal maps are not yet in use.'};(O/'checks/corneal_shape255.json').write_text(json.dumps(r,indent=2));print('CORNEA255',r,flush=True)
