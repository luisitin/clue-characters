"""Run frozen exact216 selected kernel on one immutable compact258 selection tile."""
from pathlib import Path
import json,hashlib,numpy as np,argparse
from intersection_v4_selected216 import audit
O=Path(__file__).resolve().parents[1];pa=argparse.ArgumentParser();pa.add_argument('--tile',type=int,required=True);args=pa.parse_args();cfg=json.loads((O/'checks/orbit_contact330.json').read_text());p=O/'checks/orbit_contact330.npz';assert hashlib.sha256(p.read_bytes()).hexdigest()==cfg['npz_sha256'];z=np.load(p);P=z['P'];F=z['F'];S=z['selected'];lineage=z['source_global_faces'];z.close();a=args.tile*cfg['tile_size'];b=min(len(S),a+cfg['tile_size']);assert 0<=a<b<=len(S);r=audit(P,F,selected_faces=S[a:b]);r.update(selection_range=[a,b],input_sha256=cfg['npz_sha256'],sources=cfg['sources'],groups=cfg['groups'],selector_core_sha256=hashlib.sha256((O/'scripts/intersection_v4_selected216.py').read_bytes()).hexdigest())
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for pair in r[key]:pair['source_global_faces']=lineage[pair['faces']].tolist()
(O/f'checks/orbits331_{args.tile:02}.json').write_text(json.dumps(r,indent=2));print('TILE331',args.tile,a,b,len(r['proper_crossings']),len(r['positive_area_coplanar_pairs']),flush=True)
