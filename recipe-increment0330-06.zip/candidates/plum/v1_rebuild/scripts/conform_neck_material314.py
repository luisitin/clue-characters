"""Conforming continuous skin/shirt material boundary, replacing308 face-centroid steps.
Every original source triangle is retained or split in its own plane, all corner
attributes are extended, and shared cut edges use one exact-position knot.
"""
from pathlib import Path
import numpy as np,json,hashlib,struct,copy,collections
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];src=O/'components/source_body313.glb';j,b,a=read_glb(src);assert np.array_equal(node_matrix(j['nodes'][0]),np.eye(4));oldpr=j['meshes'][0]['primitives'];attrs0=oldpr[0]['attributes'];assert all(p['attributes']==attrs0 for p in oldpr);A={k:a(ai).astype(float)for k,ai in attrs0.items()};assert set(A)<={'POSITION','NORMAL','TANGENT','TEXCOORD_0','TEXCOORD_1','COLOR_0'};LP=A['POSITION'];W=LP[:,[0,2,1]]*[1,-1,1];U,iv=np.unique(W,axis=0,return_inverse=True);report=json.loads((O/'checks/neck_loft126.json').read_text());C=np.array(report['endpoints'][0]['plane_origin']);N=np.array(report['endpoints'][0]['plane_normal']);AX=np.array([[1.,0,0],np.cross(N,[1.,0,0]),N]);z=np.load(O/'checks/neck_loft126.npz');B=z['positions'][:129];z.close();xy=(B-C)@AX[:2].T;cross=xy[:,0]*np.roll(xy[:,1],-1)-np.roll(xy[:,0],-1)*xy[:,1];center=np.sum((xy+np.roll(xy,-1,axis=0))*cross[:,None],axis=0)/(3*cross.sum());rad=xy-center;angle=np.mod(np.arctan2(rad[:,1],rad[:,0]),2*np.pi);order=np.argsort(angle);rad=rad[order];angle=angle[order]
def scalar(P):
 L=(P-C)@AX.T;R=L[:,:2]-center;theta=np.mod(np.arctan2(R[:,1],R[:,0]),2*np.pi);ix=(np.searchsorted(angle,theta,side='right')-1)%len(angle);aa=rad[ix];bb=rad[(ix+1)%len(rad)];dr=np.c_[np.cos(theta),np.sin(theta)];e=bb-aa;radius=(aa[:,0]*bb[:,1]-aa[:,1]*bb[:,0])/(dr[:,0]*e[:,1]-dr[:,1]*e[:,0]);assert np.all(radius>0);lower=-.048+.016*np.sin(theta);return np.minimum(L[:,2]-lower,1.25*radius-np.linalg.norm(R,axis=1))
s=scalar(U);assert np.min(scalar(B))>0;lists={k:v.tolist()for k,v in A.items()};cache={};geomcache={};new={};lineage={};splitrecords=[];mi=len(j['materials']);j['materials'].append({'name':'Plum conforming exposed neck314 provisional skin','doubleSided':False,'pbrMetallicRoughness':{'baseColorFactor':[.78,.53,.34,1],'roughnessFactor':.6,'metallicFactor':0}})
def split(aa,bb):
 key=tuple(sorted((int(aa),int(bb))))
 if key in cache:return cache[key]
 ga,gb=map(int,iv[[aa,bb]]);gk=tuple(sorted((ga,gb)))
 if gk not in geomcache:
  ia,ib=gk;t=-s[ia]/(s[ib]-s[ia]);geomcache[gk]=U[ia]+t*(U[ib]-U[ia])
 t=-s[ga]/(s[gb]-s[ga]);v={k:(1-t)*val[aa]+t*val[bb]for k,val in A.items()};v['POSITION']=geomcache[gk][[0,2,1]]*[1,1,-1];v['NORMAL']/=np.linalg.norm(v['NORMAL'])
 if 'TANGENT'in v:
  assert A['TANGENT'][aa,3]==A['TANGENT'][bb,3];v['TANGENT'][3]=A['TANGENT'][aa,3];v['TANGENT'][:3]-=v['NORMAL']*(v['TANGENT'][:3]@v['NORMAL']);v['TANGENT'][:3]/=np.linalg.norm(v['TANGENT'][:3])
 # Exact float32 endpoint coincidences are reused rather than emitting a zero-area sliver.
 for end in (aa,bb):
  if np.array_equal(v['POSITION'].astype('<f4'),A['POSITION'][end].astype('<f4')):cache[key]=int(end);return int(end)
 idx=len(lists['POSITION'])
 for k,vv in v.items():lists[k].append(vv.tolist())
 cache[key]=idx;splitrecords.append({'new_vertex':idx,'source_edge':[int(aa),int(bb)],'t':float(t)});return idx
for pi,p in enumerate(oldpr):
 F=a(p['indices']).reshape(-1,3).astype(int)
 for fi,f in enumerate(F):
  for sign,mat in [(1,mi),(-1,p.get('material',0))]:
   d=s[iv[f]]*sign
   if d.min()>=0:pol=f.tolist()
   elif d.max()<=0:continue
   else:
    pol=[]
    for aa,bb in zip(f,np.roll(f,-1)):
     da,db=s[iv[[aa,bb]]]*sign
     if da>=0:pol.append(int(aa))
     if da*db<0:pol.append(split(int(aa),int(bb)))
    pol=[x for k,x in enumerate(pol)if k==0 or x!=pol[k-1]]
    if len(pol)>1 and pol[0]==pol[-1]:pol.pop()
   for k in range(1,len(pol)-1):new.setdefault(mat,[]).append([pol[0],pol[k],pol[k+1]]);lineage.setdefault(mat,[]).append([pi,fi])
Q={k:np.array(v,dtype='<f4')for k,v in lists.items()};assert np.array_equal(Q['POSITION'][:len(LP)],LP.astype('<f4'));assert all(len(v)==len(Q['POSITION'])for v in Q.values());total=sum(map(len,new.values()));oldtotal=sum(j['accessors'][p['indices']]['count']//3 for p in oldpr);assert total>=oldtotal;WQ=Q['POSITION'].astype(float)[:,[0,2,1]]*[1,-1,1];minarea=np.inf
for mat,faces in new.items():
 F=np.array(faces);g=np.cross(WQ[F[:,1]]-WQ[F[:,0]],WQ[F[:,2]]-WQ[F[:,0]]);minarea=min(minarea,float(np.linalg.norm(g,axis=1).min()/2))
assert minarea>1e-16,'Collapsed material-boundary fragment';payload=bytearray(b)
def append(A,typ,ct=5126,target=34962):
 A=np.ascontiguousarray(A);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':A.nbytes,'target':target});payload.extend(A.tobytes());ai=len(j['accessors']);r={'bufferView':vi,'componentType':ct,'count':len(A),'type':typ}
 if typ=='VEC3':r.update(min=A.min(0).tolist(),max=A.max(0).tolist())
 j['accessors'].append(r);return ai
attrs={k:append(v,'VEC'+str(v.shape[1]))for k,v in Q.items()};prims=[];mappings={}
for k,mat in enumerate(sorted(new)):
 F=np.array(new[mat],dtype='<u4');prims.append({'attributes':attrs,'indices':append(F.ravel(),'SCALAR',5125,34963),'material':mat});mappings[str(k)]={'material':mat,'source_primitive_face':lineage[mat]}
j['meshes'][0]['primitives']=prims;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_body314.glb';dst.write_bytes(raw);r={'source313_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'input_triangles':oldtotal,'output_triangles':total,'skin_triangles':len(new[mi]),'new_attribute_vertices':len(Q['POSITION'])-len(LP),'shared_geometric_cut_knots':len(geomcache),'minimum_triangle_area_m2':minarea,'all_original_positions_held':True,'all_semantic_attribute_counts_equal':True,'neck_profile_front_back_m':[-.064,-.032],'radial_factor':1.25,'split_records':splitrecords,'source_face_lineage':mappings,'scope':'Conforming source-plane material cut removes face-centroid staircase boundary without deleting any source surface. New clothing/neck ownership, original source defects and current normal interpolation still need actual-view and exact local QA.'};(O/'checks/source_neck314.json').write_text(json.dumps(r,indent=2));print('NECK314',{k:v for k,v in r.items()if k not in ['split_records','source_face_lineage']},flush=True)
