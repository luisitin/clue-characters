"""Carry only three fully retained, proved posterior-neck source branch fixes into127.
Exact world POSITION triplets select the untouched source triangles. No cap,
recolour, position/normal/UV edit or whole121 merge is performed.
"""
from pathlib import Path
import collections,hashlib,json,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];source=O/'components/plum_strip_cleanup085.glb';sj,sb,sa=read_glb(source);sp=sj['meshes'][0]['primitives'][0];SM=node_matrix(sj['nodes'][0]);SP=sa(sp['attributes']['POSITION']).astype(float);SP=((SP@SM[:3,:3].T+SM[:3,3])[:,[0,2,1]]*[1,-1,1]).astype('<f4');SF=sa(sp['indices']).reshape(-1,3).astype(np.int64);proof=json.loads((O/'checks/branch_cleanup121.json').read_text());assert proof['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest();groups=[x for x in proof['accepted_components']if x['component_root']in [5431,6668,60278]];assert len(groups)==3;oldfaces=[fi for x in groups for fi in x['faces']];assert len(oldfaces)==12
src=O/'components/source_cuff_cleanup243.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=a(pr['attributes']['POSITION']).astype('<f4')[:,[0,2,1]]*np.array([1,-1,1],dtype='<f4');F=a(pr['indices']).reshape(-1,3).astype(np.int64)
def signature(T):return tuple(sorted(map(tuple,T)))
lookup=collections.defaultdict(list)
for fi,f in enumerate(F):lookup[signature(P[f])].append(fi)
mapfaces={}
for old in oldfaces:
 hit=lookup[signature(SP[SF[old]])];assert len(hit)==1,('Not one fully retained source face',old,hit);mapfaces[old]=hit[0]
remove=set(mapfaces.values());U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];edge=collections.defaultdict(list)
for fi,f in enumerate(T):
 for aa,bb in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(aa),int(bb))))].append((fi,int(aa),int(bb)))
for key,fam in edge.items():
 if not any(fi in remove for fi,aa,bb in fam):continue
 keep=[x for x in fam if x[0]not in remove];assert len(keep)in(0,2),('Affected incidence',key,keep)
 if keep:assert keep[0][1:]==keep[1][1:][::-1]
mask=np.ones(len(F),bool);mask[sorted(remove)]=False;indices=F[mask].astype('<u4').ravel();payload=bytearray(b);payload.extend(b'\0'*((-len(payload))%4));vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(payload),'byteLength':indices.nbytes,'target':34963});payload.extend(indices.tobytes());ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':len(indices),'type':'SCALAR','min':[int(indices.min())],'max':[int(indices.max())]});pr['indices']=ai;j['buffers'][0]['byteLength']=len(payload);js=json.dumps(j,separators=(',',':')).encode();js+=b' '*((-len(js))%4);payload.extend(b'\0'*((-len(payload))%4));raw=struct.pack('<4sII',b'glTF',2,28+len(js)+len(payload))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(payload),0x004e4942)+payload;dst=O/'components/source_body298.glb';dst.write_bytes(raw);jj,bb,aa=read_glb(dst);assert bb[:len(b)]==b
r={'source_context_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(raw).hexdigest(),'component_roots':[5431,6668,60278],'source085_to_body243_face':mapfaces,'whole_component_full_triangle_correspondence':True,'affected_surviving_edge_incidence_and_parity_pass':True,'all_prior_BIN_and_vertex_attributes_unchanged':True,'scope':'Only the three proved fully retained posterior-neck branches are removed. Body243 geometry, materials and all other source defects are held. Actual matched views remain required; this does not close vertical posterior ridges, anterior source marks or skin/shirt material gates.'};(O/'checks/source_body298.json').write_text(json.dumps(r,indent=2));print('BODY298',r,flush=True)
