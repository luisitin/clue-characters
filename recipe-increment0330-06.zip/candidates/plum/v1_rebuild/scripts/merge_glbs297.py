"""Raw static GLB assembly without Blender re-export or unrelated attribute rewrites."""
import copy,json,struct,argparse,hashlib
from pathlib import Path
from glb_io import read_glb
class GLB:
    def __init__(self,path):
        self.j,self.bin,self.array=read_glb(path)
        self.sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest()
def merge(paths,output):
    out={'asset':{'version':'2.0','generator':'Plum source-preserving static component assembler297'},'buffers':[{'byteLength':0}],'bufferViews':[],'accessors':[],'images':[],'textures':[],'samplers':[],'materials':[],'meshes':[],'nodes':[],'scenes':[{'nodes':[]}],'scene':0};blob=bytearray();sources=[]
    for path in paths:
        g=GLB(path);j=g.j;assert not j.get('skins') and not j.get('animations') and not j.get('cameras')
        offsets={key:len(out[key]) for key in ('bufferViews','accessors','images','textures','samplers','materials','meshes','nodes')};blob.extend(b'\0'*((-len(blob))%4));base=len(blob);blob.extend(g.bin)
        for v0 in j.get('bufferViews',[]):
            v=copy.deepcopy(v0);assert v.get('buffer',0)==0;v['buffer']=0;v['byteOffset']=v.get('byteOffset',0)+base;out['bufferViews'].append(v)
        for a0 in j.get('accessors',[]):
            a=copy.deepcopy(a0)
            if 'bufferView' in a:a['bufferView']+=offsets['bufferViews']
            if 'sparse' in a:
                a['sparse']['indices']['bufferView']+=offsets['bufferViews'];a['sparse']['values']['bufferView']+=offsets['bufferViews']
            out['accessors'].append(a)
        for im0 in j.get('images',[]):
            im=copy.deepcopy(im0);assert 'bufferView' in im;im['bufferView']+=offsets['bufferViews'];out['images'].append(im)
        out['samplers'].extend(copy.deepcopy(j.get('samplers',[])))
        for t0 in j.get('textures',[]):
            t=copy.deepcopy(t0)
            if 'source' in t:t['source']+=offsets['images']
            if 'sampler' in t:t['sampler']+=offsets['samplers']
            for ext in t.get('extensions',{}).values():
                if 'source' in ext:ext['source']+=offsets['images']
            out['textures'].append(t)
        def material_texture_remap(obj):
            if isinstance(obj,dict):
                for key,value in obj.items():
                    if key.endswith('Texture') and isinstance(value,dict) and 'index' in value:value['index']+=offsets['textures']
                    else:material_texture_remap(value)
            elif isinstance(obj,list):
                for value in obj:material_texture_remap(value)
        for m0 in j.get('materials',[]):
            m=copy.deepcopy(m0);material_texture_remap(m);out['materials'].append(m)
        for mesh0 in j.get('meshes',[]):
            mesh=copy.deepcopy(mesh0)
            for pr in mesh['primitives']:
                pr['attributes']={k:v+offsets['accessors'] for k,v in pr['attributes'].items()}
                if 'indices' in pr:pr['indices']+=offsets['accessors']
                if 'material' in pr:pr['material']+=offsets['materials']
                for target in pr.get('targets',[]):
                    for k in target:target[k]+=offsets['accessors']
            out['meshes'].append(mesh)
        for node0 in j.get('nodes',[]):
            node=copy.deepcopy(node0)
            if 'mesh' in node:node['mesh']+=offsets['meshes']
            if 'children' in node:node['children']=[n+offsets['nodes'] for n in node['children']]
            out['nodes'].append(node)
        roots=j['scenes'][j.get('scene',0)]['nodes'];out['scenes'][0]['nodes'].extend([x+offsets['nodes'] for x in roots])
        for key in ('extensionsUsed','extensionsRequired'):
            out[key]=sorted(set(out.get(key,[])+j.get(key,[])))
        sources.append({'path':str(path),'sha256':g.sha256,'BIN_offset':base,'BIN_bytes':len(g.bin),'index_offsets':offsets})
    out['buffers'][0]['byteLength']=len(blob);js=json.dumps(out,separators=(',',':')).encode();js+=b' '*((-len(js))%4);blob.extend(b'\0'*((-len(blob))%4))
    raw=struct.pack('<III',0x46546c67,2,28+len(js)+len(blob))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(blob),0x004e4942)+blob;Path(output).write_bytes(raw)
    for source in sources:
        g=GLB(source['path']);assert bytes(blob[source['BIN_offset']:source['BIN_offset']+source['BIN_bytes']])==bytes(g.bin)
    report={'output':str(output),'sha256':hashlib.sha256(raw).hexdigest(),'sources':sources,'all_component_BIN_blocks_byte_identical':True,'transforms_geometry_material_parameters_held':True}
    Path(output).with_suffix('.assembly.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('sources',nargs='+');a=p.parse_args();print(json.dumps(merge(a.sources,a.output),indent=2),flush=True)
