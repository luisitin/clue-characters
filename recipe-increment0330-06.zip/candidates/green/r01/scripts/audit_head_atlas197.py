import pathlib,json,numpy as np
from intersection_kernel_v4_selected import audit
R=pathlib.Path(__file__).resolve().parents[1]
with np.load(R/'audit/head_atlas196_binding.npz')as z:uv=z['UV_CORNER'].copy();source=z['source_face_ids'].copy()
p=np.column_stack([uv.reshape(-1,2),np.zeros(uv.size//2)]);f=np.arange(len(p)).reshape(-1,3);res=audit(p,f,selected_faces=np.arange(len(f)),progress_interval=2000)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in res[key]:row['source_faces']=source[row['faces']].tolist()
res['scope']='UV-only196 proposal, exact float32 corner coordinates. This is not an exported atlas or geometry change.';(R/'audit/head_atlas197_v4.json').write_text(json.dumps(res,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in res.items()},flush=True)
