"""Replace only the held hand node's primitive records with painted182."""
import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_context173_fp32.glb';part=R/'Green_grip_wrist182_painted.glb';j,b,A=read_glb(src);s,sb,S=read_glb(part);original=copy.deepcopy(j);ni=2;mi=j['nodes'][ni]['mesh'];a=copy.deepcopy(j['nodes'][ni]);c=copy.deepcopy(s['nodes'][0]);a.pop('mesh');c.pop('mesh');assert a==c
for old,new in zip(j['meshes'][mi]['primitives'],s['meshes'][0]['primitives']):
 f=A(old['indices']).astype(np.int64).reshape(-1,3);g=S(new['indices']).astype(np.int64).reshape(-1,3);assert f.shape==g.shape
 for key in ['POSITION','NORMAL']:assert np.array_equal(A(old['attributes'][key])[f],S(new['attributes'][key])[g])
off={k:len(j.get(k,[]))for k in ['accessors','bufferViews','images','textures','samplers','materials']};b=bytes(b)+b'\0'*((-len(b))%4);bo=len(b);b+=bytes(sb)
for v in s['bufferViews']:v['byteOffset']=v.get('byteOffset',0)+bo;v['buffer']=0
for ac in s['accessors']:ac['bufferView']+=off['bufferViews'];assert not ac.get('sparse')
for im in s.get('images',[]):im['bufferView']+=off['bufferViews']
for t in s.get('textures',[]):
 if'source'in t:t['source']+=off['images']
 if'sampler'in t:t['sampler']+=off['samplers']
 for ex in t.get('extensions',{}).values():
  if'source'in ex:ex['source']+=off['images']
def walk(obj):
 if isinstance(obj,dict):
  for key,val in obj.items():
   if key.endswith('Texture')and isinstance(val,dict)and'index'in val:val['index']+=off['textures']
   else:walk(val)
 elif isinstance(obj,list):
  for val in obj:walk(val)
for material in s.get('materials',[]):walk(material)
for pr in s['meshes'][0]['primitives']:pr['attributes']={k:v+off['accessors']for k,v in pr['attributes'].items()};pr['indices']+=off['accessors'];pr['material']+=off['materials']
for key in off:j.setdefault(key,[]).extend(s.get(key,[]))
j['meshes'][mi]['primitives']=s['meshes'][0]['primitives'];out=R/'Green_full_context183_raw.glb';write_glb(out,j,b)
assert j['nodes']==original['nodes']
for k,(x,y)in enumerate(zip(j['meshes'],original['meshes'])):
 if k!=mi:assert x==y
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'wrist_component_sha256':hashlib.sha256(part.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changed_node':ni,'ordered_corner_POSITION_NORMAL_exact':True,'all_other_component_geometry_bindings_transforms_materials_exact':True,'scope':'Only the current wrist/hand UVs, corresponding tangents and painted map bindings change. All shape/contact evidence carries by exact corner equality; actual paint and UV tests remain separate.'};(R/'audit/wrist_merge183.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
