#!/usr/bin/env bash
set -euo pipefail
R=clue-recovery-20261004/candidates/green/r01
for tag in body_angle_0 body_angle_45 body_angle_90 body_angle_135 body_angle_180 body_angle_225 body_angle_270 body_angle_315 body_top body_under head_angle_-11 head_angle_270 head_under; do
 bash "$R/scripts/run_heavy_stage.sh" "review213_${tag}" env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 blender -b -t 1 --python-exit-code 1 -P "$R/scripts/render_review213.py" -- "$R/Green_full_context193.glb" "$R/review_20261005_0105" "$tag" paint 1024 > "$R/logs/review213_${tag}.log" 2>&1
done
