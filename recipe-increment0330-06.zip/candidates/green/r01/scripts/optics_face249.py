import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/repaint_optics236.py').read_text().replace('Green_full_face234','Green_full_face248').replace('Optics236','Optics249').replace('iris236','iris249').replace('Green_full_face236','Green_full_face249').replace('optics236.json','optics249.json');exec(compile(code,'optics_face249','exec'))
