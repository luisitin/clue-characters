import pathlib,json,hashlib,gc,numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
R=pathlib.Path(__file__).resolve().parents[1];folder=R/'textures/head205_tiles';reports=[]
for kind,res in [('BaseColor',4096),('ORM',2048)]:
 color=np.concatenate([np.array(Image.open(folder/f'{kind}_{row}.png'))for row in range(0,res,512)]);valid=np.concatenate([np.array(Image.open(folder/f'{kind}_{row}_valid.png'))>0 for row in range(0,res,512)]);sampled=np.logical_or.reduce([np.load(folder/f'{kind}_{row}_sampled.npy')for row in range(0,res,512)]);assert sampled.all();index=distance_transform_edt(~valid,return_distances=False,return_indices=True);color[~valid]=color[index[0][~valid],index[1][~valid]];out=R/'textures'/f'Green_Head206_{kind}_{res}.png';Image.fromarray(color).save(out);reports.append({'kind':kind,'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'resolution':res,'occupied':int(valid.sum()),'all_faces_sampled':True});del color,valid,index,sampled;gc.collect()
(R/'audit/head_atlas206_maps.json').write_text(json.dumps({'maps':reports,'scope':'Original-color/ORM atlas transfer and nearest-valid filtering padding only. No face paint cleanup or geometry change yet.'},indent=2));print(reports,flush=True)
