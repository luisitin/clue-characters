import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/fair_sleeve74.py').read_text().replace('sleeve69','sleeve219').replace('sleeve74','sleeve220')
exec(compile(code,'fair_sleeve220','exec'))
