import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_wrist_uv185.py').read_text().replace('wrist182','wrist189').replace('wrist_uv185','wrist_uv190');exec(compile(code,'audit_wrist_uv190','exec'))
