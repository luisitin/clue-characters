import pathlib,json,hashlib,numpy as np
from glb_source import read_glb
from uv_coverage import audit
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist154.glb';j,b,A=read_glb(src);rows=[]
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 F=A(pr['indices']).astype(np.int64).reshape(-1,3);uv=A(pr['attributes']['TEXCOORD_0']);results={str(res):audit(uv[F],res)for res in [2048,4096]};row={'primitive':pi,'triangles':len(F),'independent_material_atlas':True,'out_of_range_corners':int(((uv[F]<0)|(uv[F]>1)).any(-1).sum()),'results':results};rows.append(row);print({'primitive':pi,**{res:{k:len(v)if isinstance(v,list)else v for k,v in result.items()}for res,result in results.items()}},flush=True)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'primitives':rows,'scope':'Strict texel interior multiplicity and sample coverage per actual distinct material atlas; this does not substitute for continuous UV intersection or paint appearance.'};(R/'audit/wrist_uv176.json').write_text(json.dumps(report,indent=2))
