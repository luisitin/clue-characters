"""Continue held AI-derived hand color through the exact skin boundary; repaint only new UV slots."""
import pathlib,json,hashlib,io,collections,numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter1d
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist154.glb';j,b,A=read_glb(src)
with np.load(R/'audit/wrist_uv179_binding.npz')as z:data={k:z[k]for k in z.files}
pr=j['meshes'][0]['primitives'][0];mat=j['materials'][pr['material']];texture=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];assert'source'in texture;im=j['images'][texture['source']];bv=j['bufferViews'][im['bufferView']];raw=bytes(b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]);sourceImage=np.array(Image.open(io.BytesIO(raw)).convert('RGB'));lin=sourceImage.astype('float32')/255;lin=np.where(lin<=.04045,lin/12.92,((lin+.055)/1.055)**2.4)
def sample(uv):
 p=np.clip(uv,0,1)*np.array([lin.shape[1],lin.shape[0]])-.5;p=np.maximum(p,0);p=np.minimum(p,np.array([lin.shape[1]-1.000001,lin.shape[0]-1.000001]));i=np.floor(p).astype(int);f=p-i
 return (1-f[...,1,None])*((1-f[...,0,None])*lin[i[...,1],i[...,0]]+f[...,0,None]*lin[i[...,1],i[...,0]+1])+f[...,1,None]*((1-f[...,0,None])*lin[i[...,1]+1,i[...,0]]+f[...,0,None]*lin[i[...,1]+1,i[...,0]+1])
def encode(c):return np.round(np.clip(np.where(c<=.0031308,c*12.92,1.055*np.maximum(c,0)**(1/2.4)-.055),0,1)*255).astype('uint8')
P=A(pr['attributes']['POSITION']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).astype(np.int64).reshape(-1,3);U,g=np.unique(P,axis=0,return_inverse=True);edges=collections.defaultdict(list)
for fi,f in enumerate(F):
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(g[a]),int(g[c]))))].append((int(a),int(c)))
ext=j['meshes'][0]['primitives'][1];EP=A(ext['attributes']['POSITION']);EU=A(ext['attributes']['TEXCOORD_0']);n=162;nr=28;Q=EP[(nr-1)*(n+1):(nr-1)*(n+1)+n];lookup={tuple(p):i for i,p in enumerate(U)};qids=np.array([lookup[tuple(p)]for p in Q]);edgeUV=[]
for a,c in zip(qids,np.roll(qids,-1)):
 rows=edges[tuple(sorted((int(a),int(c))))];assert len(rows)==1;va,vc=rows[0]
 if g[va]!=a:va,vc=vc,va
 edgeUV.append([UV[va],UV[vc]])
edgeUV=np.array(edgeUV);params=(EU[(nr-1)*(n+1):(nr)*(n+1),0]-.03)/.94;params[0]=0;params[-1]=1;assert np.all(np.diff(params)>0)
def boundary(u):
 u=np.clip(u,0,1);idx=np.clip(np.searchsorted(params,u,side='right')-1,0,n-1);t=(u-params[idx])/(params[idx+1]-params[idx]);uv=edgeUV[idx,0]*(1-t[...,None])+edgeUV[idx,1]*t[...,None];return sample(uv)
mean=boundary((np.arange(2048)+.5)/2048).mean(0)
def extension_color(uv):
 u=(uv[...,0]-.03)/.94;d=np.clip((.73-uv[...,1])/.70,0,1);weight=.25*d*d*(3-2*d);c=boundary(u)*(1-weight[...,None])+mean*weight[...,None];cap=(uv[...,1]>.755)&(uv[...,0]>.38)&(uv[...,0]<.62);c[cap]=mean;return c
S=2048;primary=sourceImage.copy();extension=np.empty((S,S,3),'uint8')
for y in range(0,S,128):
 uu,vv=np.meshgrid((np.arange(S)+.5)/S,(np.arange(y,min(y+128,S))+.5)/S);extension[y:y+len(vv)]=encode(extension_color(np.stack([uu,vv],-1)))
maps=[primary,extension];changed=[]
for pi in [0,1]:
 for fi,cell in zip(data[f'moved_faces_{pi}'],data[f'chart_cells_{pi}']):
  origin=np.array([1993+12*(cell%4),10+12*(cell//4)]);xx,yy=np.meshgrid(np.arange(12)+.5,np.arange(12)+.5);s=(xx-3)/6;t=(yy-3)/6;bc=np.stack([1-s-t,s,t],-1);bc=np.maximum(bc,0);bc/=bc.sum(-1)[...,None];oldUV=bc@data[f'OLD_UV_CORNER_{pi}'][fi];c=sample(oldUV)if pi==0 else extension_color(oldUV);maps[pi][origin[1]:origin[1]+12,origin[0]:origin[0]+12]=encode(c)
  if pi==0:changed.append(origin.tolist())
mask=np.zeros((S,S),bool)
for x,y in changed:mask[y:y+12,x:x+12]=True
assert np.array_equal(primary[~mask],sourceImage[~mask]);paths=[]
for pi,name in enumerate(['Hand','Extension']):
 p=R/'textures'/f'Green_Wrist180_{name}_BaseColor_2K.png';Image.fromarray(maps[pi]).save(p);paths.append({'primitive':pi,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
orm=np.empty((S,S,3),'uint8');orm[:]=[255,158,0];op=R/'textures/Green_Wrist180_Extension_ORM_2K.png';Image.fromarray(orm).save(op)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_embedded_basecolor_sha256':hashlib.sha256(raw).hexdigest(),'source_hand_paint_outside_8_reserved_slots_exact':True,'boundary_edge_UV_pairs':len(edgeUV),'extension_color_method':'Exact per-boundary-face native-UV bilinear color samples in linear light, continued proximally with at most25percent convergence to the circumferential mean. The input is the held AI-derived hand atlas; no baked lighting or invented crease is added.','maps':paths+[{'path':str(op),'sha256':hashlib.sha256(op.read_bytes()).hexdigest()}],'status':'Prepared texture transfer only. Exact UV export/tangent and actual seam/skin appearance checks remain.'};(R/'audit/wrist_skin180.json').write_text(json.dumps(report,indent=2));np.savez_compressed(R/'audit/wrist_skin180_boundary.npz',edge_native_UV=edgeUV,circumference_params=params);print(report,flush=True)
