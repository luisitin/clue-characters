"""Export the coherent head albedo rebuild on the unchanged unique charts."""
import pathlib,json,hashlib,copy,numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_head211.glb';j,b,A=read_glb(src);before=copy.deepcopy(j);report=json.loads((R/'audit/face232.json').read_text());rows=[]
def texture(path):
 global b
 raw=path.read_bytes();b=bytes(b)+b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(raw)});b+=raw;ii=len(j['images']);j['images'].append({'name':path.name,'mimeType':'image/png','bufferView':vi});ti=len(j['textures']);j['textures'].append({'source':ii});return ti
for key,d in report['targets'].items():
 res=d['resolution'];folder=R/'textures/face233_tiles';im=np.concatenate([np.array(Image.open(folder/f'{key}_{row}.png'))for row in range(0,res,512)]);valid=np.concatenate([np.array(Image.open(folder/f'{key}_{row}_valid.png'))>0 for row in range(0,res,512)]);painted=np.concatenate([np.array(Image.open(folder/f'{key}_{row}_painted.png'))for row in range(0,res,512)]);distance,ix=distance_transform_edt(~valid,return_indices=True);guard=(~valid)&(distance<=12);im[guard]=im[ix[0][guard],ix[1][guard]];path=R/'textures'/f'Green_{key}_Skin234_BaseColor_{res}.png';Image.fromarray(im).save(path)
 pr=j['meshes'][j['nodes'][d['node']]['mesh']]['primitives'][d['primitive']];mat=copy.deepcopy(j['materials'][pr['material']]);mat['name']=f'Green coherent {key} albedo234';p=mat['pbrMetallicRoughness'];p['baseColorTexture']={'index':texture(path)};p.pop('metallicRoughnessTexture',None);p['metallicFactor']=0.;p['roughnessFactor']=.64;mat.pop('occlusionTexture',None);pr['material']=len(j['materials']);j['materials'].append(mat);rows.append({'component':key,'map_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'occupied_texels':int(valid.sum()),'majority_painted_texels':int(np.count_nonzero((painted>127)&valid)),'retained_geometry':True,'base_resolution':res,'roughness':.64,'AO_map_removed':True})
# A restrained warm wet margin, keeping the exact physical wall geometry.
for pi in [1,4]:
 pr=j['meshes'][j['nodes'][34]['mesh']]['primitives'][pi];mat=copy.deepcopy(j['materials'][pr['material']]);mat['name']='Green warm natural lid margin234';mat['pbrMetallicRoughness'].update(baseColorFactor=[.48,.25,.175,1],roughnessFactor=.52);pr['material']=len(j['materials']);j['materials'].append(mat)
out=R/'Green_full_face234.glb';write_glb(out,j,b);rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'maps':rows,'all_geometry_normals_UV_tangents_transforms_held':True,'status':'Full head skin/hair albedo rebuild with softer material response. Actual front/side/rear/under projection alignment and appearance remain unreviewed; generated inputs are not model-quality evidence.'};(R/'audit/face234.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
