"""Continuous head skin colors with one frontal feature layer and an explicit neck/hair boundary."""
import pathlib,json,numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter,map_coordinates
R=pathlib.Path(__file__).resolve().parents[1]
class HeadField:
 def __init__(self):
  with np.load(R/'audit/face232_projection.npz')as z:self.C=z['cameras'][0];self.scale=float(z['scales'][0]);self.depth=z['depths'][0];self.guard=z['guards'][0]
  front=np.array(Image.open(R/'textures/painting_plates/face224/front.png').convert('RGB').resize((1024,1024),Image.Resampling.LANCZOS)).astype(float)/255;log=np.log(np.maximum(front,.01));self.detail=log-gaussian_filter(log,(24,24,0));self.grain=np.array(Image.open(R/'textures/Green_Skin255_Source.png').convert('RGB')).astype(float)/255;self.mean=self.grain.mean((0,1))
 def image(self,im,xy):return np.column_stack([map_coordinates(im[:,:,k],xy[:,::-1].T,order=1,mode='nearest')for k in range(3)])
 def evaluate(self,P,N,source,hair):
  pc=(P-self.C[:3,3])@self.C[:3,:3];xy=np.column_stack([pc[:,0]/self.scale+.5,.5-pc[:,1]/self.scale])*1024-.5;ix=np.clip(np.rint(xy[:,0]).astype(int),0,1023);iy=np.clip(np.rint(xy[:,1]).astype(int),0,1023);visible=(-pc[:,2]<=self.depth[iy,ix]+.0012)&np.isfinite(self.depth[iy,ix]);facing=np.maximum(N@self.C[:3,2],0);w=visible*np.clip((self.guard[iy,ix]-1)/4,0,1)*np.clip((facing-.05)/.45,0,1);w=w*w*(3-2*w)
  blend=np.abs(N)**4;blend/=np.maximum(blend.sum(1)[:,None],1e-20);grain=np.zeros((len(P),3))
  for k,axes in enumerate([(1,2),(0,2),(0,1)]):
   uv=np.mod(P[:,axes]/.022,2);uv=np.where(uv>1,2-uv,uv);grain+=blend[:,k,None]*self.image(self.grain,uv*np.array([self.grain.shape[1]-1,self.grain.shape[0]-1]))
  color=(1+(grain/self.mean-1)*.14)*np.array([224,168,135])/255
  # Modest coherent vascular color, independent of the painting camera.
  cheek=np.exp(-(((P[:,0]-.115)/.045)**2+((P[:,1]+.018)/.05)**2+((P[:,2]-.795)/.035)**2))+np.exp(-(((P[:,0]-.005)/.042)**2+((P[:,1]+.018)/.05)**2+((P[:,2]-.815)/.035)**2));color+=cheek[:,None]*np.array([.012,-.006,-.005])
  detail=np.clip(self.image(self.detail,xy),-1.8,.23);color*=np.exp(detail*w[:,None]);rough=np.full(len(P),.60)
  hx=np.array([330,342,355,370,390,415,440,470,510,555,605,650,692,729,767,789,803,815]);hy=np.array([490,465,410,337,292,253,227,261,289,302,309,298,314,305,314,374,438,491]);line=np.interp(xy[:,0],hx,hy);front_hair=(xy[:,1]<line)&(xy[:,0]>=330)&(xy[:,0]<=815);back_line=.787-.08*(P[:,0]-.035);back_hair=P[:,2]>back_line;is_hair=np.where(visible,front_hair,back_hair)
  # Both physical ear volumes stay skin, including rear surfaces hidden in the front plate.
  ear=np.zeros(len(P),bool)
  for c,r in [([.177,.083,.821],[.035,.038,.054]),([-.052,.043,.846],[.032,.034,.052])]:ear|=np.sum(((P-np.array(c))/np.array(r))**2,1)<1.
  is_hair&=~ear;color[is_hair]=hair[is_hair];rough[is_hair]=.56;color[ear]+=np.array([.012,-.010,-.008])
  neck_r=np.sqrt(((P[:,0]-.035)/.092)**2+((P[:,1]-.045)/.075)**2);collar_z=.666+.13*(P[:,1]-.02)+.035*(P[:,0]-.035);shirt=(P[:,2]<collar_z)&(neck_r<1.22);theta=np.arctan2((P[:,1]-.045)/.075,(P[:,0]-.035)/.092);rib=1+.07*np.cos(theta*72);color[shirt]=np.array([.12,.13,.12])*rib[shirt,None];rough[shirt]=.88
  cloth=(P[:,2]<.73)&(neck_r>=1.22);color[cloth]=source[cloth];rough[cloth]=.85
  return np.clip(color,0,1),rough
