"""Decisive visual reset: human-scale uncompressed anatomy and a natural palm-up root."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/build_openhand_thumb3.py').read_text()
code=code.replace("angles={1:[0,6,4],2:[32,58,32],3:[32,58,32],4:[32,58,32],5:[38,65,38]}","angles={1:[0,8,5],2:[42,65,30],3:[42,65,30],4:[42,65,30],5:[45,70,35]}")
code=code.replace('math.radians(-42.9718)','math.radians(-25)').replace('math.radians(-26.6061)','math.radians(0)').replace('math.radians(45.0001)','math.radians(0)')
code=code.replace('scale=np.array([.107,.102,.109])','scale=np.array([.1183,.1183,.1183])').replace('world[:,2]*=1-.14*np.clip((world[:,0]-.7)/.5,0,1);','')
code=code.replace('o.location=(.002810508,-.000833660,.006596714)','o.location=(0.,0.,0.)')
start=code.index('root=np.array(');end=code.index('o.matrix_world=Matrix(root.tolist());',start);code=code[:start]+'root=np.eye(4)\n'+code[end:]
code=code.replace('[-42.9718,-26.6061,45.0001]','[-25,0,0]').replace('openhand_thumb3','openhand_reset216')
code=code.replace("'status':'New anatomical hand seed; root orientation is a context study. Self-intersections, cap UV overlap, thumb pose, painting and cuff contact are not cleared'","'uniform_body_calibrated_scale':.1183,'distal_transverse_compression_removed':True,'inherited_root_rotation_removed':True,'status':'Rejected193 hand reset: uncompressed anatomy at body-consistent scale, moderate thumb opposition without forced axial roll, and native palm-up root. Visual source/reference comparison comes before adoption; self/contact/paint checks remain.'")
exec(compile(code,'build_openhand_reset216','exec'))
