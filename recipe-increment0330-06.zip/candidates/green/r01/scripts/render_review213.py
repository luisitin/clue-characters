"""Current user-requested WIP review cameras; actual materials and complete geometry."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/render_exact.py').read_text()
needle='target,scale,angle,elev=regions[tag];';extra="regions['body_top']=((0,0,0),1.30,0,50)\nregions['body_under']=((0,0,0),1.30,0,-50)\n"
assert code.count(needle)==1;code=code.replace(needle,extra+needle);exec(compile(code,'render_review213','exec'))
