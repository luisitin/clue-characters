import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/stitch_export_face234.py').read_text().replace('Green_full_head211.glb','Green_full_reset231.glb').replace('face232','hand241').replace('face233_tiles','hand242_tiles').replace('Skin234','Skin243').replace('albedo234','albedo243')
start=code.index('# A restrained warm wet margin');end=code.index("out=R/'Green_full_face234.glb'",start);code=code[:start]+code[end:]
code=code.replace("mat.pop('occlusionTexture',None);", "mat.pop('occlusionTexture',None);mat.pop('normalTexture',None);")
code=code.replace('Green_full_face234.glb','Green_full_hand243.glb').replace('face234.json','hand243.json');exec(compile(code,'export_hand243','exec'))
