#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for row in 0 512 1024 1536; do
 bash "$R/scripts/run_heavy_stage.sh" "hand270_$row" python "$R/scripts/bake_hand270_tile.py" hand "$row" > "$R/logs/hand270_$row.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" hand271 python "$R/scripts/export_hand271.py" > "$R/logs/hand271.log" 2>&1
for spec in 'openhand_top unlit' 'openhand_angle_-11 paint' 'openhand_top paint' 'openhand_angle_79 paint'; do
 read -r tag mode <<< "$spec"
 bash "$R/scripts/run_heavy_stage.sh" "hand271_${tag}_$mode" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_hand264.py" -- "$R/Green_full_hand271.glb" "$R/renders/full_hand271" "$tag" "$mode" 1024 > "$R/logs/hand271_${tag}_$mode.log" 2>&1
done
