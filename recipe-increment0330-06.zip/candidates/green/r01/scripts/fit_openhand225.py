"""Fit whole-hand placement to explicit original-source gesture anchors, without bone changes."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R.parents[2]/'shared_sources/makehuman/scripts'));from load_donor import load_donor
D=load_donor();DV=D['positions'];DF=D['faces'];DG=D['face_group'];z=np.load(R/'audit/openhand_reset216_binding.npz');a={k:z[k]for k in z.files};z.close();ids=a['donor_vertex_ids'];B=a['native_basis'];OB=a['world_basis'];scale=a['scale'];anchor=a['anchor'];w=(a['posed_lowres_local']*scale)@OB.T;tree=cKDTree(DV[ids])
def joint(n):return DV[np.unique(np.concatenate([DF[i]for i in np.flatnonzero(DG==n)]))].mean(0)
tip=[]
for k in range(1,6):
 p=joint(f'joint-l-finger-{k}-4');dist,ix=tree.query(p,k=8);tip.append(w[ix].mean(0))
q=np.vstack([np.zeros(3),tip]);targets=np.array([[356,428],[297,378],[302,402],[313,414],[327,424],[342,428]],float);unc=np.array([4,3,4,4,4,4],float)
meta=json.loads((R/'renders/source_normalized/body_angle_0_paint.json').read_text());C=np.array(meta['camera_world_matrix']);s=meta['ortho_scale'];res=meta['resolution'][0]
def project(P):
 p=(P-C[:3,3])@C[:3,:3];return np.column_stack([p[:,0]/s+.5,.5-p[:,1]/s])*res
def evaluate(x):
 rot=Rotation.from_rotvec(x[:3]).as_matrix();t=anchor+np.array([x[3],0,x[4]]);P=q@rot.T+t;normal=rot@OB[:,1]
 return np.r_[((project(P)-targets)/unc[:,None]).ravel(),max(0,.65-normal@C[:3,2])*5,np.linalg.norm(x[:3])*.04]
starts=[np.zeros(5)]
for x in [0,1.0,-1.0,2.0,-2.0]:
 for y in [-1.5,0,1.5]:starts.append(np.array([x,y,0,0,0]))
fits=[least_squares(evaluate,x,max_nfev=250)for x in starts];fit=min(fits,key=lambda f:np.sum(f.fun*f.fun));rot=Rotation.from_rotvec(fit.x[:3]).as_matrix();translation=anchor+np.array([fit.x[3],0,fit.x[4]])-rot@anchor
# Coordinates are stored in glTF axes; apply one rigid node transform only.
convert=np.array([[1,0,0],[0,0,1],[0,-1,0]],float);RG=convert.T@rot@convert;TG=convert.T@translation
src=R/'Green_openhand_reset216_painted98.glb';j,b,A=read_glb(src);node=next(n for n in j['nodes']if'mesh'in n)
for key in ['rotation','scale','translation','matrix']:node.pop(key,None)
M=np.eye(4);M[:3,:3]=RG;M[:3,3]=TG;node['matrix']=M.T.ravel().tolist();node['name']='Green natural anatomical hand source-gesture fit225'
out=R/'Green_openhand_fit225.glb';write_glb(out,j,b)
newanchor=rot@anchor+translation;axis=((joint('joint-l-hand')-joint('joint-l-elbow'))@B.T*scale)@OB.T;axis=rot@axis;axis/=np.linalg.norm(axis)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_anchor_image':str(R/'renders/source_normalized/body_angle_0_paint.png'),'manual_source_pixel_targets':targets.tolist(),'manual_uncertainty_pixels':unc.tolist(),'labels':['wrist','thumb','index','middle','ring','little'],'fitted_pixels':project(q@rot.T+newanchor).tolist(),'residual_pixels':(project(q@rot.T+newanchor)-targets).tolist(),'world_rotation':rot.tolist(),'world_translation':translation.tolist(),'wrist_world':newanchor.tolist(),'distal_forearm_axis_world':axis.tolist(),'projected_palmar_facing':float((rot@OB[:,1])@C[:3,2]),'geometry_normals_UV_maps_held':True,'status':'Unadopted rigid whole-hand fit to uncertain source-image pad anchors. No bone lengths/scales or digit poses altered. Actual complete-context gesture decides; source is not anatomical ground truth.'}
(R/'audit/openhand_fit225.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
