#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for row in 0 512 1024 1536; do
 bash "$R/scripts/run_heavy_stage.sh" "hand251_$row" python "$R/scripts/bake_hand251_tile.py" hand "$row" > "$R/logs/hand251_$row.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" hand252 python "$R/scripts/export_hand252.py" > "$R/logs/hand252.log" 2>&1
for tag in openhand_top openhand_angle_-11 openhand_angle_79; do
 bash "$R/scripts/run_heavy_stage.sh" "hand252_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_hand252.glb" "$R/renders/full_hand252" "$tag" paint 1024 > "$R/logs/hand252_$tag.log" 2>&1
done
