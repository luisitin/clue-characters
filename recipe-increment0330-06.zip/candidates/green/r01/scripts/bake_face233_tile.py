"""Tile one unique head chart using visibility-weighted, linear-light five-view painting."""
import pathlib,sys,json,io,numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates
from glb_source import read_glb
from uv_raster import samples
R=pathlib.Path(__file__).resolve().parents[1];key=sys.argv[1];row=int(sys.argv[2]);report=json.loads((R/'audit/face232.json').read_text());d=report['targets'][key];res=d['resolution'];assert row%512==0
with np.load(R/'audit/face232_projection.npz')as z:a={k:z[k]for k in z.files}
with np.load(R/'audit'/f'face232_{key}.npz')as z:g={k:z[k]for k in z.files}
im=a['images'].astype('float32')/255;im=np.where(im<=.04045,im/12.92,((im+.055)/1.055)**2.4)
j,b,A=read_glb(R/'Green_full_head211.glb');mat=j['materials'][d['material']];tx=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tx.get('extensions',{}).get('EXT_texture_webp',{}).get('source',tx.get('source'));bv=j['bufferViews'][j['images'][ii]['bufferView']];old=np.array(Image.open(io.BytesIO(bytes(b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]))).convert('RGB').resize((res,res),Image.Resampling.LANCZOS));out=old[row:row+512].copy();valid=np.zeros((512,res),'uint8');painted=np.zeros_like(valid);total=changed=0
for fi,yy,xx,bc in samples(g['UV'],res,row,row+512):
 P=bc@g['P'][fi];N=bc@g['N'][fi];N/=np.linalg.norm(N,axis=1)[:,None];colors=np.zeros((len(P),3));weight=np.zeros(len(P));best=np.zeros(len(P))
 for k,C in enumerate(a['cameras']):
  pc=(P-C[:3,3])@C[:3,:3];xy=np.column_stack([pc[:,0]/a['scales'][k]+.5,.5-pc[:,1]/a['scales'][k]])*1024-.5;inside=(xy[:,0]>=1)&(xy[:,0]<1022)&(xy[:,1]>=1)&(xy[:,1]<1022);ix=np.clip(np.rint(xy[:,0]).astype(int),0,1023);iy=np.clip(np.rint(xy[:,1]).astype(int),0,1023);facing=np.maximum(N@C[:3,2],0);visible=(-pc[:,2]<=a['depths'][k,iy,ix]+.0012)&np.isfinite(a['depths'][k,iy,ix]);guard=np.clip((a['guards'][k,iy,ix]-1)/3,0,1);w=facing**6*visible*inside*guard
  # Front plate owns expression detail; underside chiefly owns neck/chin.
  if k==3:w*=np.clip((.79-P[:,2])/.035,0,1)
  c=np.column_stack([map_coordinates(im[k,:,:,ch],xy[:,::-1].T,order=1,mode='nearest')for ch in range(3)]);colors+=c*w[:,None];weight+=w;best=np.maximum(best,w)
 good=weight>1e-5;colors[good]/=weight[good,None];blend=np.clip((best-.005)/.035,0,1);blend=blend*blend*(3-2*blend);prior=old[row+yy,xx].astype(float)/255;prior=np.where(prior<=.04045,prior/12.92,((prior+.055)/1.055)**2.4);color=prior*(1-blend[:,None])+colors*blend[:,None];color=np.where(color<=.0031308,color*12.92,1.055*np.maximum(color,0)**(1/2.4)-.055);out[yy,xx]=np.round(np.clip(color,0,1)*255).astype('uint8');valid[yy,xx]=255;painted[yy,xx]=np.round(blend*255).astype('uint8');total+=len(yy);changed+=int(np.count_nonzero(blend>.5))
folder=R/'textures/face233_tiles';folder.mkdir(exist_ok=True);Image.fromarray(out).save(folder/f'{key}_{row}.png');Image.fromarray(valid).save(folder/f'{key}_{row}_valid.png');Image.fromarray(painted).save(folder/f'{key}_{row}_painted.png');(folder/f'{key}_{row}.json').write_text(json.dumps({'component':key,'row':row,'resolution':res,'occupied_texels':total,'majority_painted_texels':changed,'scope':'Actual held UVs and surface positions; five saved cameras, source depth and normal-facing weights. No geometry change.'},indent=2));print(key,row,total,changed,flush=True)
