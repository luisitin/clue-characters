"""Use every verified visible paint sample; do not turn view-occlusion footprints into flat-color decals."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/bake_hand242_tile.py').read_text();code=code.replace("code=code.replace(\"prior=old[row+yy,xx].astype(float)/255;\",", "code=code.replace(\"good=weight>1e-5\",\"good=weight>1e-12\").replace(\"blend=np.clip((best-.005)/.035,0,1);blend=blend*blend*(3-2*blend)\",\"blend=good.astype(float)\").replace(\"hand242_tiles\",\"hand251_tiles\")\ncode=code.replace(\"prior=old[row+yy,xx].astype(float)/255;\",")
exec(compile(code,'bake_hand251_tile','exec'))
