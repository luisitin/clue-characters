import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/bake_face233_tile.py').read_text().replace('face232','hand241').replace('Green_full_head211.glb','Green_full_reset231.glb').replace('face233_tiles','hand270_tiles')
needle="im=a['images'].astype('float32')/255;im=np.where(im<=.04045,im/12.92,((im+.055)/1.055)**2.4)"
replacement=needle+"\nwith np.load(R/'audit/hand269_calibration.npz')as z:cal={k:z[k]for k in z.files}\nim=np.clip(im*np.exp(cal['view_log_gain'])[:,None,None,:],0,1)"
assert needle in code;code=code.replace(needle,replacement).replace("out=old[row:row+512].copy();","old=np.array(Image.open(R/'textures/Green_Hand263_BaseColor_2K.png').convert('RGB'));out=old[row:row+512].copy();")
code=code.replace('w=facing**6*visible*inside*guard',"distance=bc@cal['visibility_distance_corner'][k,fi];fade=np.clip(distance/.006,0,1);fade=fade*fade*(3-2*fade);w=facing**4*visible*inside*guard*fade")
code=code.replace("if k==3:w*=np.clip((.79-P[:,2])/.035,0,1)","if False:pass").replace('good=weight>1e-5','good=weight>1e-12').replace('blend=np.clip((best-.005)/.035,0,1);blend=blend*blend*(3-2*blend)','blend=good.astype(float)');exec(compile(code,'bake_hand270_tile','exec'))
