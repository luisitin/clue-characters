"""Label the already-rendered rejected193 snapshot; never alter its model/images."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/assemble_review214.py').read_text()
replacements={
 'Green_WIP_v193':'Green_REJECTED_v193',
 'GREEN | CURRENT WIP | v193':'GREEN | REJECTED v193 | COMPARISON ONLY',
 'Eight views from the same complete model. Visible unfinished areas are retained.':'Rejected snapshot retained for comparison. These images are not an approval request.',
 'Top, underside and face closeups from the same current draft.':'Rejected baseline: hands, face and skin require a substantial rebuild.',
 'Visible work remaining':'Repair priorities',
 'Unify outfit colors and fabric':'Rebuild natural-looking hands',
 'Clean face, neck and hair paint':'Replace the facial artifacts',
 'Refine expression and face detail':'Restore convincing skin',
 'Rebuild the footwear':'Correct outfit and footwear',
 'Check the complete model again':'Compare the rebuilt whole model',
 'Unapproved draft':'Rejected baseline',
 "'version':'WIP v193'":"'version':'Rejected v193'",
 "'status':'Unapproved current work in progress'":"'status':'Rejected baseline retained for historical comparison'",
 'GREEN | CURRENT WORK IN PROGRESS, v193':'GREEN | REJECTED BASELINE, v193',
 'These are actual renders of one complete model. This is an unfinished, unapproved draft.':'These are screenshots of the rejected version, kept for historical comparison. They are not being presented for acceptance.',
 'Eye expression and physical face detail remain under review.':'The face and hands were rejected and will be rebuilt or rolled back where weaker than the reference.'
}
for a,b in replacements.items():
 assert a in code,a
 code=code.replace(a,b)
exec(compile(code,'assemble_rejected_review215','exec'))
