"""Rebuild the complete forearm around the restored palm-up anatomical placement."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/build_sleeve69.py').read_text()
start=code.index("h=np.load(R/'audit/hand_forearm6_binding.npz')")
end=code.index(";turn=np.cross(axis,endaxis)",start)
replacement="""h=np.load(R/'audit/openhand_reset216_binding.npz');B=h['native_basis'];OB=h['world_basis'];bodyScale=h['scale'];endc=h['anchor'].copy()
sys.path.insert(0,str(R.parents[2]/'shared_sources/makehuman/scripts'));from load_donor import load_donor
D=load_donor();DV=D['positions'];DF=D['faces'];DG=D['face_group']
def joint(name):return DV[np.unique(np.concatenate([DF[i]for i in np.flatnonzero(DG==name)]))].mean(0)
endaxis=((joint('joint-l-hand')-joint('joint-l-elbow'))@B.T*bodyScale)@OB.T;endaxis/=np.linalg.norm(endaxis)"""
code=code[:start]+replacement+code[end:]
code=code.replace('Green_openhand_depth68.glb','Green_openhand_reset216_painted98.glb')
code=code.replace('sleeve69','sleeve219')
exec(compile(code,'build_sleeve219','exec'))
