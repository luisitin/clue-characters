import pathlib,sys
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/prepare_grip_paint97.py').read_text().replace("else'Green_grip88'","else'Green_openhand_reset216'").replace("neutral('Green_grip84_neutral','grip84_neutral_binding.npz')","neutral('Green_openhand_rest217','openhand_rest217_binding.npz')");exec(compile(code,'prepare_openhand_paint218','exec'))
