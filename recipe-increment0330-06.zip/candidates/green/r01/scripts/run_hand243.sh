#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for row in 0 512 1024 1536; do
 bash "$R/scripts/run_heavy_stage.sh" "hand242_$row" python "$R/scripts/bake_hand242_tile.py" hand "$row" > "$R/logs/hand242_$row.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" hand243 python "$R/scripts/export_hand243.py" > "$R/logs/hand243.log" 2>&1
for tag in openhand_angle_-11 openhand_angle_79 openhand_top openhand_under body_angle_0; do
 bash "$R/scripts/run_heavy_stage.sh" "hand243_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_hand243.glb" "$R/renders/full_hand243" "$tag" paint 1024 > "$R/logs/hand243_$tag.log" 2>&1
done
