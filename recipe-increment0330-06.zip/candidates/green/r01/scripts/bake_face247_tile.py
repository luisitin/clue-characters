"""Give front-visible facial features one registered painting owner; side plates only supply lateral surfaces."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/bake_face233_tile.py').read_text()
needle="colors=np.zeros((len(P),3));weight=np.zeros(len(P));best=np.zeros(len(P))"
replacement=needle+"""
 C0=a['cameras'][0];pc0=(P-C0[:3,3])@C0[:3,:3];xy0=np.column_stack([pc0[:,0]/a['scales'][0]+.5,.5-pc0[:,1]/a['scales'][0]])*1024-.5;x0=np.clip(np.rint(xy0[:,0]).astype(int),0,1023);y0=np.clip(np.rint(xy0[:,1]).astype(int),0,1023);visible0=(-pc0[:,2]<=a['depths'][0,y0,x0]+.0012)&np.isfinite(a['depths'][0,y0,x0]);frontown=np.clip((N@C0[:3,2]-.02)/.10,0,1)*visible0*np.clip((a['guards'][0,y0,x0]-1)/3,0,1)
"""
assert code.count(needle)==1;code=code.replace(needle,replacement)
needle='w=facing**6*visible*inside*guard'
replacement=needle+"""
  if k==0:w=np.maximum(w,frontown)
  else:w*=1-frontown
  if k==1:w*=np.clip((430-xy[:,0])/35,0,1)
  if k==2:w*=np.clip((xy[:,0]-590)/35,0,1)
"""
code=code.replace(needle,replacement).replace("if k==3:w*=np.clip((.79-P[:,2])/.035,0,1)","if k==3:w*=np.clip((.727-P[:,2])/.015,0,1)")
needle="prior=old[row+yy,xx].astype(float)/255;prior=np.where"
replacement="prior=old[row+yy,xx].astype(float)/255;skin_hair=(prior[:,0]-prior[:,1]>.012)&(prior[:,0]-prior[:,2]>.020);blend*=skin_hair;prior=np.where"
assert needle in code;code=code.replace(needle,replacement).replace('face233_tiles','face247_tiles')
exec(compile(code,'bake_face247_tile','exec'))
