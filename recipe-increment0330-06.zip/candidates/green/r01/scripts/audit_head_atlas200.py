import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_head_atlas197.py').read_text().replace('head_atlas196_binding','head_atlas199_binding').replace('head_atlas197_v4','head_atlas200_v4').replace('UV-only196 proposal','UV-only199 proposal');exec(compile(code,'audit_head_atlas200','exec'))
