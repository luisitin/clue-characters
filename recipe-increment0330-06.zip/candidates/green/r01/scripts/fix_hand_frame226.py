"""Encode the fitted Blender-world rigid transform in glTF axes, with explicit point equivalence."""
import pathlib,json,hashlib,numpy as np
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];r=json.loads((R/'audit/openhand_fit225.json').read_text());rot=np.array(r['world_rotation']);t=np.array(r['world_translation']);C=np.array([[1,0,0],[0,0,1],[0,-1,0]],float)
src=R/'Green_openhand_reset216_painted98.glb';j,b,A=read_glb(src);n=next(n for n in j['nodes']if'mesh'in n);M=np.eye(4);M[:3,:3]=C@rot@C.T;M[:3,3]=C@t
for key in ['rotation','scale','translation','matrix']:n.pop(key,None)
n['matrix']=M.T.ravel().tolist();n['name']='Green natural anatomical hand source-gesture fit226'
p=A(j['meshes'][n['mesh']]['primitives'][0]['attributes']['POSITION']);expected=((p@C)@rot.T+t)@C.T;actual=p@M[:3,:3].T+M[:3,3];error=float(abs(expected-actual).max());assert error<1e-12
out=R/'Green_openhand_fit226.glb';write_glb(out,j,b);r.update(candidate_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),axis_conversion_max_error=error,prior225_axis_encoding_superseded=True);(R/'audit/openhand_fit226.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
