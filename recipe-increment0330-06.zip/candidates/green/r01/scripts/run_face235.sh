#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for component in head forehead eye0 eye1; do
 res=2048; if [[ "$component" = head ]]; then res=4096; fi
 for ((row=0;row<res;row+=512)); do
  bash "$R/scripts/run_heavy_stage.sh" "face233_${component}_${row}" python "$R/scripts/bake_face233_tile.py" "$component" "$row" > "$R/logs/face233_${component}_${row}.log" 2>&1
 done
done
bash "$R/scripts/run_heavy_stage.sh" face234 python "$R/scripts/stitch_export_face234.py" > "$R/logs/face234.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" optics236 python "$R/scripts/repaint_optics236.py" > "$R/logs/optics236.log" 2>&1
for tag in head_angle_0 head_angle_-11 head_angle_270 head_angle_90 head_under head_angle_180; do
 bash "$R/scripts/run_heavy_stage.sh" "face236_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_face236.glb" "$R/renders/full_face236" "$tag" paint 1024 > "$R/logs/face236_$tag.log" 2>&1
done
