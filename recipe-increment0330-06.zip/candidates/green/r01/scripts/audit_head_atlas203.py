import pathlib,json,numpy as np
from uv_shared_edge_overlaps201 import audit_shared_uv_edges
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_head_atlas197.py').read_text().replace('head_atlas196_binding','head_atlas202_binding').replace('head_atlas197_v4','head_atlas203_v4').replace('UV-only196 proposal','UV-only202 proposal');exec(compile(code,'audit_head_atlas203','exec'))
with np.load(R/'audit/head_atlas202_binding.npz')as z:uv=z['UV_CORNER'].copy()
result=audit_shared_uv_edges(uv);(R/'audit/head_atlas203_shared.json').write_text(json.dumps(result,indent=2));assert not result['same_side_positive_area_overlap_pairs'];print({k:len(v)if isinstance(v,list)else v for k,v in result.items()},flush=True)
