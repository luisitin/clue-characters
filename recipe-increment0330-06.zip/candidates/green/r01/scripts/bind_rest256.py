"""Recover exact native anatomy per held posed triangle corner for continuous skin fields."""
import pathlib,sys,json,hashlib,numpy as np
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
D=load_donor();wrist=D['positions'][np.unique(np.concatenate([D['faces'][i]for i in np.flatnonzero(D['face_group']=='joint-l-hand')]))].mean(0)
with np.load(R/'audit/openhand_rest217_binding.npz')as z:bind={k:z[k]for k in z.files}
def read(stem):
 j,b,A=read_glb(R/(stem+'.glb'));node=next(n for n in j['nodes']if'mesh'in n);pr=j['meshes'][node['mesh']]['primitives'][0];return j,A,pr
j,A,p=read('Green_openhand_rest217');P=A(p['attributes']['POSITION']);N=A(p['attributes']['NORMAL']);UV=A(p['attributes']['TEXCOORD_0']);W=P[:,[0,2,1]]*[1,-1,1];NR=((W-bind['anchor'])@bind['world_basis']/bind['scale'])@bind['native_basis']+wrist;RN=((N[:,[0,2,1]]*[1,-1,1])@bind['world_basis'])@bind['native_basis'];RN/=np.linalg.norm(RN,axis=1)[:,None];table={}
for i,u in enumerate(UV.astype('float32')):
 key=u.tobytes()
 if key in table:assert np.linalg.norm(table[key][0]-NR[i])<1e-5
 else:table[key]=(NR[i],RN[i])
j,A,p=read('Green_openhand_reset216');P=A(p['attributes']['POSITION']).astype('float32');UV=A(p['attributes']['TEXCOORD_0']).astype('float32');posed={}
for pp,u in zip(P,UV):
 rr,nn=table[u.tobytes()];key=pp.tobytes()
 if key in posed:assert np.linalg.norm(posed[key][0]-rr)<1e-5
 else:posed[key]=(rr,nn)
src=R/'Green_full_reset231.glb';j,b,A=read_glb(src);pr=j['meshes'][j['nodes'][1]['mesh']]['primitives'][0];F=A(pr['indices']).astype(np.int64).reshape(-1,3);P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']);T=A(pr['attributes']['TANGENT']);UV=A(pr['attributes']['TEXCOORD_0']);RR=np.array([posed[p.tobytes()][0]for p in P]);NN=np.array([posed[p.tobytes()][1]for p in P]);np.savez_compressed(R/'audit/hand256_native_binding.npz',REST=RR[F],REST_N=NN[F],P=P[F],N=N[F],T=T[F],UV=UV[F]);pose={'scale':float(bind['scale'][0]),'native_forward':bind['native_basis'][0].tolist(),'native_thumbward':bind['native_basis'][2].tolist(),'native_anatomical_dorsal':(-bind['native_basis'][1]).tolist(),'donor_side':'L'};rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'triangles':len(F),'exact_pose_POSITION_keys_matched':len(P),'native_anatomy_binding':'Native corner UV from unchanged neutral217 to posed216, then exact local POSITION into held231. No shape or UV changed.','pose':pose};(R/'audit/hand256.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
