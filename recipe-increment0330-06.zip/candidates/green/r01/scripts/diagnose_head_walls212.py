"""Read-only source-family and backing attribution for three invalid native tangent corners."""
import pathlib,sys,json,hashlib,collections,numpy as np
from scipy.spatial.transform import Rotation
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_full_context193.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype(float);N=A(pr['attributes']['NORMAL']).astype(float);F=A(pr['indices']).astype(np.int64).reshape(-1,3);nd=j['nodes'][0];scale=np.array(nd['scale']);tr=np.array(nd['translation']);W=(P*scale+tr)[:,[0,2,1]]*[1,-1,1];WN=(N/scale)[:,[0,2,1]]*[1,-1,1];WN/=np.linalg.norm(WN,axis=1)[:,None];T=W[F];GN=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);GN/=np.maximum(np.linalg.norm(GN,axis=1)[:,None],1e-30);_,g=np.unique(W,axis=0,return_inverse=True);G=g[F];edges=collections.defaultdict(list)
for fi,f in enumerate(G):
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(c))))].append(fi)
adj=collections.defaultdict(set)
for faces in edges.values():
 for fi in faces:adj[fi].update(faces)
allP=[];allF=[];owners=[];off=0
for ni,node in enumerate(j['nodes']):
 if'mesh'not in node:continue
 if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
 else:
  M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
 for pi,p0 in enumerate(j['meshes'][node['mesh']]['primitives']):
  p=A(p0['attributes']['POSITION']).astype(float);f=A(p0['indices']).astype(np.int64).reshape(-1,3);w=(p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];keep=np.flatnonzero(w[f][:,:,2].max(1)>.65)
  if not len(keep):continue
  used,inv=np.unique(f[keep],return_inverse=True);allP.append(w[used]);allF.append(inv.reshape(-1,3)+off);owners.extend([[ni,pi,int(k)]for k in keep]);off+=len(used)
allP=np.vstack(allP);allF=np.vstack(allF);owners=np.array(owners);reports=[];meta=json.loads((R/'renders/full_context173/head_angle_-11_paint.json').read_text());C=np.array(meta['camera_world_matrix']);res=meta['resolution'][0];orth=meta['ortho_scale']
for seed in [15088,17922,54581]:
 center=T[seed].mean(0);normal=GN[seed];family={seed};stack=[seed]
 while stack:
  fi=stack.pop()
  for other in adj[fi]:
   if other in family:continue
   if abs(GN[other]@normal)<.999999:continue
   if abs((T[other]-center)@normal).max()>2e-7:continue
   if np.linalg.norm(T[other]-center,axis=1).max()>.020:continue
   family.add(other);stack.append(other)
 assert len(family)<200
 family=sorted(family);remove=(owners[:,0]==0)&(owners[:,1]==0)&np.isin(owners[:,2],family);keep=np.flatnonzero(~remove);used,inv=np.unique(allF[keep],return_inverse=True);tree=BVHTree.FromPolygons(allP[used].tolist(),inv.reshape(-1,3).tolist(),all_triangles=True);rows=[]
 for fi in family:
  samples=[]
  for a in range(1,12):
   for c in range(1,12-a):samples.append(T[fi,0]*(a/12)+T[fi,1]*(c/12)+T[fi,2]*(1-(a+c)/12))
  summary=[]
  for side in [-1,1]:
   hits=[]
   for q in samples:
    origin=q+GN[fi]*side*.0002;direction=-GN[fi]*side;hit,hn,hf,d=tree.ray_cast(Vector(origin),Vector(direction),.004)
    if hit is not None:hits.append({'distance_from_plane_m':float(d-.0002),'front_facing':float(-hn.dot(Vector(direction)))>0,'owner':owners[keep[hf]].tolist()})
   summary.append({'normal_side':side,'samples':len(samples),'hits':len(hits),'front_hits':sum(x['front_facing']for x in hits),'within_0_1mm':sum(abs(x['distance_from_plane_m'])<.0001 for x in hits),'distance_min_max_m':[min((x['distance_from_plane_m']for x in hits),default=None),max((x['distance_from_plane_m']for x in hits),default=None)]})
  rows.append({'face':fi,'stored_corner_normal_to_geometric_dot':(WN[F[fi]]@GN[fi]).tolist(),'backing':summary})
 pixel=[res*(.5+(center-C[:3,3])@C[:3,0]/orth),res*(.5-(center-C[:3,3])@C[:3,1]/orth)];reports.append({'seed':seed,'family':family,'world_center':center.tolist(),'front_pixel':pixel,'world_bounds':[T[family].reshape(-1,3).min(0).tolist(),T[family].reshape(-1,3).max(0).tolist()],'faces':rows})
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'families':reports,'scope':'Read-only exact source topology and normal-axis backing samples, excluding each full coplanar family. Neither sampled backing nor poor stored normals alone authorizes removal or flattening.'};(R/'audit/head_walls212.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
