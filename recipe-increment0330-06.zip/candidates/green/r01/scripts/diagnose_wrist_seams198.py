"""Measure actual skin-atlas color disagreements across continuous geometric edges."""
import pathlib,json,hashlib,io,collections,numpy as np
from PIL import Image
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist191_painted_valid.glb';j,b,A=read_glb(src);M=np.array(j['nodes'][0]['matrix']).reshape((4,4),order='F');fit=json.loads((R/'audit/grip_fit143.json').read_text());wrist=np.array(fit['wrist_world']);prox=np.array(fit['native_forearm_proximal_world']);P=[];N=[];UV=[];F=[];owner=[];images=[];off=0
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 p=A(pr['attributes']['POSITION']);n=A(pr['attributes']['NORMAL']);uv=A(pr['attributes']['TEXCOORD_0']);f=A(pr['indices']).astype(np.int64).reshape(-1,3);P.append(p);N.append(n);UV.append(uv);F.append(f+off);owner.extend([pi]*len(f));off+=len(p);mat=j['materials'][pr['material']];t=j['textures'][mat['pbrMetallicRoughness']['baseColorTexture']['index']];im=j['images'][t['source']];v=j['bufferViews'][im['bufferView']];images.append(np.array(Image.open(io.BytesIO(bytes(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]))).convert('RGB')).astype(float))
P=np.vstack(P);N=np.vstack(N);UV=np.vstack(UV);F=np.vstack(F);owner=np.array(owner);W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];U,g=np.unique(P,axis=0,return_inverse=True);edges=collections.defaultdict(list)
for fi,f in enumerate(F):
 for a,c in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(g[a]),int(g[c]))))].append((fi,int(a),int(c)))
def sample(uv,pi):
 im=images[pi];p=np.clip(uv*np.array([im.shape[1],im.shape[0]])-.5,0,np.array([im.shape[1]-1.00001,im.shape[0]-1.00001]));i=np.floor(p).astype(int);f=p-i;return (1-f[:,1,None])*((1-f[:,0,None])*im[i[:,1],i[:,0]]+f[:,0,None]*im[i[:,1],i[:,0]+1])+f[:,1,None]*((1-f[:,0,None])*im[i[:,1]+1,i[:,0]]+f[:,0,None]*im[i[:,1]+1,i[:,0]+1])
meta=json.loads((R/'renders/full_context193/grip_cuff165_front_unlit.json').read_text());C=np.array(meta['camera_world_matrix']);scale=meta['ortho_scale'];res=meta['resolution'][0];rows=[]
for key,pair in edges.items():
 if len(pair)!=2:continue
 fa,a,c=pair[0];fb,x,y=pair[1]
 if g[x]!=g[a]:x,y=y,x
 assert g[a]==g[x]and g[c]==g[y]
 middle=(W[a]+W[c])/2;q=float((middle-wrist)@prox)
 if q<-.04 or q>.047:continue
 if owner[fa]==owner[fb]and np.array_equal(UV[[a,c]],UV[[x,y]]):continue
 ts=np.array([.1,.3,.5,.7,.9]);ca=sample(UV[a]*(1-ts[:,None])+UV[c]*ts[:,None],owner[fa]);cb=sample(UV[x]*(1-ts[:,None])+UV[y]*ts[:,None],owner[fb]);contrast=float(abs(ca-cb).max());nerr=float(max(np.linalg.norm(N[a]-N[x]),np.linalg.norm(N[c]-N[y])));pixel=[res*(.5+(middle-C[:3,3])@C[:3,0]/scale),res*(.5-(middle-C[:3,3])@C[:3,1]/scale)]
 rows.append({'faces':[int(fa),int(fb)],'primitives':[int(owner[fa]),int(owner[fb])],'world_edge':[W[a].tolist(),W[c].tolist()],'world_midpoint':middle.tolist(),'proximal_q_m':q,'maximum_sRGB_channel_difference_255':contrast,'normal_difference':nerr,'projected_pixel':pixel,'UV_edges':[UV[[a,c]].tolist(),UV[[x,y]].tolist()]})
rows.sort(key=lambda x:x['maximum_sRGB_channel_difference_255'],reverse=True);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'camera_sha256':meta['source_sha256'],'seams':rows,'scope':'Read-only exact paired physical-edge albedo test within40mm distal and47mm proximal to the native wrist. Skin/nail semantics outside this interval are excluded; no color correction or geometric change.'};(R/'audit/wrist_seams198.json').write_text(json.dumps(report,indent=2));print({'seam_edges':len(rows),'above_2_RGB':sum(x['maximum_sRGB_channel_difference_255']>2 for x in rows),'worst':rows[:8]},flush=True)
