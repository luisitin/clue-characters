"""Use the valid glTF default sampler for the newly added hand maps."""
import pathlib,json,hashlib,copy
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist189_painted.glb';j,b,A=read_glb(src);old=copy.deepcopy(j);assert len(j.get('samplers',[]))==0;changed=[]
for ti,t in enumerate(j.get('textures',[])):
 if'sampler'in t:
  assert t['sampler']==0 and t.get('source',-1)>=len(j['images'])-3
  del t['sampler'];changed.append(ti)
assert len(changed)==3
out=R/'Green_grip_wrist191_painted_valid.glb';write_glb(out,j,b)
for key in ['nodes','meshes','accessors','bufferViews','materials','images']:assert old.get(key)==j.get(key)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'new_texture_indices_using_default_sampler':changed,'all_geometry_material_bindings_and_encoded_maps_exact':True,'reason':'The source hand had no explicit sampler table. Newly added textures incorrectly referenced sampler0; omission now selects the intended valid glTF default repeat/filter behavior.189/184 are not renderable baselines.'};(R/'audit/wrist_sampler191.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
