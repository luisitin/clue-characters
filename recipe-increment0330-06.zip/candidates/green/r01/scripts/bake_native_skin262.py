"""Bake one continuous native-anatomy skin field into the held unique hand atlas."""
import pathlib,sys,json,time,numpy as np
from PIL import Image
from uv_raster import samples
from native_skin_fields261 import SkinFields
R=pathlib.Path(__file__).resolve().parents[1];row=int(sys.argv[1]);S=2048;start=time.time()
with np.load(R/'audit/hand256_native_binding.npz')as z:g={k:z[k]for k in z.files}
pose=json.loads((R/'audit/hand256.json').read_text())['pose'];field=SkinFields(pose);ids=[];ys=[];xs=[];bcs=[]
for fi,y,x,bc in samples(g['UV'],S,row,row+512):ids.append(np.full(len(y),fi,dtype=np.int32));ys.append(y);xs.append(x);bcs.append(bc)
ids=np.concatenate(ids);y=np.concatenate(ys);x=np.concatenate(xs);bc=np.concatenate(bcs);out=np.zeros((512,S,3),'uint8');normal=np.full_like(out,[128,128,255]);orm=np.full_like(out,[255,150,0]);valid=np.zeros((512,S),'uint8');assert len(set(zip(y.tolist(),x.tolist())))==len(y),'UV overlap in actual retained hand chart'
E=g['P'][:,1:]-g['P'][:,0,None];ER=g['REST'][:,1:]-g['REST'][:,0,None];aa=np.sum(E[:,0]**2,1);bb=np.sum(E[:,0]*E[:,1],1);cc=np.sum(E[:,1]**2,1);det=aa*cc-bb*bb;assert det.min()>1e-22
maxslope=0.;nailtotal=0
for first in range(0,len(ids),32768):
 sl=slice(first,min(first+32768,len(ids)));fi=ids[sl];q=bc[sl];nr=np.einsum('ij,ijk->ik',q,g['REST'][fi]);rn=np.einsum('ij,ijk->ik',q,g['REST_N'][fi]);rn/=np.linalg.norm(rn,axis=1)[:,None];nn=np.einsum('ij,ijk->ik',q,g['N'][fi]);nn/=np.linalg.norm(nn,axis=1)[:,None];tt=np.einsum('ij,ijk->ik',q,g['T'][fi]);sg=np.where(tt[:,3]>=0,1.,-1.);tt=tt[:,:3];tt-=nn*np.sum(nn*tt,axis=1)[:,None];tt/=np.linalg.norm(tt,axis=1)[:,None];bt=np.cross(nn,tt)*sg[:,None]
 def rest_derivative(v):
  a=np.sum(v*E[fi,0],axis=1);b=np.sum(v*E[fi,1],axis=1);c0=(cc[fi]*a-bb[fi]*b)/det[fi];c1=(aa[fi]*b-bb[fi]*a)/det[fi];return ER[fi,0]*c0[:,None]+ER[fi,1]*c1[:,None]
 dt=rest_derivative(tt);db=rest_derivative(bt);eps=.0001;color,height,rough,nail=field.material(nr,rn);htp=field.material(nr+eps*dt,rn,False)[1];htm=field.material(nr-eps*dt,rn,False)[1];hbp=field.material(nr+eps*db,rn,False)[1];hbm=field.material(nr-eps*db,rn,False)[1];gx=(htp-htm)/(2*eps);gy=(hbp-hbm)/(2*eps);nt=np.column_stack([-gx,-gy,np.ones(len(gx))]);nt/=np.linalg.norm(nt,axis=1)[:,None];yy=y[sl];xx=x[sl];out[yy,xx]=np.round(np.clip(color,0,1)*255).astype('uint8');normal[yy,xx]=np.round((nt*.5+.5)*255).astype('uint8');orm[yy,xx,1]=np.round(rough*255).astype('uint8');valid[yy,xx]=255;maxslope=max(maxslope,float(np.sqrt(gx*gx+gy*gy).max()));nailtotal+=int(np.count_nonzero(nail>.5))
folder=R/'textures/hand262_tiles';folder.mkdir(exist_ok=True)
for key,a in [('BaseColor',out),('Normal',normal),('ORM',orm),('valid',valid)]:Image.fromarray(a).save(folder/f'{key}_{row}.png')
report={'row':row,'occupied_texels':len(ids),'UV_overlap':0,'nail_texels':nailtotal,'maximum_normal_slope':maxslope,'seconds':time.time()-start,'field':'Native rest-anatomy skin/nail/crease field; own AI skin microtexture with mirrored triplanar addressing. No camera-dependent color blending.','normal_basis':'Actual held exported native-Mikk tangent/sign. Height directional derivatives transported through each exact posed/rest triangle Jacobian, without PNG-V inversion.'};(folder/f'{row}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
