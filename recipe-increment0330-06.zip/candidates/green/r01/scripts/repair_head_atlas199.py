"""Keep healthy head charts; isolate a weighted cover of overlap pairs and unsampled faces."""
import pathlib,json,numpy as np
from uv_coverage import audit
R=pathlib.Path(__file__).resolve().parents[1]
with np.load(R/'audit/head_atlas196_binding.npz')as z:data={k:z[k]for k in z.files}
old=data['UV_CORNER'];uv=old.astype(float).copy();pre=json.loads((R/'audit/head_atlas196.json').read_text());cross=json.loads((R/'audit/head_atlas197_v4.json').read_text());pairs={tuple(sorted(x['faces']))for x in cross['positive_area_coplanar_pairs']};q=uv*2048;edge=q[:,1]-q[:,0];e2=q[:,2]-q[:,0];area=abs(edge[:,0]*e2[:,1]-edge[:,1]*e2[:,0])/2;moved=set(pre['checks']['2048']['missing_faces']+pre['checks']['4096']['missing_faces'])
remaining={x for x in pairs if not any(v in moved for v in x)}
while remaining:
 degree={}
 for pair in remaining:
  for fi in pair:degree[fi]=degree.get(fi,0)+1
 fi=max(degree,key=lambda x:(degree[x]/max(area[x],18),-x));moved.add(fi);remaining={x for x in remaining if fi not in x}
rects=[]
for fi in sorted(moved):
 t=q[fi];lengths=np.linalg.norm(np.roll(t,-1,axis=0)-t,axis=1);k=int(np.argmax(lengths));order=np.array([k,(k+1)%3,(k+2)%3]);a,b,c=t[order];d=(b-a);L=float(np.linalg.norm(d));assert L>1e-8;axis=d/L;x=float((c-a)@axis);h=float(abs(np.cross(d,c-a))/L);assert h>1e-10
 w=max(6.,L);hh=max(6.,h);shape=np.array([[0.,0.],[w,0.],[x/L*w,hh]]);width=int(np.ceil(w))+6;height=int(np.ceil(hh))+6;rects.append((fi,width,height,order,shape))
free=[(1710,4,334,2040)];placements=[]
for fi,w,h,order,shape in sorted(rects,key=lambda x:(max(x[1],x[2]),x[1]*x[2]),reverse=True):
 options=[]
 for k,(x,y,bw,bh)in enumerate(free):
  if w<=bw and h<=bh:options.append((bw*bh-w*h,k,False))
  if h<=bw and w<=bh:options.append((bw*bh-w*h,k,True))
 assert options,('Insufficient reserved strip',fi,w,h,len(placements),len(rects))
 _,k,rotate=min(options);x,y,bw,bh=free.pop(k)
 if rotate:shape=shape[:,[1,0]];w,h=h,w
 coords=shape+[x+3,y+3];uv[fi,order]=coords/2048;placements.append({'face':fi,'box':[x,y,w,h],'original_area_texels2K':float(area[fi]),'new_area_texels2K':float(abs(np.cross(coords[1]-coords[0],coords[2]-coords[0]))/2),'source_max_edge_texels2K':float(np.max(np.linalg.norm(np.roll(q[fi],-1,axis=0)-q[fi],axis=1)))})
 if bw>w:free.append((x+w,y,bw-w,h))
 if bh>h:free.append((x,y+h,bw,bh-h))
uv=uv.astype('float32');checks={str(res):audit(uv,res)for res in [2048,4096]}
for res,result in checks.items():assert not result['overlapping']and not result['missing_faces']and not result['degenerate_faces'],(res,result)
data['UV_CORNER']=uv;data['moved_faces']=np.array(sorted(moved),dtype=np.int64);np.savez_compressed(R/'audit/head_atlas199_binding.npz',**data);report={'source_sha256':pre['source_sha256'],'faces':len(uv),'moved_faces':sorted(moved),'covered_original_continuous_overlap_pairs':len(pairs),'placements':placements,'checks':checks,'healthy_chart_corner_UVs_held':True,'packing':'Reserved strip; each padded chart preserves the previous longest UV edge resolution and only expands too-thin altitude to6pixels at2K.3pixel filter guard. No new geometry or texture baking.','status':'Prepared atlas with zero sampled overlap/full2K/4Kcoverage; continuous exact-float32 retest and original-color transfer appearance remain pending.'};(R/'audit/head_atlas199.json').write_text(json.dumps(report,indent=2));print({'faces':len(uv),'moved':len(moved),'covered_pairs':len(pairs),'largest_chart':[max(x['box'][2]for x in placements),max(x['box'][3]for x in placements)],'checks':{res:{k:len(v)if isinstance(v,list)else v for k,v in result.items()}for res,result in checks.items()}},flush=True)
