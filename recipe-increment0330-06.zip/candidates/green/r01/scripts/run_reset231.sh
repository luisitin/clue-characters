#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for spec in 'hand226 fix_hand_frame226.py' 'sleeve227 build_sleeve227.py' 'sleeve229 build_sleeve228_229.py' 'merge230 merge_reset230.py'; do
 read -r stage script <<< "$spec"
 bash "$R/scripts/run_heavy_stage.sh" "$stage" python "$R/scripts/$script" > "$R/logs/$stage.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" compact231 python "$R/scripts/compact_glb168.py" Green_full_reset230_raw Green_full_reset231 > "$R/logs/compact231.log" 2>&1
for tag in body_angle_0 body_angle_-11 openhand_angle_-11 openhand_top; do
 bash "$R/scripts/run_heavy_stage.sh" "reset231_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_reset231.glb" "$R/renders/full_reset231" "$tag" paint 1024 > "$R/logs/reset231_$tag.log" 2>&1
done
