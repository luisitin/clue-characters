"""Assemble the requested actual WIP screenshots without altering model content."""
import pathlib,json,hashlib,zipfile,sys,io
from PIL import Image,ImageDraw,ImageFont
R=pathlib.Path(__file__).resolve().parents[1];folder=R/'review_20261005_0105';source=R/'Green_full_context193.glb';sha=hashlib.sha256(source.read_bytes()).hexdigest();assert sha=='098cad4cf7a5d064497fe5ddfdfa865bed2ed419f140fbfd5263b414ac9cc431'
angles=list(range(0,360,45));tags=[f'body_angle_{a}'for a in angles]+['body_top','body_under','head_angle_-11','head_angle_270','head_under'];labels=[f'{a:03d} degrees'for a in angles]+['Top','Underside','Face: -11 degrees','Face: 270 degrees','Face: underside'];records=[]
bodyOnly='--body-only'in sys.argv
if bodyOnly:tags=tags[:8];labels=labels[:8]
for tag,label in zip(tags,labels):
 p=folder/(tag+'_paint.png');meta=json.loads(p.with_suffix('.json').read_text());assert meta['source_sha256']==sha and meta['shader_mode']=='paint'and meta['resolution']==[1024,1024];assert meta['whole_model_geometry'];assert meta['rendered_image_sha256']==hashlib.sha256(p.read_bytes()).hexdigest();records.append({'file':p.name,'label':label,'sha256':meta['rendered_image_sha256'],'resolution':meta['resolution'],'camera_world_matrix':meta['camera_world_matrix'],'projection_type':meta['projection_type'],'ortho_scale':meta['ortho_scale'],'angle_deg':meta['angle_deg'],'elevation_world_z_offset':meta['elevation_world_z_offset'],'target':meta['target']})
fontRoot=pathlib.Path('/usr/share/fonts/truetype/dejavu');bold=ImageFont.truetype(str(fontRoot/'DejaVuSans-Bold.ttf'),30);small=ImageFont.truetype(str(fontRoot/'DejaVuSans.ttf'),19);tiny=ImageFont.truetype(str(fontRoot/'DejaVuSans.ttf'),17)
def sheet(rows,cols,name,subtitle):
 cell=512;header=100;labelH=36;nrows=(len(rows)+cols-1)//cols;canvas=Image.new('RGB',(cols*cell,header+nrows*(cell+labelH)+48),(28,30,33));draw=ImageDraw.Draw(canvas);draw.text((24,17),'GREEN | CURRENT WIP | v193',font=bold,fill=(245,245,245));draw.text((24,59),subtitle,font=small,fill=(200,207,212))
 for k,row in enumerate(rows):
  x=(k%cols)*cell;y=header+(k//cols)*(cell+labelH);im=Image.open(folder/row['file']).convert('RGB');im.thumbnail((cell,cell),Image.Resampling.LANCZOS);canvas.paste(im,(x+(cell-im.width)//2,y));draw.text((x+16,y+cell+7),row['label'],font=small,fill=(235,237,240))
 if len(rows)==5 and cols==3:
  x=2*cell+28;y=header+cell+labelH+48;draw.text((x,y),'Visible work remaining',font=small,fill=(245,245,245))
  for line in ['Unify outfit colors and fabric','Clean face, neck and hair paint','Refine expression and face detail','Rebuild the footwear','Check the complete model again']:
   y+=48;draw.text((x,y),line,font=tiny,fill=(200,207,212))
 draw.text((24,canvas.height-32),'324,473 triangles | Actual materials | SHA-256 '+sha[:16]+'... | Unapproved draft',font=tiny,fill=(190,198,204));out=folder/name;encoded=io.BytesIO();canvas.save(encoded,format='PNG');payload=encoded.getvalue()
 if out.exists():assert out.read_bytes()==payload,'Frozen review sheet changed'
 else:out.write_bytes(payload)
 return out
first=sheet(records[:8],4,'Green_WIP_v193_eight_angles.png','Eight views from the same complete model. Visible unfinished areas are retained.')
if bodyOnly:print(json.dumps({'source_sha256':sha,'body_contact_sheet':str(first),'verified_views':8,'remaining':'Top/under and face views will follow separately.'},indent=2),flush=True);raise SystemExit(0)
second=sheet(records[8:],3,'Green_WIP_v193_top_under_and_face.png','Top, underside and face closeups from the same current draft.')
status=['Face, jaw, neck, ear and hair paint still need cleanup.','Eye expression and physical face detail remain under review.','Garment color transitions and fabric finish are unfinished.','A small wrist paint trace remains; footwear and final proportions need work.','Final close-up and all-angle checks remain pending.']
manifest={'character':'Green','version':'WIP v193','source_model':source.name,'source_sha256':sha,'triangles':324473,'status':'Unapproved current work in progress','remaining_major_work':status,'views':records,'contact_sheets':[first.name,second.name]};(folder/'Green_WIP_v193_manifest.json').write_text(json.dumps(manifest,indent=2));readme='GREEN | CURRENT WORK IN PROGRESS, v193\n\nThese are actual renders of one complete model. This is an unfinished, unapproved draft.\n\n'+ '\n'.join('- '+x for x in status)+'\n\nModel SHA-256: '+sha+'\nGeometry: 324,473 triangles\nAll individual images are 1024×1024.\n';(folder/'Green_WIP_v193_README.txt').write_text(readme)
archive=folder/'Green_WIP_v193_all_views.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for row in records:z.write(folder/row['file'],row['file'])
 for p in [first,second,folder/'Green_WIP_v193_manifest.json',folder/'Green_WIP_v193_README.txt']:z.write(p,p.name)
print(json.dumps({'source_sha256':sha,'contact_sheets':[str(first),str(second)],'individual_folder':str(folder),'archive':str(archive),'archive_bytes':archive.stat().st_size,'views':len(records)},indent=2),flush=True)
