"""Calibrate view color in shared anatomy and feather visibility seams by surface distance."""
import pathlib,json,numpy as np
from scipy.ndimage import map_coordinates
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
R=pathlib.Path(__file__).resolve().parents[1]
with np.load(R/'audit/hand241_projection.npz')as z:a={k:z[k]for k in z.files}
with np.load(R/'audit/hand241_hand.npz')as z:g={k:z[k]for k in z.files}
P,F=np.unique(g['P'].reshape(-1,3),axis=0,return_inverse=True);F=F.reshape(-1,3);N=np.zeros_like(P);np.add.at(N,F.ravel(),g['N'].reshape(-1,3));N/=np.linalg.norm(N,axis=1)[:,None];edges=np.unique(np.sort(np.concatenate([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),axis=1),axis=0);length=np.linalg.norm(P[edges[:,0]]-P[edges[:,1]],axis=1);graph=coo_matrix((np.r_[length,length],(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(P),len(P))).tocsr();colors=[];calibmask=[];distances=[]
im=a['images'].astype(float)/255;im=np.where(im<=.04045,im/12.92,((im+.055)/1.055)**2.4)
for k,C in enumerate(a['cameras']):
 pc=(P-C[:3,3])@C[:3,:3];xy=np.column_stack([pc[:,0]/a['scales'][k]+.5,.5-pc[:,1]/a['scales'][k]])*1024-.5;inside=(xy[:,0]>=1)&(xy[:,0]<1022)&(xy[:,1]>=1)&(xy[:,1]<1022);ix=np.clip(np.rint(xy[:,0]).astype(int),0,1023);iy=np.clip(np.rint(xy[:,1]).astype(int),0,1023);face=N@C[:3,2];visible=inside&(face>.015)&(-pc[:,2]<=a['depths'][k,iy,ix]+.0012)&np.isfinite(a['depths'][k,iy,ix])&(a['guards'][k,iy,ix]>1.5);dist=dijkstra(graph,directed=False,indices=np.flatnonzero(~visible),min_only=True);dist[~np.isfinite(dist)]=.02;distances.append(dist[F].astype('float32'));col=np.column_stack([map_coordinates(im[k,:,:,ch],xy[:,::-1].T,order=1,mode='nearest')for ch in range(3)]);colors.append(np.maximum(col,.005));calibmask.append(visible&(face>.35)&(a['guards'][k,iy,ix]>5)&(col.max(1)<.9)&(col.min(1)>.025));print('view',k,'visible',int(visible.sum()),'max distance',float(dist.max()),flush=True)
colors=np.array(colors);calibmask=np.array(calibmask);eq=[];rhs=[];pairs=[]
for i in range(6):
 for j in range(i+1,6):
  shared=calibmask[i]&calibmask[j];count=int(shared.sum())
  if count<40:continue
  diff=np.log(colors[j,shared])-np.log(colors[i,shared]);median=np.median(diff,axis=0);w=np.sqrt(min(count,3000));r=np.zeros(6);r[i]=w;r[j]=-w;eq.append(r);rhs.append(median*w);pairs.append({'views':[i,j],'shared_vertices':count,'median_log_difference':median.tolist(),'IQR':(np.percentile(diff,75,axis=0)-np.percentile(diff,25,axis=0)).tolist()})
r=np.zeros(6);r[0]=1000;eq.append(r);rhs.append(np.zeros(3));gain=np.linalg.lstsq(np.array(eq),np.array(rhs),rcond=None)[0];assert np.max(abs(gain))<.5;np.savez_compressed(R/'audit/hand269_calibration.npz',view_log_gain=gain,visibility_distance_corner=np.array(distances));report={'view_linear_RGB_gain':np.exp(gain).tolist(),'overlap_pairs':pairs,'feather_surface_distance_m':.006,'status':'Shared-surface median color calibration and geodesic visibility feathering. No geometry/UV change; actual appearance remains the deciding gate.'};(R/'audit/hand269.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
