"""Attribute new paint ghosting to exact model points and contributing plate pixels."""
import pathlib,json,numpy as np
from scipy.ndimage import map_coordinates
from scipy.spatial.transform import Rotation
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];j,b,A=read_glb(R/'Green_full_hand243.glb');n=j['nodes'][1];M=np.array(n['matrix']).reshape(4,4).T;pr=j['meshes'][n['mesh']]['primitives'][0];P=A(pr['attributes']['POSITION']);F=A(pr['indices']).astype(np.int64).reshape(-1,3);W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];N=A(pr['attributes']['NORMAL'])@np.linalg.inv(M[:3,:3]);N=N[:,[0,2,1]]*[1,-1,1];N/=np.linalg.norm(N,axis=1)[:,None];T=W[F];e1=T[:,1]-T[:,0];e2=T[:,2]-T[:,0];meta=json.loads((R/'renders/full_hand243/openhand_top_paint.json').read_text());C=np.array(meta['camera_world_matrix']);s=meta['ortho_scale'];d=-C[:3,2]
with np.load(R/'audit/hand241_projection.npz')as z:a={k:z[k]for k in z.files}
report=[]
for px,py in [(357,563),(401,578),(455,583),(512,648)]:
 origin=C[:3,3]+C[:3,0]*((px+.5)/1024-.5)*s+C[:3,1]*(.5-(py+.5)/1024)*s;h=np.cross(np.broadcast_to(d,e2.shape),e2);det=np.sum(e1*h,axis=1);safe=np.abs(det)>1e-14;iv=np.zeros(len(det));iv[safe]=1/det[safe];ss=origin-T[:,0];u=iv*np.sum(ss*h,axis=1);q=np.cross(ss,e1);v=iv*(q@d);tt=iv*np.sum(e2*q,axis=1);good=safe&(u>=0)&(v>=0)&(u+v<=1)&(tt>0);assert good.any();fi=np.flatnonzero(good)[np.argmin(tt[good])];bc=np.array([1-u[fi]-v[fi],u[fi],v[fi]]);p=bc@T[fi];nn=bc@N[F[fi]];nn/=np.linalg.norm(nn);views=[]
 for k,cam in enumerate(a['cameras']):
  pc=(p-cam[:3,3])@cam[:3,:3];xy=np.array([pc[0]/a['scales'][k]+.5,.5-pc[1]/a['scales'][k]])*1024-.5;ix,iy=np.clip(np.rint(xy).astype(int),0,1023);facing=max(float(nn@cam[:3,2]),0);depth=float(a['depths'][k,iy,ix]);valid=-pc[2]<=depth+.0012 and np.isfinite(depth);guard=np.clip((a['guards'][k,iy,ix]-1)/3,0,1);weight=float(facing**6*valid*guard);views.append({'view':k,'pixel':xy.tolist(),'normal_facing':facing,'point_depth':float(-pc[2]),'first_depth':depth,'depth_delta_m':float(-pc[2]-depth),'weight':weight,'RGB':a['images'][k,iy,ix].tolist()})
 report.append({'render_pixel':[px,py],'triangle':int(fi),'world':p.tolist(),'UV':(bc@A(pr['attributes']['TEXCOORD_0'])[F[fi]]).tolist(),'views':views})
(R/'audit/projection250.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
