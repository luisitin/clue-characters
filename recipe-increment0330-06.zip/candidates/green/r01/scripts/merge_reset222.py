"""Assemble the natural hand and its complete refitted forearm for visual judgment."""
import pathlib,copy,json,hashlib
from glb_source import read_glb,write_glb
R=pathlib.Path(__file__).resolve().parents[1]
src=R/'Green_full_context193.glb';j,b,A=read_glb(src);before=copy.deepcopy(j)
def append_part(path):
 global b
 s,sb,S=read_glb(path);s=copy.deepcopy(s);off={k:len(j.get(k,[]))for k in ['accessors','bufferViews','images','textures','samplers','materials']};b=bytes(b)+b'\0'*((-len(b))%4);bo=len(b);b+=bytes(sb)
 for v in s.get('bufferViews',[]):v['byteOffset']=v.get('byteOffset',0)+bo;v['buffer']=0
 for a in s.get('accessors',[]):a['bufferView']+=off['bufferViews'];assert not a.get('sparse')
 for im in s.get('images',[]):im['bufferView']+=off['bufferViews']
 for t in s.get('textures',[]):
  if 'source'in t:t['source']+=off['images']
  if 'sampler'in t:t['sampler']+=off['samplers']
  for ex in t.get('extensions',{}).values():
   if 'source'in ex:ex['source']+=off['images']
 def walk(o):
  if isinstance(o,dict):
   for k,v in o.items():
    if k.endswith('Texture')and isinstance(v,dict)and 'index'in v:v['index']+=off['textures']
    else:walk(v)
  elif isinstance(o,list):
   for v in o:walk(v)
 for m in s.get('materials',[]):walk(m)
 for mesh in s['meshes']:
  for p in mesh['primitives']:
   p['attributes']={k:v+off['accessors']for k,v in p['attributes'].items()};p['indices']+=off['accessors']
   if 'material'in p:p['material']+=off['materials']
 for k in off:j.setdefault(k,[]).extend(s.get(k,[]))
 for k in ['extensionsUsed','extensionsRequired']:
  if k in s:j[k]=sorted(set(j.get(k,[])+s[k]))
 return s
handpath=R/'Green_openhand_reset216_painted98.glb';s=append_part(handpath);hn=next(n for n in s['nodes']if 'mesh'in n);targetmesh=j['nodes'][1]['mesh'];j['meshes'][targetmesh]['primitives']=s['meshes'][hn['mesh']]['primitives'];j['nodes'][1]=copy.deepcopy(hn);j['nodes'][1]['mesh']=targetmesh
clothpath=R/'Green_sleeve221_body.glb';s=append_part(clothpath);sn=s['nodes'][0]
for key in ['translation','rotation','scale','matrix']:assert sn.get(key)==j['nodes'][0].get(key),(key,sn.get(key),j['nodes'][0].get(key))
body=j['meshes'][j['nodes'][0]['mesh']]['primitives'];oldbody=copy.deepcopy(body);body[3:6]=s['meshes'][sn['mesh']]['primitives'][-3:]
assert body[:3]==oldbody[:3]and body[6:]==oldbody[6:]
out=R/'Green_full_reset222_raw.glb';write_glb(out,j,b)
report={'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'components':{str(p.name):hashlib.sha256(p.read_bytes()).hexdigest()for p in [handpath,clothpath]},'changed_nodes':[1],'changed_source_body_primitives':[3,4,5],'all_other_component_bindings_held':True,'status':'Unadopted complete-context natural palm-up hand/forearm reset. Actual proportions and gesture are the first gate; prior skin texture is temporary. Self/contact and final clothing finish remain pending.'}
(R/'audit/full_reset222.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
