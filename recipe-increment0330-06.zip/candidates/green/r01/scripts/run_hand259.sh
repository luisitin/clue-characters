#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for row in 0 512 1024 1536; do
 bash "$R/scripts/run_heavy_stage.sh" "hand258_$row" python "$R/scripts/bake_native_skin258.py" "$row" > "$R/logs/hand258_$row.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" hand259 python "$R/scripts/export_native_skin259.py" > "$R/logs/hand259.log" 2>&1
for spec in 'openhand_top unlit' 'openhand_angle_-11 paint' 'openhand_top paint' 'openhand_angle_79 paint' 'openhand_under paint'; do
 read -r tag mode <<< "$spec"
 bash "$R/scripts/run_heavy_stage.sh" "hand259_${tag}_$mode" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_hand259.glb" "$R/renders/full_hand259" "$tag" "$mode" 1024 > "$R/logs/hand259_${tag}_$mode.log" 2>&1
done
