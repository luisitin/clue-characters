#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for component in head forehead eye0 eye1; do
 res=2048; if [[ "$component" = head ]]; then res=4096; fi
 for ((row=0;row<res;row+=512)); do
  bash "$R/scripts/run_heavy_stage.sh" "face247_${component}_${row}" python "$R/scripts/bake_face247_tile.py" "$component" "$row" > "$R/logs/face247_${component}_${row}.log" 2>&1
 done
done
bash "$R/scripts/run_heavy_stage.sh" face248 python "$R/scripts/export_face248.py" > "$R/logs/face248.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" face249 python "$R/scripts/optics_face249.py" > "$R/logs/face249.log" 2>&1
for tag in head_angle_0 head_angle_270 head_under; do
 bash "$R/scripts/run_heavy_stage.sh" "face249_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_face249.glb" "$R/renders/full_face249" "$tag" paint 1024 > "$R/logs/face249_$tag.log" 2>&1
done
