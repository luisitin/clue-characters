import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/derive_wrist_tangents181.py').read_text().replace('wrist_uv179','wrist_uv186').replace('wrist_tangents181','wrist_tangents188').replace('changed_8_UV_faces','changed_9_UV_faces');exec(compile(code,'derive_wrist_tangents188','exec'))
