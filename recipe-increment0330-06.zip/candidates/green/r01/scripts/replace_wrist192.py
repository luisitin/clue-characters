import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/replace_wrist183.py').read_text().replace('Green_grip_wrist182_painted','Green_grip_wrist191_painted_valid').replace('Green_full_context183_raw','Green_full_context192_raw').replace('wrist_merge183','wrist_merge192');exec(compile(code,'replace_wrist192','exec'))
