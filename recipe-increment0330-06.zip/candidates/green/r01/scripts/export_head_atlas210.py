"""UV-only original-color comparison; no tangent fallback on three inherited bad walls."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/export_head_atlas208.py').read_text()
old="with np.load(R/'audit/head_tangents207.npz')as z:tangent={k:z[k]for k in z.files}"
new="nn=data['NORMAL_CORNER'].astype(float);nn/=np.linalg.norm(nn,axis=2)[:,:,None];tangent={'NORMAL_UNIT_CORNER':nn.astype('float32')};assert 'normalTexture'not in mat"
assert code.count(old)==1;code=code.replace(old,new).replace(",tangent['TANGENT_CORNER']",'').replace('reshape(-1,12)','reshape(-1,8)').replace("view('V48')","view('V32')").replace(",('TANGENT',slice(8,12),'VEC4')",'')
code=code.replace('Green_full_head208_raw','Green_full_head210_raw').replace('head_atlas208.json','head_atlas210.json').replace('head208','head210').replace("'status':'Unique head atlas candidate;", "'known_source_normal_wall_failures':[15088,17922,54581],'head_TANGENT_omitted_because_no_normal_map_and_no_safe_native_frame_on_three_inherited_corners':True,'status':'Unique head atlas candidate;")
exec(compile(code,'export_head_atlas210','exec'))
