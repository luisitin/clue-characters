import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/audit_moved_hand70.py').read_text().replace('Green_sleeve69_assembly.glb','Green_full_reset231.glb').replace("f=A(pr['indices']).reshape(-1,3)","f=A(pr['indices']).astype(np.int64).reshape(-1,3)")
start=code.index("z=np.load(R/'audit/sleeve69_binding.npz')");end=code.index('isnew=owners[:,0]==1',start);code=code[:start]+code[end:];code=code.replace('hand70_body_v4_compact','hand237_v4');exec(compile(code,'audit_hand237','exec'))
