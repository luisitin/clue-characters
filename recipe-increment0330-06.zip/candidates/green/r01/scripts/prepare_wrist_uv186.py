"""One extra isolated chart for the185 continuous-UV counterexample."""
import pathlib,json
R=pathlib.Path(__file__).resolve().parents[1];proof=json.loads((R/'audit/wrist_uv185_primitive0.json').read_text());assert {tuple(x['faces'])for x in proof['positive_area_coplanar_pairs']}=={(20317,48613),(46327,48613)}
code=(R/'scripts/prepare_wrist_uv179.py').read_text();old=";lo=old.min(1)*2048;hi=old.max(1)*2048;cells=[]";new=";missing=sorted(set(missing+([48613]if pi==0 else[])));lo=old.min(1)*2048;hi=old.max(1)*2048;cells=[]";assert code.count(old)==1;code=code.replace(old,new).replace('wrist_uv179','wrist_uv186');exec(compile(code,'prepare_wrist_uv186','exec'))
