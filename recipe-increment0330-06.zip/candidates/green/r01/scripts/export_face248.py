import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/stitch_export_face234.py').read_text().replace('face233_tiles','face247_tiles').replace('Skin234','Skin248').replace('albedo234','albedo248').replace('margin234','margin248').replace('Green_full_face234','Green_full_face248').replace('face234.json','face248.json');exec(compile(code,'export_face248','exec'))
