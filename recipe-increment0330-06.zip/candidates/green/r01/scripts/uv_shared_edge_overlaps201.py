"""UV-specific exact check omitted by a geometry kernel's shared-edge shortcut."""
import itertools,collections,numpy as np
from fractions import Fraction
def audit_shared_uv_edges(corner_uv):
 uv=np.asarray(corner_uv,dtype='float32').astype(float);u,g=np.unique(uv.reshape(-1,2),axis=0,return_inverse=True);f=g.reshape(-1,3);edges=collections.defaultdict(list)
 for fi,tr in enumerate(f):
  for a,c in zip(tr,np.roll(tr,-1)):edges[tuple(sorted((int(a),int(c))))].append(fi)
 rational=[(Fraction(float(p[0])),Fraction(float(p[1])))for p in u];orientation={};pairs=set();contacts=0;tested=0;deg=[]
 def sign(edge,third):
  key=(edge,third)
  if key not in orientation:
   a,c=[rational[x]for x in edge];p=rational[third];v=(c[0]-a[0])*(p[1]-a[1])-(c[1]-a[1])*(p[0]-a[0]);orientation[key]=(v>0)-(v<0)
  return orientation[key]
 for edge,ids in edges.items():
  for i,k in itertools.combinations(sorted(set(ids)),2):
   ai=[int(v)for v in f[i]if int(v)not in edge];ak=[int(v)for v in f[k]if int(v)not in edge]
   if len(ai)!=1 or len(ak)!=1:deg.append([i,k]);continue
   si=sign(edge,ai[0]);sk=sign(edge,ak[0]);tested+=1
   if si*sk>0:pairs.add((i,k))
   else:contacts+=1
 return {'tested_shared_edge_face_pairs':tested,'same_side_positive_area_overlap_pairs':[list(p)for p in sorted(pairs)],'opposite_side_or_zero_area_contacts':contacts,'degenerate_incidence_pairs':deg,'max_UV_edge_incidence':max(map(len,edges.values()),default=0),'predicate':'Exact rational2D half-plane orientation from stored float32 UV coordinates. Nondegenerate triangles sharing a full edge overlap with positive area iff their opposite vertices lie in the same open half-plane. Combine with V4 non-shared-edge and copy/degenerate tests.'}
if __name__=='__main__':
 import pathlib,sys,json,hashlib
 from glb_source import read_glb
 R=pathlib.Path(__file__).resolve().parents[1];mode=sys.argv[1]
 if mode=='head196':
  path=R/'audit/head_atlas196_binding.npz'
  with np.load(path)as z:uv=z['UV_CORNER'].copy()
 else:
  pi=int(mode);path=R/'Green_grip_wrist191_painted_valid.glb';j,b,A=read_glb(path);pr=j['meshes'][0]['primitives'][pi];uv=A(pr['attributes']['TEXCOORD_0'])[A(pr['indices']).astype(np.int64).reshape(-1,3)]
 result=audit_shared_uv_edges(uv);result['input_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();(R/'audit'/f'uv_shared201_{mode}.json').write_text(json.dumps(result,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in result.items()},flush=True)
