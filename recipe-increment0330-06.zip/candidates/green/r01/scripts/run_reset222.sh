#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for spec in 'sleeve220 fair_sleeve220.py' 'lining221 add_lining221.py' 'merge222 merge_reset222.py'; do
 read -r stage script <<< "$spec"
 bash "$R/scripts/run_heavy_stage.sh" "$stage" python "$R/scripts/$script" > "$R/logs/$stage.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" compact223 python "$R/scripts/compact_glb168.py" Green_full_reset222_raw Green_full_reset223 > "$R/logs/compact223.log" 2>&1
for tag in body_angle_0 body_angle_-11 openhand_angle_-11 openhand_top; do
 bash "$R/scripts/run_heavy_stage.sh" "reset223_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_reset223.glb" "$R/renders/full_reset223" "$tag" paint 1024 > "$R/logs/reset223_$tag.log" 2>&1
done
