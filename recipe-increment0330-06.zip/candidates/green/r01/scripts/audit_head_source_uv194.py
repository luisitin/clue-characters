"""Find source head UV conflicts before any spatially local skin painting."""
import pathlib,json,hashlib,numpy as np
from glb_source import read_glb
from intersection_kernel_v4_selected import audit
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_full_context173_fp32.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32').astype(float);UV=A(pr['attributes']['TEXCOORD_0']).astype('float32').astype(float);F=A(pr['indices']).astype(np.int64).reshape(-1,3);node=j['nodes'][0];W=(P*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];selected=W[F][:,:,2].max(1)>.65
uvtri=UV[F];lo=uvtri.min(1);hi=uvtri.max(1);lower=lo[selected].min(0);upper=hi[selected].max(0);potential=np.all(hi>=lower-1e-10,axis=1)&np.all(lo<=upper+1e-10,axis=1);ids=np.flatnonzero(potential);used,inv=np.unique(F[ids],return_inverse=True);uvp=np.column_stack([UV[used],np.zeros(len(used))]);pick=np.flatnonzero(selected[ids]);print({'stage':'COMPACT_READY','selected_head_faces':len(pick),'retained_uv_targets':int((~selected[ids]).sum()),'total_source_faces':len(F)},flush=True);res=audit(uvp,inv.reshape(-1,3),selected_faces=pick,progress_interval=2000)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in res[key]:
  row['faces']=[int(ids[x])for x in row['faces']];row['world_centroid_separation_m']=float(np.linalg.norm(W[F[row['faces'][0]]].mean(0)-W[F[row['faces'][1]]].mean(0)));row['both_in_head']=bool(selected[row['faces']].all())
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:res[key]=[[int(ids[x])for x in row]for row in res[key]]
res['zero_area_faces']=[int(ids[x])for x in res['zero_area_faces']];res.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),selected_head_faces=len(pick),retained_uv_targets=int((~selected[ids]).sum()),scope='Read-only continuous source-atlas UV conflict audit. Head selection uses any corner worldZ>.65; every possible original-atlas target is retained. UVs are explicitly float32-consumer decoded. Findings guide local atlas separation; none authorizes source geometry deletion.')
(R/'audit/head_source_uv194.json').write_text(json.dumps(res,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in res.items()},flush=True)
