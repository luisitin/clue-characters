import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/render_exact.py').read_text().replace('scene.cycles.samples=32','scene.cycles.samples=64');exec(compile(code,'render_hand264','exec'))
