"""Move only unsampled actual wrist triangles into provably unused padded charts."""
import pathlib,json,hashlib,numpy as np
from glb_source import read_glb
from uv_coverage import audit
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist154.glb';j,b,A=read_glb(src);pre=json.loads((R/'audit/wrist_uv176.json').read_text());assert pre['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();saved={};reports=[]
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 F=A(pr['indices']).astype(np.int64).reshape(-1,3);old=A(pr['attributes']['TEXCOORD_0'])[F];corner=old.copy();row=pre['primitives'][pi];missing=sorted(set(row['results']['2048']['missing_faces']+row['results']['4096']['missing_faces']));lo=old.min(1)*2048;hi=old.max(1)*2048;cells=[]
 for fi in missing:
  found=False
  for cell in range(4*169):
   if cell in cells:continue
   origin=np.array([1993+12*(cell%4),10+12*(cell//4)]);upper=origin+12
   if upper.max()>2047:continue
   if np.any(np.all(hi>=origin,axis=1)&np.all(lo<=upper,axis=1)):continue
   cells.append(cell);corner[fi]=(origin+np.array([[3.,3.],[9.,3.],[3.,9.]]))/2048;found=True;break
  assert found,('No unused padded chart',pi,fi)
 corner=corner.astype('float32');proof={str(res):audit(corner,res)for res in [2048,4096]}
 for result in proof.values():assert not result['overlapping']and not result['missing_faces']and not result['degenerate_faces'],(pi,result)
 saved[f'UV_CORNER_{pi}']=corner;saved[f'OLD_UV_CORNER_{pi}']=old;saved[f'moved_faces_{pi}']=np.array(missing,dtype=np.int64);saved[f'chart_cells_{pi}']=np.array(cells,dtype=np.int64)
 report={'primitive':pi,'moved_faces':missing,'cells':cells,'actual_float32_UV_checks':proof,'all_other_corner_UVs_exact':bool(np.array_equal(corner[np.setdiff1d(np.arange(len(F)),missing)],old[np.setdiff1d(np.arange(len(F)),missing)]))};reports.append(report);print({'primitive':pi,'moved':len(missing),'cells':cells,'2K_4K_zero_overlap_and_full_face_sampling':True},flush=True)
np.savez_compressed(R/'audit/wrist_uv179_binding.npz',**saved);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'primitives':reports,'scope':'UV-only prepared correspondence; no mesh exported yet. Every new12px slot lies outside every original triangle UV AABB, with6px inner triangular chart and3px guard. Geometry/P/N and final paint transfer remain held and must be asserted at export.'};(R/'audit/wrist_uv179.json').write_text(json.dumps(report,indent=2))
