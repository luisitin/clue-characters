"""Compare exact known surface UV colors with each saved projection input after the interrupted252 run."""
import pathlib,json,numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates
R=pathlib.Path(__file__).resolve().parents[1]
with np.load(R/'audit/hand241_projection.npz')as z:a={k:z[k]for k in z.files}
im=a['images'].astype(float)/255;lin=np.where(im<=.04045,im/12.92,((im+.055)/1.055)**2.4)
out=np.array(Image.open(R/'textures/Green_hand_Skin252_BaseColor_2048.png').convert('RGB'));rows=[]
for row in json.loads((R/'audit/projection250.json').read_text()):
 P=np.array(row['world']);uv=np.array(row['UV']);colors=[];weights=[]
 for k,v in enumerate(row['views']):
  xy=np.array(v['pixel']);c=np.array([map_coordinates(lin[k,:,:,ch],xy[::-1,None],order=1,mode='nearest')[0]for ch in range(3)]);colors.append(c);weights.append(v['weight'])
 w=np.array(weights);expected=np.sum(np.array(colors)*w[:,None],axis=0)/w.sum();expected=np.where(expected<=.0031308,expected*12.92,1.055*expected**(1/2.4)-.055)*255;stored=np.array([map_coordinates(out[:,:,ch].astype(float),(uv[::-1]*2048-.5)[:,None],order=1,mode='nearest')[0]for ch in range(3)])
 rows.append({'render_pixel':row['render_pixel'],'UV':uv.tolist(),'normalized_weights':(w/w.sum()).tolist(),'expected_RGB':expected.tolist(),'stored_RGB':stored.tolist(),'max_channel_difference':float(abs(expected-stored).max())})
(R/'audit/hand_projection253.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
