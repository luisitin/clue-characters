"""Bind six new hand-paint views to the exact accepted-for-study gesture, including skin masks."""
import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/prepare_face232.py').read_text().replace('Green_full_head211.glb','Green_full_reset231.glb')
start=code.index('specs=');end=code.index('\nfor ni,node',start);code=code[:start]+"specs={(1,0):('hand',2048)}"+code[end:]
code=code.replace("if 'mesh'not in node:continue","if 'mesh'not in node or ni!=1:continue")
code=code.replace('keep=np.max(W[F][:,:,2],axis=1)>.62','keep=np.ones(len(F),bool)')
start=code.index("plates=[");end=code.index(';cameras=[]',start);code=code[:start]+"plates=[('front','renders/hand238_inputs/openhand_angle_-11_unlit.json'),('79','renders/hand238_inputs/openhand_angle_79_unlit.json'),('169','renders/hand238_inputs/openhand_angle_169_unlit.json'),('259','renders/hand238_inputs/openhand_angle_259_unlit.json'),('top','renders/hand238_inputs/openhand_top_unlit.json'),('under','renders/hand238_inputs/openhand_under_unlit.json')]"+code[end:]
code=code.replace('textures/painting_plates/face224','textures/painting_plates/hand239')
code=code.replace("mask=(im.max(2).astype(int)-im.min(2)>12);guard=", "original=np.array(Image.open((R/metafile).with_suffix('.png')).convert('RGB')).astype(int);mask=(im[:,:,0].astype(int)-im[:,:,2]>25)&(im[:,:,0].astype(int)-im[:,:,1]>12)&(original[:,:,0]-original[:,:,2]>25)&(original[:,:,0]-original[:,:,1]>12);guard=")
code=code.replace('face232','hand241');exec(compile(code,'prepare_hand241','exec'))
