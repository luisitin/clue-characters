#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for component in head forehead eye0 eye1; do
 res=2048; if [[ "$component" = head ]]; then res=4096; fi
 for ((row=0;row<res;row+=512)); do
  bash "$R/scripts/run_heavy_stage.sh" "head266_${component}_${row}" python "$R/scripts/bake_head266_tile.py" "$component" "$row" > "$R/logs/head266_${component}_${row}.log" 2>&1
 done
done
bash "$R/scripts/run_heavy_stage.sh" head267 python "$R/scripts/export_head267.py" > "$R/logs/head267.log" 2>&1
bash "$R/scripts/run_heavy_stage.sh" head268 python "$R/scripts/compact_glb168.py" Green_full_head267_raw Green_full_head268 > "$R/logs/head268.log" 2>&1
for tag in head_angle_0 head_angle_270 head_angle_90 head_under head_angle_180; do
 bash "$R/scripts/run_heavy_stage.sh" "head268_$tag" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_exact.py" -- "$R/Green_full_head268.glb" "$R/renders/full_head268" "$tag" paint 1024 > "$R/logs/head268_$tag.log" 2>&1
done
