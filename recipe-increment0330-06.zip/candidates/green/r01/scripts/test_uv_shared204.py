import pathlib,itertools,json,numpy as np
from uv_shared_edge_overlaps201 import audit_shared_uv_edges
R=pathlib.Path(__file__).resolve().parents[1];tested=0
for scale in [1e-4,1.,1e4]:
 for h in [1.,1e-8]:
  a=np.array([[0.,0],[1,0],[.2,h]])*scale
  for same in [False,True]:
   b=np.array([[0.,0],[1,0],[.7,h*(1 if same else-1)]])*scale
   for pa in itertools.permutations(range(3)):
    for pb in itertools.permutations(range(3)):
     result=audit_shared_uv_edges(np.stack([a[list(pa)],b[list(pb)]]));assert bool(result['same_side_positive_area_overlap_pairs'])==same,(scale,h,same,pa,pb);tested+=1
report={'fixture_permutations':tested,'same_side_shared_edge_positive_area_detected':True,'opposite_side_edge_contacts_rejected':True,'scales':[1e-4,1.,1e4],'third_vertex_heights':[1.,1e-8],'scope':'UV-specific shared-edge supplement only; V4 remains responsible for non-shared-edge/copy/degenerate cases.'};(R/'audit/uv_shared204_tests.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
