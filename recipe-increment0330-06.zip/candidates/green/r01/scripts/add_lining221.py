import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/add_recessed_lining75.py').read_text().replace('sleeve69','sleeve219').replace('sleeve74','sleeve220').replace('sleeve75','sleeve221')
exec(compile(code,'add_lining221','exec'))
