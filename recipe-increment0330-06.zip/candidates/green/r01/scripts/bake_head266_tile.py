import pathlib,sys,json,io,numpy as np
from PIL import Image
from uv_raster import samples
from glb_source import read_glb
from head_skin_field265 import HeadField
R=pathlib.Path(__file__).resolve().parents[1];key=sys.argv[1];row=int(sys.argv[2]);d=json.loads((R/'audit/face232.json').read_text())['targets'][key];S=d['resolution'];field=HeadField()
with np.load(R/'audit'/f'face232_{key}.npz')as z:g={k:z[k]for k in z.files}
def oldmap(name):
 j,b,A=read_glb(R/name);p=j['meshes'][j['nodes'][d['node']]['mesh']]['primitives'][d['primitive']];m=j['materials'][p['material']];t=j['textures'][m['pbrMetallicRoughness']['baseColorTexture']['index']];ii=t.get('extensions',{}).get('EXT_texture_webp',{}).get('source',t.get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];return np.array(Image.open(io.BytesIO(bytes(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]))).convert('RGB').resize((S,S),Image.Resampling.LANCZOS))
source=oldmap('Green_full_head211.glb');hair=oldmap('Green_full_face249.glb');out=source[row:row+512].copy();rough=np.full((512,S),210,'uint8');valid=np.zeros((512,S),'uint8');total=0
for fi,y,x,bc in samples(g['UV'],S,row,row+512):
 P=bc@g['P'][fi];N=bc@g['N'][fi];N/=np.linalg.norm(N,axis=1)[:,None];col,r=field.evaluate(P,N,source[row+y,x]/255,hair[row+y,x]/255);out[y,x]=np.round(col*255).astype('uint8');rough[y,x]=np.round(r*255).astype('uint8');valid[y,x]=255;total+=len(y)
folder=R/'textures/head266_tiles';folder.mkdir(exist_ok=True);Image.fromarray(out).save(folder/f'{key}_{row}.png');Image.fromarray(rough).save(folder/f'{key}_{row}_rough.png');Image.fromarray(valid).save(folder/f'{key}_{row}_valid.png');(folder/f'{key}_{row}.json').write_text(json.dumps({'component':key,'row':row,'occupied_texels':total,'scope':'Continuous3D skin/neck field with one frontal high-frequency feature layer; no side-view facial decal blending. Actual appearance and semantic boundaries remain unreviewed.'},indent=2));print(key,row,total,flush=True)
