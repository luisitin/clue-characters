import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/merge_reset222.py').read_text().replace('Green_openhand_reset216_painted98','Green_openhand_fit226').replace('Green_sleeve221_body','Green_sleeve229_body').replace('reset222','reset230');exec(compile(code,'merge_reset230','exec'))
