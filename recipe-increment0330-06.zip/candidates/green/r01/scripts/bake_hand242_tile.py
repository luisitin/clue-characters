import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/bake_face233_tile.py').read_text().replace('face232','hand241').replace('Green_full_head211.glb','Green_full_reset231.glb').replace('face233_tiles','hand242_tiles')
code=code.replace("if k==3:w*=np.clip((.79-P[:,2])/.035,0,1)","if False:pass")
code=code.replace("prior=old[row+yy,xx].astype(float)/255;", "prior=np.broadcast_to(np.array([.79,.57,.46]),(len(yy),3)).copy();")
exec(compile(code,'bake_hand242_tile','exec'))
