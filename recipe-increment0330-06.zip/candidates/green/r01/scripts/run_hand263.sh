#!/usr/bin/env bash
set -eu
R=candidates/green/r01
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
for row in 0 512 1024 1536; do
 bash "$R/scripts/run_heavy_stage.sh" "hand262_$row" python "$R/scripts/bake_native_skin262.py" "$row" > "$R/logs/hand262_$row.log" 2>&1
done
bash "$R/scripts/run_heavy_stage.sh" hand263 python "$R/scripts/export_native_skin263.py" > "$R/logs/hand263.log" 2>&1
for spec in 'openhand_angle_-11 paint' 'openhand_top unlit' 'openhand_top paint' 'body_angle_0 paint'; do
 read -r tag mode <<< "$spec"
 bash "$R/scripts/run_heavy_stage.sh" "hand263_${tag}_$mode" blender -b --python-exit-code 1 -t 1 --python "$R/scripts/render_hand264.py" -- "$R/Green_full_hand263.glb" "$R/renders/full_hand263" "$tag" "$mode" 1024 > "$R/logs/hand263_${tag}_$mode.log" 2>&1
done
