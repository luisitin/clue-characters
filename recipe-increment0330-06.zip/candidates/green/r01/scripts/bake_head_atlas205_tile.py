"""Bounded exact original-face UV transfer into the verified dedicated head atlas."""
import pathlib,sys,json,hashlib,io,time,numpy as np
from PIL import Image
from glb_source import read_glb
from uv_raster import samples
R=pathlib.Path(__file__).resolve().parents[1];kind=sys.argv[1];row=int(sys.argv[2]);assert kind in ['BaseColor','ORM'];res=4096 if kind=='BaseColor' else 2048;assert 0<=row<res and row%512==0
src=R/'Green_full_context173_fp32.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];mat=j['materials'][pr['material']];info=mat['pbrMetallicRoughness']['baseColorTexture'if kind=='BaseColor'else'metallicRoughnessTexture'];assert info.get('texCoord',0)==0 and not info.get('extensions');tex=j['textures'][info['index']];ii=tex.get('extensions',{}).get('EXT_texture_webp',{}).get('source',tex.get('source'));im=j['images'][ii];bv=j['bufferViews'][im['bufferView']];raw=bytes(b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]);image=np.array(Image.open(io.BytesIO(raw)).convert('RGB')).astype('float32')/255
if kind=='BaseColor':image=np.where(image<=.04045,image/12.92,((image+.055)/1.055)**2.4)
with np.load(R/'audit/head_atlas202_binding.npz')as z:data={k:z[k]for k in z.files}
uv=data['UV_CORNER'];sourceUV=data['SOURCE_UV_CORNER'];out=np.zeros((512,res,3),'uint8');valid=np.zeros((512,res),'uint8');sampled=np.zeros(len(uv),bool);total=overlap=0;started=time.time()
def sample(q):
 p=(q%1)*np.array([image.shape[1],image.shape[0]])-.5;i=np.floor(p).astype(np.int64);f=p-i;x=i[:,0]%image.shape[1];y=i[:,1]%image.shape[0];xx=(x+1)%image.shape[1];yy=(y+1)%image.shape[0];return (1-f[:,1,None])*((1-f[:,0,None])*image[y,x]+f[:,0,None]*image[y,xx])+f[:,1,None]*((1-f[:,0,None])*image[yy,x]+f[:,0,None]*image[yy,xx])
for fi,yy,xx,bc in samples(uv,res,row,row+512):
 oldUV=bc@sourceUV[fi];color=sample(oldUV)
 if kind=='BaseColor':color=np.where(color<=.0031308,color*12.92,1.055*np.maximum(color,0)**(1/2.4)-.055)
 overlap+=int(np.count_nonzero(valid[yy,xx]));out[yy,xx]=np.round(np.clip(color,0,1)*255).astype('uint8');valid[yy,xx]=1;sampled[fi]=True;total+=len(yy)
assert overlap==0
folder=R/'textures/head205_tiles';folder.mkdir(exist_ok=True);Image.fromarray(out).save(folder/f'{kind}_{row}.png');Image.fromarray(valid*255).save(folder/f'{kind}_{row}_valid.png');np.save(folder/f'{kind}_{row}_sampled.npy',sampled)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_encoded_map_sha256':hashlib.sha256(raw).hexdigest(),'kind':kind,'resolution':res,'row':row,'occupied':total,'overlap':overlap,'sampled_faces_in_tile':int(sampled.sum()),'seconds':time.time()-started,'transfer':'Exact held face correspondence and barycentric originalUV; bilinear source samples, linear-light filtering for sRGB base color. No BVH guess, nearest-sheet fallback or identity repaint.'};(folder/f'{kind}_{row}.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
