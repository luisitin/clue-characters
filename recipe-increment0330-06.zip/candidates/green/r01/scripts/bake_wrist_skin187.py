import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/bake_wrist_skin180.py').read_text().replace('wrist_uv179','wrist_uv186').replace('Wrist180','Wrist187').replace('wrist_skin180','wrist_skin187').replace('8_reserved_slots','9_reserved_slots');exec(compile(code,'bake_wrist_skin187','exec'))
