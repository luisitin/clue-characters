import pathlib,json,hashlib,copy,numpy as np
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_grip_wrist154.glb';j,b,A=read_glb(src);old=copy.deepcopy(j)
with np.load(R/'audit/wrist_uv179_binding.npz')as z:uvs={k:z[k]for k in z.files}
with np.load(R/'audit/wrist_tangents181.npz')as z:tans={k:z[k]for k in z.files}
def image(path):
 global b
 raw=path.read_bytes();b=bytes(b)+b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(raw)});b+=raw;ii=len(j['images']);j['images'].append({'name':path.name,'mimeType':'image/png','bufferView':vi});ti=len(j['textures']);j['textures'].append({'source':ii,'sampler':0});return ti
handtex=image(R/'textures/Green_Wrist180_Hand_BaseColor_2K.png');exttex=image(R/'textures/Green_Wrist180_Extension_BaseColor_2K.png');orm=image(R/'textures/Green_Wrist180_Extension_ORM_2K.png');reports=[]
template=copy.deepcopy(j['materials'][j['meshes'][0]['primitives'][0]['material']])
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 P=A(pr['attributes']['POSITION']);N=A(pr['attributes']['NORMAL']);F=A(pr['indices']).astype(np.int64).reshape(-1,3);UV=uvs[f'UV_CORNER_{pi}'];T=tans[f'TANGENT_CORNER_{pi}'];records=np.concatenate([P[F],N[F],UV,T],axis=2).astype('float32').reshape(-1,12);_,first,inv=np.unique(np.ascontiguousarray(records).view('V48').ravel(),return_index=True,return_inverse=True);data=records[first];attrs={}
 for key,sl,kind in [('POSITION',slice(0,3),'VEC3'),('NORMAL',slice(3,6),'VEC3'),('TEXCOORD_0',slice(6,8),'VEC2'),('TANGENT',slice(8,12),'VEC4')]:attrs[key],b=append_accessor(j,b,data[:,sl],kind,34962)
 pr['attributes']=attrs;pr['indices'],b=append_accessor(j,b,inv.astype('uint32').ravel(),'SCALAR',34963);mat=copy.deepcopy(template);mat['name']='Green held hand with eight UV microcharts182'if pi==0 else'Green continuous anatomical wrist182';mat['pbrMetallicRoughness']['baseColorTexture']['index']=handtex if pi==0 else exttex
 if pi==1:mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=orm;mat['occlusionTexture']['index']=orm
 pr['material']=len(j['materials']);j['materials'].append(mat);reports.append({'primitive':pi,'triangles':len(F),'vertices':len(data),'moved_UV_faces':len(uvs[f'moved_faces_{pi}'])})
out=R/'Green_grip_wrist182_painted.glb';write_glb(out,j,b);jj,bb,B=read_glb(out);assert jj['nodes']==old['nodes']
for pi,(p,q)in enumerate(zip(old['meshes'][0]['primitives'],jj['meshes'][0]['primitives'])):
 f=A(p['indices']).astype(np.int64).reshape(-1,3);g=B(q['indices']).astype(np.int64).reshape(-1,3);assert f.shape==g.shape
 for key in ['POSITION','NORMAL']:assert np.array_equal(A(p['attributes'][key])[f],B(q['attributes'][key])[g])
 assert np.array_equal(B(q['attributes']['TEXCOORD_0'])[g],uvs[f'UV_CORNER_{pi}']);NN=B(q['attributes']['NORMAL']);TT=B(q['attributes']['TANGENT']);length=np.linalg.norm(NN,axis=1);assert length.min()>1e-6;assert abs(np.linalg.norm(TT[:,:3],axis=1)-1).max()<2e-6;assert abs(np.sum(NN*TT[:,:3],axis=1)).max()<2e-6
reports={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'parts':reports,'all_ordered_corner_positions_normals_and_node_transform_exact':True,'new_UV_and_T_exact_to_prepared_bindings':True,'triangles':60940,'status':'Prepared actual painted component. UV zero overlap/full sampling proven at2K/4K; exact exported continuous UV test and actual skin-seam/cuff regression still pending.'};(R/'audit/wrist_paint182.json').write_text(json.dumps(reports,indent=2));print(reports,flush=True)
