import pathlib
R=pathlib.Path(__file__).resolve().parents[1];code=(R/'scripts/build_sleeve69.py').read_text();start=code.index("h=np.load(R/'audit/hand_forearm6_binding.npz')");end=code.index(';turn=np.cross(axis,endaxis)',start)
code=code[:start]+"fit=json.loads((R/'audit/openhand_fit226.json').read_text());endc=np.array(fit['wrist_world']);endaxis=np.array(fit['distal_forearm_axis_world'])"+code[end:]
code=code.replace('Green_openhand_depth68.glb','Green_openhand_fit226.glb').replace("HM[:3,3]=hn.get('translation',[0,0,0]);sections=[]","HM[:3,3]=hn.get('translation',[0,0,0]);HM=np.array(hn['matrix']).reshape(4,4).T if 'matrix'in hn else HM;sections=[]")
code=code.replace('sleeve69','sleeve227');exec(compile(code,'build_sleeve227','exec'))
