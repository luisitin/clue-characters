import pathlib,json,numpy as np
from glb_source import read_glb
from native_skin_fields257 import SkinFields
R=pathlib.Path(__file__).resolve().parents[1];pose=json.loads((R/'audit/hand256.json').read_text())['pose'];field=SkinFields(pose)
with np.load(R/'audit/hand256_native_binding.npz')as z:g={k:z[k]for k in z.files}
j,b,A=read_glb(R/'Green_full_reset231.glb');M=np.array(j['nodes'][1]['matrix']).reshape(4,4).T;rows=[]
for row in json.loads((R/'audit/projection250.json').read_text()):
 fi=row['triangle'];p=(g['P'][fi]@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];xy=np.linalg.lstsq((p[1:]-p[0]).T,np.array(row['world'])-p[0],rcond=None)[0];bc=np.r_[1-xy.sum(),xy];nr=bc@g['REST'][fi];rn=bc@g['REST_N'][fi];rn/=np.linalg.norm(rn);q=nr-field.wrist;col,h,rough,nail=field.material(nr[None],rn[None]);rows.append({'pixel':row['render_pixel'],'rest_forward':float(q@field.F),'rest_thumbward':float(q@field.S),'dorsal_facing':float(rn@field.D),'RGB':(col[0]*255).tolist(),'height':float(h[0]),'roughness':float(rough[0]),'nail':float(nail[0])})
(R/'audit/native_skin260.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
