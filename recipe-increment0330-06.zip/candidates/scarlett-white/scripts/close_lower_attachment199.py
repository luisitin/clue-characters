"""Bounded source-frontier closure within the explicitly owned compound region; no cuts."""
from pathlib import Path
from collections import defaultdict,Counter
import json
import numpy as np
r=Path(__file__).resolve().parents[1];z=np.load(r/'checks/scarlett197_complete_skin_graph.npz');D={k:z[k]for k in z.files};z.close();W=D['PHYSICAL_P'];G=D['PHYSICAL_F'];raw=D['SOURCE_RAW_IDS'];start=D['SELECTED'];chosen=start.copy();protected=D['PROTECTED'].copy();center=W[G].mean(1);lower_attachment=(raw>=0)&(center[:,1]<.735)&(center[:,0]<-.120);protected[lower_attachment]=False;D['PROTECTED']=protected;edges=defaultdict(list);vf=defaultdict(set)
for fi,f in enumerate(G):
 for v in f:vf[int(v)].add(fi)
 for u,v in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(u),int(v))))].append(fi)
front=set(v for e,fs in edges.items()if any(start[fs])and not all(start[fs])for v in e);allowed=set(np.flatnonzero(start));layer=set(front)
for _ in range(6):
 new=set(f for v in layer for f in vf[v]);allowed|=new;layer=set(v for f in new for v in G[f])
C=W[G].mean(1);allowed={f for f in allowed if not protected[f]and C[f,0]<-.105 and .32<C[f,1]<.805};history=[]
for iteration in range(30):
 border=[e for e,fs in edges.items()if any(chosen[fs])and not all(chosen[fs])];degree=Counter(v for e in border for v in e);badverts={v for v,d in degree.items()if d!=2};badedges=[e for e in border if sum(not chosen[f]for f in edges[e])!=1];need=set(f for v in badverts for f in vf[v]if not chosen[f])|set(f for e in badedges for f in edges[e]if not chosen[f]);grow=need&allowed;blocked=need-allowed;history.append({'iteration':iteration,'faces':int(chosen.sum()),'boundary_edges':len(border),'bad_degree_vertices':len(badverts),'bad_retained_count_edges':len(badedges),'added':len(grow),'blocked_candidate_faces':len(blocked)});print(history[-1],flush=True)
 if not badverts and not badedges:break
 if not grow:break
 if int(chosen.sum())+len(grow)>int(start.sum())+1500:break
 chosen[list(grow)]=True
border=[e for e,fs in edges.items()if any(chosen[fs])and not all(chosen[fs])];degree=Counter(v for e in border for v in e);badverts={v for v,d in degree.items()if d!=2};badedges=[e for e in border if sum(not chosen[f]for f in edges[e])!=1];loops=[]
if not badverts and not badedges:
 adj=defaultdict(list)
 for u,v in border:adj[u].append(v);adj[v].append(u)
 left=set(adj)
 while left:
  first=min(left);ring=[first];prev=None;cur=first
  while True:
   nxt=next(v for v in adj[cur]if v!=prev)
   if nxt==first:break
   assert nxt not in ring;ring.append(nxt);prev,cur=cur,nxt
  left-=set(ring);loops.append(ring)
D['SELECTED']=chosen;D['SELECTED_RAW_IDS']=raw[chosen];D['BOUNDARY_EDGES']=np.array(border);D['ADDED_RAW_IDS']=raw[chosen&~start];D['BAD_BOUNDARY_VERTICES']=np.array(sorted(badverts),int);D['BAD_RETAINED_COUNT_EDGES']=np.array(badedges);D['LOOP_OFFSETS']=np.cumsum([0]+[len(l)for l in loops]);D['LOOP_VERTICES']=np.concatenate(loops)if loops else np.array([],int);np.savez_compressed(r/'checks/scarlett199_whole_arm_domain.npz',**D);report={'history':history,'selected_faces':int(chosen.sum()),'added_faces':int((chosen&~start).sum()),'boundary_degree_histogram':dict(Counter(degree.values())),'one_retained_face_per_edge':not badedges,'closed_degree_two_interfaces':bool(loops),'loops':[{'vertices':len(l),'min_gltf':W[l].min(0).tolist(),'max_gltf':W[l].max(0).tolist()}for l in loops],'scope':'Deterministic bounded additions absorb inherited branch/corner fragments inside the whole-arm/contact-footprint proposal. Protected central facial faces and held skin repairs are retained. The lower lateral hoop/wrist contact belowY.735m and lateral toX−.120m is included in the compound return domain. This does not authorize a cut before ownership, geometry and return construction.'};(r/'checks/scarlett199_whole_arm_domain.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
