"""Transplant held White31 upper-source repairs onto the independent coherent garment73.
Existing garment/stocking/hand/cuff buffers, attributes and primitives stay exact.
"""
from pathlib import Path
import copy,json,hashlib
import numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=Path(__file__).resolve().parents[1];base=r.parent/'white-hands/models/white73_coherent_garment_assembly.glb';old=r/'models/white_25_continuous_neck_paint_trial.glb';upper=r/'models/white_31_neck_duplicate_cleanup.glb';j,b,a=read_glb(base);oj,ob,oa=read_glb(old);uj,ub,ua=read_glb(upper);original=copy.deepcopy(j);originalB=b
assert j['nodes']==oj['nodes']==uj['nodes']
op=oj['meshes'][0]['primitives'][0];up=uj['meshes'][0]['primitives'][0];bp=j['meshes'][0]['primitives'][0]
for key,ai in op['attributes'].items():
 assert np.array_equal(oa(ai,normalized=False),a(bp['attributes'][key],normalized=False));assert np.array_equal(oa(ai,normalized=False),ua(up['attributes'][key],normalized=False))
for i in range(len(oj['materials'])):assert j['materials'][i]==oj['materials'][i]==uj['materials'][i]
OF=oa(op['indices']).reshape(-1,3);UF=ua(up['indices']).reshape(-1,3);BF=a(bp['indices']).reshape(-1,3);oldset={tuple(map(int,f))for f in OF};newset={tuple(map(int,f))for f in UF};deleted=oldset-newset;added=newset-oldset;flips={};newcanonical={tuple(sorted(f)):f for f in added}
for f in list(deleted):
 key=tuple(sorted(f))
 if key in newcanonical:flips[f]=newcanonical[key]
assert len(flips)==2 and len(added)==2 and len(deleted)==368,(len(flips),len(added),len(deleted))
line=np.load(r/'checks/white27_shirt_source_lineage.npz');shirt_old=line['original_source_vertex_ids'];shirt_raw=line['raw_preLOD_face_ids'];line.close();Bset={tuple(map(int,f))for f in BF};shirt_keep=np.array([tuple(map(int,f))in Bset for f in shirt_old]);assert shirt_keep.all(),'Partial chest intersection requires explicit clip-aware handling, not a whole-face reinsertion'
result=[];removed=[];flipped=[]
for f in BF:
 k=tuple(map(int,f))
 if k in flips:result.append(flips[k]);flipped.append(k)
 elif k in deleted:removed.append(k)
 else:result.append(k)
assert len(flipped)==2;assert len(removed)==366,(len(removed),len(flipped));bp['indices'],b=append_accessor(j,b,np.asarray(result,'u4').ravel(),'SCALAR',34963)
# Copy only resources needed by the new painted upper-shirt primitive.
vm={};am={};im={};tm={};sm={};mm={}
def view(i):
 global b
 if i in vm:return vm[i]
 v=copy.deepcopy(uj['bufferViews'][i]);assert v.get('buffer',0)==0;start=v.get('byteOffset',0);blob=ub[start:start+v['byteLength']];b+=b'\0'*((-len(b))%4);v['byteOffset']=len(b);v['buffer']=0;vm[i]=len(j['bufferViews']);j['bufferViews'].append(v);b+=blob;return vm[i]
def acc(i):
 if i in am:return am[i]
 x=copy.deepcopy(uj['accessors'][i]);assert 'sparse'not in x;x['bufferView']=view(x['bufferView']);am[i]=len(j['accessors']);j['accessors'].append(x);return am[i]
def img(i):
 if i in im:return im[i]
 x=copy.deepcopy(uj['images'][i]);assert 'bufferView'in x;x['bufferView']=view(x['bufferView']);im[i]=len(j.setdefault('images',[]));j['images'].append(x);return im[i]
def samp(i):
 if i not in sm:sm[i]=len(j.setdefault('samplers',[]));j['samplers'].append(copy.deepcopy(uj['samplers'][i]))
 return sm[i]
def tex(i):
 if i in tm:return tm[i]
 x=copy.deepcopy(uj['textures'][i])
 if 'source'in x:x['source']=img(x['source'])
 if 'sampler'in x:x['sampler']=samp(x['sampler'])
 for ext in x.get('extensions',{}).values():
  if 'source'in ext:ext['source']=img(ext['source'])
 tm[i]=len(j.setdefault('textures',[]));j['textures'].append(x);return tm[i]
def mat(i):
 if i in mm:return mm[i]
 x=copy.deepcopy(uj['materials'][i])
 def walk(d):
  if isinstance(d,dict):
   for k,v in d.items():
    if k.endswith('Texture')and isinstance(v,dict)and'index'in v:v['index']=tex(v['index'])
    else:walk(v)
  elif isinstance(d,list):
   for v in d:walk(v)
 walk(x);mm[i]=len(j['materials']);j['materials'].append(x);return mm[i]
assert len(uj['meshes'][0]['primitives'])==len(oj['meshes'][0]['primitives'])+1
p=copy.deepcopy(uj['meshes'][0]['primitives'][9]);p['attributes']={k:acc(v)for k,v in p['attributes'].items()};p['indices']=acc(p['indices']);p['material']=mat(p['material']);shirt_index=len(j['meshes'][0]['primitives']);j['meshes'][0]['primitives'].append(p)
for key in ['extensionsUsed','extensionsRequired']:j[key]=sorted(set(j.get(key,[]))|set(uj.get(key,[])))
out=r/'models/white_32_upper_garment_merge_trial.glb';write_glb(out,j,b);nj,nb,na=read_glb(out);assert nb[:len(originalB)]==originalB
for pi,p0 in enumerate(original['meshes'][0]['primitives'][1:],1):
 p1=nj['meshes'][0]['primitives'][pi];assert p0==p1
 for key,ai in p0['attributes'].items():assert np.array_equal(a(ai,False),na(p1['attributes'][key],False))
 assert np.array_equal(a(p0['indices']),na(p1['indices']))
for key,ai in original['meshes'][0]['primitives'][0]['attributes'].items():assert np.array_equal(a(ai,False),na(nj['meshes'][0]['primitives'][0]['attributes'][key],False))
np.savez_compressed(r/'checks/white192_upper_merge_lineage.npz',removed_source25_vertex_triangles=np.array(removed),flipped_source25_vertex_triangles=np.array(flipped),shirt_raw_preLOD_ids=shirt_raw,shirt_original_vertex_triangles=shirt_old,shirt_target_primitive=shirt_index)
report={'base73':str(base),'base73_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'held_upper31_sha256':hashlib.sha256(upper.read_bytes()).hexdigest(),'source25_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'retained73_binary_prefix_exact':True,'all_existing_other_primitives_attributes_indices_materials_exact':True,'existing_source0_position_normal_uv_accessors_exact':True,'source_winding_corrections':2,'source_removed_triangles':366,'shirt_repainted_exact_source_faces':360,'actual_neck_removed_triangles':6,'new_shirt_primitive':shirt_index,'triangles':sum(nj['accessors'][p['indices']]['count']//3 for p in nj['meshes'][0]['primitives']),'scope':'Coherent assembly trial merging the held upper repairs with garment73 without rebuilding any component. It inherits73 hand pose/cuff/contact/drape gates and31 collar/material gates. Matched actual-model views still required; no final appearance approval.'};(r/'checks/white192_upper_merge.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
