"""Join held native hand to a closed elbow union through an explicit cylindrical wrist annulus."""
from pathlib import Path
from collections import defaultdict,Counter
import json,hashlib
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from glb_io import append_accessor,write_glb,read_glb
r=Path(__file__).resolve().parents[1];z=np.load(r/'checks/scarlett176_arm_union_input.npz');W=z['PHYSICAL_P'];G=z['PHYSICAL_F'];C=z['CLIP_CENTER'];n=z['AXIS'];ex=z['AXIS_EX'];ey=z['AXIS_EY'];z.close();native_source=r/'components/scarlett_right_forearm168_painted_trial.glb';nj,nb,na=read_glb(native_source);np0=nj['meshes'][0]['primitives'][0];nativeP=na(np0['attributes']['POSITION']);nativeF=na(np0['indices']).reshape(-1,3);W,inv=np.unique(nativeP,axis=0,return_inverse=True);G=inv[nativeF];q=np.load(r/'checks/scarlett179_open_proximal_arm.npz');PP=q['P'];PF=q['F'];pl=q['WRIST_LOOP'];q.close();level=.027;h=(W-C)@n-level;positive=h>0;E=np.unique(np.sort(np.concatenate([G[:,[0,1]],G[:,[1,2]],G[:,[2,0]]]),1),axis=0);E=E[positive[E].all(1)];graph=coo_matrix((np.ones(len(E)*2),(np.r_[E[:,0],E[:,1]],np.r_[E[:,1],E[:,0]])),shape=(len(W),len(W))).tocsr();_,labels=connected_components(graph,directed=False);seed=int(np.argmax(W[:,1]));selected=positive&(labels==labels[seed]);points=W.tolist();tri=[];cache={};native_whole=[];native_clipped=[]
for fid,f in enumerate(G):
 if not selected[f].any():continue
 assert np.all(selected[f]==positive[f])
 if selected[f].all():native_whole.append(fid);tri.append(f.tolist());continue
 out=[]
 for u,v in zip(f,np.roll(f,-1)):
  if h[u]>=0:out.append(int(u))
  if (h[u]>0)!=(h[v]>0):
   key=tuple(sorted((int(u),int(v))))
   if key not in cache:
    t=h[u]/(h[u]-h[v]);cache[key]=len(points);points.append((W[u]+t*(W[v]-W[u])).tolist())
   out.append(cache[key])
 for k in range(1,len(out)-1):tri.append([out[0],out[k],out[k+1]])
 native_clipped.append(fid)
HP=np.asarray(points,'f4').astype('f8');HF=np.array(tri,int);used=np.unique(HF);inv=np.full(len(HP),-1,int);inv[used]=np.arange(len(used));HP=HP[used];HF=inv[HF]
def boundaries(P,F):
 edges=defaultdict(list)
 for fi,f in enumerate(F):
  for u,v in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(u),int(v))))].append((fi,int(u),int(v)))
 assert max(map(len,edges.values()))<=2
 border=[v[0][1:]for v in edges.values()if len(v)==1];out={u:v for u,v in border};assert len(out)==len(border);ring=[min(out)];cur=ring[0]
 while out[cur]!=ring[0]:
  cur=out[cur];assert cur not in ring;ring.append(cur)
 assert len(ring)==len(border);return np.array(ring),edges
hl,_=boundaries(HP,HF)
def polar(P,loop):
 X=P[loop]-C;xy=X@np.stack([ex,ey],1);theta=np.arctan2(xy[:,1],xy[:,0]);delta=(np.roll(theta,-1)-theta+np.pi)%(2*np.pi)-np.pi;sgn=np.sign(delta.sum());assert np.all(delta*sgn>0),('Non-star wrist ring',float(delta.min()),float(delta.max()));idx=np.argsort(theta);return loop[idx],theta[idx],np.linalg.norm(xy[idx],axis=1)
hl,ht,hr=polar(HP,hl);pl,pt,pr=polar(PP,pl);points=np.vstack([PP,HP]).tolist();faces=PF.tolist()+(HF+len(PP)).tolist();kinds=[0]*len(PF)+[1]*len(HF);hl=hl+len(PP)
# Keep both exact observed rings; interpolate only between these two planar boundaries.
theta=np.linspace(-np.pi,np.pi,160,endpoint=False);rp=np.interp(theta,pt,pr,period=2*np.pi);rh=np.interp(theta,ht,hr,period=2*np.pi);rings=[pl.tolist()];angles=[pt]
for t in np.linspace(0,1,9)[1:-1]:
 radius=(1-t)*rp+t*rh;X=C+(level*t)*n+radius[:,None]*(np.cos(theta)[:,None]*ex+np.sin(theta)[:,None]*ey);start=len(points);points.extend(X.tolist());rings.append(list(range(start,start+len(theta))));angles.append(theta)
rings.append(hl.tolist());angles.append(ht)
def ziprings(A,ta,B,tb):
 i=j=0;out=[]
 while i<len(A)or j<len(B):
  ni=ta[(i+1)%len(A)]+(2*np.pi if i+1>=len(A)else 0)if i<len(A)else np.inf
  nj=tb[(j+1)%len(B)]+(2*np.pi if j+1>=len(B)else 0)if j<len(B)else np.inf
  if ni<nj:out.append([A[i%len(A)],A[(i+1)%len(A)],B[j%len(B)]]);i+=1
  else:out.append([A[i%len(A)],B[(j+1)%len(B)],B[j%len(B)]]);j+=1
 return out
for A,ta,B,tb in zip(rings,angles,rings[1:],angles[1:]):
 new=ziprings(A,ta,B,tb);faces.extend(new);kinds.extend([2]*len(new))
P=np.array(points,'f4');F=np.array(faces,'u4');kinds=np.array(kinds,'i1');counts=Counter(tuple(sorted((int(u),int(v))))for f in F for u,v in zip(f,np.roll(f,-1)));assert set(counts.values())=={2},Counter(counts.values());physical,iv=np.unique(P,axis=0,return_inverse=True);assert len(physical)==len(P),'Unexpected exact duplicate vertices';Euler=len(P)-len(counts)+len(F);assert Euler==2;fn=np.cross(P[F[:,1]].astype('f8')-P[F[:,0]],P[F[:,2]].astype('f8')-P[F[:,0]]);area=np.linalg.norm(fn,axis=1)/2;assert area.min()>1e-13;volume=float(np.einsum('ij,ij->i',P[F[:,0]],fn).sum()/6);assert volume>0
N=np.zeros(P.shape,'f8')
for k in range(3):np.add.at(N,F[:,k],fn)
N/=np.linalg.norm(N,axis=1)[:,None];N=N.astype('f4');edges=defaultdict(list)
for fi,f in enumerate(F):
 for u,v in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(u),int(v))))].append(fi)
unit=fn/np.linalg.norm(fn,axis=1)[:,None];joinangles=[]
for ids in edges.values():
 if kinds[ids[0]]!=kinds[ids[1]]:joinangles.append(float(np.degrees(np.arccos(np.clip(unit[ids[0]]@unit[ids[1]],-1,1)))))
out=r/'components/scarlett_right_arm183_nail_geometry_trial.glb';j={'asset':{'version':'2.0','generator':'Complete native hand and bounded proximal union183'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'Scarlett complete raised arm183','mesh':0}],'meshes':[{'primitives':[]}],'materials':[{'name':'Neutral anatomical study','pbrMetallicRoughness':{'baseColorFactor':[.62,.43,.31,1],'metallicFactor':0,'roughnessFactor':.6}}],'bufferViews':[],'accessors':[]};b=b'';attrs={}
for key,arr in [('POSITION',P),('NORMAL',N)]:attrs[key],b=append_accessor(j,b,arr,'VEC3',34962)
ix,b=append_accessor(j,b,F.ravel(),'SCALAR',34963);j['meshes'][0]['primitives']=[{'attributes':attrs,'indices':ix,'material':0}];write_glb(out,j,b);np.savez_compressed(r/'checks/scarlett183_complete_arm.npz',P=P,F=F,N=N,FACE_KIND=kinds,NATIVE_WHOLE_SOURCE_IDS=np.array(native_whole),NATIVE_CLIPPED_SOURCE_IDS=np.array(native_clipped),DISTAL_JOIN=hl,PROXIMAL_JOIN=pl)
report={'held_native_source':str(native_source),'held_native_sha256':hashlib.sha256(native_source.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':len(F),'vertices':len(P),'Euler':Euler,'closed_two_face_edges':len(counts),'signed_volume_m3':volume,'minimum_triangle_area_m2':float(area.min()),'native_whole_triangles':len(native_whole),'native_clipped_source_triangles':len(native_clipped),'proximal_triangles':len(PF),'bridge_triangles':int((kinds==2).sum()),'native_planar_wrist_edges':len(hl),'proximal_planar_wrist_edges':len(pl),'max_join_dihedral_deg':max(joinangles),'scope':'Whole isolated donor arm with exact native distal triangles, coherent elbow union, explicit open-annulus wrist bridge and a temporary shoulder cap. Source character is unchanged. V4 and actual views remain pending.'};(r/'checks/scarlett183_complete_arm.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
