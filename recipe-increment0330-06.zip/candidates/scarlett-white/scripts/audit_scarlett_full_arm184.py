"""Actual serialized whole-hand intersection audit after integral nail relief."""
from pathlib import Path
import sys, json, hashlib
import numpy as np
from glb_io import read_glb
root=Path(__file__).resolve().parents[1]; source=root/'components/scarlett_right_arm183_nail_geometry_trial.glb'
j,b,a=read_glb(source); pr=j['meshes'][0]['primitives'][0]
P=a(pr['attributes']['POSITION']); T=a(pr['indices']).reshape(-1,3); N=a(pr['attributes']['NORMAL'])
assert np.isfinite(P).all() and np.isfinite(N).all()
assert abs(np.linalg.norm(N,axis=1)-1).max()<1e-5
weld,inverse=np.unique(P,axis=0,return_inverse=True); T=inverse[T]
helper=root.parent/'mustard/v5_rebuild/scripts/audit_intersections_v4.py'
sys.path.append(str(helper.parent)); ns={'__name__':'scarlett_arm184_audit','__file__':str(helper)}
exec(compile(helper.read_text().replace('from glb_io import GLB\n',''),str(helper),'exec'),ns)
result=ns['audit'](weld,T,tol=1e-8)
from scipy.spatial import cKDTree
oj,ob,oa=read_glb(root/'components/scarlett_right_forearm168_painted_trial.glb');op=oj['meshes'][0]['primitives'][0];oldP=oa(op['attributes']['POSITION']);held=oldP[:,1]>.710;held_error=float(cKDTree(P).query(oldP[held])[0].max())
report={'held_distal168_max_position_error_m':held_error,'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'triangles':len(T),'proper_crossings':result['proper_crossings'],'positive_area_coplanar_pairs':result['positive_area_coplanar_pairs'],'full_face_copy_groups':result['position_triangle_copy_groups'],'zero_area_faces':result['zero_area_faces'],'scope':'Complete isolated shoulder-to-hand component with temporary shoulder cap; source character integration remains open.'}
(root/'checks/scarlett184_full_arm_v4.json').write_text(json.dumps(report,indent=2));print({k:len(report[k])for k in ['proper_crossings','positive_area_coplanar_pairs','full_face_copy_groups','zero_area_faces']},flush=True)
assert not any(report[k] for k in ['proper_crossings','positive_area_coplanar_pairs','full_face_copy_groups','zero_area_faces'])
