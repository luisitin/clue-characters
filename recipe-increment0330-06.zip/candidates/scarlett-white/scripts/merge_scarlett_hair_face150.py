"""Merge current far-skin work with six jointly supported source hair removals."""
from pathlib import Path
from collections import Counter
import json,hashlib,copy
import numpy as np
from glb_io import read_glb,append_accessor,write_glb
r=Path(__file__).resolve().parents[1];source=r/'models/scarlett_25_far_skin_material_trial.glb';digest=hashlib.sha256(source.read_bytes()).hexdigest();targets=[27235,83662,28932,52091,50881,51194];proof=[]
for rawface in targets:
    path=r/'checks'/f'scarlett148_raw{rawface}_support.json';q=json.loads(path.read_text());assert q['sha256']==digest and q['jointly_excluded_raw_faces']==targets
    for obs in q['observations']:
        c=obs['counts']['all'];assert c['n']==c['first_hit_front_with_ties']==c['front_backing_within_5mm']==3321
        assert all(x['raw_face']>=0 and x['raw_face']not in targets for x in obs['backing_faces'])
    proof.append({'raw_face':rawface,'report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'max_backing_mm':max(o['nearest_front_backing_min_median_max_mm'][2]for o in q['observations'])})
j,b,a=read_glb(source);original=copy.deepcopy(j);sj,sb,sa=read_glb(r/'models/scarlett_01_exact_duplicates.glb');sp=sj['meshes'][0]['primitives'][0];raw=np.load(r/'checks/scarlett_01_source_face_lineage.npz')['retained_source_face_ids'];lookup={tuple(map(int,f)):int(raw[k])for k,f in enumerate(sa(sp['indices']).reshape(-1,3))};removed=[];oldF=[];newF=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
    if p['attributes']['POSITION']!=sp['attributes']['POSITION']:continue
    F=a(p['indices']).reshape(-1,3);lineage=np.array([lookup.get(tuple(map(int,f)),-1)for f in F]);keep=~np.isin(lineage,targets);oldF.extend(F);newF.extend(F[keep])
    if not keep.all():
        removed.extend({'raw_face':int(lineage[k]),'primitive':pi,'face':int(k)}for k in np.flatnonzero(~keep));p['indices'],b=append_accessor(j,b,F[keep].astype('u4'),'SCALAR',34963)
assert sorted(x['raw_face']for x in removed)==sorted(targets)
P=sa(sp['attributes']['POSITION']);W,iv=np.unique(P,axis=0,return_inverse=True)
def edge_counts(F):
    c=Counter()
    for f in iv[np.asarray(F)]:
        for aa,bb in zip(f,np.roll(f,-1)):c[tuple(sorted((int(aa),int(bb))))]+=1
    return c
before=edge_counts(oldF);after=edge_counts(newF);changed=[{'welded_edge':list(e),'before':n,'after':after[e]}for e,n in before.items()if n!=after[e]]
out=r/'models/scarlett_27_face_hair_merge.glb';write_glb(out,j,b);nj,nb,na=read_glb(out)
for pi,p in enumerate(nj['meshes'][0]['primitives']):
    old=original['meshes'][0]['primitives'][pi]
    assert p['attributes']==old['attributes'] and p.get('material')==old.get('material')
    for key,index in p['attributes'].items():assert np.array_equal(na(index),a(old['attributes'][key]))
report={'source':str(source),'source_sha256':digest,'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_faces':removed,'six_face_joint_proof':proof,'all_retained_attributes_images_materials_held':True,'incidence_changes':changed,'triangles':sum(len(na(p['indices']))//3 for p in nj['meshes'][0]['primitives']),'scope':'Coherent current face/hair WIP, combining25 paint/tangent work and24 hair cleanup plus the independently diagnosed51194 caster. Fresh final-union proof uses exact25 and all six exclusions; original required27724 stays. Actual final-file front/profile/exposing-view regression required.'}
(r/'checks/scarlett150_face_hair_merge.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
