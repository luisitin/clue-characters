# Six-character WIP recipe checkpoint

Snapshot: 2026-10-04. These are editable build recipes, authored construction inputs and exact painting/calibration images. They do not replace the published current GLBs.

Extract all numbered ZIP archives into one empty directory, preserving paths. Run `python3 verify_recipe_files.py`. From that directory, run `python3 prepare_original_inputs.py /path/to/clue-characters` using a clone of this public repository. This copies the six checksummed original models from its preserved desktop backup. Run the character-specific instructions in `recipes/` from the extracted directory with the stated dependencies. Generated outputs belong in this separate recipe workspace.

- Green: captured sleeve38 and eye50 recipe dependency chain, exact six-view painting inputs. Static dependency review only; no fresh end-to-end replay claimed.
- Mustard: deep pointing-hand/cuff recipes; the small frozen cuff-profile array closes a legacy dependency. A fresh full replay has not been performed.
- Peacock: editable132 export checkpoint plus unique140 painting input. The captured144 paint experiment is rejected because a front view showed an extra far-nostril mark. It is retained only as an explicitly failed experiment, never an accepted model. Newer work is outside this checkpoint.
- Plum: clean-tree replay completed. Seven of eight GLBs were byte-identical. The hand differed by one tangent scalar (0.0001000166); geometry, normals, UVs, indices, transforms and other bytes matched. New components remain unjoined studies.
- Scarlett/White: captured procedural chains and prepared eye/lip arrays; individual stages ran, but the curated full clean-directory replay has not been performed.

Absolute machine paths in copied metadata were relocated; hashes record both original and relocated bytes. The shared official MakeHuman donor asset subset occurs once under `shared_sources/`, with pinned provenance and scoped licenses. No upstream executable code or software binaries are bundled. Other custom source models, artwork and generated painting inputs receive no new blanket license here. No recipe result is approved as a finished character, and archive integrity is not a visual/anatomical test.
