"""Copy the already-public original six models into this recipe workspace."""
from pathlib import Path
import hashlib, json, shutil, sys
root=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root
for item in json.loads((root/'recipes/ORIGINAL_INPUTS.json').read_text())['files']:
    src=repo/item['repository_path'];dst=root/item['path']
    data=src.read_bytes()
    if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
        raise ValueError('Original model mismatch: '+item['repository_path'])
    if dst.exists() and dst.read_bytes()!=data:
        raise FileExistsError('Refusing to replace changed input: '+item['path'])
    dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    print('Verified '+item['path'])
