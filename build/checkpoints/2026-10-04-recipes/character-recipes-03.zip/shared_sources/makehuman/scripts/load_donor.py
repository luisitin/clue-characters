"""Read pinned CC0 hm08 data without running MakeHuman code.
Coordinates and UVs are native OBJ. Corner UV indices remain separate from geometry.
No rig pose, winding correction or dimensional assumptions are silently applied.
"""
import pathlib,json,numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load_obj(path=None):
 V=[];UV=[];polygons=[];uvpolygons=[];groups=[];group=''
 for line in open(path or ROOT/'raw/base.obj'):
  s=line.split()
  if not s:continue
  if s[0]=='v':V.append(list(map(float,s[1:4])))
  elif s[0]=='vt':UV.append(list(map(float,s[1:3])))
  elif s[0]=='g':group=' '.join(s[1:])
  elif s[0]=='f':
   q=[t.split('/')for t in s[1:]];polygons.append([int(v[0])-1 for v in q]);uvpolygons.append([int(v[1])-1 if len(v)>1 and v[1]else -1 for v in q]);groups.append(group)
 return np.array(V,float),np.array(UV,float),polygons,uvpolygons,np.array(groups)
def load_donor():
 V,UV,F,FUV,G=load_obj();rig=json.load(open(ROOT/'raw/default.mhskel'));wd=json.load(open(ROOT/'raw/default_weights.mhw'));assert rig['license']==wd['license']=='CC0';names=list(rig['bones']);W=np.zeros((len(V),len(names)),float)
 for name,entries in wd['weights'].items():
  assert name in names;col=names.index(name)
  for idx,value in entries:
   assert 0<=idx<len(V) and value>=0;W[idx,col]+=value
 sums=W.sum(1);normalized=np.divide(W,sums[:,None],out=np.zeros_like(W),where=sums[:,None]>0)
 joints={name:V[ids].mean(0)for name,ids in rig['joints'].items()};body=np.flatnonzero(G=='body')
 return {'positions':V,'uv':UV,'faces':F,'face_uv':FUV,'face_group':G,'body_face_ids':body,'rig':rig,'bone_names':names,'weights_raw':W,'weights_normalized':normalized,'weight_sums_raw':sums,'joint_positions':joints}
