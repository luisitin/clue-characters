"""Soften the thin corner crease while holding the measured lip envelope and topology."""
import pathlib,json,numpy as np,hashlib
from scipy.interpolate import PchipInterpolator
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_05_back_roughness.glb';j,b,a=read_glb(src);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);controls=json.loads((r/'checks/scarlett_lip_traces04.json').read_text());origin=np.array(controls['image_origin']);B=np.stack([controls['image_longitudinal_axis'],controls['image_downward_transverse_axis']],1);length=controls['longitudinal_length_pixels'];curves={k:PchipInterpolator(np.array(v)[:,0],np.array(v)[:,1],extrapolate=False)for k,v in controls['normalized_longitudinal_and_transverse_traces'].items()};pixel_m=.085/800;D=np.array(json.loads((r/'checks/scarlett_04_lip_support.json').read_text())['constant_anatomical_outward_direction_gltf'])
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def displacement(Q,new=False):
 pix=np.c_[400+(Q[:,0]+.055)/pixel_m,400-(Q[:,1]-.7488)/pixel_m];q=(pix-origin)@B;u=q[:,0]/length;v=q[:,1];uc=np.clip(u,0,1);top=curves['upper'](uc);seam=curves['seam'](uc);bottom=curves['lower'](uc);top=np.minimum(top,seam);bottom=np.maximum(bottom,seam);long=smooth(uc/(.14 if new else .08))*smooth((1-uc)/.08);active=(u>=0)&(u<=1)&(v>=top)&(v<=bottom);tu=(v-top)/np.maximum(seam-top,1e-6);tl=(v-seam)/np.maximum(bottom-seam,1e-6);amp_upper=.00055*np.tanh(.25*np.maximum(seam-top,0)*pixel_m/.00055);amp_lower=.00085*np.tanh(.25*np.maximum(bottom-seam,0)*pixel_m/.00085);du=amp_upper*np.sin(np.pi*np.clip(tu,0,1))**2*((v<=seam)&(seam>top));dl=amp_lower*np.sin(np.pi*np.clip(tl,0,1))**2*((v>seam)&(bottom>seam));whole=np.clip((v-top)/np.maximum(bottom-top,1e-6),0,1);grooveamp=.00012*(np.tanh(.055*np.maximum(bottom-top,0)*pixel_m/.00012)if new else 1);groove=-grooveamp*np.exp(-.5*((v-seam)*pixel_m/.00045)**2)*np.sin(np.pi*whole)**2;depthgate=smooth((Q[:,2]-.02)/.015);return (du+dl+groove)*long*active*depthgate
def grad(Q,new=False):
 G=np.zeros_like(Q);h=2e-6
 for k in range(3):s=np.zeros(3);s[k]=h;G[:,k]=(displacement(Q+s,new)-displacement(Q-s,new))/(2*h)
 return G
reports=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 acc=j['accessors'][p['attributes']['POSITION']]
 if acc['componentType']!=5126:continue
 P=a(p['attributes']['POSITION'])*scale+translation;N=a(p['attributes']['NORMAL']);rest=P.copy()
 for _ in range(12):
  g=grad(rest);d=displacement(rest);err=np.sum((rest+d[:,None]*D-P)*D,axis=1);rest-=((err/(1+g@D))[:,None]*D)
 residual=np.linalg.norm(rest+displacement(rest)[:,None]*D-P,axis=1).max();assert residual<1e-10
 oldg=grad(rest);newg=grad(rest,True);baseN=N+oldg*(N@D)[:,None];baseN/=np.linalg.norm(baseN,axis=1)[:,None];det=1+newg@D;assert det.min()>.35;NN=baseN-newg*((baseN@D)/det)[:,None];NN/=np.linalg.norm(NN,axis=1)[:,None];Q=rest+displacement(rest,True)[:,None]*D;delta=np.linalg.norm(Q-P,axis=1);assert delta.max()<.00025
 for key,val in [('POSITION',((Q-translation)/scale).astype(np.float32)),('NORMAL',NN.astype(np.float32))]:p['attributes'][key],b=append_accessor(j,b,val,'VEC3',34962)
 reports.append({'primitive':pi,'vertices':len(P),'rest_inverse_residual_m':float(residual),'change_max_m':float(delta.max()),'change_vertices':int((delta>1e-8).sum()),'new_min_Jacobian':float(det.min())})
assert len(reports)==1;out=r/'models/scarlett_06_lip_corner_softness.glb';write_glb(out,j,b);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changed':reports,'topology_UV_all_maps_materials_and_held_source_geometry_unchanged':True,'method':'Invert existing constant-direction lip relief, then taper image-left corner amplitude over14% versus8%, and taper seam depression with total local lip width. Upper/lower painted envelope and broad volume constants held.','status':'Unapproved bounded corner trial; exact front/low/profile comparison and crossing gate required.'};(r/'checks/scarlett_06_lip_corner_softness.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
