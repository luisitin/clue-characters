"""Match continuous piecewise-linear source edges before smoothing the annular depth field.
Apertures, ellipsoid fronts, contact strips and exact source outer positions are held.
"""
import pathlib,json,numpy as np,hashlib,collections
from scipy.interpolate import RBFInterpolator
from glb_io import read_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_01_exact_duplicates.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION'])*j['nodes'][0]['scale']+j['nodes'][0]['translation'];F=a(p['indices']).reshape(-1,3);W,inv=np.unique(P,axis=0,return_inverse=True);WF=inv[F];cross=np.cross(P[F[:,1]]-P[F[:,0]],P[F[:,2]]-P[F[:,0]]);normal=cross/np.maximum(np.linalg.norm(cross,axis=1)[:,None],1e-15);C=P[F].mean(1);d=np.load(r/'checks/white_eye_patch08.npz');data={k:d[k]for k in d.files};d.close();reports={}
def inside(points,poly):
 x=points[:,0];y=points[:,1];result=np.zeros(len(points),bool)
 for aa,bb in zip(poly,np.roll(poly,-1,axis=0)):result^=((aa[1]>y)!=(bb[1]>y))&(x<(bb[0]-aa[0])*(y-aa[1])/(bb[1]-aa[1]+1e-30)+aa[0])
 return result
for name in ['near','far']:
 Q=data[name+'_positions'].copy();old=Q.copy();T=data[name+'_skin_triangles'];outer=data[name+'_outer_vertex_ids'];inner=data[name+'_aperture_vertex_ids'];source_ids=data[name+'_outer_source_position_ids'];selected=data[name+'_source_face_ids'];adjacent=np.flatnonzero(np.any(np.isin(WF,source_ids),axis=1));adjacent=np.setdiff1d(adjacent,selected);adjacent=adjacent[(normal[adjacent,2]>.15)&~inside(C[adjacent,:2],Q[outer,:2])];support=C[adjacent];fixed=np.r_[outer,inner];edge_support=[]
 for aa,bb in zip(Q[outer],np.roll(Q[outer],-1,axis=0)):
  steps=max(2,int(np.ceil(np.linalg.norm(bb[:2]-aa[:2])/.0003)))
  edge_support.extend(aa+(bb-aa)*t for t in np.arange(1,steps)/steps)
 edge_support=np.array(edge_support);X=np.vstack([Q[fixed,:2],edge_support[:,:2],support[:,:2]]);Z=np.r_[Q[fixed,2],edge_support[:,2],support[:,2]];smoothing=np.r_[np.zeros(len(fixed)+len(edge_support)),np.full(len(support),.001)];center=Q[inner,:2].mean(0);rbf=RBFInterpolator((X-center)/.04,Z,kernel='thin_plate_spline',degree=1,smoothing=smoothing);used=np.unique(T)
 for start in range(0,len(used),1024):q=used[start:start+1024];Q[q,2]=rbf((Q[q,:2]-center)/.04)
 Q[fixed]=old[fixed];assert np.array_equal(Q[:,:2],old[:,:2]);assert Q[used,2].min()>old[outer,2].min()-.003 and Q[used,2].max()<old[outer,2].max()+.003,'Skin field exceeds bounded orbital envelope';nc=np.cross(Q[T[:,1]]-Q[T[:,0]],Q[T[:,2]]-Q[T[:,0]]);N=np.zeros_like(Q)
 for k in range(3):np.add.at(N,T[:,k],nc)
 N/=np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-15);N[outer]=data[name+'_skin_normals'][outer];edges=collections.defaultdict(list)
 for fi,f in enumerate(T):
  for u,v in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(u),int(v))))].append(fi)
 fn=nc/np.linalg.norm(nc,axis=1)[:,None];pairs=np.array([q for q in edges.values()if len(q)==2]);angles=np.degrees(np.arccos(np.clip(np.sum(fn[pairs[:,0]]*fn[pairs[:,1]],axis=1),-1,1)));reports[name]={'linear_source_edge_constraints':len(edge_support),'retained_source_support_faces':adjacent.tolist(),'skin_depth_change_max_m':float(abs(Q[:,2]-old[:,2]).max()),'skin_depth_change_rms_m':float(np.sqrt(np.mean((Q[used,2]-old[used,2])**2))),'internal_skin_max_dihedral_degrees':float(angles.max()),'internal_skin_edges_over70_degrees':int((angles>70).sum()),'internal_skin_edges_over105_degrees':int((angles>105).sum()),'source_outer_and_aperture_positions_held_exact':bool(np.array_equal(Q[fixed],old[fixed])),'projected_domain_and_triangles_held_exact':True};data[name+'_positions']=Q;data[name+'_skin_normals']=N
np.savez_compressed(r/'checks/white_eye_patch11.npz',**data);(r/'checks/white_eye_patch11.json').write_text(json.dumps({'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eyes':reports,'status':'Unapproved smooth annular field trial. Cap/contact/XY domains held, so height-field self-separation is invariant; fresh retained-source intersections and exact appearance remain required.'},indent=2));print(reports,flush=True)
