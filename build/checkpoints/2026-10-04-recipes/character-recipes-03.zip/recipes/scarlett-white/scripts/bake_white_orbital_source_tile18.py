"""Bounded native4K albedo projection for the new orbital skin/contact chart.
Samples original source UVs directly; no lighting, screenshot upscaling or baked glint edit.
"""
import pathlib,json,numpy as np,hashlib,io,os,time
from PIL import Image
from glb_io import read_glb
r=pathlib.Path(__file__).resolve().parents[1];tile=int(os.environ['TILE']);S=4096;rows=1024;ybase=tile*rows;src=r/'models/white_01_exact_duplicates.glb';target=r/'models/white_17_refined_face.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION'])*j['nodes'][0]['scale']+j['nodes'][0]['translation'];UV=a(p['attributes']['TEXCOORD_0']);F=a(p['indices']).reshape(-1,3);lineage=np.load(r/'checks/white_01_source_face_lineage.npz')['retained_source_face_ids'];keep=~np.isin(lineage,[71217,71218]);material=j['materials'][p['material']];tex=j['textures'][material['pbrMetallicRoughness']['baseColorTexture']['index']];ii=tex.get('source',tex.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));bv=j['bufferViews'][j['images'][ii]['bufferView']];payload=b[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']];base=np.array(Image.open(io.BytesIO(payload)).convert('RGB'));H,W=base.shape[:2];color=np.zeros((rows,S,3),np.uint8);depth=np.full((rows,S),-np.inf,np.float32);face_id=np.full((rows,S),-1,np.int32);xy=np.c_[(.5+(P[:,0]-.009)/.2)*S,(.5-(P[:,1]-.78)/.2)*S];tri=xy[F];lo=tri.min(1);hi=tri.max(1);candidate=np.flatnonzero(keep&(hi[:,0]>=0)&(lo[:,0]<S)&(hi[:,1]>=ybase)&(lo[:,1]<ybase+rows)&(P[F,2].max(1)>.025));ties=0;written=0;start=time.time()
def windows(q):
 low=np.maximum(np.floor(q.min(0)).astype(int),[0,ybase]);high=np.minimum(np.ceil(q.max(0)).astype(int),[S-1,ybase+rows-1]);aa,bb,cc=q;den=(bb[1]-cc[1])*(aa[0]-cc[0])+(cc[0]-bb[0])*(aa[1]-cc[1])
 if abs(den)<1e-12:return
 for y0 in range(low[1],high[1]+1,64):
  for x0 in range(low[0],high[0]+1,512):
   yy,xx=np.meshgrid(np.arange(y0,min(y0+64,high[1]+1)),np.arange(x0,min(x0+512,high[0]+1)),indexing='ij');x=xx+.5;y=yy+.5;w0=((bb[1]-cc[1])*(x-cc[0])+(cc[0]-bb[0])*(y-cc[1]))/den;w1=((cc[1]-aa[1])*(x-cc[0])+(aa[0]-cc[0])*(y-cc[1]))/den;w2=1-w0-w1;ok=(w0>=-1e-9)&(w1>=-1e-9)&(w2>=-1e-9)
   if ok.any():yield yy[ok]-ybase,xx[ok],np.c_[w0[ok],w1[ok],w2[ok]]
def sample(uv):
 xx=uv[:,0]*W-.5;yy=uv[:,1]*H-.5;x0=np.floor(xx).astype(int);y0=np.floor(yy).astype(int);fx=(xx-x0)[:,None];fy=(yy-y0)[:,None];return (base[y0%H,x0%W]*(1-fx)*(1-fy)+base[y0%H,(x0+1)%W]*fx*(1-fy)+base[(y0+1)%H,x0%W]*(1-fx)*fy+base[(y0+1)%H,(x0+1)%W]*fx*fy)
for n,fi in enumerate(candidate):
 f=F[fi]
 for yy,xx,bc in windows(xy[f]):
  z=bc@P[f,2];old=depth[yy,xx];ties+=int(((abs(z-old)<1e-8)&(face_id[yy,xx]>=0)).sum());mask=z>old+1e-8
  if mask.any():
   yv,xv=yy[mask],xx[mask];color[yv,xv]=np.rint(np.clip(sample(bc[mask]@UV[f]),0,255)).astype(np.uint8);depth[yv,xv]=z[mask];face_id[yv,xv]=fi;written+=len(yv)
 if n%3000==0:print('SOURCE_PROJECTION',tile,n,'/',len(candidate),'elapsed',round(time.time()-start,1),flush=True)
tj,tb,ta=read_glb(target);required=np.zeros((rows,S),bool);target_names=[]
for pr in tj['meshes'][0]['primitives']:
 name=tj['materials'][pr.get('material',0)].get('name','')
 if name not in ['White orbital geometry trial skin','White orbital geometry trial lid_contact']:continue
 target_names.append(name);uv=ta(pr['attributes']['TEXCOORD_0'])*S;T=ta(pr['indices']).reshape(-1,3);tt=uv[T];low=tt.min(1);high=tt.max(1);ids=np.flatnonzero((high[:,0]>=0)&(low[:,0]<S)&(high[:,1]>=ybase)&(low[:,1]<ybase+rows))
 for fi in ids:
  for yy,xx,bc in windows(uv[T[fi]]):required[yy,xx]=True
missing=required&(face_id<0);out=r/'checks'/f'white18_orbital_albedo_tile{tile}.png';Image.fromarray(color).save(out);np.savez_compressed(r/'checks'/f'white18_orbital_tile{tile}_coverage.npz',required=required,valid=face_id>=0);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'target_geometry':str(target),'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source_base_image_sha256':hashlib.sha256(payload).hexdigest(),'source_base_image_dimensions':[W,H],'tile':tile,'atlas_dimensions':[S,S],'row_start':ybase,'rows':rows,'candidate_source_faces':len(candidate),'required_skin_texels':int(required.sum()),'required_missing_source_texels':int(missing.sum()),'covered_source_texels':int((face_id>=0).sum()),'depth_tie_samples':ties,'source_depth_tie_policy':'Stable lowest current01 face index within1e-8m depth; all actual color transfer requires exact-model visual review.','validated_nose_pair_excluded_raw_faces':[71217,71218],'target_material_names':sorted(set(target_names)),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'seconds':time.time()-start,'status':'Native4K color transfer input, not final model proof. Intentional1D lid-wall UV strips share boundary color; no normal maps are baked here.'};(r/'checks'/f'white18_orbital_tile{tile}.json').write_text(json.dumps(report,indent=2));print(report,flush=True);assert not missing.any(),'New skin chart lacks source albedo coverage; classify gaps before assembly'
