"""Remove one measured redundant source sheets after fresh joint backing proof."""
import pathlib,json,hashlib,numpy as np,collections,copy
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_18_native4k_orbital_albedo.glb';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();source_hash=sha(src);removed_raw=[115247];proof=[]
for raw in removed_raw:
 path=r/'checks'/f'white20_raw{raw}_support.json';d=json.loads(path.read_text());assert d['sha256']==source_hash and d['jointly_excluded_raw_faces']==removed_raw
 for o in d['observations']:
  c=o['counts']['all'];assert c['n']==3321 and c['first_hit_front_with_ties']==3321 and c['foreground_occluded']==0 and c['visible_without_first_front_within5mm']==0 and o['nearest_front_backing_min_median_max_mm'][-1]<2
 proof.append({'file':str(path),'sha256':sha(path)})
j,b,a=read_glb(src);before=copy.deepcopy(j);p=j['meshes'][0]['primitives'][0];F=a(p['indices']).reshape(-1,3);raw=np.load(r/'checks/white_04_face_lineage.npz')['retained_original_source_face_ids'][np.load(r/'checks/white_08_lip_lineage.npz')['retained_source05_primitive0_face_ids']];keep=~np.isin(raw,removed_raw);assert (~keep).sum()==1;P=a(p['attributes']['POSITION']);W,inv=np.unique(P,axis=0,return_inverse=True);WF=inv[F];edge=collections.Counter(tuple(sorted((int(u),int(v))))for f in WF for u,v in zip(f,np.roll(f,-1)));after=edge.copy();affected=set()
for f in WF[~keep]:
 for u,v in zip(f,np.roll(f,-1)):
  e=tuple(sorted((int(u),int(v))));after[e]-=1;affected.add(e)
changes=[{'position_ids':list(e),'before':edge[e],'after':after[e]}for e in sorted(affected)];ix,b=append_accessor(j,b,F[keep].astype(np.uint32),'SCALAR',34963);p['indices']=ix;out=r/'models/white_20_hair_sheet_cleanup.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out)
for pi,pr in enumerate(jj['meshes'][0]['primitives']):
 for k,v in pr['attributes'].items():assert np.array_equal(aa(v),a(before['meshes'][0]['primitives'][pi]['attributes'][k]))
 if pi:assert np.array_equal(aa(pr['indices']),a(before['meshes'][0]['primitives'][pi]['indices']))
assert j['materials']==before['materials'] and j['images']==before['images'];np.savez_compressed(r/'checks/white_20_source_face_lineage.npz',retained_original_raw_faces=raw[keep]);report={'source':str(src),'source_sha256':source_hash,'output':str(out),'sha256':sha(out),'removed_raw_faces':removed_raw,'removed_current18_primitive0_faces':np.flatnonzero(~keep).tolist(),'proofs':proof,'affected_edge_incidence':changes,'all_retained_positions_normals_UVs_materials_images_and_other_primitives_held':True,'triangles':sum(len(aa(q['indices']))//3 for q in jj['meshes'][0]['primitives']),'status':'Bounded redundant-sheet cleanup trial. Joint dense support is finite-sample proof; exact exposing views and alternate-angle checks remain required.'};(r/'checks/white_20_hair_sheet_cleanup.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
