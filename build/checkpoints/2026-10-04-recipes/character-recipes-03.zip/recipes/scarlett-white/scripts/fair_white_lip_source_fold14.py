"""Bounded tangent fairing of required raw71203 fold; every face is retained."""
import pathlib,json,numpy as np,hashlib,ast,collections
from scipy.interpolate import PchipInterpolator
from scipy.spatial import cKDTree
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_12_eye_cornea_trial.glb';j,b,a=read_glb(src);node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);base=r/'models/white_05_orbit_boundary_normals.glb';bj,bb,ba=read_glb(base);bp=bj['meshes'][0]['primitives'][0];P=ba(bp['attributes']['POSITION'])*scale+translation;F=ba(bp['indices']).reshape(-1,3);lin=np.load(r/'checks/white_04_face_lineage.npz')['retained_original_source_face_ids'];fi=int(np.flatnonzero(lin==71203)[0]);tri=P[F[fi]];pairs=[(0,1),(1,2),(2,0)];u,v=max(pairs,key=lambda p:np.linalg.norm(tri[p[1],:2]-tri[p[0],:2]));A,B=tri[u],tri[v];center=(A[:2]+B[:2])/2;axis=B[:2]-A[:2];length=np.linalg.norm(axis);ex=axis/length;ey=np.array([-ex[1],ex[0]]);basis=np.stack([ex,ey],1)
W,iv=np.unique(P,axis=0,return_inverse=True);WF=iv[F];edge=collections.defaultdict(set)
for k,f in enumerate(WF):
 for x,y in zip(f,np.roll(f,-1)):edge[tuple(sorted((int(x),int(y))))].add(k)
family={fi};wave={fi}
for _ in range(3):
 more={z for k in wave for x,y in zip(WF[k],np.roll(WF[k],-1)) for z in edge[tuple(sorted((int(x),int(y))))]};wave=more-family;family|=more
verts=np.unique(WF[list(family)]);support=W[verts];along=(support[:,:2]-A[:2])@ex;side=np.abs((support[:,:2]-A[:2])@ey);mask=(side>.001)&(along>-.007)&(along<length+.007)&(abs(support[:,2]-tri[:,2].mean())<.015);support=support[mask];assert len(support)>=6

def design(xy):
 q=(xy-center)@basis/.01;u,v=q.T;return np.c_[np.ones(len(q)),u,v,u*u,u*v,v*v]
X=design(support[:,:2]);Z=support[:,2];C=design(np.stack([A[:2],B[:2]]));H=X.T@X+np.diag([0,0,0,1e-5,1e-5,1e-5]);K=np.block([[H,C.T],[C,np.zeros((2,2))]]);rhs=np.r_[X.T@Z,A[2],B[2]];coef=np.linalg.solve(K,rhs)[:6];assert np.linalg.cond(K)<1e10
controls=json.loads((r/'checks/white_lip_traces06.json').read_text());origin=np.array(controls['image_origin']);lipB=np.stack([controls['image_longitudinal_axis'],controls['image_downward_transverse_axis']],1);lip_length=controls['longitudinal_length_pixels'];curves={k:PchipInterpolator(np.array(v)[:,0],np.array(v)[:,1],extrapolate=False)for k,v in controls['normalized_longitudinal_and_transverse_traces'].items()};ns={'np':np,'origin':origin,'B':lipB,'length':lip_length,'curves':curves,'pixel_m':.1/800};tree=ast.parse((r/'scripts/build_white_lip_soft08.py').read_text());funcs=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name in ['smooth','displacement']];exec(compile(ast.Module(body=funcs,type_ignores=[]),'<held_white08_lip_field>','exec'),ns);disp=ns['displacement'];smooth=ns['smooth'];D=np.array(json.loads((r/'checks/white_08_lip_soft_support.json').read_text())['constant_anatomical_outward_direction_gltf'])
def grad(fun,Q):
 G=np.zeros_like(Q);h=2e-6
 for k in range(3):d=np.zeros(3);d[k]=h;G[:,k]=(fun(Q+d)-fun(Q-d))/(2*h)
 return G
def fair_delta(Q):
 along=(Q[:,:2]-A[:2])@ex;t=np.clip(along/length,0,1);nearest=A[:2]+t[:,None]*axis;dist=np.linalg.norm(Q[:,:2]-nearest,axis=1);weight=.8*smooth(1-dist/.0018);return weight*(design(Q[:,:2])@coef-Q[:,2])
p=j['meshes'][0]['primitives'][1];old=a(p['attributes']['POSITION'])*scale+translation;N=a(p['attributes']['NORMAL']);rest=old.copy()
for _ in range(12):
 g=grad(disp,rest);err=np.sum((rest+disp(rest)[:,None]*D-old)*D,axis=1);rest-=err[:,None]*D/(1+g@D)[:,None]
assert np.linalg.norm(rest+disp(rest)[:,None]*D-old,axis=1).max()<1e-9;delta=fair_delta(rest);assert abs(delta).max()<.001;held=j['meshes'][0]['primitives'][0];heldP=a(held['attributes']['POSITION'])*scale+translation;heldT=a(held['indices']).ravel();shared_distance,shared_index=cKDTree(heldP[np.unique(heldT)]).query(old);shared_mask=shared_distance<2e-7;assert abs(delta[shared_mask]).max()<1e-10,'A moved lip vertex shares a held source seam; expand conforming support first'
gradRest=grad(fair_delta,rest);gradLip=grad(disp,rest);gradCurrent=gradRest-gradLip*((gradRest@D)/(1+gradLip@D))[:,None];det=1+gradCurrent[:,2];assert det.min()>.1;NN=N-gradCurrent*(N[:,2]/det)[:,None];NN/=np.linalg.norm(NN,axis=1)[:,None];Q=old.copy();Q[:,2]+=delta
for key,arr in [('POSITION',((Q-translation)/scale).astype(np.float32)),('NORMAL',NN.astype(np.float32))]:p['attributes'][key],b=append_accessor(j,b,arr,'VEC3',34962)
out=r/'models/white_14_lip_source_fold_fairing.glb';write_glb(out,j,b);report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'required_source_face_raw':71203,'all_faces_indices_UVs_materials_and_maps_retained':True,'fit_source_family_raw_faces':lin[sorted(family)].tolist(),'fit_support_points':support.tolist(),'fit_quadratic_coefficients':coef.tolist(),'fit_RMS_m':float(np.sqrt(np.mean((X@coef-Z)**2))),'held_edge_endpoints':np.stack([A,B]).tolist(),'compact_fairing_radius_m':.0018,'maximum_fairing_weight':.8,'shared_held_source_seam_vertices':int(shared_mask.sum()),'shared_held_source_max_delta_m':float(abs(delta[shared_mask]).max()),'moved_vertices':int((abs(delta)>1e-8).sum()),'displacement_min_max_m':[float(delta.min()),float(delta.max())],'minimum_fairing_Jacobian':float(det.min()),'status':'Unapproved bounded required-surface fairing. Exact macro comparison, duplicate-position and crossing checks required; source lip seam and broad shape are held outside1.8mm of the measured strip.'};(r/'checks/white_14_lip_source_fold_fairing.json').write_text(json.dumps(report,indent=2));print({k:report[k]for k in ['sha256','fit_RMS_m','moved_vertices','displacement_min_max_m','minimum_fairing_Jacobian']},flush=True)
