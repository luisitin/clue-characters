"""Add bounded physical lip support to the original piecewise-linear face.
Conforming edge fractions and original barycentric UV binding preserve the source.
"""
import pathlib,json,numpy as np,hashlib,sys,collections,copy
from scipy.interpolate import PchipInterpolator
sys.path.append(str(pathlib.Path(__file__).resolve().parents[3]/'shared_tools/triangle_lib'));import triangle
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];geom=r/'models/scarlett_01_exact_duplicates.glb';src=r/'models/scarlett_02_hair_roughness.glb';j,b,a=read_glb(src);jg,bg,ag=read_glb(geom);p=jg['meshes'][0]['primitives'][0];localP=ag(p['attributes']['POSITION']);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);P=localP*scale+translation;N=ag(p['attributes']['NORMAL']);UV=ag(p['attributes']['TEXCOORD_0']);F=ag(p['indices']).reshape(-1,3);W,inverse=np.unique(P,axis=0,return_inverse=True);G=inverse[F];controls=json.loads((r/'checks/scarlett_lip_traces04.json').read_text());origin=np.array(controls['image_origin']);B=np.stack([controls['image_longitudinal_axis'],controls['image_downward_transverse_axis']],1);length=controls['longitudinal_length_pixels'];curves={k:PchipInterpolator(np.array(v)[:,0],np.array(v)[:,1],extrapolate=False)for k,v in controls['normalized_longitudinal_and_transverse_traces'].items()};pixel_m=.085/800
u_check=np.linspace(0,1,10001);corner_error=np.maximum(curves['upper'](u_check)-curves['seam'](u_check),curves['seam'](u_check)-curves['lower'](u_check));assert corner_error.max()<1.5 and not np.any((corner_error>.5)&(u_check<.95)),'Only subpixel-to1.5px uncertainty at the upturned tip may collapse to the seam';corner_curve_uncertainty=float(corner_error.max())

def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def displacement(Q):
 pix=np.c_[400+(Q[:,0]+.055)/pixel_m,400-(Q[:,1]-.7488)/pixel_m];q=(pix-origin)@B;u=q[:,0]/length;v=q[:,1];uc=np.clip(u,0,1);top=curves['upper'](uc);seam=curves['seam'](uc);bottom=curves['lower'](uc);top=np.minimum(top,seam);bottom=np.maximum(bottom,seam);long=smooth(uc/.08)*smooth((1-uc)/.08);active=(u>=0)&(u<=1)&(v>=top)&(v<=bottom);tu=(v-top)/np.maximum(seam-top,1e-6);tl=(v-seam)/np.maximum(bottom-seam,1e-6);amp_upper=.00055*np.tanh(.25*np.maximum(seam-top,0)*pixel_m/.00055);amp_lower=.00085*np.tanh(.25*np.maximum(bottom-seam,0)*pixel_m/.00085);du=amp_upper*np.sin(np.pi*np.clip(tu,0,1))**2*((v<=seam)&(seam>top));dl=amp_lower*np.sin(np.pi*np.clip(tl,0,1))**2*((v>seam)&(bottom>seam));whole=np.clip((v-top)/np.maximum(bottom-top,1e-6),0,1);groove=-.00012*np.exp(-.5*((v-seam)*pixel_m/.00045)**2)*np.sin(np.pi*whole)**2;depthgate=smooth((Q[:,2]-.02)/.015);return (du+dl+groove)*long*active*depthgate
allpix=np.vstack(list(controls['original_pixel_traces'].values()));xy=np.c_[-.055+(allpix[:,0]-400)*pixel_m,.7488-(allpix[:,1]-400)*pixel_m];low=xy.min(0)-.0015;high=xy.max(0)+.0015;tri=P[F];lo=tri.min(1);hi=tri.max(1);roi=np.all(hi[:,:2]>=low,axis=1)&np.all(lo[:,:2]<=high,axis=1)&(hi[:,2]>.02)&(lo[:,2]<.3);cross=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);area=np.linalg.norm(cross,axis=1)/2;roi&=area>1e-12;front=roi&(cross[:,2]>0);direction=cross[front].sum(0);direction/=np.linalg.norm(direction);assert direction[2]>.4;step=.00045;edge_counts={}
for f in G[roi]:
 for u,v in zip(f,np.roll(f,-1)):
  key=tuple(sorted((int(u),int(v))));edge_counts[key]=max(edge_counts.get(key,1),int(np.ceil(np.linalg.norm(W[u]-W[v])/step)))
edge_faces=collections.defaultdict(set)
for fi,f in enumerate(G):
 for u,v in zip(f,np.roll(f,-1)):
  key=tuple(sorted((int(u),int(v))))
  if key in edge_counts:edge_faces[key].add(fi)
replace=set(np.flatnonzero(roi).tolist())
for key,count in edge_counts.items():
 if count>1:replace|=edge_faces[key]
zero={fi for fi in replace if area[fi]<=1e-12};replace-=zero;assert not zero,'Degenerate source transition needs separate provenance before remeshing';ids=np.array(sorted(replace));assert 10<len(ids)<2000;edge_points={key:np.linspace(W[key[0]],W[key[1]],count+1)for key,count in edge_counts.items()};newP=[];newN=[];newUV=[];newT=[];newMaterial=[];lineage=[];hair=np.load(r/'checks/scarlett_02_hair_face_lineage.npz');materials=np.zeros(len(F),int);materials[hair['source01_material_changed_faces']]=1;hair.close();jacmin=1.;largest_delta=0.;max_rest_error=0.;baryverts=np.array([[0.,0.],[1.,0.],[0.,1.]])
for seq,fi in enumerate(ids):
 f=F[fi];g=G[fi];boundary=[];world_boundary=[]
 for k in range(3):
  kk=(k+1)%3;key=tuple(sorted((int(g[k]),int(g[kk]))));count=edge_counts.get(key,1)
  for n in range(count):
   t=n/count;boundary.append((1-t)*baryverts[k]+t*baryverts[kk]);world_boundary.append(edge_points[key][n if g[k]<g[kk]else count-n]if key in edge_points else P[f[k]])
 boundary=np.array(boundary);segments=np.c_[np.arange(len(boundary)),np.roll(np.arange(len(boundary)),-1)];opts='pY'
 if roi[fi]:opts+=f'q20a{min(.1,1e-7/(2*area[fi])):.12f}'
 tess=triangle.triangulate({'vertices':boundary,'segments':segments},opts);bc=tess['vertices'];tt=tess['triangles'];bary=np.c_[1-bc[:,0]-bc[:,1],bc];Q=bary@P[f];Q[:len(boundary)]=world_boundary;old=Q.copy();delta=displacement(Q);Q+=delta[:,None]*direction;largest_delta=max(largest_delta,float(abs(delta).max()));grad=np.zeros_like(Q);h=2e-6
 for axis in range(3):
  shift=np.zeros(3);shift[axis]=h;grad[:,axis]=(displacement(old+shift)-displacement(old-shift))/(2*h)
 det=1+grad@direction;jacmin=min(jacmin,float(det.min()));assert det.min()>.35,'Lip relief deformation approaches a fold';norm=bary@N[f];norm-=grad*((norm@direction)/det)[:,None];norm/=np.linalg.norm(norm,axis=1)[:,None];colorUV=bary@UV[f];base_index=len(newP);newP.extend(Q);newN.extend(norm);newUV.extend(colorUV);newT.extend(tt+base_index);newMaterial.extend([int(materials[fi])]*len(tt));lineage.extend([int(fi)]*len(tt))
 if seq%100==0:print('LIP_REFINEMENT',seq,'/',len(ids),'triangles',len(newT),flush=True)
newP=np.array(newP);newN=np.array(newN);newUV=np.array(newUV);newT=np.array(newT);newMaterial=np.array(newMaterial);retained=np.ones(len(F),bool);retained[ids]=False;moved_old_groups=set(np.flatnonzero(abs(displacement(W))>1e-10));assert not(moved_old_groups&set(G[retained].ravel().tolist())),'A held source face still uses a moved lip vertex';primitives=[];geometry_before=F[retained];counts=[]
for mi in [0,1]:
 mask=retained&(materials==mi)
 if mask.any():
  ai,b=append_accessor(j,b,F[mask].astype(np.uint32).ravel(),'SCALAR',34963);pr=copy.deepcopy(p);pr['indices']=ai;pr['material']=mi;primitives.append(pr);counts.append({'label':'held_source','material':mi,'faces':int(mask.sum())})
for mi in [0,1]:
 mask=newMaterial==mi
 if not mask.any():continue
 T=newT[mask];used,ii=np.unique(T,return_inverse=True);attrs={}
 for key,arr,kind in [('POSITION',((newP[used]-translation)/scale).astype(np.float32),'VEC3'),('NORMAL',newN[used].astype(np.float32),'VEC3'),('TEXCOORD_0',newUV[used].astype(np.float32),'VEC2')]:attrs[key],b=append_accessor(j,b,arr,kind,34962)
 ai,b=append_accessor(j,b,ii.astype(np.uint32),'SCALAR',34963);primitives.append({'attributes':attrs,'indices':ai,'mode':4,'material':mi});counts.append({'label':'lip_support_and_lossless_transition','material':mi,'faces':int(mask.sum())})
j['meshes'][0]['primitives']=primitives;out=r/'models/scarlett_04_lip_support.glb';write_glb(out,j,b);verify_j,verify_b,verify_a=read_glb(out);assert sum(len(verify_a(q['indices']))//3 for q in verify_j['meshes'][0]['primitives'])==int(retained.sum())+len(newT);np.savez_compressed(r/'checks/scarlett_04_lip_lineage.npz',replaced_source01_face_ids=ids,retained_source01_face_ids=np.flatnonzero(retained),new_triangle_source01_face_ids=np.array(lineage));report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'upturned_corner_curve_uncertainty_pixels':corner_curve_uncertainty,'relief_amplitude_tapers_with_local_lip_thickness':True,'source01_replaced_faces':len(ids),'new_triangles':len(newT),'final_triangles':int(retained.sum())+len(newT),'constant_anatomical_outward_direction_gltf':direction.tolist(),'maximum_relief_m':largest_delta,'minimum_deformation_jacobian_determinant':jacmin,'shared_source_edge_fractions':True,'base_is_exact_original_piecewise_linear_surface':True,'original_UV_barycentric_binding_preserved':True,'all_original_images_and_materials_held':True,'primitive_counts':counts,'status':'Unapproved lip-support trial. Exact source/patch geometry audit, registered PBR/clay and both local profiles are required; face/hair/hand and whole-character gates remain open.'};(r/'checks/scarlett_04_lip_support.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
