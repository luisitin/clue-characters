"""Assemble native4K source-albedo transfer for held White17 orbital skin only."""
import pathlib,json,hashlib,copy,io,numpy as np
from PIL import Image
from glb_io import read_glb,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_17_refined_face.glb';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();source_hash=sha(src);j,b,a=read_glb(src);before=copy.deepcopy(j);atlas=Image.new('RGB',(4096,4096));tiles=[]
for i in range(4):
 report=json.loads((r/'checks'/f'white18_orbital_tile{i}.json').read_text());image=r/'checks'/f'white18_orbital_albedo_tile{i}.png';assert report['target_sha256']==source_hash and report['required_missing_source_texels']==0 and sha(image)==report['sha256'];atlas.paste(Image.open(image),(0,i*1024));tiles.append(report)
image=r/'checks/white_18_orbital_native4k_albedo.png';atlas.save(image);payload=image.read_bytes();b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(payload)});b+=payload;ii=len(j['images']);j['images'].append({'name':'White orbital skin, native source4K UV transfer18','bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});changed=[]
for mi,material in enumerate(j['materials']):
 if material.get('name') in ['White orbital geometry trial skin','White orbital geometry trial lid_contact']:
  material['pbrMetallicRoughness']['baseColorTexture']['index']=ti;changed.append(mi)
assert len(changed)==2
out=r/'models/white_18_native4k_orbital_albedo.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);preserved=[]
for pi,p in enumerate(j['meshes'][0]['primitives']):
 for k,v in p['attributes'].items():assert np.array_equal(a(before['meshes'][0]['primitives'][pi]['attributes'][k]),aa(v)),(pi,k)
 assert np.array_equal(a(before['meshes'][0]['primitives'][pi]['indices']),aa(p['indices']));preserved.append(pi)
for mi,m in enumerate(before['materials']):
 if mi not in changed:assert m==j['materials'][mi]
report={'source':str(src),'source_sha256':source_hash,'output':str(out),'sha256':sha(out),'native_image':str(image),'image_sha256':sha(image),'image_dimensions':[4096,4096],'changed_material_indices':changed,'geometry_normals_UVs_indices_and_unrelated_materials_preserved':True,'preserved_primitives':preserved,'required_skin_texels':sum(t['required_skin_texels']for t in tiles),'missing_required_texels':0,'provenance':'Direct barycentric sampling of the original4096px source base-color image into the new orbital chart. No rendered lighting, screenshot upscaling or generated raster imagery. Procedural2K iris material remains held.','status':'Unapproved complete-model WIP; exact-model material and all-angle checks pending.'};(r/'checks/white_18_native4k_orbital_albedo.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
