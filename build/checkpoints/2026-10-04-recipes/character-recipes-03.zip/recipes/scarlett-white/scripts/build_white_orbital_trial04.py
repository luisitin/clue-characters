"""Assemble the bounded eye geometry with a registered temporary source-color probe.
Original face/hair/body vertices and paint are held outside the explicit domains.
"""
import pathlib,numpy as np,json,hashlib,copy
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_01_exact_duplicates.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];original_attrs={k:a(v,False)for k,v in p['attributes'].items()};F=a(p['indices']).reshape(-1,3);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation']);d=np.load(r/'checks/white_eye_patch11.npz');arrays={k:d[k]for k in d.files};d.close();lin=np.load(r/'checks/white_01_source_face_lineage.npz')['retained_source_face_ids'];removed=set(np.flatnonzero(np.isin(lin,[71217,71218])).tolist())
for n in ['near','far']:removed.update(arrays[n+'_source_face_ids'].tolist())
keep=np.array([i for i in range(len(F))if i not in removed]);ia,b=append_accessor(j,b,F[keep].astype(np.uint32).ravel(),'SCALAR',34963);p['indices']=ia;primitives=[p];ranges=[{'label':'held_source','start':0,'count':len(keep)}];count=len(keep)
probe=r/'renders/white_01_eyes_front_unlit.png';image_bytes=probe.read_bytes();b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(image_bytes)});b+=image_bytes;ii=len(j['images']);j['images'].append({'name':'Temporary registered source albedo probe,800px,not final HD paint','mimeType':'image/png','bufferView':vi});ti=len(j['textures']);j['textures'].append({'source':ii});material_ids={}
for label,rough in [('skin',.62),('globe',.25),('lid_contact',.62)]:
 material_ids[label]=len(j['materials']);j['materials'].append({'name':'White orbital geometry trial '+label,'pbrMetallicRoughness':{'baseColorTexture':{'index':ti},'roughnessFactor':rough,'metallicFactor':0},'doubleSided':False})
def add(label,P,N,T,mi,flat=False):
 global b,count
 if flat:
  P=P[T].reshape(-1,3);N=np.repeat(N,3,axis=0);T=np.arange(len(P)).reshape(-1,3)
 else:
  used,inv=np.unique(T,return_inverse=True);P=P[used];N=N[used];T=inv.reshape(-1,3)
 assert np.isfinite(P).all()and np.isfinite(N).all();N=N/np.maximum(np.linalg.norm(N,axis=1)[:,None],1e-15);assert(np.linalg.norm(N,axis=1)>.999).all();uv=np.c_[.5+(P[:,0]-.009)/.2,.5-(P[:,1]-.78)/.2].astype(np.float32);local=((P-translation)/scale).astype(np.float32);attrs={}
 for name,values,kind in [('POSITION',local,'VEC3'),('NORMAL',N.astype(np.float32),'VEC3'),('TEXCOORD_0',uv,'VEC2')]:attrs[name],b=append_accessor(j,b,values,kind,34962)
 indices,b=append_accessor(j,b,T.astype(np.uint32).ravel(),'SCALAR',34963);primitives.append({'attributes':attrs,'indices':indices,'material':mi,'mode':4});ranges.append({'label':label,'start':count,'count':len(T)});count+=len(T)
for name in ['near','far']:
 add(name+'_skin',arrays[name+'_positions'],arrays[name+'_skin_normals'],arrays[name+'_skin_triangles'],material_ids['skin']);add(name+'_globe_front',arrays[name+'_cap_positions'],arrays[name+'_cap_normals'],arrays[name+'_cap_triangles'],material_ids['globe']);add(name+'_lid_contact',arrays[name+'_contact_positions'],arrays[name+'_contact_face_normals'],arrays[name+'_contact_triangles'],material_ids['lid_contact'],True)
j['meshes'][0]['primitives']=primitives;out=r/'models/white_04_orbital_geometry_trial.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out)
for k,v in jj['meshes'][0]['primitives'][0]['attributes'].items():assert np.array_equal(aa(v,False),original_attrs[k]),k
assert sum(len(aa(q['indices']))//3 for q in jj['meshes'][0]['primitives'])==count;np.savez_compressed(r/'checks/white_04_face_lineage.npz',retained_original_source_face_ids=lin[keep],removed_original_source_face_ids=lin[sorted(removed)]);rep={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':count,'removed_current01_faces':len(removed),'source_nose_pair_71217_71218_stays_removed':True,'source_vertex_normal_UV_arrays_materials_and_original_images_held':True,'temporary_registered_material_source':str(probe),'temporary_registered_material_sha256':hashlib.sha256(image_bytes).hexdigest(),'temporary_paint_resolution':800,'new_patch_coordinate_representation':'Float32 normalized-source-local coordinates, while original quantized accessors are held; seam equivalence is checked at renderer precision.','primitive_face_ranges':ranges,'status':'Unapproved eye geometry trial. The aligned800px source-color probe is temporary, not final HD paint. Source/patch crossings, exact side/under/front appearance, lid thickness and final paint remain required.'};(r/'checks/white_04_orbital_geometry_trial.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
