"""Extend verified rear-hair roughness coverage while keeping geometry/albedo/AO."""
import pathlib,json,numpy as np,hashlib,io,copy
from PIL import Image
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/scarlett_04_lip_support.glb';j,b,a=read_glb(src);prims=j['meshes'][0]['primitives'];originals=copy.deepcopy(prims);scale=np.array(j['nodes'][0]['scale']);translation=np.array(j['nodes'][0]['translation'])
def get_image(ti):
 t=j['textures'][ti];ii=t.get('source',t.get('extensions',{}).get('EXT_texture_webp',{}).get('source'));v=j['bufferViews'][j['images'][ii]['bufferView']];return Image.open(io.BytesIO(b[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB')
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
new_prims=[];reports=[]
for mi in sorted({p.get('material',0)for p in prims}):
 mat=j['materials'][mi];old=np.array(get_image(mat['pbrMetallicRoughness']['metallicRoughnessTexture']['index']));H,W=old.shape[:2];base=np.array(get_image(mat['pbrMetallicRoughness']['baseColorTexture']['index']).resize((W,H),Image.Resampling.BILINEAR)).astype(float);red,green,blue=base.transpose(2,0,1);brown=(red<170)&(green>red*.18)&(green<red*.65)&(blue<red*.52);dark=(red<20)&(green<14)&(blue<12);eligible=(brown|dark)&(old[:,:,1]>=90)&(old[:,:,1]<=135)&(old[:,:,2]<10);alpha=np.zeros((H,W),np.float32);groups=[]
 for pi,p in enumerate(prims):
  if p.get('material',0)!=mi:continue
  F=a(p['indices']).reshape(-1,3);P=a(p['attributes']['POSITION'])*scale+translation;UV=a(p['attributes']['TEXCOORD_0']);x,y,z=P.T;weight=smooth((-.025-z)/.04)*smooth((y-.52)/.04);affected=np.zeros(len(F),bool)
  for fi in np.flatnonzero(weight[F].max(1)>1e-6):
   f=F[fi];q=UV[f]*[W,H];lo=np.maximum(np.floor(q.min(0)).astype(int),0);hi=np.minimum(np.ceil(q.max(0)).astype(int),[W-1,H-1]);aa,bb,cc=q;den=(bb[1]-cc[1])*(aa[0]-cc[0])+(cc[0]-bb[0])*(aa[1]-cc[1])
   if abs(den)<1e-12:continue
   for y0 in range(lo[1],hi[1]+1,128):
    yy,xx=np.meshgrid(np.arange(y0,min(y0+128,hi[1]+1)),np.arange(lo[0],hi[0]+1),indexing='ij');px=xx+.5;py=yy+.5;w0=((bb[1]-cc[1])*(px-cc[0])+(cc[0]-bb[0])*(py-cc[1]))/den;w1=((cc[1]-aa[1])*(px-cc[0])+(aa[0]-cc[0])*(py-cc[1]))/den;w2=1-w0-w1;ok=(w0>=0)&(w1>=0)&(w2>=0)&eligible[yy,xx];val=(w0*weight[f[0]]+w1*weight[f[1]]+w2*weight[f[2]])*ok
    if np.max(val)>0:affected[fi]=True;alpha[yy,xx]=np.maximum(alpha[yy,xx],val)
  groups.append((pi,p,F,affected))
 new=old.copy();new[:,:,1]=np.rint(old[:,:,1]*(1-alpha)+np.maximum(old[:,:,1],178)*alpha).astype(np.uint8);assert np.array_equal(new[:,:,0],old[:,:,0])and np.array_equal(new[:,:,2],old[:,:,2]);changed=np.any(new!=old,axis=2);nmi=mi
 if changed.any():
  buf=io.BytesIO();Image.fromarray(new).save(buf,format='PNG');img=buf.getvalue();b+=b'\0'*((-len(b))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(b),'byteLength':len(img)});b+=img;ii=len(j['images']);j['images'].append({'name':'Scarlett back hair roughness05','bufferView':vi,'mimeType':'image/png'});ti=len(j['textures']);j['textures'].append({'source':ii});nm=copy.deepcopy(mat);nm['name']='Scarlett bounded rear hair roughness05';nm['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=ti;nmi=len(j['materials']);j['materials'].append(nm)
 for pi,p,F,affected in groups:
  for mask,m in [(~affected,mi),(affected,nmi)]:
   if mask.any():
    pp=copy.deepcopy(p);pp['indices'],b=append_accessor(j,b,F[mask].astype(np.uint32).ravel(),'SCALAR',34963);pp['material']=m;new_prims.append(pp)
  reports.append({'source_primitive':pi,'material_changed_faces':int(affected.sum()),'retained_faces':int((~affected).sum())})
 reports.append({'source_material':mi,'changed_ORM_texels':int(changed.sum()),'AO_and_metal_held_exact':True});print(reports[-1],flush=True)
j['meshes'][0]['primitives']=new_prims;out=r/'models/scarlett_05_back_roughness.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);before=sum(len(a(p['indices'])) for p in originals);after=sum(len(aa(p['indices']))for p in new_prims);assert before==after
report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':after//3,'geometry_normals_UVs_albedo_AO_metal_held':True,'domain':'Rear only: glTF z below -25 mm, smoothly full at -65 mm; above y520–560 mm; existing brown/dark nonmetal source texels roughness90–135. Matches verified back centers at roughness117.','reports':reports,'status':'Unapproved material-only rear extension. Matched back and side PBR required.'};(r/'checks/scarlett_05_back_roughness.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
