"""Match source corner-normal continuity at the held orbital perimeter, no geometry edit."""
import pathlib,numpy as np,json,hashlib
from glb_io import read_glb,append_accessor,write_glb
r=pathlib.Path(__file__).resolve().parents[1];src=r/'models/white_04_orbital_geometry_trial.glb';j,b,a=read_glb(src);prims=j['meshes'][0]['primitives'];sp=prims[0];P=a(sp['attributes']['POSITION'])*j['nodes'][0]['scale']+j['nodes'][0]['translation'];F=a(sp['indices']).reshape(-1,3);SN=a(sp['attributes']['NORMAL']);SN/=np.linalg.norm(SN,axis=1)[:,None];W,inv=np.unique(P,axis=0,return_inverse=True);used_source=np.unique(F);d=np.load(r/'checks/white_eye_patch11.npz');data={k:d[k]for k in d.files};d.close();reports={}
def angle(x,y):return np.degrees(np.arccos(np.clip(np.sum(x*y,axis=-1),-1,1)))
for name,pi in [('near',1),('far',4)]:
 Q=data[name+'_positions'];T=data[name+'_skin_triangles'];outer=data[name+'_outer_vertex_ids'];outer_source=data[name+'_outer_source_position_ids'];N=data[name+'_skin_normals'].copy();target=[];spreads=[]
 for wi in outer_source:
  ii=used_source[inv[used_source]==wi];assert len(ii)>0;nn=SN[ii];mean=nn.mean(0);mean/=np.linalg.norm(mean);target.append(mean);spreads.append(float(angle(nn,mean).max()))
 target=np.array(target);assert max(spreads)<3,'Required source has a genuine hard normal seam; preserve corner-specific join.'
 delta=target-N[outer];used=np.unique(T);q=Q[used,:2];best=np.full(len(q),np.inf);corr=np.zeros((len(q),3));nearest=np.zeros(len(q),int)
 for i,(u,v)in enumerate(zip(outer,np.roll(outer,-1))):
  aa,bb=Q[u,:2],Q[v,:2];t=np.clip(((q-aa)@(bb-aa))/np.sum((bb-aa)**2),0,1);dist=np.linalg.norm(q-(aa+t[:,None]*(bb-aa)),axis=1);m=dist<best;best[m]=dist[m];corr[m]=(1-t[m,None])*delta[i]+t[m,None]*delta[(i+1)%len(outer)];nearest[m]=i
 w=np.clip(1-best/.003,0,1);w=w*w*(3-2*w);NN=N.copy();NN[used]+=w[:,None]*corr;NN[used]/=np.linalg.norm(NN[used],axis=1)[:,None];NN[outer]=target;nc=np.cross(Q[T[:,1]]-Q[T[:,0]],Q[T[:,2]]-Q[T[:,0]]);nc/=np.linalg.norm(nc,axis=1)[:,None];dots=np.sum(NN[T]*nc[:,None,:],axis=2);assert dots.min()>.45
 p=prims[pi];local=a(p['attributes']['POSITION']);world=local*j['nodes'][0]['scale']+j['nodes'][0]['translation'];assert np.max(np.linalg.norm(world-Q[used],axis=1))<5e-8;nn=NN[used].astype(np.float32);p['attributes']['NORMAL'],b=append_accessor(j,b,nn,'VEC3',34962);reports[name]={'source_same_position_normal_spread_max_deg':max(spreads),'old_boundary_normal_jump_max_deg':float(angle(N[outer],target).max()),'new_boundary_normal_jump_max_deg':float(angle(NN[outer],target).max()),'normal_only_fade_width_m':.003,'changed_normal_vertices':int((angle(N[used],NN[used])>.001).sum()),'minimum_corner_geometric_dot':float(dots.min()),'boundary_target_source_position_ids':outer_source.tolist()}
out=r/'models/white_05_orbit_boundary_normals.glb';write_glb(out,j,b);jj,bb,aa=read_glb(out);jo,bo,ao=read_glb(src)
for old,new in zip(jo['meshes'][0]['primitives'],jj['meshes'][0]['primitives']):
 assert np.array_equal(ao(old['indices'],False),aa(new['indices'],False))
 for k in ['POSITION','TEXCOORD_0']:assert np.array_equal(ao(old['attributes'][k],False),aa(new['attributes'][k],False))
report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'geometry_indices_UVs_maps_materials_caps_contacts_held':True,'eyes':reports,'status':'Unapproved normal-only continuity trial. Exact matched front, profiles and under PBR/clay required. Lower source37206 geometry remains held.'};(r/'checks/white_05_orbit_boundary_normals.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
