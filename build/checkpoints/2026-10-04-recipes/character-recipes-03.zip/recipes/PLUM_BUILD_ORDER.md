# Plum WIP component build

This is an unfinished asset. The coherent whole-character snapshot is plum_raw_cleanup003.glb. The newer head, eyes, glasses and hand are separate components and are not yet joined to the original body. Provisional colors are not final paint.

## Layout and versions

Preserve the manifest-relative layout from the recovery project root. Use Blender 4.3.2, external Python 3.12 with NumPy 2.3.5 and SciPy 1.17.0. The bpy stages use Blender's bundled Python/NumPy. Create candidates/plum/v1_rebuild/{components,checks,native} before running.

Run each Python stage with python, and each Blender stage with blender -b --python-exit-code 1 --python. Scripts resolve their inputs relative to their own locations. Do not run the rejected prototype scripts or overwrite the published snapshots while experimenting.

## Ordered recipe

1. Python: remove_exact_redundancies003.py. Produces the coherent source-cleanup snapshot using exact original quantized degeneracy and complete corner-payload duplicate proofs.
2. Python: identify_native_orbits008.py, then retain_native_canthi024.py. The latter's historical filename refers to the retained upper-lateral skin quads; current code documents that location.
3. Blender: build_head_trial025.py, then extract_visible_apertures070.py.
4. Python: prepare_regular_orbits033.py.
5. Blender: build_regular_orbits034.py.
6. Python: flip_lateral_quad043.py.
7. Blender: build_exact_eye_shells039.py.
8. Python: widen_eye_apertures058.py, then retriangulate_corner_quads065.py.
9. Blender: build_spectacle_front059.py.
10. Python: locate_ear_roofs063.py.
11. Blender: build_spectacle_temples069.py.
12. Optional diagnostic colors, Python: provisional_face_colors060.py, then transfer_diagnostic_colors067.py. Use head_colors067 with eyes_colors060.
13. Hand, Blender: build_thinking_hand026.py, then scale_hand_about_contact038.py. This also retains an editable026 native rig; the038 affine fit is recorded as a generated build result.

The current outputs are listed by hash in the manifest. Generated intermediate files are dependencies within this recipe, not independently accepted assets. Final skin/iris/brow/hair paint, optical eye/lens materials, source hair repair, neck/wrist joins, original hand/head extraction, wardrobe corrections, book detail and complete-character regression remain unfinished.

## Rights

Selected official MakeHuman asset data is CC0 at the pinned commit in the manifest. Keep its asset license and source headers. No MakeHuman executable source code is used. Preserve the existing project rights for the recovered GLB and original reference artwork; they are not relicensed by this package.

## Recipe verification

A fresh output-tree replay using only the listed scripts and selected input files completed all stages successfully. Seven of the eight manifest GLBs were byte-identical. The hand GLB had identical geometry, normals, UVs, indices, transforms and JSON, with one tangent scalar differing by 0.0001000166 between Blender exports; all other bytes were identical. Published snapshot hashes remain the manifest hashes.
