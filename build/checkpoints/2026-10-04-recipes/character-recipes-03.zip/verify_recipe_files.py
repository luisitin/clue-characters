"""Check every captured file; this does not execute modeling recipes."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'FILES.json').read_text())
for item in manifest['files']:
    path=(root/item['path']).resolve()
    if not path.is_relative_to(root) or path==root:raise ValueError('Unsafe path')
    data=path.read_bytes()
    if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
        raise ValueError('Mismatch: '+item['path'])
print('PASS: '+str(len(manifest['files']))+' captured recipe files match their hashes. No modeling or visual quality claim is implied.')
