"""Extract exact evaluated aperture boundaries for the reproducible head recipe.
Read-only geometry extraction from head025; no official-eye trial is required.
"""
import bpy,pathlib,sys,json,numpy as np,hashlib,collections,math
O=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'scripts'));from constrained_disk import triangulate,mean_value_height,cross
source=O/'components/head_trial025.glb';meta=json.loads((O/'checks/head_trial025.json').read_text());assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['output_sha256']
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(source));bpy.context.view_layer.update();body=next(o for o in bpy.context.scene.objects if o.type=='MESH');P=np.array([body.matrix_world@v.co for v in body.data.vertices],float);body.data.calc_loop_triangles();F=np.array([t.vertices for t in body.data.loop_triangles],int);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];ed=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for a,b in zip(f,np.roll(f,-1)):ed[tuple(sorted((int(a),int(b))))].append((fi,int(a),int(b)))
boundary={e:r[0]for e,r in ed.items()if len(r)==1};adj=collections.defaultdict(list)
for a,b in boundary:adj[a].append(b);adj[b].append(a)
assert all(len(v)==2 for v in adj.values()),'Non-cyclic native head boundary'
loops=[];left=set(adj)
while left:
 start=min(left);loop=[start];prev=None;cur=start
 while True:
  nxt=next(x for x in adj[cur]if x!=prev)
  if nxt==start:break
  assert nxt not in loop;loop.append(nxt);prev,cur=cur,nxt
 left-=set(loop);loops.append(np.array(loop,int))
centers=np.array([U[v].mean(0)for v in loops]);targets=np.array(meta['actual_eye_centers_world']);chosen=[]
for target in targets:
 d=np.linalg.norm(centers-target,axis=1);ii=int(d.argmin());assert d[ii]<.015 and ii not in chosen;chosen.append(ii)
yaw=math.radians(meta['world_yaw_deg']);ax=np.array([math.cos(yaw),math.sin(yaw),0.]);az=np.array([0.,0.,1.]);normal=np.cross(ax,az);records=[];objects=[]
for side,ii in zip(['positive','negative'],chosen):
 ids=loops[ii].copy();ring=U[ids];center=ring.mean(0);xy=np.c_[(ring-center)@ax,(ring-center)@az];depth=(ring-center)@normal
 if sum(cross(a,b)for a,b in zip(xy,np.roll(xy,-1,axis=0)))<0:ids=ids[::-1];ring=ring[::-1];xy=xy[::-1];depth=depth[::-1]
 nb=len(ids);span=float(np.ptp(xy,axis=0).max());assert .012<span<.060
 q=xy/span;crossings=[]
 for i,(a,b)in enumerate(zip(q,np.roll(q,-1,axis=0))):
  for j in range(i+1,len(q)):
   if j==(i+1)%len(q)or i==(j+1)%len(q):continue
   c,d=q[j],q[(j+1)%len(q)];den=cross(b-a,d-c)
   if abs(den)<1e-16:continue
   t=cross(c-a,d-c)/den;u=cross(c-a,b-a)/den
   if 1e-10<t<1-1e-10 and 1e-10<u<1-1e-10:
    p0=ring[i]+t*(ring[(i+1)%nb]-ring[i]);p1=ring[j]+u*(ring[(j+1)%nb]-ring[j]);crossings.append({'edge_indices':[i,j],'fractions':[t,u],'head_vertex_ids':[[int(ids[i]),int(ids[(i+1)%nb])],[int(ids[j]),int(ids[(j+1)%nb])]],'world_points':[p0.tolist(),p1.tolist()],'separation_m':float(np.linalg.norm(p0-p1))})
 records.append({'side':side,'vertices':nb,'projected_width_height_m':np.ptp(xy,axis=0).tolist(),'crossings':crossings,'ring_world':ring.tolist(),'ring_local_uv_depth':np.c_[xy,depth].tolist()});print('APERTURE032',side,'vertices',nb,'crossings',crossings,flush=True)
r={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'loops':records,'scope':'Read-only actual evaluated boundary projection diagnosis. A projected crossing is not automatically a3D triangle intersection. No cap or model changes.'};(O/'checks/aperture_projection032.json').write_text(json.dumps(r,indent=2))
