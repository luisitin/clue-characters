"""Bounded donor-lid trial: smooth aperture chart and a closed covering ellipsoid.
Does not alter the recovered Plum source. Exact-position donor seams move together.
"""
import pathlib,json,hashlib,math,collections,heapq,numpy as np
from glb_io import read_glb,node_matrix
O=pathlib.Path(__file__).resolve().parents[1];src=O/'components/head_trial025.glb';j,b,arr=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=arr(pr['attributes']['POSITION']).astype(float);M=node_matrix(j['nodes'][0]);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];F=arr(pr['indices']).reshape(-1,3).astype(np.int64);U,iv=np.unique(P,axis=0,return_inverse=True);T=iv[F];adj=[set()for _ in U]
for f in T:
 for a,c in zip(f,np.roll(f,-1)):adj[a].add(c);adj[c].add(a)
meta=json.loads((O/'checks/head_trial025.json').read_text());diag=json.loads((O/'checks/aperture_projection032.json').read_text());assert diag['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();yaw=math.radians(meta['world_yaw_deg']);X=np.array([math.cos(yaw),math.sin(yaw),0.]);Y=np.array([0.,0.,1.]);N=np.cross(X,Y);Q=U.copy();rows=[]
for row in diag['loops']:
 B=np.array(row['ring_world']);keys={tuple(p):i for i,p in enumerate(U)};ids=np.array([keys[tuple(p)]for p in B]);C=B.mean(0);xy=np.c_[(B-C)@X,(B-C)@Y];dep=(B-C)@N
 edge=np.linalg.norm(np.roll(xy,-1,axis=0)-xy,axis=1);t=np.r_[0,np.cumsum(edge[:-1])]/edge.sum()*2*np.pi
 A=np.stack([np.ones(len(t))]+[f(k*t)for k in range(1,9)for f in [np.cos,np.sin]],axis=1);smooth=A@np.linalg.lstsq(A,xy,rcond=None)[0]
 # Preserve measured projected width/height and center; only submillimeter corner irregularities are regularized.
 smooth=(smooth-(smooth.min(0)+smooth.max(0))/2)*(np.ptp(xy,axis=0)/np.ptp(smooth,axis=0))+(xy.min(0)+xy.max(0))/2
 def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
 I,J=np.triu_indices(len(B),1);ok=(J!=I+1)&~((I==0)&(J==len(B)-1));I,J=I[ok],J[ok];a=smooth[I];c=smooth[J];v=smooth[(I+1)%len(B)]-a;w=smooth[(J+1)%len(B)]-c;bad=(cross(v,c-a)*cross(v,c+w-a)<-1e-24)&(cross(w,a-c)*cross(w,a+v-c)<-1e-24);assert not bad.any()
 radii=np.array([.022,.020,.019]);centerxy=(smooth.min(0)+smooth.max(0))/2;unit=(smooth-centerxy)/radii[:2];assert (np.sum(unit*unit,axis=1)<.94).all();h=radii[2]*np.sqrt(1-np.sum(unit*unit,axis=1));cd=float(np.mean(dep-h));target=C+(smooth[:,0,None]*X+smooth[:,1,None]*Y)+(cd+h)[:,None]*N
 # A12mm geodesic band includes the lower shelf but fixes the healthy outside skin.
 dist=np.full(len(U),np.inf);dist[ids]=0;heap=[(0,int(i))for i in ids]
 while heap:
  d,i=heapq.heappop(heap)
  if d!=dist[i]or d>.014:continue
  for k in adj[i]:
   v=d+np.linalg.norm(U[k]-U[i])
   if v<dist[k]and v<.016:dist[k]=v;heapq.heappush(heap,(v,int(k)))
 active=np.flatnonzero(dist<.012);inner=np.setdiff1d(active,ids);idx=np.r_[active,sorted(set(int(k)for i in active for k in adj[i])-set(active))];lookup={int(g):i for i,g in enumerate(idx)};old=U[idx];new=old.copy();rid=np.array([lookup[int(i)]for i in ids]);iid=np.array([lookup[int(i)]for i in inner]);neigh=[np.array([lookup[int(k)]for k in adj[i]],int)for i in inner];new[rid]=target
 # Harmonic displacement holds tangential identity beyond the corrected rim.
 disp=np.zeros_like(old);disp[rid]=target-B
 for iteration in range(240):
  nxt=np.array([disp[n].mean(0)for n in neigh]);disp[iid]=.6*nxt+.4*disp[iid]
 new=old+disp;new[rid]=target
 # Depth-only harmonic fairing, bounded to3mm relative to the seated skin, removes excessive bag shelves.
 seated=new.copy();depth=new@N;held=depth.copy()
 for iteration in range(260):
  nxt=np.array([depth[n].mean()for n in neigh]);candidate=.55*nxt+.45*depth[iid];depth[iid]=np.clip(candidate,held[iid]-.003,held[iid]+.003)
 new+=(depth-held)[:,None]*N;new[rid]=target;Q[active]=new[[lookup[int(i)]for i in active]]
 globeC=C+centerxy[0]*X+centerxy[1]*Y+cd*N
 rows.append({'side':row['side'],'boundary_ids':ids.tolist(),'boundary_target_world':target.tolist(),'affected_vertices':len(active),'maximum_aperture_tangential_change_m':float(np.linalg.norm(smooth-xy,axis=1).max()),'maximum_aperture_depth_change_m':float(np.max(abs(cd+h-dep))),'globe_center_world':globeC.tolist(),'globe_radii_m':radii.tolist(),'frame':[X.tolist(),Y.tolist(),N.tolist()],'fixed_outer_geodesic_band_m':.012,'maximum_total_displacement_m':float(np.linalg.norm(Q[active]-U[active],axis=1).max())})
# Preserve exact source split-position equivalence; source indices/UVs untouched.
newP=Q[iv];tri0=P[F];tri1=newP[F];n0=np.cross(tri0[:,1]-tri0[:,0],tri0[:,2]-tri0[:,0]);n1=np.cross(tri1[:,1]-tri1[:,0],tri1[:,2]-tri1[:,0]);area=np.linalg.norm(n1,axis=1)/2;assert area.min()>1e-15
np.savez_compressed(O/'checks/regular_orbits033.npz',world_positions=newP,source_world_positions=P,indices=F)
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eyes':rows,'exact_position_equivalence_groups_preserved':True,'minimum_triangle_area_m2':float(area.min()),'faces_reversing_original_normal':int((np.einsum('ij,ij->i',n0,n1)<0).sum()),'scope':'New unapproved donor-only lid/eye study. Numerical simplicity does not establish likeness, tangent continuity, or intersection clearance.'};(O/'checks/regular_orbits033.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
