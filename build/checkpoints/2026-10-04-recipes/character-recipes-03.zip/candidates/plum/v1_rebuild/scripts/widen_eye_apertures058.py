"""One smooth positive-Jacobian field applied identically to held skin and eye shells.
Reference proportion trial only: widen each aperture horizontally by30 percent
while holding its center, vertical extent, jaw, nose and shared skin/eye interface.
"""
from pathlib import Path
import json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];eyes=json.loads((O/'checks/regular_orbits033.json').read_text())['eyes']
def h(t):
 t=np.clip(t,0,1);return t*t*t*(t*(t*6-15)+10)
def dh(t):
 return np.where((t>0)&(t<1),30*t*t*(t-1)*(t-1),0)
def field(P):
 offset=np.zeros(len(P));gradient=np.zeros_like(P)
 for row in eyes:
  X,Y,N=np.array(row['frame']);C=np.array(row['boundary_target_world']).mean(0);x=(P-C)@X;y=(P-C)@Y;z=(P-C)@N
  tx=(.036-abs(x))/.018;ty=(.025-abs(y))/.013;tz0=(z+.045)/.010;tz1=(.035-z)/.010
  wx=h(tx);wy=h(ty);z0=h(tz0);z1=h(tz1);f=.30*x*wx*wy*z0*z1
  fx=.30*(wx+x*dh(tx)*(-np.sign(x)/.018))*wy*z0*z1
  fy=.30*x*wx*dh(ty)*(-np.sign(y)/.013)*z0*z1
  fz=.30*x*wx*wy*(dh(tz0)/.010*z1-z0*dh(tz1)/.010)
  offset+=f;gradient+=fx[:,None]*X+fy[:,None]*Y+fz[:,None]*N
 return offset,gradient
from numpy.polynomial import Polynomial
poly=Polynomial([0,0,-60,160,-135,36]);roots=poly.deriv().roots();ts=[0.,1.]+[float(r.real)for r in roots if abs(r.imag)<1e-12 and 0<r.real<1];JBOUND=1+.30*min(poly(t)for t in ts);AX=np.array(eyes[0]['frame'][0]);centers=np.array([np.array(r['boundary_target_world']).mean(0)for r in eyes]);assert abs((centers[1]-centers[0])@AX)>.072;assert JBOUND>.2
outputs=[];test_errors=[]

for source,name in [('head_trial043.glb','head_wide058'),('eye_shells039.glb','eye_wide058')]:
 src=O/'components'/source;j,b,a=read_glb(src);payload=bytearray(b);records=[];seen=set()
 for node in j['nodes']:
  if 'mesh'not in node:continue
  assert np.max(abs(node_matrix(node)-np.eye(4)))<1e-8
  assert node['mesh']not in seen;seen.add(node['mesh'])
  for pr in j['meshes'][node['mesh']]['primitives']:
   assert 'TANGENT'not in pr['attributes'],'Transform retained tangents explicitly if later supplied'
   P=a(pr['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(pr['indices']).reshape(-1,3).astype(int);f,g=field(P);det=1+g@AX;assert det.min()>JBOUND-1e-9;W=P+f[:,None]*AX;NN=N-(N@AX)[:,None]*g/det[:,None];NN/=np.linalg.norm(NN,axis=1)[:,None]
   tri0=P[F];tri1=W[F];n0=np.cross(tri0[:,1]-tri0[:,0],tri0[:,2]-tri0[:,0]);n1=np.cross(tri1[:,1]-tri1[:,0],tri1[:,2]-tri1[:,0]);assert np.all(np.einsum('ij,ij->i',n0,n1)>0);assert np.linalg.norm(n1,axis=1).min()>1e-16
   sample=P[np.linspace(0,len(P)-1,min(100,len(P)),dtype=int)];_,gg=field(sample)
   for axis in range(3):
    v=np.eye(3)[axis]*1e-7;fp,_=field(sample+v);fm,_=field(sample-v);err=float(np.max(abs((fp-fm)/(2e-7)-gg[:,axis])));test_errors.append(err);assert err<2e-6
   for semantic,values in [('POSITION',W),('NORMAL',NN)]:
    while len(payload)%4:payload.append(0)
    values=(values*[1,-1,1])[:,[0,2,1]].astype('<f4');off=len(payload);bb=values.tobytes();payload.extend(bb);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(bb),'target':34962});ai=len(j['accessors']);ac={'bufferView':vi,'componentType':5126,'count':len(values),'type':'VEC3'}
    if semantic=='POSITION':ac.update(min=values.min(0).tolist(),max=values.max(0).tolist())
    j['accessors'].append(ac);pr['attributes'][semantic]=ai
   records.append({'node':node['name'],'maximum_displacement_m':float(np.max(abs(f))),'minimum_deformation_Jacobian':float(det.min()),'maximum_normal_length_error':float(np.max(abs(np.linalg.norm(NN,axis=1)-1))),'triangle_orientation_relative_source_held':True})
 j['buffers'][0]['byteLength']=len(payload);jb=json.dumps(j,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);payload+=b'\0'*((-len(payload))%4);dst=O/'components'/f'{name}.glb';dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(payload))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(payload),b'BIN\0')+payload);outputs.append({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'path':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'primitives':records})
r={'outputs':outputs,'maximum_finite_difference_Jacobian_error':max(test_errors),'continuous_field_Jacobian_lower_bound':float(JBOUND),'central_horizontal_aperture_factor':1.30,'normals':'Analytic inverse-transpose of the same world deformation Jacobian, normalized; nodes are explicitly verified identity.','shared_interface_policy':'Both skin and scleral geometry use exactly the same continuous field and float32 output; no independent lid or eye movement.','source_geometry_gate':'043+039 retained;049/051 lower-bag changes and056 height change excluded.','scope':'Horizontal eye-opening proportion study only. Actual reference contour, contact, complete V4 crossings and all-angle appearances remain required.'};(O/'checks/eye_width058.json').write_text(json.dumps(r,indent=2));print('WIDTH058',r,flush=True)
