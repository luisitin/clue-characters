"""Preserve the native upper-lateral skin quads instead of forcing sclera over the34-node detour."""
import pathlib,sys,json,numpy as np,collections,hashlib
O=pathlib.Path(__file__).resolve().parents[1];D=O.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(D/'scripts'));from load_donor import load_obj
V,UV,F,FU,G=load_obj();old=np.load(O/'checks/native_orbits008.npz');post=old['posterior_vertices'];postset=set(map(int,post));keep=[int(i)for i in np.flatnonzero(G=='body')if not any(v in postset for v in F[i])];faces=[F[i]for i in keep];faceuv=[FU[i]for i in keep];inc=collections.defaultdict(list)
for fi in keep:
 f=F[fi]
 for a,b in zip(f,f[1:]+f[:1]):inc[tuple(sorted((a,b)))].append((fi,a,b))
loops={};rows=[]
for side,key in [('positive','positive_loop'),('negative','negative_loop')]:
 candidates=set(map(int,old[key]));adj=collections.defaultdict(list)
 for (a,b),r in inc.items():
  if len(r)==1 and a in candidates and b in candidates:adj[a].append(b);adj[b].append(a)
 assert len(adj)==32 and all(len(x)==2 for x in adj.values());start=min(adj);loop=[start];prev=None;cur=start
 while True:
  nxt=next(x for x in adj[cur]if x!=prev)
  if nxt==start:break
  assert nxt not in loop;loop.append(nxt);prev,cur=cur,nxt
 assert set(loop)==set(adj);loops[side]=np.array(loop);pad=[i for i in keep if all(v in candidates for v in F[i])];assert len(pad)==1
 rows.append({'side':side,'actual_aperture_vertices':loop,'retained_upper_lateral_skin_quad':pad[0],'retained_quad_native_vertices':F[pad[0]],'retained_quad_native_positions':V[F[pad[0]]].tolist(),'excluded_from_sclera_boundary':sorted(candidates-set(loop)),'retained_edge_incidence':1})
np.savez_compressed(O/'checks/native_orbits024.npz',positive_loop=loops['positive'],negative_loop=loops['negative'],posterior_vertices=post,retained_source_face_ids=np.array(keep),retained_polygon_indices=np.concatenate(faces),retained_polygon_uv_indices=np.concatenate(faceuv),retained_polygon_offsets=np.r_[0,np.cumsum([len(f)for f in faces])]);r={'base_sha256':hashlib.sha256((D/'raw/base.obj').read_bytes()).hexdigest(),'removed_posterior_quads':int((G=='body').sum()-len(keep)),'retained_native_skin_quads':rows,'rationale':'Preserve the two native upper-lateral all-ring skin quads and use the actual32-node boundary after posterior-socket removal. Their original coordinates establish the lateral location. Earlier medial/canthal labeling was incorrect. The observed custom-cap folds were near medial corners, so retaining these lateral quads has not been shown to repair those folds. Actual local views remain required.','scope':'Source-data topology trial only; no original Plum character geometry is cut.'};(O/'checks/native_orbits024.json').write_text(json.dumps(r,indent=2));print('CANTHI024',r['removed_posterior_quads'],rows,flush=True)
