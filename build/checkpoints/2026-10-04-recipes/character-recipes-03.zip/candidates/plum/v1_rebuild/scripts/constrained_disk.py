"""Small boundary-preserving 2D disk triangulation, refinement and quality flips.
Every supplied boundary segment is retained verbatim. No convex-hull substitution.
Input must be a simple CCW polygon with distinct points; failures stop the caller.
"""
import numpy as np,collections

def cross(a,b):return float(a[0]*b[1]-a[1]*b[0])
def quality(a,b,c):
 ar=cross(b-a,c-a);return 2*np.sqrt(3)*ar/(np.sum((a-b)**2)+np.sum((b-c)**2)+np.sum((c-a)**2))
def earclip(P,ids=None):
 ids=list(range(len(P)))if ids is None else list(ids);out=[]
 while len(ids)>3:
  candidates=[]
  for k,b in enumerate(ids):
   a=ids[k-1];c=ids[(k+1)%len(ids)];pa,pb,pc=P[[a,b,c]];det=cross(pb-pa,pc-pa)
   if det<=1e-14:continue
   inside=False
   for q in ids:
    if q in (a,b,c):continue
    pq=P[q];v=cross(pb-pa,pq-pa);w=cross(pq-pa,pc-pa)
    if v>=-1e-13 and w>=-1e-13 and v+w<=det+1e-13:inside=True;break
   if not inside:candidates.append((quality(pa,pb,pc),k,(a,b,c)))
  assert candidates,'No valid ear: non-simple polygon or unresolved collinearity'
  _,k,t=max(candidates);out.append(t);ids.pop(k)
 assert cross(P[ids[1]]-P[ids[0]],P[ids[2]]-P[ids[0]])>1e-14
 out.append(tuple(ids));return out

def edges(F):
 e=collections.defaultdict(list)
 for i,f in enumerate(F):
  for a,b in zip(f,np.roll(f,-1)):e[tuple(sorted((int(a),int(b))))].append(i)
 return e

def triangulate(poly,max_edge=.04):
 poly=np.asarray(poly,float);n=len(poly);assert len(np.unique(poly,axis=0))==n and n>=3
 assert sum(cross(a,b)for a,b in zip(poly,np.roll(poly,-1,axis=0)))>0
 for i,(a,b)in enumerate(zip(poly,np.roll(poly,-1,axis=0))):
  for j in range(i+1,n):
   if j in (i,(i+1)%n)or i==(j+1)%n:continue
   c,d=poly[j],poly[(j+1)%n]
   assert not(cross(b-a,c-a)*cross(b-a,d-a)<-1e-18 and cross(d-c,a-c)*cross(d-c,b-c)<-1e-18),'Crossed boundary'
 requested_edge=float(max_edge);max_edge=max(requested_edge,float(np.linalg.norm(np.roll(poly,-1,axis=0)-poly,axis=1).max())*1.05)
 P=poly.copy();F=np.array(earclip(P),int);boundary={tuple(sorted((i,(i+1)%n)))for i in range(n)}
 for iteration in range(24):
  inc=edges(F);mark=[e for e,fs in inc.items()if len(fs)==2 and np.linalg.norm(P[e[0]]-P[e[1]])>max_edge];assert len(F)<40000,'Refinement budget exceeded'
  if not mark:break
  mid={e:len(P)+i for i,e in enumerate(mark)};P=np.vstack([P,np.array([(P[a]+P[b])/2 for a,b in mark])]);out=[]
  for f0 in F:
   f=list(map(int,f0));ee=[tuple(sorted((f[i],f[(i+1)%3])))for i in range(3)];flags=[e in mid for e in ee];count=sum(flags)
   if count==0:out.append(tuple(f))
   elif count==1:
    k=flags.index(True);a,b,c=f[k],f[(k+1)%3],f[(k+2)%3];m=mid[ee[k]];out.extend([(a,m,c),(m,b,c)])
   elif count==2:
    k=flags.index(False);a,b,c=f[(k+1)%3],f[(k+2)%3],f[k];m=mid[tuple(sorted((a,b)))];n0=mid[tuple(sorted((b,c)))];out.append((m,b,n0))
    if np.linalg.norm(P[a]-P[n0])<np.linalg.norm(P[m]-P[c]):out.extend([(a,m,n0),(a,n0,c)])
    else:out.extend([(a,m,c),(m,n0,c)])
   else:
    a,b,c=f;m=mid[ee[0]];n0=mid[ee[1]];q=mid[ee[2]];out.extend([(a,m,q),(m,b,n0),(q,n0,c),(m,n0,q)])
  F=np.array(out,int)
 else:raise AssertionError('Refinement did not converge')
 flips=0
 for _ in range(30):
  inc=edges(F);used=set();nf=0
  for (a,b),fs in inc.items():
   if len(fs)!=2 or any(fi in used for fi in fs):continue
   i,j=fs;c=next(int(x)for x in F[i]if x not in (a,b));d=next(int(x)for x in F[j]if x not in (a,b))
   candidates=[(c,d,a),(d,c,b)]
   for k,t in enumerate(candidates):
    if cross(P[t[1]]-P[t[0]],P[t[2]]-P[t[0]])<0:candidates[k]=(t[0],t[2],t[1])
   # A valid flip has both old endpoints on opposite sides of the new diagonal.
   if cross(P[d]-P[c],P[a]-P[c])*cross(P[d]-P[c],P[b]-P[c])>=-1e-16:continue
   old=min(quality(*P[F[i]]),quality(*P[F[j]]));new=min(quality(*P[list(candidates[0])]),quality(*P[list(candidates[1])]))
   if new>old+1e-7:F[i],F[j]=candidates;used.update(fs);nf+=1
  flips+=nf
  if not nf:break
 inc=edges(F);actual={e for e,fs in inc.items()if len(fs)==1};assert actual==boundary and max(map(len,inc.values()))==2
 u=P[F[:,1]]-P[F[:,0]];v=P[F[:,2]]-P[F[:,0]];area=u[:,0]*v[:,1]-u[:,1]*v[:,0];assert np.all(area>1e-14);assert len(P)-len(inc)+len(F)==1
 return P,F,{'requested_max_edge':requested_edge,'effective_refinement_edge':max_edge,'boundary_vertices':n,'vertices':len(P),'triangles':len(F),'minimum_double_area':float(area.min()),'quality_flips':flips,'boundary_segments_exact':True,'euler_characteristic':1}

def mean_value_height(points,boundary,depths):
 """Continuous polygon interpolation with exact line/vertex handling."""
 B=np.asarray(boundary,float);h=np.asarray(depths,float);out=[];dist=[]
 for p in points:
  v=B-p;r=np.linalg.norm(v,axis=1);i=int(r.argmin())
  if r[i]<1e-12:out.append(float(h[i]));dist.append(0.);continue
  nearest=1e99;edge_value=None
  for k,(a,b)in enumerate(zip(B,np.roll(B,-1,axis=0))):
   d=b-a;t=float(np.clip((p-a)@d/(d@d),0,1));q=a+t*d;dd=np.linalg.norm(p-q);nearest=min(nearest,dd)
   if dd<1e-12:edge_value=float(h[k]*(1-t)+h[(k+1)%len(h)]*t)
  if edge_value is not None:out.append(edge_value);dist.append(0.);continue
  nxt=np.roll(v,-1,axis=0);rn=np.roll(r,-1);den=r*rn+np.sum(v*nxt,axis=1);tan=(v[:,0]*nxt[:,1]-v[:,1]*nxt[:,0])/den;w=(np.roll(tan,1)+tan)/r;out.append(float(w@h/w.sum()));dist.append(float(nearest))
 return np.array(out),np.array(dist)
