"""First recovered anatomical hand trial. Native topology/UV, official normalized weights, fixed rest winding."""
import bpy,sys,json,math,hashlib,os
from pathlib import Path
import numpy as np
from mathutils import Vector,Matrix
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2]
TAG=os.environ.get('POINT_TAG','026');SUBDIV=int(os.environ.get('SUBDIV','2'));SIDE=os.environ.get('HAND_SIDE','L');FLEX=-1 if SIDE=='R' else 1
assert SIDE in ('R','L')
sys.path.insert(0,str(ROOT/'shared_sources/makehuman/scripts'))
from load_donor import load_donor
a=load_donor();V=a['positions'];UV=a['uv'];J=a['joint_positions'];bones=a['rig']['bones']
wrist=J[f'wrist.{SIDE}____head'];forward=J[f'finger3-1.{SIDE}____head']-wrist;forward/=np.linalg.norm(forward)
side=J[f'finger2-1.{SIDE}____head']-J[f'finger5-1.{SIDE}____head'];side-=side@forward*forward;side/=np.linalg.norm(side)
dorsal=np.cross(forward,side);dorsal/=np.linalg.norm(dorsal)
F=np.array([float(x) for x in os.environ.get('HAND_FORWARD','.55,-.35,.76').split(',')]);F/=np.linalg.norm(F);S=np.array([1.,0.,0.]);S-=S@F*F;S/=np.linalg.norm(S);N=np.cross(F,S);palm_roll=math.radians(55);S=S*math.cos(palm_roll)+N*math.sin(palm_roll);N=np.cross(F,S)
R=np.column_stack([F,S,N])@np.column_stack([forward,side,dorsal]).T
assert np.linalg.det(R)>.999999
scale=.095;anchor=np.array([-.1297,-.0430,.5274])
def world(p):return (np.asarray(p)-wrist)@R.T*scale+anchor
proj=(V-wrist)@forward;dist=np.linalg.norm(V-wrist,axis=1)
chosen=[]
for i in a['body_face_ids']:
    face=a['faces'][i]
    if all(proj[x]>-.20 and dist[x]<2.05 and ((V[x,0]<-3.8) if SIDE=='R' else (V[x,0]>3.8)) for x in face):chosen.append(int(i))
ids=np.unique(np.concatenate([a['faces'][i] for i in chosen]));lookup={int(v):i for i,v in enumerate(ids)}
faces=[[lookup[v] for v in a['faces'][i]] for i in chosen]
pv=world(V[ids]);edges={}
for face in faces:
    for x,y in zip(face,face[1:]+face[:1]):edges.setdefault(tuple(sorted((x,y))),[]).append((x,y))
boundary=[q[0] for q in edges.values() if len(q)==1]
assert all(len(q)<=2 for q in edges.values())
degrees={}
for x,y in boundary:degrees[x]=degrees.get(x,0)+1;degrees[y]=degrees.get(y,0)+1
assert set(degrees.values())=={2},degrees
# A cap only for the winding test; never exported as hand skin.
c=pv[list(degrees)].mean(axis=0);volume=0.
for face in faces:
    for k in range(1,len(face)-1):volume+=np.dot(pv[face[0]],np.cross(pv[face[k]],pv[face[k+1]]))/6
for x,y in boundary:volume+=np.dot(c,np.cross(pv[y],pv[x]))/6
assert volume>0,('Unexpected rest winding; inspect before fitting',volume)
bpy.ops.wm.read_factory_settings(use_empty=True)
mesh=bpy.data.meshes.new('Official hand rest UV');mesh.from_pydata(pv.tolist(),[],faces);mesh.update()
ob=bpy.data.objects.new(f'Plum anatomical thinking hand{TAG} {SIDE}',mesh);bpy.context.collection.objects.link(ob)
uvlayer=mesh.uv_layers.new(name='NativeHandUV')
for poly,sourceface in zip(mesh.polygons,chosen):
    for loopid,uvi in zip(poly.loop_indices,a['face_uv'][sourceface]):uvlayer.data[loopid].uv=UV[uvi]
    poly.use_smooth=True
armdata=bpy.data.armatures.new('Official hand articulation');arm=bpy.data.objects.new('Official hand articulation',armdata);bpy.context.collection.objects.link(arm)
bpy.context.view_layer.objects.active=arm;arm.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for name,b in bones.items():
    e=armdata.edit_bones.new(name);e.head=world(J[b['head']]);e.tail=world(J[b['tail']])
    if (e.tail-e.head).length<1e-6:e.tail=e.head+Vector((0,0,1e-4))
    e.align_roll(Vector(N))
for name,b in bones.items():
    if b.get('parent'):armdata.edit_bones[name].parent=armdata.edit_bones[b['parent']]
bpy.ops.object.mode_set(mode='OBJECT');arm.select_set(False)
weights=a['weights_normalized'][ids]
for k,name in enumerate(a['bone_names']):
    active=np.flatnonzero(weights[:,k]>0)
    if len(active):
        group=ob.vertex_groups.new(name=name)
        for i in active:group.add([int(i)],float(weights[i,k]),'REPLACE')
mod=ob.modifiers.new('Official weighted preserve-volume articulation','ARMATURE');mod.object=arm;mod.use_deform_preserve_volume=True
angles={};ik_reports=[]
from mathutils.bvhtree import BVHTree
palm_tree=BVHTree.FromPolygons([Vector(p)for p in pv],faces,all_triangles=False);palmar=FLEX*N

def RX(t):
    c=math.cos(t);s0=math.sin(t);return np.array([[1,0,0,0],[0,c,-s0,0],[0,s0,c,0],[0,0,0,1]],float)
for digit in (3,4,5):
    names=[f'finger{digit}-{seg}.{SIDE}'for seg in (1,2,3)];restM=[np.array(armdata.bones[n].matrix_local)for n in names];relative=[np.linalg.inv(restM[0])@restM[1],np.linalg.inv(restM[1])@restM[2]];tail=np.array([0,armdata.bones[names[2]].length,0,1.]);mcp=restM[0][:3,3];probe=mcp-F*(.025 if digit==5 else .030)+palmar*.20;hit,normal_hit,face_hit,distance=palm_tree.ray_cast(Vector(probe),Vector(-palmar),.4);assert hit is not None and np.array(normal_hit)@palmar>.2,(digit,hit,normal_hit)
    # Native palm ownership is recorded; this is a target, not a claim of final clearance.
    pad_radius=.0045 if digit in (3,4)else .0038;gap=.003;target=np.array(hit)+palmar*(pad_radius+gap)
    def fk(theta):
        M=restM[0]@RX(FLEX*theta[0]);M=M@relative[0]@RX(FLEX*theta[1]);M=M@relative[1]@RX(FLEX*theta[2]);return (M@tail)[:3]
    lower=np.radians([45,40,20]);upper=np.radians([65 if digit==5 else 110,115,90]);preferred=np.radians([65,80,60]if digit==5 else [95,95,65]);initial_target=target.copy();goal_forward=float(target@F);axes=np.vstack([F,palmar]);last_theta=None
    for contact_iteration in range(4):
        solutions=[];seeds=[np.radians(x)for x in ([90,90,60],[100,85,65],[80,100,85])]
        if last_theta is not None:seeds.append(last_theta)
        for seed in seeds:
            theta=np.clip(seed.astype(float),lower,upper);damping=1e-6
            for iteration in range(100):
                pos=fk(theta);res=axes@(pos-target);J=np.column_stack([axes@(fk(theta+np.eye(3)[k]*1e-5)-pos)/1e-5 for k in range(3)]);prior=1e-8;step=np.linalg.solve(J.T@J+np.eye(3)*(damping+prior),-J.T@res-prior*(theta-preferred));trial=np.clip(theta+np.clip(step,-.2,.2),lower,upper)
                value=np.sum((axes@(fk(theta)-target))**2)+prior*np.sum((theta-preferred)**2);newvalue=np.sum((axes@(fk(trial)-target))**2)+prior*np.sum((trial-preferred)**2)
                if newvalue<value:theta=trial;damping=max(1e-10,damping*.5)
                else:damping=min(.1,damping*4)
                if np.linalg.norm(step)<1e-7:break
            solutions.append((float(np.linalg.norm(axes@(fk(theta)-target))),float(np.sum((theta-preferred)**2)),theta))
        error,penalty,theta=min(solutions,key=lambda x:(round(x[0],5),x[1]));last_theta=theta.copy();actual_point=fk(theta);hit,normal_hit,face_hit,distance=palm_tree.ray_cast(Vector(actual_point+palmar*.20),Vector(-palmar),.4);assert hit is not None and np.array(normal_hit)@palmar>.2
        palm_cols=[k for k,name in enumerate(a['bone_names'])if name.startswith(('wrist.','metacarpal'))];palm_weight=float(weights[faces[face_hit]][:,palm_cols].sum(axis=1).mean());assert palm_weight>.55,('Target is not a wrist/metacarpal-supported palm face',digit,palm_weight)
        updated=np.array(hit)+palmar*(pad_radius+gap);updated+=F*(goal_forward-updated@F);change=float(abs((updated-target)@palmar));target=updated
        if change<.00005:break
    assert np.all(theta>=lower-1e-12)and np.all(theta<=upper+1e-12);error=float(np.linalg.norm(fk(theta)-target));assert error<.003,(digit,error,np.degrees(theta))
    for name,angle in zip(names,theta):pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=FLEX*float(angle);angles[name]=FLEX*math.degrees(float(angle))
    bpy.context.view_layer.update();actual=np.array(arm.pose.bones[names[2]].tail);predicted=fk(theta);assert np.linalg.norm(actual-predicted)<1e-6
    ik_reports.append({'digit':digit,'source_palm_quad':chosen[face_hit],'palm_hit_world':list(hit),'palm_normal_world':list(normal_hit),'initial_target_world':initial_target.tolist(),'target_bone_tip_world':target.tolist(),'lateral_retarget_m':float((target-initial_target)@S),'palm_support_weight':palm_weight,'contact_iterations':contact_iteration+1,'lateral_policy':'Native curl planes held. Palm target is recast at the realized lateral position instead of forcing sideways finger deformation.','estimated_tip_pad_radius_m':pad_radius,'requested_pad_gap_m':gap,'angles_degrees':np.degrees(theta).tolist(),'bone_target_error_m':error,'FK_realized_matrix_error_m':float(np.linalg.norm(actual-predicted)),'actual_bone_tip_world':actual.tolist()})
for seg,degrees_ in enumerate([6,44,64],1):
    name=f'finger2-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
if os.environ.get('STRAIGHT_INDEX','0')=='1':
    # Set every index segment to the target direction through the actual parent pose.
    # No edited vertex or bone length is inferred from a post-subdivision array order.
    for seg in (1,2,3):
        name=f'finger2-{seg}.{SIDE}';pb=arm.pose.bones[name];bpy.context.view_layer.update()
        parent=pb.parent;rest=pb.bone.matrix_local.copy()
        base=(parent.matrix @ parent.bone.matrix_local.inverted() @ rest) if parent else rest
        desiredY=Vector(F);desiredZ=Vector(N);desiredX=desiredY.cross(desiredZ).normalized();desiredZ=desiredX.cross(desiredY).normalized()
        desired=Matrix((desiredX,desiredY,desiredZ)).transposed()
        pb.rotation_mode='QUATERNION';pb.rotation_quaternion=(base.to_3x3().inverted()@desired).to_quaternion()
    bpy.context.view_layer.update()
for seg,degrees_ in enumerate([0,30,25],1):
    name=f'finger1-{seg}.{SIDE}';pb=arm.pose.bones[name];pb.rotation_mode='XYZ';pb.rotation_euler.x=math.radians(FLEX*degrees_);angles[name]=FLEX*degrees_
thumb_angle=float(os.environ.get('THUMB_ABDUCT','15'))
if thumb_angle:
    pb=arm.pose.bones[f'finger1-1.{SIDE}'];pb.rotation_mode='XYZ';pb.rotation_euler.z=math.radians(thumb_angle)
    angles[f'finger1-1.{SIDE} local_z']=thumb_angle
# Thumb opposition is assessed from actual views.
sub=ob.modifiers.new('Anatomical surface subdivision','SUBSURF');sub.levels=SUBDIV;sub.render_levels=SUBDIV
mat=bpy.data.materials.new('Neutral skin trial');mat.diffuse_color=(.61,.36,.23,1);mat.use_nodes=True
mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.61,.36,.23,1)
mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.55;ob.data.materials.append(mat)
bpy.context.view_layer.update()
posed_bones={name:{'head':list(pb.head),'tail':list(pb.tail),'matrix':[list(row) for row in pb.matrix]} for name,pb in arm.pose.bones.items() if name.endswith('.'+SIDE) and any(q in name for q in ('finger','wrist','metacarpal'))}
rest_report={'pinky_revision':'V3 localized all79 crossings of022 to little-finger MCP. Only that digit is retargeted5mm toward its MCP and bounded to65degrees proximal flexion; other digit goals and index/thumb pose are held.', 'closed_finger_IK_targets':ik_reports,'posed_bones':posed_bones,'source_manifest_sha256':hashlib.sha256((ROOT/'shared_sources/makehuman/provenance/manifest.json').read_bytes()).hexdigest(),'source_body_faces':chosen,'source_vertices':ids.tolist(),'rest_quads':len(faces),'rest_vertices':len(pv),'boundary_edges':len(boundary),'boundary_degree_two':True,'rest_cap_volume':float(volume),'fixed_original_OBJ_winding':True,'raw_weight_sum_range':[float(a['weight_sums_raw'][ids].min()),float(a['weight_sums_raw'][ids].max())],'normalized_weight_max_error':float(np.abs(weights.sum(axis=1)-1).max()),'palm_roll_degrees':55,'world_thumbward':S.tolist(),'world_forward':F.tolist(),'index_straightened':os.environ.get('STRAIGHT_INDEX','0')=='1','world_anchor':anchor.tolist(),'scale':scale,'native_forward':forward.tolist(),'native_thumbward':side.tolist(),'donor_side':SIDE,'native_basis_normal':dorsal.tolist(),'native_anatomical_dorsal':(-FLEX*dorsal).tolist(),'world_anatomical_dorsal':(-FLEX*N).tolist(),'pose_degrees_local_x':angles,'construction_source':'Adapted from the recovered and numerically verified Mustard hand09 rig plumbing, with Plum-specific frame, anchor, index and thumb pose. No posed component recovered from lost v5.', 'scope':'Plum thinking-hand trial only. Native lengths and normalized official weights held; whole-hand self/cap/skin/neck clearance, source/ref gesture and cuff fit remain unapproved.'}
bpy.context.view_layer.update();bpy.ops.wm.save_as_mainfile(filepath=str(D/f'native/thinking_hand{TAG}.blend'))
bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
for modifier in list(ob.modifiers):bpy.ops.object.modifier_apply(modifier=modifier.name)
ob.data.calc_loop_triangles();rest_report['evaluated_triangles']=len(ob.data.loop_triangles)
out=D/f'components/thinking_hand{TAG}.glb';bpy.ops.export_scene.gltf(filepath=str(out),export_format='GLB',use_selection=True,export_apply=False,export_yup=True,export_texcoords=True,export_normals=True,export_tangents=True)
rest_report['output_sha256']=hashlib.sha256(out.read_bytes()).hexdigest()
(D/f'checks/thinking_hand{TAG}.json').write_text(json.dumps(rest_report,indent=2));print(json.dumps({k:v for k,v in rest_report.items() if k not in ('source_body_faces','source_vertices')},indent=2),flush=True)
