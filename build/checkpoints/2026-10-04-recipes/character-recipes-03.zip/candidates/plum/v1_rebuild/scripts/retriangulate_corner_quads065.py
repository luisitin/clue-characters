"""Repair explicit four-edge donor quads whose old diagonals cross the scleral corner.
Positions, UVs, aperture edges and quad perimeter stay held; only each internal
triangle diagonal and its four incident smooth normal groups change.
"""
from pathlib import Path
import json,struct,hashlib,collections,numpy as np
from glb_io import read_glb
O=Path(__file__).resolve().parents[1];src=O/'components/head_wide058.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(p['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(np.uint32);oldF=F.copy();X,Y,D=np.array(json.loads((O/'checks/regular_orbits033.json').read_text())['eyes'][0]['frame']);records=[];affected=set()
def perimeter(fs):
 c=collections.Counter((int(x),int(y))for f in fs for x,y in zip(f,np.roll(f,-1)));return sorted(e for e in c if e[::-1]not in c)
def metrics(fs):
 T=P[fs];g=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);areas=np.linalg.norm(g,axis=1)/2;g/=2*areas[:,None];return {'dihedral_degrees':float(np.degrees(np.arccos(np.clip(g[0]@g[1],-1,1)))),'areas_m2':areas.tolist(),'front_facing_dot':(g@D).tolist(),'corner_normal_dot':np.einsum('fij,fj->fi',N[fs],g).tolist()}
for pair in [(26266,26267),(87886,87887),(88046,88047)]:
 old=F[list(pair)].copy();shared=set(map(int,old[0]))&set(map(int,old[1]));assert len(shared)==2;boundary=perimeter(old);assert len(boundary)==4;adj=dict(boundary);assert len(adj)==4;cycle=[min(adj)]
 while len(cycle)<4:cycle.append(adj[cycle[-1]])
 assert adj[cycle[-1]]==cycle[0] and len(set(cycle))==4
 u,v,w,z=cycle
 if shared=={u,w}:new=np.array([[u,v,z],[v,w,z]],np.uint32)
 else:assert shared=={v,z};new=np.array([[u,v,w],[u,w,z]],np.uint32)
 assert perimeter(new)==boundary;before=metrics(old);after=metrics(new);print('QUAD065',pair,before,after,flush=True)
 assert after['dihedral_degrees']<before['dihedral_degrees'] and min(after['areas_m2'])>1e-12
 assert min(after['front_facing_dot'])>0
 F[list(pair)]=new;affected.update(cycle);records.append({'faces':list(pair),'old':old.tolist(),'new':new.tolist(),'ordered_boundary':boundary,'before':before,'after_before_normal_update':after})
normal_ids=[]
for vi in sorted(affected):
 ids=np.flatnonzero(np.all(P==P[vi],axis=1));fi=np.flatnonzero(np.isin(F,ids).any(1));T=P[F[fi]];nn=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]).sum(0);nn/=np.linalg.norm(nn);N[ids]=nn;normal_ids.extend(ids.tolist())
for row in records:
 row['after']=metrics(F[row['faces']]);assert min(np.array(row['after']['corner_normal_dot']).ravel())>0
payload=bytearray(b)
for semantic,values,target in [('indices',F.ravel().astype('<u4'),34963),('NORMAL',(N*[1,-1,1])[:,[0,2,1]].astype('<f4'),34962)]:
 while len(payload)%4:payload.append(0)
 off=len(payload);bb=values.tobytes();payload.extend(bb);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(bb),'target':target});ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125 if semantic=='indices'else 5126,'count':len(values),'type':'SCALAR'if semantic=='indices'else'VEC3'})
 if semantic=='indices':p['indices']=ai
 else:p['attributes'][semantic]=ai
j['buffers'][0]['byteLength']=len(payload);jb=json.dumps(j,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);payload+=b'\0'*((-len(payload))%4);dst=O/'components/head_corners065.glb';dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(payload))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(payload),b'BIN\0')+payload);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'quads':records,'recomputed_normal_vertex_ids':sorted(set(normal_ids)),'all_positions_UVs_and_original_BIN_held':True,'all_ordered_quad_boundaries_held':True,'scope':'Three explicit donor corner quad diagonals only. Full local V4 eye/skin contacts and actual close appearance still require retest.'};(O/'checks/corner_quads065.json').write_text(json.dumps(r,indent=2));print('CORNERS065',r['output_sha256'],flush=True)
