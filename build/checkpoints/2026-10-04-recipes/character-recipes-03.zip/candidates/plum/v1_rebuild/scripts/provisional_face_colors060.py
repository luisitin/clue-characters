"""Diagnostic gaze/brow color only, for reference-fit judgment. This is not final AI paint."""
from pathlib import Path
import json,hashlib,struct,numpy as np
from glb_io import read_glb,node_matrix
O=Path(__file__).resolve().parents[1];eyes=json.loads((O/'checks/regular_orbits033.json').read_text())['eyes'];outputs=[]
def write(j,payload,dst):
 j['buffers'][0]['byteLength']=len(payload);jb=json.dumps(j,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);payload+=b'\0'*((-len(payload))%4);dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(payload))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(payload),b'BIN\0')+payload)
def add(j,payload,pr,col):
 while len(payload)%4:payload.append(0)
 col=np.asarray(col,dtype='<f4');off=len(payload);buf=col.tobytes();payload.extend(buf);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(buf),'target':34962});ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5126,'count':len(col),'type':'VEC4'});pr['attributes']['COLOR_0']=ai;j['materials'][pr['material']].setdefault('pbrMetallicRoughness',{})['baseColorFactor']=[1,1,1,1]
for source,tag in [('head_wide058.glb','head_colors060'),('eye_wide058.glb','eyes_colors060')]:
 src=O/'components'/source;j,b,a=read_glb(src);payload=bytearray(b)
 for node in j['nodes']:
  if 'mesh'not in node:continue
  M=node_matrix(node)
  for pr in j['meshes'][node['mesh']]['primitives']:
   P=a(pr['attributes']['POSITION']).astype(float);P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1]
   if tag.startswith('eyes'):
    if not j['materials'][pr['material']].get('name','').startswith('sclera'):continue
    row=next(r for r in eyes if r['side']in node['name']);X,Y,D=np.array(row['frame']);C=np.array(row['globe_center_world']);x=(P-C)@X-.0070;y=(P-C)@Y-.001;rad=np.sqrt(x*x+y*y);iris=.0105;pupil=.0033;col=np.tile([.84,.86,.76,1.],(len(P),1));body=np.array([.075,.19,.055,1]);limbus=np.array([.014,.040,.014,1]);pup=np.array([.0025,.004,.0015,1]);inside=rad<iris;col[inside]=body;ring=(rad>=iris-.0006)&inside;t=np.clip((rad[ring]-(iris-.0006))/.0006,0,1);col[ring]=body*(1-t[:,None])+limbus*t[:,None];dark=rad<pupil;col[dark]=pup
   else:
    col=np.tile([.78,.53,.34,1.],(len(P),1));mask=np.zeros(len(P))
    for row in eyes:
     X,Y,D=np.array(row['frame']);C=np.array(row['boundary_target_world']).mean(0);x=((P-C)@X)*(1 if row['side']=='positive'else -1);y=(P-C)@Y;depth=(P-C)@D;A=np.array([-.031,.023]);B=np.array([.007,.063]);C2=np.array([.042,.024]);closest=np.full(len(P),np.inf);parameter=np.zeros(len(P))
     ts=np.linspace(0,1,65);points=np.array([(1-t)**2*A+2*(1-t)*t*B+t*t*C2 for t in ts]);XY=np.c_[x,y]
     for k in range(64):
      e=points[k+1]-points[k];f=np.clip((XY-points[k])@e/(e@e),0,1);dist=np.linalg.norm(XY-points[k]-f[:,None]*e,axis=1);better=dist<closest;closest[better]=dist[better];parameter[better]=(k+f[better])/64
     width=.0032*(1-.75*parameter**2);m=np.clip((width-closest)/.0007,0,1);m*=((depth>-.005)&(depth<.027));mask=np.maximum(mask,m)
    brow=np.array([.095,.032,.011,1]);col=col*(1-mask[:,None])+brow*mask[:,None]
   add(j,payload,pr,col)
 dst=O/'components'/f'{tag}.glb';write(j,payload,dst);outputs.append({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(dst),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
r={'outputs':outputs,'geometry_normals_UVs_and_original_BIN_held':True,'iris_radius_m':.0105,'pupil_radius_m':.0033,'iris_center_shift_in_head_basis_m':[.0070,.001],'scope':'Diagnostic solid skin/brow and iris colors only. No final skin, iris fibers, optical cornea, brow detail or AI raster-paint pass. Used only to judge reference expression before changing global face geometry.'};(O/'checks/provisional_face060.json').write_text(json.dumps(r,indent=2));print('FACE060',r,flush=True)
