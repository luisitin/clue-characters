"""Uniform anatomical scale study about the measured index/head nearest contact.
Held pose topology, UVs, normal/tangent data and original BIN bytes are preserved.
"""
import bpy,pathlib,sys,json,numpy as np,hashlib,struct
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=pathlib.Path(__file__).resolve().parents[1];R=O.parents[2];sys.path.insert(0,str(O/'scripts'));from glb_io import read_glb,node_matrix
head=O/'components/head_trial025.glb';src=O/'components/thinking_hand026.glb';report=json.loads((O/'checks/thinking_hand026.json').read_text());bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(head));ob=next(o for o in bpy.context.scene.objects if o.type=='MESH');ob.data.calc_loop_triangles();tree=BVHTree.FromPolygons([ob.matrix_world@v.co for v in ob.data.vertices],[list(t.vertices)for t in ob.data.loop_triangles],all_triangles=True)
j,b,arr=read_glb(src);p=j['meshes'][0]['primitives'][0];M=node_matrix(j['nodes'][0]);assert np.max(abs(M-np.eye(4)))<1e-8;P=arr(p['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];F=arr(p['indices']).reshape(-1,3).astype(int);bones=report['posed_bones'];names=list(bones);ds=[]
for name in names:
 A=np.array(bones[name]['head']);B=np.array(bones[name]['tail']);d=B-A;t=np.clip((P-A)@d/(d@d),0,1);ds.append(np.linalg.norm(P-A-t[:,None]*d,axis=1))
labels=np.argmin(np.array(ds),axis=0);selected=np.flatnonzero(np.array([names[i].startswith('finger2-')for i in labels]));contacts=[]
for i in selected:
 q,n,fi,d=tree.find_nearest(Vector(P[i]));contacts.append((float(d),int(i),list(q),int(fi)))
dist,i,q,fi=min(contacts);anchor=P[i];assert dist<.003,(dist,i)
# Derive the scale from the actual source body and native body height, not a sibling's trial constant.
sys.path.insert(0,str(R/'shared_sources/makehuman/scripts'));from load_donor import load_donor
donor=load_donor();ids=np.unique(np.concatenate([donor['faces'][i]for i in donor['body_face_ids']]));native_height=float(np.ptp(donor['positions'][ids,1]));sj,sb,sa=read_glb(R/'sources/prelod-cd4c20d/sus-plum.glb');sp=sj['meshes'][0]['primitives'][0];sm=node_matrix(sj['nodes'][0]);sv=sa(sp['attributes']['POSITION']).astype(float);sv=sv@sm[:3,:3].T+sm[:3,3];height=float(np.ptp(sv[:,1]));target_scale=height/native_height;factor=target_scale/report['scale'];assert 1.1<factor<1.4
W=anchor+(P-anchor)*factor;local=(W*[1,-1,1])[:,[0,2,1]].astype('<f4');payload=bytearray(b)
while len(payload)%4:payload.append(0)
off=len(payload);payload.extend(local.tobytes());view=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':local.nbytes,'target':34962});ai=len(j['accessors']);j['accessors'].append({'bufferView':view,'componentType':5126,'count':len(local),'type':'VEC3','min':local.min(0).tolist(),'max':local.max(0).tolist()});p['attributes']['POSITION']=ai;j['buffers'][0]['byteLength']=len(payload);jj=json.dumps(j,separators=(',',':')).encode();jj+=b' '*((-len(jj))%4);payload+=b'\0'*((-len(payload))%4);dst=O/'components/thinking_hand038.glb';dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jj)+8+len(payload))+struct.pack('<I4s',len(jj),b'JSON')+jj+struct.pack('<I4s',len(payload),b'BIN\0')+payload)
r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'head_sha256':hashlib.sha256(head.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'source_body_height_m':height,'native_body_height':native_height,'old_native_hand_scale':report['scale'],'trial_native_hand_scale':target_scale,'uniform_factor':factor,'fixed_index_contact_world':anchor.tolist(),'sampled_index_head_distance_m':dist,'head_contact_world':q,'head_triangle':fi,'world_wrist_before':report['world_anchor'],'world_wrist_after':(anchor+(np.array(report['world_anchor'])-anchor)*factor).tolist(),'original_BIN_prefix_preserved':True,'only_POSITION_accessor_replaced':True,'scope':'Body-derived provisional scale study; actual reference silhouette, cuff position and whole hand/head clearance still decide acceptance.'};(O/'checks/hand_scale038.json').write_text(json.dumps(r,indent=2));print('SCALE038',r,flush=True)
