"""Repair one tiny twisted triangulation diagonal; all positions/UVs are held; four local smooth normal groups are recomputed."""
import pathlib,json,struct,hashlib,numpy as np,collections
from glb_io import read_glb
O=pathlib.Path(__file__).resolve().parents[1];src=O/'components/head_trial034.glb';j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];F=a(pr['indices']).reshape(-1,3).astype(np.uint32);P=a(pr['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];N=a(pr['attributes']['NORMAL']).astype(float)[:,[0,2,1]]*[1,-1,1];old=F[[26106,26107]].copy();assert old.tolist()==[[4800,35269,25659],[4800,25659,1164]];new=np.array([[4800,35269,1164],[35269,25659,1164]],np.uint32)
def boundary(fs):
 c=collections.Counter((int(x),int(y))for f in fs for x,y in zip(f,np.roll(f,-1)))
 return sorted(e for e in c if e[::-1]not in c)
assert boundary(old)==boundary(new)
def metric(fs):
 T=P[fs];gn=np.cross(T[:,1]-T[:,0],T[:,2]-T[:,0]);ar=np.linalg.norm(gn,axis=1);gn/=ar[:,None];return {'dihedral_degrees':float(np.degrees(np.arccos(np.clip(gn[0]@gn[1],-1,1)))),'areas_m2':(ar/2).tolist(),'corner_normal_dot_geometric':np.einsum('fij,fj->fi',N[fs],gn).tolist()}
before=metric(old);F[[26106,26107]]=new
# The old folded face contaminated several smooth corner normals. Recompute only
# the four exact-position groups from the complete retained incident face area normals.
changed=[]
for vi in np.unique(new):
 group=np.flatnonzero(np.all(P==P[vi],axis=1));faceids=np.flatnonzero(np.isin(F,group).any(1));tt=P[F[faceids]];nn=np.cross(tt[:,1]-tt[:,0],tt[:,2]-tt[:,0]).sum(0);nn/=np.linalg.norm(nn);N[group]=nn;changed.extend(group.tolist())
after=metric(new);print('QUAD_DIAGNOSTIC',before,after,flush=True);assert after['dihedral_degrees']<10 and np.min(after['corner_normal_dot_geometric'])>0;payload=bytearray(b)
while len(payload)%4:payload.append(0)
off=len(payload);ib=F.astype('<u4').tobytes();payload.extend(ib);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(ib),'target':34963});ai=len(j['accessors']);j['accessors'].append({'bufferView':vi,'componentType':5125,'count':int(F.size),'type':'SCALAR','min':[int(F.min())],'max':[int(F.max())]});pr['indices']=ai
normal_local=(N*[1,-1,1])[:,[0,2,1]].astype('<f4');noff=len(payload);nb=normal_local.tobytes();payload.extend(nb);nvi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':noff,'byteLength':len(nb),'target':34962});nai=len(j['accessors']);j['accessors'].append({'bufferView':nvi,'componentType':5126,'count':len(N),'type':'VEC3'});pr['attributes']['NORMAL']=nai;j['buffers'][0]['byteLength']=len(payload);jb=json.dumps(j,separators=(',',':')).encode();jb+=b' '*((-len(jb))%4);payload+=b'\0'*((-len(payload))%4);dst=O/'components/head_trial043.glb';dst.write_bytes(struct.pack('<4sII',b'glTF',2,12+8+len(jb)+8+len(payload))+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(payload),b'BIN\0')+payload);r={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'before':before,'after':after,'old_faces':old.tolist(),'new_faces':new.tolist(),'ordered_quad_perimeter_held':True,'original_BIN_and_all_positions_UVs_held':True,'recomputed_normal_vertex_ids':sorted(set(changed)),'normal_method':'Complete retained incident face area normals for only the four exact-position groups affected by diagonal correction.','scope':'One donor upper-lateral quad diagonal only. Local intersections and actual shading still require validation.'};(O/'checks/lateral_quad043.json').write_text(json.dumps(r,indent=2));print('QUAD043',r,flush=True)
