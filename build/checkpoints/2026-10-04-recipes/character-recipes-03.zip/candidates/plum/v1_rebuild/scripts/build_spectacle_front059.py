"""Separate fitted spectacle front for anatomical likeness context. Temples remain unbuilt."""
import bpy,pathlib,json,math,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=pathlib.Path(__file__).resolve().parents[1];src=O/'components/head_wide058.glb';meta=json.loads((O/'checks/regular_orbits033.json').read_text());bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src));head=next(o for o in bpy.context.scene.objects if o.type=='MESH');head.data.calc_loop_triangles();tree=BVHTree.FromPolygons([head.matrix_world@v.co for v in head.data.vertices],[list(t.vertices)for t in head.data.loop_triangles],all_triangles=True);records=[];objects=[];fronts=[]
mat=bpy.data.materials.new('Plum dark warm metal spectacle front');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.034,.022,.009,1);bs.inputs['Metallic'].default_value=.58;bs.inputs['Roughness'].default_value=.30

def tube(name,Q,r,closed=True,n=16):
 Q=np.array(Q);t=np.roll(Q,-1,axis=0)-np.roll(Q,1,axis=0)
 if not closed:t[0]=Q[1]-Q[0];t[-1]=Q[-1]-Q[-2]
 t/=np.linalg.norm(t,axis=1)[:,None];N=np.array(meta['eyes'][0]['frame'][2]);v=N-t*(t@N)[:,None];v/=np.linalg.norm(v,axis=1)[:,None];w=np.cross(t,v);V=[];faces=[]
 for q,a,b in zip(Q,v,w):
  for k in range(n):V.append(q+r*(math.cos(2*math.pi*k/n)*a+math.sin(2*math.pi*k/n)*b))
 for i in range(len(Q)if closed else len(Q)-1):
  ni=(i+1)%len(Q)
  for k in range(n):nk=(k+1)%n;faces.append((i*n+nk,ni*n+nk,ni*n+k,i*n+k))
 if not closed:
  st=len(V);V.append(Q[0]);en=len(V);V.append(Q[-1])
  for k in range(n):nk=(k+1)%n;faces.extend([(st,nk,k),(en,(len(Q)-1)*n+k,(len(Q)-1)*n+nk)])
 vv=np.array(V);tt=np.array([(f[0],f[k],f[k+1])for f in faces for k in range(1,len(f)-1)],int);tri=vv[tt];volume=float(np.sum(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])))/6);assert volume>0,(name,volume)
 me=bpy.data.meshes.new(name);me.from_pydata([q.tolist()for q in V],[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);me.materials.append(mat)
 for p in me.polygons:p.use_smooth=True
 objects.append(ob);return ob

for row in meta['eyes']:
 X,Y,N=np.array(row['frame']);B=np.array(row['boundary_target_world']);C=B.mean(0)+Y*.001;theta=np.linspace(0,2*np.pi,128,endpoint=False);x=.033*np.cos(theta);y=.0325*np.sin(theta);y=np.where(y<0,y*.95,y);samples=[]
 for u,v in zip(x,y):
  q=C+u*X+v*Y;hit,normal,fi,d=tree.ray_cast(Vector(q+N*.15),Vector(-N),.3)
  assert hit is not None;depth=float((np.array(hit)-q)@N);samples.append(depth)
 A=np.c_[np.ones(len(x)),x,y];fit=np.linalg.lstsq(A,np.array(samples),rcond=None)[0];res=np.array(samples)-A@fit;offset=float(res.max()+.0027);depth=A@fit+offset;Q=C+x[:,None]*X+y[:,None]*Y+depth[:,None]*N;tube('Plum | fitted spectacle rim059 '+row['side'],Q,.00115);inner=64 if row['side']=='positive'else 0;fronts.append(Q[(inner-2 if row['side']=='positive'else inner+2)%128]);records.append({'side':row['side'],'frame_center_world':C.tolist(),'plane_coefficients':fit.tolist(),'clearance_offset_m':offset,'sampled_centerline_front_depth_clearance_min_m':float((depth-np.array(samples)).min()),'rim_radius_m':.00115,'shape_horizontal_radius_m':.033,'shape_vertical_radius_m':.0325})
# Continuous bridge endpoints enter the rims; a shallow upward arch clears the nasal root.
A,B=fronts;X,Y,N=np.array(meta['eyes'][0]['frame']);Q=[]
for t in np.linspace(0,1,65):
 q=A*(1-t)+B*t+Y*(.002*4*t*(1-t));hit,normal,fi,d=tree.ray_cast(Vector(q+N*.15),Vector(-N),.3)
 if hit is not None:
  front=float((np.array(hit)-q)@N)+.0025;q+=N*max(0,front)*(math.sin(math.pi*t)**.3)
 Q.append(q)
tube('Plum | nasal bridge059',Q,.00095,False)
bpy.ops.object.select_all(action='DESELECT')
for ob in objects:ob.select_set(True)
bpy.context.view_layer.objects.active=objects[0];dst=O/'components/spectacle_front059.glb';bpy.ops.export_scene.gltf(filepath=str(dst),export_format='GLB',use_selection=True,export_yup=True,export_normals=True,export_animations=False);r={'head_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'frames':records,'scope':'Provisional spectacle-front context only. Open-frame lenses omitted; temples, bridge seating, all-angle contact, source/reference identity and paint remain unapproved.'};(O/'checks/spectacle_front059.json').write_text(json.dumps(r,indent=2));print('SPECTACLE059',r,flush=True)
