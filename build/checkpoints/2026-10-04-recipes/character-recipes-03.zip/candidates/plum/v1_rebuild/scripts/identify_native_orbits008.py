"""Separate the actual visible hm08 aperture from posterior socket walls by explicit topology."""
import pathlib,sys,json,numpy as np,hashlib,collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
O=pathlib.Path(__file__).resolve().parents[1];D=O.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(D/'scripts'));from load_donor import load_obj
V,UV,F,FU,G=load_obj();bodyids=np.flatnonzero(G=='body');B=np.array([F[i]for i in bodyids]);bv=np.unique(B);positive=np.array([7768,7769,7795,7796,7797,7790,11719,7789,7788,7787,7786,7785,7784,7758,7757,11716,7756,7755,7781,7780,7779,7778,7777,7776,7750,7749,7775,7773,7774,7791,7792,7793,7767,7772]);negative=[]
for k in positive:
 d=np.linalg.norm(V-V[k]*[-1,1,1],axis=1);i=int(d.argmin());assert d[i]<1e-5;negative.append(i)
negative=np.array(negative);ring=np.r_[positive,negative];remaining=bv[~np.isin(bv,ring)];lookup=np.full(len(V),-1,int);lookup[remaining]=np.arange(len(remaining));edges=np.concatenate([B[:,[0,1]],B[:,[1,2]],B[:,[2,3]],B[:,[3,0]]]);ed=lookup[edges];ed=ed[(ed>=0).all(1)];graph=coo_matrix((np.ones(len(ed)*2),(np.r_[ed[:,0],ed[:,1]],np.r_[ed[:,1],ed[:,0]])),shape=(len(remaining),len(remaining))).tocsr();nc,lab=connected_components(graph,directed=False);counts=np.bincount(lab);rows=[];selected=[]
for k in range(nc):
 ids=remaining[lab==k];rows.append({'component':k,'vertices':len(ids),'bounds_native':[V[ids].min(0).tolist(),V[ids].max(0).tolist()],'centroid_native':V[ids].mean(0).tolist()})
 if len(ids)==285 and V[ids,1].min()>6.9 and V[ids,1].max()<7.6:selected.append(ids)
assert len(selected)==2,rows
posterior=np.concatenate(selected);postset=set(map(int,posterior));ringset=set(map(int,ring));retained=[];retuv=[];retids=[];removed=[];split=[];interior_ring_quads=[];inc=collections.defaultdict(list)
def inside_polygon(q,poly):
 count=False
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):
  if (a[1]>q[1])!=(b[1]>q[1])and q[0]<(b[0]-a[0])*(q[1]-a[1])/(b[1]-a[1])+a[0]:count=not count
 return count
for fi in bodyids:
 f=F[fi];uv=FU[fi];inside=[x in postset for x in f]
 if all(x in ringset for x in f):
  centroid=V[f,:2].mean(0);owns=[inside_polygon(centroid,V[loop,:2])for loop in (positive,negative)]
  assert sum(owns)==1,(fi,f,centroid,owns)
  removed.append(int(fi));interior_ring_quads.append({'source_quad':int(fi),'native_vertices':f,'centroid_native_xy':centroid.tolist(),'contained_in_aperture':int(np.flatnonzero(owns)[0])});continue
 if not any(inside):newf=f;newuv=uv
 elif all(x in postset or x in ringset for x in f):removed.append(int(fi));continue
 else:
  # The measured aperture follows the diagonal of a few native quads.
  # Preserve the exterior half, including all original corner UVs, rather than dropping that support.
  ir=[k for k,x in enumerate(f)if x in ringset];assert len(ir)==2 and (ir[1]-ir[0])%2==0,(fi,f,ir)
  keepcorners=[k for k,x in enumerate(f)if x not in postset];assert len(keepcorners)==3
  newf=[f[k]for k in keepcorners];newuv=[uv[k]for k in keepcorners];split.append({'source_quad':int(fi),'retained_corner_indices':keepcorners,'retained_triangle':newf})
 retained.append(newf);retuv.append(newuv);retids.append(int(fi))
 for x,y in zip(newf,newf[1:]+newf[:1]):inc[tuple(sorted((x,y)))].append((int(fi),x,y))
checks=[]
for name,loop in [('positive',positive),('negative',negative)]:
 rr=[inc[tuple(sorted((int(x),int(y))))]for x,y in zip(loop,np.roll(loop,-1))]
 for (x,y),r0 in zip(zip(loop,np.roll(loop,-1)),rr):
  if len(r0)!=1:
   ss=[int(fi) for fi in bodyids if int(x) in F[fi] and int(y) in F[fi]];print('BAD_APERTURE_EDGE',name,int(x),int(y),len(r0),'source_quads',[(fi,F[fi],[int(v in postset)for v in F[fi]])for fi in ss],flush=True)
 assert all(len(r)==1 for r in rr);checks.append({'side':name,'native_vertex_ids':loop.tolist(),'retained_edge_incidence':list(map(len,rr)),'rest_aperture_bounds':[V[loop].min(0).tolist(),V[loop].max(0).tolist()],'directed_retained_halfedges':[[r[0][1],r[0][2]]for r in rr]})
np.savez_compressed(O/'checks/native_orbits008.npz',positive_loop=positive,negative_loop=negative,posterior_vertices=posterior,removed_whole_source_face_ids=np.array(removed),retained_source_face_ids=np.array(retids),retained_polygon_indices=np.concatenate(retained),retained_polygon_uv_indices=np.concatenate(retuv),retained_polygon_offsets=np.r_[0,np.cumsum([len(f)for f in retained])]);r={'base_sha256':hashlib.sha256((D/'raw/base.obj').read_bytes()).hexdigest(),'ring_source':'Explicit visible34-vertex aperture loop, independently recovered from prior exact native topology; mirrored by original XYZ','components_after_removing_ring_vertices':rows,'posterior_vertices':len(posterior),'removed_posterior_quads':len(removed),'split_diagonal_quads':split,'removed_interior_all_ring_quads':interior_ring_quads,'apertures':checks,'scope':'Native topology separation only. Turning these rings into skin boundaries still requires source-preserving subdivision, closed cap seating, actual shape and full skin/cap crossings. No source character geometry changed. 008c established that the failure was an all-ring quad inside each aperture, invisible to vertex-component labeling; those two quads are explicitly classified by ordered native aperture containment. The earlier diagonal hypothesis was premature; actual split count is recorded.'};(O/'checks/native_orbits008.json').write_text(json.dumps(r,indent=2));print('ORBITS008',[(r['vertices'],r['centroid_native'])for r in rows],len(removed),'diagonal splits',len(split),flush=True)
