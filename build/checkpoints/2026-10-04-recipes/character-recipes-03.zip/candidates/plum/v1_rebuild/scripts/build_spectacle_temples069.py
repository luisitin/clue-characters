"""Closed temple/hook study guided by actual native ear roofs and dense skin clearance.
Head and existing spectacle front are immutable. Open curves use transported frames.
"""
import bpy,pathlib,json,hashlib,numpy as np,math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
O=pathlib.Path(__file__).resolve().parents[1];src=O/'components/head_corners065.glb';ears=json.loads((O/'checks/ear_roofs063.json').read_text());frames=json.loads((O/'checks/spectacle_front059.json').read_text());X,Y,N=np.array(ears['frame']);C=np.array(ears['frame_center_world']);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src));head=next(o for o in bpy.context.scene.objects if o.type=='MESH');head.data.calc_loop_triangles();tree=BVHTree.FromPolygons([head.matrix_world@v.co for v in head.data.vertices],[list(t.vertices)for t in head.data.loop_triangles],all_triangles=True)
radius=.00105;clearance=.00165;objects=[];records=[]
mat=bpy.data.materials.new('Plum dark warm metal temples069');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.034,.022,.009,1);bs.inputs['Metallic'].default_value=.58;bs.inputs['Roughness'].default_value=.30

def world(L):return C+L[0]*X+L[1]*Y+L[2]*N
def local(P):return np.array([(P-C)@X,(P-C)@Y,(P-C)@N])
def nearest(P):
 q,n,fi,d=tree.find_nearest(Vector(P));return np.array(q),np.array(n),int(fi),float(d)
def catmull(K,samples=30):
 K=np.vstack([2*K[0]-K[1],K,2*K[-1]-K[-2]]);out=[]
 for k in range(1,len(K)-2):
  a,b,c,d=K[k-1:k+3]
  for t in np.linspace(0,1,samples,endpoint=False):out.append(.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t))
 out.append(K[-2]);return np.array(out)
for ear,fr in zip(ears['ears'],frames['frames']):
 assert ear['side']==fr['side'];sign=ear['side_sign'];fc=np.array(fr['frame_center_world']);u=sign*fr['shape_horizontal_radius_m'];plane=np.array(fr['plane_coefficients']);H=fc+u*X+(plane[0]+plane[1]*u+fr['clearance_offset_m'])*N;roof=np.array(ear['candidate_roof_local']);rx=abs(roof[0]);K=np.array([local(H),[sign*.087,.006,-.050],[sign*(rx-.003),roof[1]+.003,roof[2]+.013],[sign*(rx+.0015),roof[1]+.0015,roof[2]],[sign*(rx-.004),roof[1]-.005,roof[2]-.013],[sign*(rx-.015),roof[1]-.032,roof[2]-.013]])
 K=np.array([world(p)for p in K]);end,nend,faceend,dend=nearest(K[-1]);K[-1]=end+nend*clearance;assert (K[-1]-C)@N<roof[2]-.003
 q,n,fi,d=nearest(H);assert d>radius+.0002 and (H-q)@n>0,('Hinge not clear of skin',ear['side'],d)
 Q=catmull(K);target=Q.copy();max_push=0
 for iteration in range(80):
  smooth=Q.copy();smooth[1:-1]=.72*Q[1:-1]+.23*(Q[:-2]+Q[2:])/2+.05*target[1:-1];smooth[0]=H;smooth[-1]=K[-1]
  for i in range(1,len(Q)-1):
   q,n,fi,d=nearest(smooth[i]);signed=(smooth[i]-q)@n
   if d<clearance or signed<0:
    fixed=q+n*clearance;max_push=max(max_push,float(np.linalg.norm(fixed-smooth[i])));smooth[i]=fixed
  Q=smooth
 # Uniform arclength sampling reduces short uneven strips after constrained fairing.
 lengths=np.r_[0,np.cumsum(np.linalg.norm(np.diff(Q,axis=0),axis=1))];ss=np.linspace(0,lengths[-1],160);Q=np.stack([np.interp(ss,lengths,Q[:,k])for k in range(3)],axis=1);Q[0]=H;Q[-1]=K[-1]
 # Recheck centers and segment midpoints before creating any swept surface.
 center_samples=np.vstack([Q,(Q[:-1]+Q[1:])/2]);cd=[]
 for p in center_samples:
  q,n,fi,d=nearest(p);cd.append(d);assert d>radius+.00010 and (p-q)@n>=-1e-8,('Centerline clearance',ear['side'],d)
 T=np.empty_like(Q);T[1:-1]=Q[2:]-Q[:-2];T[0]=Q[1]-Q[0];T[-1]=Q[-1]-Q[-2];T/=np.linalg.norm(T,axis=1)[:,None];axis=np.eye(3)[np.argmin(abs(T[0]))];U=[np.cross(axis,T[0])];U[0]/=np.linalg.norm(U[0])
 for i in range(1,len(T)):
  v=np.cross(T[i-1],T[i]);sn=np.linalg.norm(v);cs=float(T[i-1]@T[i]);u0=U[-1]
  if sn>1e-12:
   axis=v/sn;u0=u0*cs+np.cross(axis,u0)*sn+axis*(axis@u0)*(1-cs)
  u0-=T[i]*(u0@T[i]);u0/=np.linalg.norm(u0);U.append(u0)
 U=np.array(U);V=np.cross(T,U);nrad=16;P=[];faces=[]
 for q,u,v in zip(Q,U,V):
  for k in range(nrad):a=2*np.pi*k/nrad;P.append(q+radius*(np.cos(a)*u+np.sin(a)*v))
 for i in range(len(Q)-1):
  for k in range(nrad):nk=(k+1)%nrad;faces.append([i*nrad+nk,(i+1)*nrad+nk,(i+1)*nrad+k,i*nrad+k])
 st=len(P);P.append(Q[0]);en=len(P);P.append(Q[-1])
 for k in range(nrad):nk=(k+1)%nrad;faces.extend([[st,nk,k],[en,(len(Q)-1)*nrad+k,(len(Q)-1)*nrad+nk]])
 P=np.array(P);tri=np.array([(f[0],f[k],f[k+1])for f in faces for k in range(1,len(f)-1)],int);tt=P[tri];volume=float(np.sum(np.einsum('ij,ij->i',tt[:,0],np.cross(tt[:,1],tt[:,2])))/6);assert volume>0
 # Dense actual swept-surface clearance, not just centerline distance.
 sample=np.vstack([P,tt.mean(1),(tt[:,0]+tt[:,1])/2,(tt[:,1]+tt[:,2])/2,(tt[:,2]+tt[:,0])/2]);clear=[];negative=0
 for p in sample:
  q,n,fi,d=nearest(p);clear.append(d);negative+=int((p-q)@n< -1e-7)
 assert min(clear)>.00008 and negative==0,('Surface clearance',ear['side'],min(clear),negative)
 me=bpy.data.meshes.new('Closed transported temple and ear hook');me.from_pydata(P.tolist(),[],faces);me.update();ob=bpy.data.objects.new('Plum | temple069 '+ear['side'],me);bpy.context.collection.objects.link(ob);me.materials.append(mat)
 for poly in me.polygons:poly.use_smooth=True
 objects.append(ob);records.append({'side':ear['side'],'hinge_world':H.tolist(),'ear_roof_world':ear['candidate_roof_world'],'end_world':Q[-1].tolist(),'centerline_points':Q.tolist(),'radius_m':radius,'centerline_minimum_skin_distance_m':min(cd),'surface_minimum_skin_distance_m':min(clear),'dense_surface_samples':len(sample),'negative_signed_surface_samples':negative,'closed_volume_m3':volume,'maximum_projection_correction_m':max_push,'length_m':float(lengths[-1]),'triangles':len(tri)})
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0];dst=O/'components/spectacle_temples069.glb';bpy.ops.export_scene.gltf(filepath=str(dst),export_format='GLB',use_selection=True,export_yup=True,export_normals=True,export_animations=False);r={'head_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'frame_sha256':frames['output_sha256'],'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'temples':records,'scope':'Temple/hook geometry study only. Ear placement must be confirmed in actual side/top/under views, and full self/head intersections still require exact audit. Frame/temple overlap at the intended hinges is intentional metal assembly contact.'};(O/'checks/spectacle_temples069.json').write_text(json.dumps(r,indent=2));print('TEMPLES069',r['output_sha256'],[{k:v for k,v in x.items()if k!='centerline_points'}for x in records],flush=True)
