"""Exact shared-rim scleral fronts on033's smooth ellipsoid, with separate posterior walls.
Avoids tessellation-chord eye/lid intersections while retaining every actual034 head boundary.
"""
import bpy,pathlib,sys,json,numpy as np,hashlib,collections
O=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'scripts'));from glb_io import read_glb;from constrained_disk import triangulate
src=O/'components/head_trial034.glb';j,b,a=read_glb(src);p=j['meshes'][0]['primitives'][0];P=a(p['attributes']['POSITION']).astype(float)[:,[0,2,1]]*[1,-1,1];F=a(p['indices']).reshape(-1,3).astype(int);U,iv=np.unique(P,axis=0,return_inverse=True);UF=iv[F];edges=collections.defaultdict(list)
for fi,f in enumerate(UF):
 for a,b in zip(f,np.roll(f,-1)):edges[tuple(sorted((int(a),int(b))))].append((fi,int(a),int(b)))
meta=json.loads((O/'checks/regular_orbits033.json').read_text());bpy.ops.wm.read_factory_settings(use_empty=True);obs=[];records=[]
for row in meta['eyes']:
 B0=np.array(row['boundary_target_world']);ids=[];ds=[]
 for q in B0:
  d=np.linalg.norm(U-q,axis=1);i=int(d.argmin());ids.append(i);ds.append(d[i])
 assert max(ds)<5e-8 and len(set(ids))==len(ids);B=U[ids];X,Y,N=np.array(row['frame']);C=np.array(row['globe_center_world']);rx,ry,rz=row['globe_radii_m'];xy=np.c_[(B-C)@X,(B-C)@Y];span=float(np.ptp(xy,axis=0).max());q=xy/span;Q,T,tr=triangulate(q,max_edge=.0006/span);xy2=Q*span;nb=len(B);d=rz*np.sqrt(np.maximum(0,1-(xy2[:,0]/rx)**2-(xy2[:,1]/ry)**2));front=C+xy2[:,0,None]*X+xy2[:,1,None]*Y+d[:,None]*N;front[:nb]=B
 back=C+xy2[:,0,None]*X+xy2[:,1,None]*Y-.006*N;n=len(front);V=np.vstack([front,back]);faces=list(map(list,T))+list(map(list,(T+n)[:,::-1]));frontn=len(faces)//2;backn=frontn
 for i in range(nb):
  k=(i+1)%nb;faces.extend([[k,i,n+i],[k,n+i,n+k]])
 faces=np.array(faces,int);ec=collections.Counter(tuple(sorted((int(a),int(b))))for f in faces for a,b in zip(f,np.roll(f,-1)));assert set(ec.values())=={2}
 for i in range(nb):
  k=(i+1)%nb;r=edges[tuple(sorted((ids[i],ids[k])))];assert len(r)==1 and (r[0][1],r[0][2])==(ids[k],ids[i])
 tt=V[faces];gn=np.cross(tt[:,1]-tt[:,0],tt[:,2]-tt[:,0]);area=np.linalg.norm(gn,axis=1)/2;assert area.min()>1e-15;volume=np.sum(np.einsum('ij,ij->i',tt[:,0],np.cross(tt[:,1],tt[:,2])))/6;assert volume>0
 me=bpy.data.meshes.new('Exact-rim eye front and posterior shell');me.from_pydata(V.tolist(),[],faces.tolist());me.update();ob=bpy.data.objects.new('Plum | exact scleral shell039 '+row['side'],me);bpy.context.collection.objects.link(ob);obs.append(ob)
 for label,color in [('sclera',(.78,.80,.72,1)),('hidden shell',(.22,.24,.21,1))]:
  m=bpy.data.materials.new(label+'039');m.use_nodes=True;m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=color;m.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.35;me.materials.append(m)
 uv=me.uv_layers.new(name='EyePlanarUV');uv0=(xy2-xy2.min(0))/np.ptp(xy2,axis=0);uvall=np.vstack([uv0,uv0]);frontnorm=(front-C)@np.vstack([X,Y,N]).T/np.array([rx,ry,rz])**2;frontnorm=frontnorm@np.vstack([X,Y,N]);frontnorm/=np.linalg.norm(frontnorm,axis=1)[:,None];side=np.zeros_like(V)
 for f,ng in zip(faces[frontn+backn:],gn[frontn+backn:]):
  for i in f:side[i]+=ng
 side/=np.maximum(np.linalg.norm(side,axis=1)[:,None],1e-30);normals=[]
 for poly in me.polygons:
  poly.use_smooth=True;poly.material_index=0 if poly.index<frontn else 1
  for li,vi in zip(poly.loop_indices,poly.vertices):
   uv.data[li].uv=uvall[vi];normals.append((frontnorm[vi]if poly.index<frontn else -N if poly.index<frontn+backn else side[vi]).tolist())
 me.normals_split_custom_set(normals);records.append({'side':row['side'],'boundary_vertices':nb,'max_boundary_match_m':max(ds),'one_retained_neighbor_and_opposite_parity':True,'triangles':len(faces),'closed_edge_incidence2':True,'closed_volume_m3':float(volume),'triangulation':tr})
bpy.ops.object.select_all(action='DESELECT')
for o in obs:o.select_set(True)
bpy.context.view_layer.objects.active=obs[0];dst=O/'components/eye_shells039.glb';bpy.ops.export_scene.gltf(filepath=str(dst),export_format='GLB',use_selection=True,export_yup=True,export_normals=True,export_texcoords=True);r={'head_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'eyes':records,'scope':'Exact donor rim topology only; hidden-wall contacts, complete crossings/folds and actual visual/likeness gates remain.'};(O/'checks/eye_shells039.json').write_text(json.dumps(r,indent=2));print('EYES039',r,flush=True)
