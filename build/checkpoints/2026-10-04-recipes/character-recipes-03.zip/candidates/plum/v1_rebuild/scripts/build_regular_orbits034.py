"""Export the explicitly bounded033 donor-lid trial and analytic closed eyes."""
import bpy,pathlib,sys,json,hashlib,numpy as np,math,collections
O=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'scripts'));from glb_io import read_glb
src=O/'components/head_trial025.glb';meta=json.loads((O/'checks/regular_orbits033.json').read_text());assert hashlib.sha256(src.read_bytes()).hexdigest()==meta['source_sha256'];z=np.load(O/'checks/regular_orbits033.npz');P=z['world_positions'];F=z['indices'];j,b,a=read_glb(src);pr=j['meshes'][0]['primitives'][0];uv0=a(pr['attributes']['TEXCOORD_0']).astype(float);bpy.ops.wm.read_factory_settings(use_empty=True)
def material(name,color,rough):
 m=bpy.data.materials.new(name);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=rough;return m
skin=material('Donor skin clay034',(.62,.62,.62),.6);sclera=material('Sclera shape study034',(.78,.80,.72),.35)
def make(name,V,F,UV,mat):
 me=bpy.data.meshes.new(name);me.from_pydata(V.tolist(),[],F);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);me.materials.append(mat);uv=me.uv_layers.new(name='PreservedUV')
 for poly in me.polygons:
  poly.use_smooth=True
  for li,vi in zip(poly.loop_indices,poly.vertices):uv.data[li].uv=UV[vi]
 return o
body=make('Plum | bounded donor eyelids034',P,F.tolist(),np.c_[uv0[:,0],1-uv0[:,1]],skin);eyes=[]
for row in meta['eyes']:
 C=np.array(row['globe_center_world']);X,Y,N=np.array(row['frame']);rx,ry,rz=row['globe_radii_m'];n=96;m=48;V=[C+N*rz];UV=[[.5,1.]]
 for i in range(1,m):
  theta=np.pi*i/m
  for k in range(n):
   phi=2*np.pi*k/n;V.append(C+X*(rx*np.sin(theta)*np.cos(phi))+Y*(ry*np.sin(theta)*np.sin(phi))+N*(rz*np.cos(theta)));UV.append([k/n,1-i/m])
 back=len(V);V.append(C-N*rz);UV.append([.5,0]);faces=[]
 for k in range(n):faces.append([0,1+k,1+(k+1)%n])
 for i in range(m-2):
  for k in range(n):
   aa=1+i*n+k;bb=1+i*n+(k+1)%n;cc=1+(i+1)*n+k;dd=1+(i+1)*n+(k+1)%n;faces.append([aa,cc,dd,bb])
 for k in range(n):faces.append([1+(m-2)*n+k,back,1+(m-2)*n+(k+1)%n])
 V=np.array(V);edge=collections.Counter(tuple(sorted((a,b)))for f in faces for a,b in zip(f,f[1:]+f[:1]));assert set(edge.values())=={2};eyes.append(make('Plum | closed covering globe034 '+row['side'],V,faces,np.array(UV),sclera))
outputs=[]
for name,objects in [('head_trial034',[body]),('eyes034',eyes)]:
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0];p=O/'components'/f'{name}.glb';bpy.ops.export_scene.gltf(filepath=str(p),export_format='GLB',use_selection=True,export_yup=True,export_texcoords=True,export_normals=True,export_animations=False);outputs.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
r={'input_sha256':meta['source_sha256'],'construction033':meta,'outputs':outputs,'scope':'Unapproved donor-only eye/lid geometry study; inspect exact all-angle shell contact and full local crossings/folds before integration.'};(O/'checks/regular_orbits034.json').write_text(json.dumps(r,indent=2));print('ORBIT034',outputs,flush=True)
