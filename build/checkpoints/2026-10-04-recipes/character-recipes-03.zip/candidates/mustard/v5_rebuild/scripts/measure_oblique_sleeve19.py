"""Read-only forearm-oriented sections, avoiding a global-X cut through the bent upper arm."""
from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/mustard_source_sanitized01.glb');P,T,N,UV=g.native();tri=P[T];centers=tri.mean(1)
normal=np.array([.30,-.953,-.035]);normal/=np.linalg.norm(normal);axisU=np.cross([0,0,1],normal);axisU/=np.linalg.norm(axisU);axisV=np.cross(normal,axisU);base=np.array([.365,-.06,.255]);reports=[]
for offset in (-.02,-.01,0,.01):
    C=base+normal*offset;sd=(tri-C)@normal
    sel=np.flatnonzero((sd.min(1)<0)&(sd.max(1)>0)&(np.linalg.norm(centers-C,axis=1)<.22)&(centers[:,0]>.20)&(centers[:,2]>.08)&(centers[:,2]<.48))
    segments=[];source=[]
    for fi in sel:
        pts=[]
        for i in range(3):
            j=(i+1)%3
            if sd[fi,i]*sd[fi,j]<0:pts.append(tri[fi,i]+(tri[fi,j]-tri[fi,i])*(-sd[fi,i])/(sd[fi,j]-sd[fi,i]))
        if len(pts)==2:segments.append(pts);source.append(int(fi))
    segments=np.array(segments);flat=segments.reshape(-1,3);_,ix,inv=np.unique(np.rint(flat/1e-8).astype('i8'),axis=0,return_index=True,return_inverse=True);points=flat[ix];edges=inv.reshape(-1,2);adj={i:[] for i in range(len(points))}
    for ei,(a,b) in enumerate(edges):adj[a].append((b,ei));adj[b].append((a,ei))
    remain=set(adj);components=[]
    while remain:
        todo=[next(iter(remain))];nodes=set();es=set()
        while todo:
            i=todo.pop()
            if i in nodes:continue
            nodes.add(i);remain.discard(i)
            for j,ei in adj[i]:es.add(ei);todo.append(j)
        degrees=[len(adj[i]) for i in nodes];closed=all(x==2 for x in degrees);cycle=[];area=None
        if closed:
            cur=min(nodes);prev=None
            while not cycle or cur!=cycle[0]:
                cycle.append(cur);nxt=next(j for j,ei in adj[cur] if j!=prev);prev,cur=cur,nxt
            local=(points[cycle]-C)@np.column_stack((axisU,axisV));area=float(.5*np.sum(local[:,0]*np.roll(local[:,1],-1)-local[:,1]*np.roll(local[:,0],-1)))
        components.append({'nodes':len(nodes),'edges':len(es),'degree_counts':{str(k):degrees.count(k) for k in set(degrees)},'closed_degree_two':closed,'plane_area':area,'mean':points[list(nodes)].mean(0).tolist(),'bounds':[points[list(nodes)].min(0).tolist(),points[list(nodes)].max(0).tolist()],'source_faces':[source[k] for k in sorted(es)],'ordered_cycle':points[cycle].tolist()})
    reports.append({'offset':offset,'plane_center':C.tolist(),'plane_normal':normal.tolist(),'components':components})
    print({'offset':offset,'components':[{k:c[k] for k in ('nodes','edges','closed_degree_two','degree_counts','plane_area','mean')} for c in components]},flush=True)
(D/'audit/oblique_sleeve_sections19.json').write_text(json.dumps({'source_sha256':g.sha256,'sections':reports,'scope':'Read-only section candidates. No source removal, and no skin/cloth ownership inferred from color.'},indent=2))
