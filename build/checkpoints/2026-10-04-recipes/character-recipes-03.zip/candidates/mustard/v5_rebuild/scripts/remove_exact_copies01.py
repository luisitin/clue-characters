"""Bounded source sanitation: only exact oriented POSITION/NORMAL/UV copies and collapsed triangles."""
import json,hashlib
from pathlib import Path
import numpy as np
from glb_io import GLB
D=Path(__file__).resolve().parents[1];src=D.parents[2]/'sources/prelod-cd4c20d/sus-mustard.glb'
g=GLB(src);pr=g.primitive();attrs={k:g.read(v,False) for k,v in pr['attributes'].items()};t=g.read(pr['indices']).reshape(-1,3)
P=attrs['POSITION'];N=attrs['NORMAL'];UV=attrs['TEXCOORD_0'];seen={};delete=[];proof=[];collapsed=[]
for i,tr in enumerate(t):
    corners=[P[x].tobytes()+N[x].tobytes()+UV[x].tobytes() for x in tr]
    cycles=[b''.join(corners[k:]+corners[:k]) for k in range(3)];key=min(cycles)
    if key in seen:
        delete.append(i);proof.append({'removed':i,'retained':seen[key],'equality':'exact oriented quantized POSITION, NORMAL and UV; same primitive/material'})
    else:seen[key]=i
    if len({P[x].tobytes() for x in tr})<3:collapsed.append(i)
remove=np.array(sorted(set(delete+collapsed)),dtype=int);keep=np.ones(len(t),bool);keep[remove]=False
original_bin=bytes(g.bin);attribute_ids=dict(pr['attributes']);pr['indices']=g.append(t[keep].reshape(-1),'SCALAR',5125,34963)
dest=D/'inputs/mustard_source_sanitized01.glb';sha=g.save(dest)
assert bytes(g.bin[:len(original_bin)])==original_bin and pr['attributes']==attribute_ids
verify=GLB(dest);assert np.array_equal(verify.read(pr['indices']).reshape(-1,3),t[keep])
for k,ai in attribute_ids.items():assert np.array_equal(verify.read(ai,False),attrs[k])
report={'source':str(src),'source_sha256':GLB(src).sha256,'output':str(dest),'sha256':sha,'input_triangles':len(t),'output_triangles':int(keep.sum()),'removed_exact_oriented_attribute_copies':proof,'removed_position_collapsed':collapsed,'removed_total':len(remove),'retained_source_face_ids':np.flatnonzero(keep).tolist(),'source_bin_prefix_byte_identical':True,'all_original_attributes_images_materials_held':True,'scope':'No shape, normal, UV or material alteration. Opposite-winding or different-attribute coincident triangles are not removed.'}
(D/'audit/source_sanitized01.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('retained_source_face_ids','removed_exact_oriented_attribute_copies')},indent=2),flush=True)
