"""Affine-only native hand island repack, with unique-paint multiplicity and per-face sampling gates."""
from pathlib import Path
import numpy as np,json,hashlib
D=Path(__file__).resolve().parents[1];path=D/'inputs/pointing09_paint_binding10.npz'
z=np.load(path);a={k:z[k] for k in z.files};uv=a['UV'].astype('f8');labels=a['ISLAND'];new=np.empty_like(uv)
assert set(labels)=={0,1}
minimum=uv[labels==0].min(axis=0);size=uv[labels==0].max(axis=0)-minimum;s=.94/size[0]
new[labels==0]=(uv[labels==0]-minimum)*s+[.012,.012]
wmin=uv[labels==1].min(axis=0);wmax=uv[labels==1].max(axis=0);origin=np.array([.012,.012+size[1]*s+.014])
new[labels==1,0]=(uv[labels==1,1]-wmin[1])*s+origin[0]
new[labels==1,1]=(wmax[0]-uv[labels==1,0])*s+origin[1]
assert new.min()>.005 and new.max()<.992
transforms=[{'id':0,'matrix':[[s,0],[0,s]],'translation':(np.array([.012,.012])-minimum*s).tolist()}, {'id':1,'matrix':[[0,s],[-s,0]],'translation':(origin+[-s*wmin[1],s*wmax[0]]).tolist()}]
for tr in transforms:
    sel=labels==tr['id'];err=np.max(np.abs(uv[sel]@np.array(tr['matrix']).T+tr['translation']-new[sel]));assert err<1e-12;tr['max_affine_error']=float(err)
a['UV_PACKED']=new.astype('f4');np.savez_compressed(D/'inputs/pointing09_paint_binding11.npz',**a)
T=a['T'];tr=new[T];area=(tr[:,1,0]-tr[:,0,0])*(tr[:,2,1]-tr[:,0,1])-(tr[:,1,1]-tr[:,0,1])*(tr[:,2,0]-tr[:,0,0])
assert np.all(np.abs(area)>1e-14)
resolution=2048;face_samples=np.zeros(len(T),np.int64);total_occupied=total_samples=total_overlap=0;max_count=0
for row0 in range(0,resolution,1024):
    row1=min(row0+1024,resolution);counts=np.zeros((row1-row0,resolution),np.uint16)
    for i,q in enumerate(tr):
        lo=np.maximum(np.ceil(q.min(axis=0)*resolution-.5).astype(int),[0,row0]);hi=np.minimum(np.floor(q.max(axis=0)*resolution-.5).astype(int),[resolution-1,row1-1])
        if np.any(hi<lo):continue
        xx,yy=np.meshgrid((np.arange(lo[0],hi[0]+1)+.5)/resolution,(np.arange(lo[1],hi[1]+1)+.5)/resolution)
        u=((q[1,0]-xx)*(q[2,1]-yy)-(q[1,1]-yy)*(q[2,0]-xx))/area[i]
        v=((q[2,0]-xx)*(q[0,1]-yy)-(q[2,1]-yy)*(q[0,0]-xx))/area[i];w=1-u-v
        inside=(u>1e-8)&(v>1e-8)&(w>1e-8)
        face_samples[i]+=inside.sum();counts[lo[1]-row0:hi[1]-row0+1,lo[0]:hi[0]+1]+=inside
    occupied=int(np.count_nonzero(counts));samples=int(counts.astype('u8').sum());overlap=int(np.count_nonzero(counts>1))
    total_occupied+=occupied;total_samples+=samples;total_overlap+=overlap;max_count=max(max_count,int(counts.max()))
    print({'row0':row0,'row1':row1,'occupied':occupied,'samples':samples,'multiply_covered':overlap},flush=True)
    np.savez_compressed(D/f'audit/pointing09_uv11_counts_{row0}.npz',counts=counts)
report={'source_binding_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_GL B':'pointing_hand09.glb','scale':s,'island_transforms':transforms,'packed_bounds':[new.min(axis=0).tolist(),new.max(axis=0).tolist()],'resolution':resolution,'occupied_texels':total_occupied,'raster_samples':total_samples,'multiply_covered_texels':total_overlap,'max_multiplicity':max_count,'faces_without_strict_interior_texel_center':np.flatnonzero(face_samples==0).tolist(),'per_face_samples_quantiles':np.quantile(face_samples,[0,.01,.5,.99,1]).tolist(),'geometry_normals_pose_held':True,'scope':'Unique skin atlas: strict triangle interiors, intentional edge touching excluded. No albedo or normal paint yet.'}
np.save(D/'audit/pointing09_uv11_face_samples.npy',face_samples);(D/'audit/pointing09_uv11.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
assert total_overlap==0
