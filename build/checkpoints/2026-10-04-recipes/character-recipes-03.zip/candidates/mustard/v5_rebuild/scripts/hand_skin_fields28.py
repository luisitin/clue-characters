"""Anatomy-bound skin/nail material fields in the pinned official donor's rest coordinates."""
from pathlib import Path
import json,numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter
D=Path(__file__).resolve().parents[1];ROOT=D.parents[2]
def smooth(a,b,x):
    u=np.clip((x-a)/(b-a),0,1);return u*u*(3-2*u)
class SkinFields:
    def __init__(self,pose_report):
        self.pose=pose_report;self.scale=pose_report['scale'];self.F=np.array(pose_report['native_forward']);self.S=np.array(pose_report['native_thumbward']);self.D=np.array(pose_report['native_anatomical_dorsal']);side=pose_report['donor_side']
        V=[]
        for line in (ROOT/'shared_sources/makehuman/raw/base.obj').open():
            if line.startswith('v '):V.append(list(map(float,line.split()[1:4])))
        V=np.array(V);rig=json.loads((ROOT/'shared_sources/makehuman/raw/default.mhskel').read_text());J={name:V[ids].mean(0) for name,ids in rig['joints'].items()};self.wrist=J[f'wrist.{side}____head']
        image=np.asarray(Image.open(D/'textures/Mustard_Skin_Albedo_Source_v1.png').convert('RGB'),dtype='f4')/255;self.rgb=image;self.mean=image.mean(axis=(0,1));lum=image@np.array([.2126,.7152,.0722]);self.height=gaussian_filter(lum,1)-gaussian_filter(lum,7)
        self.joints=[];self.nails=[]
        for digit in range(1,6):
            for seg in range(1,4):
                A=J[f'finger{digit}-{seg}.{side}____head'];B=J[f'finger{digit}-{seg}.{side}____tail'];axis=B-A;length=np.linalg.norm(axis);axis/=length
                self.joints.append((A,axis,length,digit,seg))
                if seg==3:
                    out=self.D-axis*(self.D@axis);out/=np.linalg.norm(out);across=np.cross(axis,out);across/=np.linalg.norm(across)
                    self.nails.append((A+axis*length*.56,axis,out,across,length*.35,.068 if digit==1 else (.042 if digit==5 else .049),digit,length))
    def image_sample(self,img,uv):
        # Mirrored tiling guarantees matching values across repeat borders.
        uv=np.mod(uv,2);uv=np.where(uv>1,2-uv,uv);h,w=img.shape[:2];xy=uv*np.array([w-1,h-1]);lo=np.floor(xy).astype(int);hi=np.minimum(lo+1,[w-1,h-1]);f=xy-lo
        if img.ndim==3:f=f[:,:,None]
        return (img[lo[:,1],lo[:,0]]*(1-f[:,0])+img[lo[:,1],hi[:,0]]*f[:,0])*(1-f[:,1])+(img[hi[:,1],lo[:,0]]*(1-f[:,0])+img[hi[:,1],hi[:,0]]*f[:,0])*f[:,1]
    def material(self,R,RN,color=True):
        weight=np.abs(RN)**4;weight/=np.maximum(weight.sum(axis=1,keepdims=True),1e-20);coord=R*self.scale/.065
        grain=np.zeros(len(R));rgb=np.zeros((len(R),3)) if color else None
        for k,axes in enumerate(((1,2),(0,2),(0,1))):
            grain+=weight[:,k]*self.image_sample(self.height,coord[:,axes])
            if color:rgb+=weight[:,k,None]*self.image_sample(self.rgb,coord[:,axes])
        dorsal=RN@self.D;palm=smooth(-.10,-.70,dorsal);back=smooth(.10,.70,dorsal)
        q=R-self.wrist;f=q@self.F;s=q@self.S
        crease=np.zeros(len(R));pigment=np.zeros(len(R))
        for center,axis,length,digit,seg in self.joints:
            dq=R-center;along=dq@axis;radius=np.linalg.norm(dq-along[:,None]*axis,axis=1)
            gate=1-smooth(.15,.26,radius);band=np.exp(-(along/.009)**2)+.45*np.exp(-((along-.025)/.008)**2)
            crease+=gate*band*(.55*palm+.65*back)
            pigment+=gate*np.exp(-(along/.065)**2)
        palm_gate=(1-smooth(.40,.52,np.abs(s)))*smooth(.08,.19,f)*(1-smooth(.88,1.0,f))*palm
        crease+=palm_gate*(1.15*np.exp(-((f-(.48+.10*s+.18*s*s))/.010)**2)+.75*np.exp(-((f-(.73-.14*s))/.008)**2))
        thenar=np.sqrt(((f-.36)/.46)**2+((s-.25)/.34)**2)
        crease+=palm_gate*.8*np.exp(-((thenar-1)/.025)**2)*smooth(-.15,.1,s)
        nail=np.zeros(len(R));cuticle=np.zeros(len(R));free_edge=np.zeros(len(R));ridge=np.zeros(len(R))
        for center,axis,out,across,halfL,halfW,digit,length in self.nails:
            dq=R-center;long=dq@axis;wide=dq@across;dep=dq@out;rho=np.sqrt((long/halfL)**2+(wide/halfW)**2)
            gate=smooth(.15,.55,RN@out)*smooth(-.012,.006,dep)*(1-smooth(.20,.30,dep))
            mask=(1-smooth(.84,1.0,rho))*gate;nail=np.maximum(nail,mask);free_edge=np.maximum(free_edge,mask*smooth(.82,.97,long/halfL));ridge+=mask*np.sin(wide/.003*2*np.pi)*.0000012
            cuticle=np.maximum(cuticle,np.exp(-((rho-1.04)/.045)**2)*gate)
        height=grain*.00014-np.minimum(crease,2.5)*.00010+nail*.000020-cuticle*.000010+ridge
        rough=np.clip(.54+grain*.7+crease*.012-nail*.11,.28,.64)
        if color:
            base=rgb/np.maximum(self.mean,1e-6)*np.array([208,163,134])/255
            base+=palm[:,None]*np.array([.018,.005,.002]);base-=np.minimum(crease,2)[:,None]*np.array([.025,.029,.026])
            base+=np.minimum(pigment,2)[:,None]*np.array([.012,-.004,-.005]);base-=cuticle[:,None]*np.array([.012,.017,.017])
            nail_color=np.array([213,174,149])/255;free_color=np.array([230,204,181])/255;base=base*(1-nail[:,None])+nail[:,None]*nail_color;base=base*(1-free_edge[:,None])+free_edge[:,None]*free_color
            base=np.clip(base,0,1)
        else:base=None
        return base,height,rough,nail
