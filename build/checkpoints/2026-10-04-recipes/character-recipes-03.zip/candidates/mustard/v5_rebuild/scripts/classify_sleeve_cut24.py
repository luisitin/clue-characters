"""Classify the exact distal surface component separated by measured healthy sleeve cycle19."""
from pathlib import Path
import numpy as np,json,collections
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/mustard_source_sanitized01.glb');P,T,N,UV=g.native();j=json.loads((D/'audit/oblique_sleeve_sections19.json').read_text());s=next(x for x in j['sections'] if x['offset']==-.02);C=np.array(s['plane_center']);axis=np.array(s['plane_normal']);sd=(P-C)@axis
_,group=np.unique(P,axis=0,return_inverse=True);G=group[T];active=np.any(sd[T]>1e-12,axis=1);edges={}
for fi in np.flatnonzero(active):
    for k in range(3):
        a,b=T[fi,k],T[fi,(k+1)%3]
        if max(sd[a],sd[b])>1e-12:edges.setdefault(tuple(sorted((int(group[a]),int(group[b])))),[]).append(int(fi))
neighbors=collections.defaultdict(list)
for faces in edges.values():
    if len(faces)>1:
        first=faces[0]
        for other in faces[1:]:neighbors[first].append(other);neighbors[other].append(first)
seedpoint=np.array([.46868644368648527,-.18966029791559258,.3162770487031106]);centers=P[T].mean(1);dist=np.linalg.norm(centers-seedpoint,axis=1);dist[~active]=np.inf;seed=int(np.argmin(dist));todo=[seed];selected=set()
while todo:
    fi=todo.pop()
    if fi in selected:continue
    selected.add(fi);todo.extend(neighbors[fi])
selected=np.array(sorted(selected),'i4');crossing=selected[np.any(sd[T[selected]]<-1e-12,axis=1)];fullpositive=selected[np.all(sd[T[selected]]>=-1e-12,axis=1)];expected=set(s['components'][0]['source_faces']);actual=set(crossing.tolist())
report={'source_sha256':g.sha256,'seed_face':seed,'seed_point':seedpoint.tolist(),'seed_centroid_distance':float(dist[seed]),'plane_center':C.tolist(),'plane_normal':axis.tolist(),'distal_component_faces':len(selected),'fully_distal_faces':len(fullpositive),'crossing_faces':len(crossing),'crossing_set_matches_marked_healthy_cycle':actual==expected,'extra_crossing_faces':sorted(actual-expected),'missing_marked_crossing_faces':sorted(expected-actual),'distal_bounds':[P[T[selected]].min(axis=(0,1)).tolist(),P[T[selected]].max(axis=(0,1)).tolist()],'scope':'Read-only source ownership by connected positive-half surface and exact measured cycle; no RGB decision and no geometry removed.'}
np.savez_compressed(D/'inputs/pointing_cut_classification24.npz',selected=selected,crossing=crossing,full_positive=fullpositive,C=C,N=axis)
(D/'audit/pointing_cut_classification24.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
assert actual==expected and len(selected)<15000,'Selection must be diagnosed before surgery'
