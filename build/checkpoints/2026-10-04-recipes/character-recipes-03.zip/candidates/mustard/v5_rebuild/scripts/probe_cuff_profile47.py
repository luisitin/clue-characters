"""Measure an ordered garment rim and actual held-hand radial sections before loft construction."""
import sys,json
from pathlib import Path
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
D=Path(__file__).resolve().parents[1];sys.path.insert(0,str(D/'scripts'));from glb_io import GLB
body=GLB(D/'inputs/body_pointing_cut33.glb');P,T,N,UV=body.native();z=np.load(D/'inputs/pointing_cut_boundary33.npz');cut=set(z['CUT_VERTICES'].tolist());C=z['C'];axis=z['N'];_,groups=np.unique(P,axis=0,return_inverse=True)
representative={int(groups[i]):int(i) for i in cut};adj={i:set() for i in representative}
for tr in T:
    for a,b in zip(tr,np.roll(tr,-1)):
        if int(a) in cut and int(b) in cut:
            ga,gb=int(groups[a]),int(groups[b]);adj[ga].add(gb);adj[gb].add(ga)
assert len(adj)==162 and all(len(v)==2 for v in adj.values())
order=[];cur=min(adj);prev=None
while not order or cur!=order[0]:
    order.append(cur);nxt=next(i for i in adj[cur] if i!=prev);prev,cur=cur,nxt
assert len(order)==len(adj);source_ids=np.array([representative[i] for i in order]);rim=P[source_ids]
U=np.cross([0,0,1],axis);U/=np.linalg.norm(U);V=np.cross(axis,U);q=(rim-C)@np.column_stack((U,V));cross=q[:,0]*np.roll(q[:,1],-1)-np.roll(q[:,0],-1)*q[:,1];area=cross.sum()/2;centroid=np.sum((q+np.roll(q,-1,axis=0))*cross[:,None],axis=0)/(6*area);center=C+U*centroid[0]+V*centroid[1]
seg=np.linalg.norm(np.roll(rim,-1,axis=0)-rim,axis=1);arc=np.r_[0,np.cumsum(seg[:-1])]/seg.sum();phase=np.arctan2((rim[0]-center)@V,(rim[0]-center)@U);theta=phase+np.sign(area)*2*np.pi*arc
pose=json.loads((D/'audit/pointing_hand09.json').read_text());F=np.array(pose['world_forward']);H=np.array(pose['world_anchor']);rotaxis=np.cross(axis,F);s=np.linalg.norm(rotaxis);c=axis@F
if s<1e-12:R=np.eye(3)
else:
    k=rotaxis/s;K=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]]);R=np.eye(3)+s*K+(1-c)*(K@K)
UF=R@U;VF=R@V;assert abs(UF@F)<1e-10 and abs(VF@F)<1e-10
skin=GLB(D/'inputs/pointing_fitted46.glb');HP,HT,HN,HUV=skin.native();bvh=BVHTree.FromPolygons(HP.tolist(),HT.tolist(),all_triangles=True,epsilon=0.0);profiles={};summary=[]
for longitudinal in (-.006,0,.006,.012,.016):
    origin=H+F*longitudinal;rr=[];dots=[];faces=[]
    for angle in theta:
        direction=UF*np.cos(angle)+VF*np.sin(angle);hit,n,fi,d=bvh.ray_cast(Vector(origin),Vector(direction),.15)
        rr.append(np.nan if hit is None else float(d));dots.append(np.nan if n is None else float(np.dot(n,direction)));faces.append(-1 if fi is None else int(fi))
    profiles[str(longitudinal)]=np.array(rr);summary.append({'s':longitudinal,'hits':sum(i>=0 for i in faces),'min_radius':float(np.nanmin(rr)),'max_radius':float(np.nanmax(rr)),'min_outward_normal_dot':float(np.nanmin(dots)),'faces':faces})
np.savez_compressed(D/'inputs/cuff_profile47.npz',RIM=rim,SOURCE_IDS=source_ids,THETA=theta,ARC=arc,CENTER=center,N0=axis,U0=U,V0=V,F=F,H=H,UF=UF,VF=VF,**{'R_'+k.replace('-','m').replace('.','p'):v for k,v in profiles.items()})
report={'body_sha256':body.sha256,'hand_sha256':skin.sha256,'ordered_boundary_nodes':len(rim),'boundary_area':float(area),'area_centroid':center.tolist(),'boundary_segment_range':[float(seg.min()),float(seg.max())],'hand_axis_dot_sleeve_axis':float(F@axis),'profiles':summary,'scope':'Measured positions/rays only. No cuff constructed and no contact clearance inferred.'}
(D/'audit/cuff_profile47.json').write_text(json.dumps(report,indent=2));print(json.dumps({**report,'profiles':[{k:v for k,v in r.items() if k!='faces'} for r in summary]},indent=2),flush=True)
