from pathlib import Path
import numpy as np,json
from glb_io import GLB
from audit_intersections_v4 import audit
D=Path(__file__).resolve().parents[1]
def read(path):
    g=GLB(path);p,_,n,uv=g.native();mesh=g.j['meshes'][g.j['nodes'][0]['mesh']];t=np.concatenate([g.read(pr['indices']).reshape(-1,3) for pr in mesh['primitives']]);return g,p,t
cg,CP,CT=read(D/'inputs/pointing_cuff80.glb');bg,BP,BT=read(D/'inputs/body_pointing_cut33.glb');hg,HP,HT=read(D/'inputs/pointing_fitted46.glb');lo=CP.min(0)-.001;hi=CP.max(0)+.001
positions=[];triangles=[];labels=[];lineage=[];offset=0
for name,P,T in [('body',BP,BT),('hand',HP,HT),('cuff',CP,CT)]:
    tp=P[T];chosen=np.flatnonzero(np.all(tp.max(1)>=lo,axis=1)&np.all(tp.min(1)<=hi,axis=1)) if name!='cuff' else np.arange(len(T));used=np.unique(T[chosen]);local=np.searchsorted(used,T[chosen]);positions.append(P[used]);triangles.append(local+offset);offset+=len(used);labels.extend([name]*len(chosen));lineage.extend(chosen.tolist())
P=np.concatenate(positions);T=np.concatenate(triangles);labels=np.array(labels);lineage=np.array(lineage);r=audit(P,T);categorized=[]
for pair in r['proper_crossings']:
    ids=np.array(pair['faces']);categorized.append({**pair,'parts':labels[ids].tolist(),'source_faces':lineage[ids].tolist()})
cuffpairs=[p for p in categorized if 'cuff' in p['parts']];cuffcoplanar=[]
for pair in r['positive_area_coplanar_pairs']:
    ids=np.array(pair['faces'])
    if 'cuff' in labels[ids]:cuffcoplanar.append({**pair,'parts':labels[ids].tolist(),'source_faces':lineage[ids].tolist()})
out={'body_sha256':bg.sha256,'hand_sha256':hg.sha256,'cuff_sha256':cg.sha256,'bounds':[lo.tolist(),hi.tolist()],'selected_counts':{x:int(np.count_nonzero(labels==x)) for x in ['body','hand','cuff']},'proper_pairs_involving_cuff':cuffpairs,'coplanar_pairs_involving_cuff':cuffcoplanar,'all_categorized_proper_pairs':categorized,'raw_audit':r,'scope':'Full cuff self/body/hand candidate, with every external triangle whose complete AABB intersects the cuff union plus1mm. Inherited body-only findings are separate.'}
(D/'audit/pointing_cuff81_crossings.json').write_text(json.dumps(out,indent=2));print({'cuff_sha256':cg.sha256,'proper_pairs_involving_cuff':len(cuffpairs),'coplanar_pairs_involving_cuff':len(cuffcoplanar),'selected_counts':out['selected_counts'],'seconds':r['seconds']},flush=True)
