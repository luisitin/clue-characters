from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/pointing_fitted46.glb');P,T,N,UV=g.native();a=json.loads((D/'audit/pointing_hand09.json').read_text());F=np.array(a['world_forward']);H=np.array(a['world_anchor']);long=(P[np.unique(T)]-H)@F;lo=float(long.min());r=json.loads((D/'audit/pointing_cuff97_contact.json').read_text());samples=r['parts'][1]['negative_near_skin_samples'];out=[]
for p in samples:
 ss=float((np.array(p['point'])-H)@F);out.append({**p,'wrist_axis_coordinate':ss,'minimum_hand_coordinate':lo,'separating_plane_margin_m':lo-ss,'outside_entire_hand_by_separating_plane':bool(ss<lo-1e-7)})
result={'hand_sha256':g.sha256,'cuff_sha256':r['cuff_sha256'],'referenced_hand_wrist_axis_range':[lo,float(long.max())],'samples':out,'all_reported_negative_samples_outside_by_global_separating_plane':all(p['outside_entire_hand_by_separating_plane'] for p in out),'scope':'A negative nearest-face-normal projection on an open wrist is not a signed volume distance. A separating plane, when proven, is stronger evidence that the point is outside the entire hand.'};(D/'audit/cuff102_signed_sample_classification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
