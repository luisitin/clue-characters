"""Contract one explicit12µm connected boundary edge only after the manifold link condition passes."""
from pathlib import Path
import numpy as np,json
from glb_io import GLB
D=Path(__file__).resolve().parents[1];g=GLB(D/'inputs/body_pointing_cut25.glb');P,T,N,UV=g.native();pr=g.primitive();rawP=g.read(pr['attributes']['POSITION'],False).copy();z=np.load(D/'inputs/cuff_profile27.npz');rim=z['RIM'];ids=z['SOURCE_IDS'];assert np.linalg.norm(rim[25]-rim[24])<1.3e-5
unique,group=np.unique(P,axis=0,return_inverse=True);G=group[T];a,b=int(group[ids[24]]),int(group[ids[25]]);incidentA=np.flatnonzero(np.any(G==a,axis=1));incidentB=np.flatnonzero(np.any(G==b,axis=1));edge=np.intersect1d(incidentA,incidentB);neighborsA=set(G[incidentA].ravel())-{a};neighborsB=set(G[incidentB].ravel())-{b};common=neighborsA&neighborsB;opposite=set(G[edge].ravel())-{a,b}
proof={'edge_incident_faces':edge.tolist(),'neighbors_common':[int(x) for x in sorted(common)],'opposite_link_vertices':[int(x) for x in sorted(opposite)],'boundary_edge':len(edge)==1,'link_condition':common==opposite}
assert len(edge)==1 and common==opposite,proof
changedVertices=np.flatnonzero((group==a)|(group==b));mid=((rawP[ids[24]].astype('f8')+rawP[ids[25]].astype('f8'))/2).astype('f4');newP=rawP.copy();newP[changedVertices]=mid
node=g.j['nodes'][0];scale=np.array(node.get('scale',[1,1,1]));trans=np.array(node.get('translation',[0,0,0]));WP=(newP.astype('f8')*scale+trans)[:,[0,2,1]]*[1,-1,1]
affected=np.union1d(incidentA,incidentB);keep=np.ones(len(T),bool);keep[edge]=False;remain=np.setdiff1d(affected,edge)
oldGN=np.cross(P[T[remain,1]]-P[T[remain,0]],P[T[remain,2]]-P[T[remain,0]]);newGN=np.cross(WP[T[remain,1]]-WP[T[remain,0]],WP[T[remain,2]]-WP[T[remain,0]]);oldL=np.linalg.norm(oldGN,axis=1);newL=np.linalg.norm(newGN,axis=1);cos=np.sum(oldGN*newGN,axis=1)/(oldL*newL);assert cos.min()>.999 and (newL/oldL).min()>.90 and (newL/oldL).max()<1.10
oldDot=np.einsum('ij,ikj->ik',oldGN/oldL[:,None],N[T[remain]]);newDot=np.einsum('ij,ikj->ik',newGN/newL[:,None],N[T[remain]]);assert np.count_nonzero(newDot<0)<=np.count_nonzero(oldDot<0)
maxmove=float(np.linalg.norm(WP-P,axis=1).max());assert maxmove<7e-6
for gid in (a,b):assert np.unique(newP[group==gid],axis=0).shape[0]==1
pr['attributes']['POSITION']=g.append(newP,'VEC3',5126,34962);pr['indices']=g.append(T[keep].ravel(),'SCALAR',5125,34963);out=D/'inputs/body_pointing_cut33.glb';sha=g.save(out)
old=np.load(D/'inputs/pointing_cut_boundary25.npz');data={k:old[k] for k in old.files};data['P']=WP;data['T']=T[keep];data['PARENT']=data['PARENT'][keep];data['CHANGED']=np.flatnonzero(np.isin(np.arange(len(T)),data['CHANGED'])[keep]);np.savez_compressed(D/'inputs/pointing_cut_boundary33.npz',**data)
report={'source_sha256':GLB(D/'inputs/body_pointing_cut25.glb').sha256,'output_sha256':sha,'proof':proof,'contracted_edge_world_length':float(np.linalg.norm(rim[25]-rim[24])),'moved_attribute_vertices':changedVertices.tolist(),'max_displacement_m':maxmove,'affected_remaining_faces':remain.tolist(),'removed_collapsed_boundary_face':edge.tolist(),'minimum_remaining_relative_orientation_cosine':float(cos.min()),'area_ratio_range':[float((newL/oldL).min()),float((newL/oldL).max())],'new_opposed_corner_normal_count':int(np.count_nonzero(newDot<0)-np.count_nonzero(oldDot<0)),'all_original_NORMAL_UV_and_materials_held':True,'all_preexisting_position_groups_move_together':True,'scope':'Contracts an explicitly connected boundary edge satisfying the link condition, not a proximity weld of separate layers. Maximum6µm motion; one micro sidewall triangle removed. Local proper-crossing comparison and new loft still pending.'}
(D/'audit/boundary_connector33.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
