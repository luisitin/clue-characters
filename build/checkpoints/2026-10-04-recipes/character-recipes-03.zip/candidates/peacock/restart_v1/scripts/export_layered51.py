"""Export a complete NPZ component with verified float32 round-trip and exact map bytes."""
from pathlib import Path
import numpy as np,json,struct,hashlib,sys
R=Path(__file__).resolve().parents[1];name=sys.argv[1];atlas=sys.argv[2] if len(sys.argv)>2 else 'face_atlas8';a=np.load(R/f'inputs/{name}.npz');P=a['pos'];N=a['normal'];U=a['uv'];T=a['tri'];part=a['material'] if 'material' in a.files else np.zeros(len(T),int);a.close();g={'asset':{'version':'2.0','generator':'Peacock bounded refinement, raw accessor pipeline','extras':{'status':'unapproved work in progress','original_source_sha256':'22faf1e82334f5b5d19775a080448c8b2cc8edbdc6f4858fdae5e7c47961f39c'}},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0,'name':'Peacock'}],'meshes':[{'primitives':[]}],'buffers':[{}],'bufferViews':[],'accessors':[],'materials':[],'images':[],'textures':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':33071,'wrapT':33071}],'extensionsUsed':['EXT_texture_webp'],'extensionsRequired':['EXT_texture_webp']};blob=bytearray()
def view(data,target=None):
 blob.extend(b'\0'*((-len(blob))%4));v={'buffer':0,'byteOffset':len(blob),'byteLength':len(data)}
 if target:v['target']=target
 blob.extend(data);i=len(g['bufferViews']);g['bufferViews'].append(v);return i

def accessor(arr,typ,component=5126):
 arr=np.ascontiguousarray(arr,dtype='<f4' if component==5126 else '<u4');v=view(arr.tobytes(),34963 if typ=='SCALAR' else 34962);d={'bufferView':v,'componentType':component,'count':len(arr),'type':typ}
 if typ=='VEC3':d.update(min=arr.min(0).tolist(),max=arr.max(0).tolist())
 i=len(g['accessors']);g['accessors'].append(d);return i
Pg=P[:,[0,2,1]].copy();Pg[:,2]*=-1;Ng=N[:,[0,2,1]].copy();Ng[:,2]*=-1;pa=accessor(Pg,'VEC3');na=accessor(Ng,'VEC3');ua=accessor(U,'VEC2');materials=json.loads((R/f'inputs/{name}_materials.json').read_text());assert len(materials)==int(part.max())+1;maps=[Path(m[key]) for m in materials for key in ['base_path','orm_path']];maphash=[]
for i,p in enumerate(maps):
 data=p.read_bytes();mime='image/webp' if p.suffix=='.webp' else 'image/png';g['images'].append({'name':p.stem,'mimeType':mime,'bufferView':view(data)});g['textures'].append({'sampler':0,'extensions':{'EXT_texture_webp':{'source':i}}} if mime=='image/webp' else {'sampler':0,'source':i});maphash.append({'path':str(p),'sha256':hashlib.sha256(data).hexdigest()})
for material in range(int(part.max())+1):
 c,r=material*2,material*2+1;g['materials'].append({'name':materials[material]['name'],'doubleSided':True,'pbrMetallicRoughness':{'baseColorTexture':{'index':c},'metallicRoughnessTexture':{'index':r}},'occlusionTexture':{'index':r,'strength':materials[material].get('occlusion_strength',.35)}});g['meshes'][0]['primitives'].append({'attributes':{'POSITION':pa,'NORMAL':na,'TEXCOORD_0':ua},'indices':accessor(T[part==material].reshape(-1),'SCALAR',5125),'material':material,'mode':4})
g['buffers'][0]['byteLength']=len(blob);js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4);blob+=b'\0'*((-len(blob))%4);data=struct.pack('<III',0x46546c67,2,28+len(js)+len(blob))+struct.pack('<II',len(js),0x4e4f534a)+js+struct.pack('<II',len(blob),0x004e4942)+blob;out=R/f'checks/peacock_{name}.glb';out.write_bytes(data)
# Decode the emitted geometry, not an in-memory surrogate, and check all primitive corners.
g2=json.loads(data[20:20+len(js)]);off=28+len(js)
def read(ai):
 a=g2['accessors'][ai];v=g2['bufferViews'][a['bufferView']];nc={'VEC2':2,'VEC3':3,'SCALAR':1}[a['type']];return np.frombuffer(data,dtype='<f4' if a['componentType']==5126 else '<u4',count=a['count']*nc,offset=off+v['byteOffset']).reshape(-1,nc)
Pe=read(pa)[:,[0,2,1]].astype(float);Pe[:,1]*=-1;maxerr=float(np.max(np.abs(P-Pe)));assert maxerr<6e-8
for k,pr in enumerate(g2['meshes'][0]['primitives']):assert np.array_equal(read(pr['indices']).ravel().reshape(-1,3),T[part==k])
report={'candidate':str(out),'candidate_sha256':hashlib.sha256(data).hexdigest(),'component_sha256':hashlib.sha256((R/f'inputs/{name}.npz').read_bytes()).hexdigest(),'triangles':len(T),'primitive_triangle_counts':[int((part==i).sum()) for i in range(int(part.max())+1)],'export_float32_position_max_error_m':maxerr,'all_exported_triangle_indices_verified':True,'embedded_image_bytes':maphash,'status':'complete component export; appearance and full-character gates remain open'};(R/f'checks/{name}_export.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
