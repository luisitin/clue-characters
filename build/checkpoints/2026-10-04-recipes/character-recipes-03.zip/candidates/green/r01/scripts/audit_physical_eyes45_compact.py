import pathlib,sys,json,hashlib,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
from intersection_kernel_v4_selected import audit
src=R/'Green_physical_eyes45_body.glb';j,b,A=read_glb(src);node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);positions=[];normals=[];faces=[];owner=[];offset=0
for pi,pr in enumerate(j['meshes'][0]['primitives']):
 p=A(pr['attributes']['POSITION']).astype('float32').astype(float);f=A(pr['indices']).reshape(-1,3);positions.append((p*scale+translation)[:,[0,2,1]]*[1,-1,1]);nn=A(pr['attributes']['NORMAL']);normals.append((nn/scale)[:,[0,2,1]]*[1,-1,1]);faces.append(f+offset);owner.extend([pi]*len(f));offset+=len(p)
P=np.vstack(positions);N=np.vstack(normals);N/=np.linalg.norm(N,axis=1)[:,None];F=np.vstack(faces);owner=np.array(owner);first=5;isnew=owner>=first;q=P[F[isnew]].reshape(-1,3);bounds=np.r_[q.min(0)-.001,q.max(0)+.001].tolist();
tri_all=P[F];lo=tri_all.min(1);hi=tri_all.max(1);ulo=lo[isnew].min(0);uhi=hi[isnew].max(0);potential=np.all(hi>=ulo-1e-8,axis=1)&np.all(lo<=uhi+1e-8,axis=1);ids=np.flatnonzero(potential);assert potential[isnew].all();assert np.all(np.any((hi[~potential]<ulo-1e-8)|(lo[~potential]>uhi+1e-8),axis=1));used,inv=np.unique(F[ids],return_inverse=True);localF=inv.reshape(-1,3);localP=P[used];selected=np.flatnonzero(isnew[ids]);print(dict(stage='COMPACT_READY',whole_faces=len(F),retained_potential=int((~isnew[ids]).sum()),new_faces=len(selected),compact_faces=len(ids)),flush=True);res=audit(localP,localF,selected_faces=selected,progress_interval=1000)
for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for row in res[key]:row['faces']=[int(ids[x])for x in row['faces']]
for key in ['position_triangle_copy_groups','manifold_edge_folds_over_105_degrees']:
 res[key]=[[int(ids[x])for x in row]for row in res[key]]
res['zero_area_faces']=[int(ids[x])for x in res['zero_area_faces']];res.update(whole_faces=len(F),new_selected_faces=len(selected),retained_potential_faces=int((~isnew[ids]).sum()),spatial_compaction_conservative=True,all_original_coordinates_held=True,global_face_ids_restored=True)

for key in ['proper_crossings','positive_area_coplanar_pairs']:
 for item in res[key]:item['primitives']=owner[item['faces']].tolist();item['involves_new_eye']=bool(isnew[item['faces']].any())
unique,groups=np.unique(P,axis=0,return_inverse=True);G=groups[F];tri=P[F];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);length=np.linalg.norm(GN,axis=1);GN/=np.maximum(length[:,None],1e-30);edges={}
for fi,tr in enumerate(G):
 for x,y in zip(tr,np.roll(tr,-1)):edges.setdefault(tuple(sorted((int(x),int(y)))),[]).append((int(x),int(y),fi))
joins=[]
for eye in range(2):
 skin=5+eye*3;wall=skin+1;globalfaces=np.flatnonzero(owner==skin);skinEdges={}
 for fi in globalfaces:
  for x,y in zip(G[fi],np.roll(G[fi],-1)):skinEdges.setdefault(tuple(sorted((int(x),int(y)))),[]).append(fi)
 boundary=[key for key,fs in skinEdges.items()if len(fs)==1];row={'eye':eye,'outer':[],'inner_wall':[],'unmatched':[],'winding_conflicts':[]}
 for key in boundary:
  fs=edges[key];mine=next(x for x in fs if owner[x[2]]==skin);others=[x for x in fs if owner[x[2]]!=skin]
  if len(others)!=1:row['unmatched'].append({'edge':key,'faces':[x[2]for x in fs]});continue
  other=others[0];angle=float(np.degrees(np.arccos(np.clip(GN[mine[2]]@GN[other[2]],-1,1))));typ='inner_wall'if owner[other[2]]==wall else'outer';row[typ].append(angle)
  if mine[:2]!=tuple(reversed(other[:2])):row['winding_conflicts'].append(key)
 for typ in ['outer','inner_wall']:
  values=row[typ];row[typ]={'edges':len(values),'max_geometric_dihedral_degrees':max(values,default=0),'median_geometric_dihedral_degrees':float(np.median(values))if values else None}
 joins.append(row)
res.update(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),new_eye_proper=sum(x['involves_new_eye']for x in res['proper_crossings']),new_eye_coplanar=sum(x['involves_new_eye']for x in res['positive_area_coplanar_pairs']),new_eye_folds=[{'faces':x,'primitives':owner[x].tolist()}for x in res['manifold_edge_folds_over_105_degrees']if isnew[x].any()],new_eye_copies=[x for x in res['position_triangle_copy_groups']if isnew[x].any()],new_eye_zero_area=[x for x in res['zero_area_faces']if isnew[x]],joins=joins,scope='Exact exported float32 positions; full changed eye region plus every retained backing candidate. Old source-only failures remain identified separately.');(R/'audit/eyes45_surface_v4_compact.json').write_text(json.dumps(res,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in res.items()if k!='joins'},flush=True);print(joins,flush=True)
