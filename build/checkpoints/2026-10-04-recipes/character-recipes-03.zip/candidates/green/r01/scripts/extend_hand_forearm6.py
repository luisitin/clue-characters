"""Extend the held proximal hand cut into a bounded curved forearm; distal hand is held."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
src=R/'Green_openhand_thumb3_microcharts5.glb';j,buf,A=read_glb(src);node=next(n for n in j['nodes']if'mesh'in n);pr=j['meshes'][node['mesh']]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']).astype('float32');UV=A(pr['attributes']['TEXCOORD_0']);T=A(pr['attributes']['TANGENT']);F=A(pr['indices']).reshape(-1,3);labels=np.load(R/'audit/hand_thumb3_uv_islands.npz')['labels'];caps=labels==next(k for k in np.unique(labels)if (labels==k).sum()==78);assert caps.sum()==78
if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
else:M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];unique,g=np.unique(P,axis=0,return_inverse=True);CF=g[F];edges={}
for tr in CF[caps]:
 for a,b in zip(tr,np.roll(tr,-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append((int(a),int(b)))
be=[pairs[0]for pairs in edges.values()if len(pairs)==1];assert len(be)==80;nextby={a:b for a,b in be};loop=[be[0][0]]
while True:
 n=nextby[loop[-1]]
 if n==loop[0]:break
 assert n not in loop;loop.append(n)
assert len(loop)==80;first=np.zeros(len(unique),int)
for i,k in enumerate(g):first[k]=i
base_ids=first[loop];base=W[base_ids];center=base.mean(0);captri=W[F[caps]];normal0=np.cross(captri[:,1]-captri[:,0],captri[:,2]-captri[:,0]).sum(0);normal0/=np.linalg.norm(normal0);normal1=-np.array([-.3796110978350356,-.9240533302563367,.04495394579625422]);turn=np.cross(normal0,normal1);turn/=np.linalg.norm(turn);angle=float(np.arccos(np.clip(normal0@normal1,-1,1)));vturn=np.cross(turn,normal0);radius=.035;length=radius*angle;offset=base-center;axial=offset@normal0;radial=offset-axial[:,None]*normal0;skin_tri=W[F[~caps]];skin_gn=np.cross(skin_tri[:,1]-skin_tri[:,0],skin_tri[:,2]-skin_tri[:,0]);skin_norm=np.zeros((len(unique),3))
for k in range(3):np.add.at(skin_norm,CF[~caps,k],skin_gn)
SN=skin_norm[loop];SN/=np.linalg.norm(SN,axis=1)[:,None]
def smooth(t):t=np.clip(t,0,1);return t*t*t*(10+t*(-15+6*t))
def raw_ring(t):
 rot=Rotation.from_rotvec(turn*(angle*t)).as_matrix();c=center+radius*np.sin(angle*t)*normal0+radius*(1-np.cos(angle*t))*vturn;scale=1-.35*smooth(t);q=radial*scale+normal0[None,:]*axial[:,None]*(1-smooth(t/.25));return c+q@rot.T
base_derivative=(raw_ring(1e-6)-base)/(length*1e-6);desired=base_derivative-SN*np.sum(SN*base_derivative,axis=1)[:,None];den=desired@normal0;assert den.min()>.1;desired*=((base_derivative@normal0)/den)[:,None];correction=desired-base_derivative;assert np.linalg.norm(correction,axis=1).max()<2
fractions=np.array([0,.018,.045,.085,.14,.22,.32,.43,.54,.65,.76,.86,.94,1]);rings=[]
for t in fractions:
 arc=t*length;weight=arc*max(0,1-arc/.008)**3;points=raw_ring(float(t))+correction*weight;rings.append(points)
rings=np.array(rings);rings[0]=base;positions=rings.reshape(-1,3);faces=[];uvs=[]
# Duplicate only the UV seam at theta0. Every row has81 encoded records but80 physical points.
V=[];UVnew=[]
for row,t in enumerate(fractions):
 for col in range(81):V.append(rings[row,col%80]);UVnew.append([.84+.12*col/80,.86+.105*t])
for row in range(len(fractions)-1):
 for col in range(80):a=row*81+col;b=a+1;c=(row+1)*81+col+1;d=c-1;faces.extend([[a,b,c],[a,c,d]])
# Separate terminal-cap chart in the empty lower strip.
rot=Rotation.from_rotvec(turn*angle).as_matrix();endN=rot@normal0;capcenter=rings[-1].mean(0);ci=len(V);V.append(capcenter);UVnew.append([.90,.986]);basisA=radial[0]/np.linalg.norm(radial[0]);basisB=np.cross(normal0,basisA);coords=np.column_stack([radial@basisA,radial@basisB]);size=np.max(abs(coords),axis=0);endidx=[]
for col in range(80):endidx.append(len(V));V.append(rings[-1,col]);UVnew.append((np.array([.90,.986])+coords[col]/size*np.array([.035,.009])).tolist())
for col in range(80):faces.append([ci,endidx[col],endidx[(col+1)%80]])
V=np.array(V);Q=np.array(faces);uvnew=np.array(UVnew);tri=V[Q];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm=np.zeros_like(V)
for k in range(3):np.add.at(norm,Q[:,k],GN)
# Weld normal support across the UV seam and terminal cap edge, preserving the real boundary normal.
_,vg=np.unique(V,axis=0,return_inverse=True);sums=np.zeros((vg.max()+1,3));np.add.at(sums,vg,norm);norm=sums[vg];norm/=np.linalg.norm(norm,axis=1)[:,None]
for col in range(81):norm[col]=SN[col%80]
NWg=norm[:,[0,2,1]]*[1,1,-1];localN=NWg@M[:3,:3];localN/=np.linalg.norm(localN,axis=1)[:,None];Wg=V[:,[0,2,1]]*[1,1,-1];localP=(Wg-M[:3,3])@np.linalg.inv(M[:3,:3]).T
for col in range(81):localP[col]=P[base_ids[col%80]]
newOldN=N.copy()
for k,group in enumerate(loop):
 ng=(SN[k][[0,2,1]]*[1,1,-1])@M[:3,:3];ng/=np.linalg.norm(ng);newOldN[g==group]=ng
newOldT=T.copy();nn=newOldN/np.linalg.norm(newOldN,axis=1)[:,None];tt=newOldT[:,:3].astype(float);tt-=np.sum(tt*nn,axis=1)[:,None]*nn;tt/=np.linalg.norm(tt,axis=1)[:,None];newOldT[:,:3]=tt
# New primitive gets valid placeholder tangents; native Mikk is required before a normal map is bound.
axis_hint=np.tile([1.,0,0],(len(V),1));axis_hint[abs(localN[:,0])>.9]=[0,1.,0];tan=axis_hint-np.sum(axis_hint*localN,axis=1)[:,None]*localN;tan/=np.linalg.norm(tan,axis=1)[:,None];tan4=np.column_stack([tan,np.ones(len(tan))]);pi,buf=append_accessor(j,buf,localP.astype('float32'),'VEC3',34962);ni,buf=append_accessor(j,buf,localN.astype('float32'),'VEC3',34962);ui,buf=append_accessor(j,buf,uvnew.astype('float32'),'VEC2',34962);ti,buf=append_accessor(j,buf,tan4.astype('float32'),'VEC4',34962);ii,buf=append_accessor(j,buf,Q.astype('uint32').ravel(),'SCALAR',34963);pr['indices'],buf=append_accessor(j,buf,F[~caps].astype('uint32').ravel(),'SCALAR',34963);pr['attributes']['NORMAL'],buf=append_accessor(j,buf,newOldN,'VEC3',34962);pr['attributes']['TANGENT'],buf=append_accessor(j,buf,newOldT,'VEC4',34962);j['meshes'][node['mesh']]['primitives'].append({'attributes':{'POSITION':pi,'NORMAL':ni,'TEXCOORD_0':ui,'TANGENT':ti},'indices':ii,'material':pr['material'],'mode':4});out=R/'Green_openhand_forearm6.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/hand_forearm6_binding.npz',base_world=base,base_physical_group=np.array(loop),new_world=V,new_triangles=Q,removed_cap_faces=np.flatnonzero(caps),fractions=fractions);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'held_hand_position_bytes_exact':True,'changed_normal_physical_groups':80,'removed_cap_triangles':int(caps.sum()),'new_forearm_triangles':len(Q),'total_triangles':int((~caps).sum()+len(Q)),'arc_radius_m':radius,'arc_angle_degrees':float(np.degrees(angle)),'arc_length_m':length,'terminal_center_world':capcenter.tolist(),'maximum_tangent_correction':float(np.linalg.norm(correction,axis=1).max()),'status':'Unadopted forearm extension; exact self/cuff contact and actual views pending. New primitive tangents are placeholders and must be recomputed before normal-map paint.'};(R/'audit/hand_forearm6.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
