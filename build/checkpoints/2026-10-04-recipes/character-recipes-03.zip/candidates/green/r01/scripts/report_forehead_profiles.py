import pathlib,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];d=np.load(R/'audit/forehead_cylinder_source.npz');f=np.load(R/'audit/forehead_depth_trial02_binding.npz');a=d['theta'];v=d['height'];r=d['radius'];delta=f['delta_grid'];rows=[]
for ang in [-.8,-.4,0,.4,.8,1.1]:
 x=int(abs(a-ang).argmin());row={'angle':float(a[x]),'values':[]}
 for z in [.020,.030,.035,.04,.045,.05,.055,.06,.065,.07,.08,.09,.10]:
  y=int(abs(v-z).argmin());row['values'].append([round(float(v[y]),4),round(float(r[y,x]),4),round(float(r[y,x]+delta[y,x]),4)])
 rows.append(row)
(R/'audit/forehead_depth_profiles.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
