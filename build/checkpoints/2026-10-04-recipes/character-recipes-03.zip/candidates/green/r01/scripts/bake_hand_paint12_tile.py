import pathlib,sys,json,time,numpy as np
from PIL import Image
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from uv_raster import samples
from hand_paint_projection12 import Projector
row0=int(sys.argv[1]);res=2048;row1=row0+512;z=np.load(R/'audit/hand_paint12_binding.npz');a={k:z[k]for k in z.files};z.close();P=a['P'];N=a['N'];F=a['F'];owner=a['owner'];project=Projector(a);pr0vertices=int(F[owner==1].min());# first81 records of new primitive form the held boundary row
baseP=P[pr0vertices:pr0vertices+81];baseN=N[pr0vertices:pr0vertices+81];baseC,baseGood,_,_=project.color(baseP,baseN);assert len(baseC)==81;meanC=baseC.mean(0);out=np.zeros((512,res,3),np.uint8);valid=np.zeros((512,res),np.uint8);viewmap=np.zeros((512,res),np.uint8);occup=projected=fallback=extension=overlap=0;buffers=[];count=0;start=time.time();sampled=np.zeros(len(F),bool)
def flush():
 global buffers,count,occup,projected,fallback,extension,overlap
 if not buffers:return
 fi=np.concatenate([x[0]for x in buffers]);yy=np.concatenate([x[1]for x in buffers]);xx=np.concatenate([x[2]for x in buffers]);bc=np.concatenate([x[3]for x in buffers]);p=np.einsum('ni,nij->nj',bc,P[F[fi]]);n=np.einsum('ni,nij->nj',bc,N[F[fi]]);n/=np.linalg.norm(n,axis=1)[:,None];c,good,best,vcount=project.color(p,n);fore=owner[fi]==1
 if fore.any():
  uv=np.einsum('ni,nij->nj',bc[fore],a['UV'][F[fi[fore]]]);angle=np.clip((uv[:,0]-.84)/.12*80,0,79.999);col=np.floor(angle).astype(int);t=(angle-col)[:,None];cc=baseC[col]*(1-t)+baseC[col+1]*t;v=np.clip((uv[:,1]-.86)/.105,0,1);fade=(v*v*(3-2*v))[:,None]*.35;cc=cc*(1-fade)+meanC*fade;cap=uv[:,1]>.975;cc[cap]=meanC;c[fore]=cc;extension+=int(fore.sum())
 c=np.clip(c,0,1);srgb=np.where(c<=.0031308,c*12.92,1.055*c**(1/2.4)-.055);overlap+=int(np.count_nonzero(valid[yy,xx]));out[yy,xx]=np.rint(srgb*255).astype('uint8');valid[yy,xx]=1;viewmap[yy,xx]=vcount;occup+=len(fi);projected+=int((good&~fore).sum());fallback+=int((~good&~fore).sum());buffers=[];count=0
for fi,y,x,bc in samples(a['UV'][F],res,row0,row1):
 sampled[fi]=True;buffers.append((np.full(len(y),fi,int),y,x,bc));count+=len(y)
 if count>=32768:flush()
flush();folder=R/'textures/hand12_tiles';folder.mkdir(exist_ok=True);Image.fromarray(out).save(folder/f'base_{row0}.png');Image.fromarray(valid*255).save(folder/f'valid_{row0}.png');Image.fromarray(viewmap).save(folder/f'views_{row0}.png');np.save(folder/f'sampled_{row0}.npy',sampled);rep={'row0':row0,'resolution':res,'occupied':occup,'projected_visible_skin':projected,'hidden_or_unusable_plate_fallback':fallback,'continuous_forearm_boundary_transfer':extension,'overlap':overlap,'seconds':time.time()-start,'fallback_linear':project.fallback.tolist(),'forearm_boundary_samples_projected':int(baseGood.sum()),'status':'Actual generated plate transfer; hidden-surface fallback is explicit, no external raster is approval evidence.'};(folder/f'base_{row0}.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
