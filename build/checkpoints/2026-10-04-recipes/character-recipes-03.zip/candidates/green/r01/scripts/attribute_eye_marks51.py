import pathlib,sys,json,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_physical_eyes50_bounded_cap_body.glb';j,b,A=read_glb(src);node=j['nodes'][0];sc=np.array(node['scale']);tr=np.array(node['translation']);PS=[];FS=[];UV=[];owners=[];off=0
for pi,p in enumerate(j['meshes'][0]['primitives']):
 P=(A(p['attributes']['POSITION'])*sc+tr)[:,[0,2,1]]*[1,-1,1];F=A(p['indices']).reshape(-1,3);PS.append(P);FS.append(F+off);off+=len(P);UV.append(A(p['attributes']['TEXCOORD_0']));owners.extend([pi]*len(F))
P=np.vstack(PS);F=np.vstack(FS);U=np.vstack(UV);owners=np.array(owners);tree=BVHTree.FromPolygons(P.tolist(),F.tolist(),all_triangles=True);rows=[]
for tag,points in [('head_angle_0',[(597,489),(598,492),(595,486),(615,481),(631,477),(631,484)]),('head_under',[(602,395),(615,399),(630,399),(647,395),(667,387),(639,388),(619,385),(629,375)])]:
 meta=json.loads((R/'renders/eyes50'/f'{tag}_paint.json').read_text());assert meta['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest();M=np.array(meta['camera_world_matrix']);scale=meta['ortho_scale'];w,h=meta['resolution'];direction=-M[:3,2]
 for x,y in points:
  origin=M[:3,3]+M[:3,0]*((x+.5)/w-.5)*scale+M[:3,1]*(.5-(y+.5)/h)*scale;hit,n,fi,d=tree.ray_cast(Vector(origin),Vector(direction),20.)
  if hit is None:rows.append({'view':tag,'pixel':[x,y],'hit':False});continue
  Q=P[F[fi]];mat=np.column_stack([Q[1]-Q[0],Q[2]-Q[0]]);uv2=np.linalg.lstsq(mat,np.array(hit)-Q[0],rcond=None)[0];bary=np.r_[1-uv2.sum(),uv2];uv=bary@U[F[fi]];pi=int(owners[fi]);pr=j['meshes'][0]['primitives'][pi];rows.append({'view':tag,'pixel':[x,y],'hit':True,'primitive':pi,'material':j['materials'][pr['material']]['name'],'face':int(fi),'world_hit':list(hit),'front_facing':float(np.dot(n,direction))<0,'uv':uv.tolist()})
rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'samples':rows};(R/'audit/eye_marks51.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
