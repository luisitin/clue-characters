import pathlib
R=pathlib.Path(__file__).resolve().parents[1]
code=(R/'scripts/render_exact.py').read_text()
code=code.replace("target,scale,angle,elev=regions[tag];","regions['cuff_context']=((-.34,-.16,.235),.38,-11,.04)\nregions['cuff_under']=((-.34,-.16,.235),.42,-11,-5)\nregions['cuff_top']=((-.34,-.16,.235),.42,-11,5)\nregions['cuff_side']=((-.34,-.16,.235),.42,79,.04)\nregions['cuff_opposite']=((-.34,-.16,.235),.38,169,.04)\ntarget,scale,angle,elev=regions[tag];")
exec(compile(code,'render_cuff_context','exec'))
