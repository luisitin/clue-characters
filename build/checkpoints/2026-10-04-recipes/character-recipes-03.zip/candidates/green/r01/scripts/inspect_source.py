import bpy,pathlib,json,hashlib,sys,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];src=R.parents[2]/'sources/prelod-cd4c20d/sus-green.glb';bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src));rows=[]
for ob in bpy.context.scene.objects:
 if ob.type!='MESH':continue
 me=ob.data;me.calc_loop_triangles();P=np.array([(ob.matrix_world@v.co)[:]for v in me.vertices]);F=np.array([t.vertices[:]for t in me.loop_triangles]);N=np.array([n.vector[:]for n in me.corner_normals]);norm=np.linalg.norm(N,axis=1);q=P[F];area=np.linalg.norm(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]),axis=1)/2
 rows.append({'name':ob.name,'vertices':len(P),'triangles':len(F),'world_bounds':[P.min(0).tolist(),P.max(0).tolist()],'world_matrix':[list(r)for r in ob.matrix_world],'zero_area_triangles':int((area<1e-15).sum()),'nonfinite_normal_count':int((~np.isfinite(N).all(1)).sum()),'zero_normal_count':int((norm<1e-6).sum()),'max_normal_unit_error':float(abs(norm-1).max())})
images=[]
for im in bpy.data.images:
 images.append({'name':im.name,'size':list(im.size),'packed_bytes':len(im.packed_file.data)if im.packed_file else 0})
report={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_bytes':src.stat().st_size,'git_commit':'cd4c20dcfbf0e59cc64e916746048ed5b49fb627','source_kind':'Recovered GitHub pre-LOD asset; lost later HD components are not restored','objects':rows,'images':images,'geometry_modified':False};(R/'audit/source_inventory.json').write_text(json.dumps(report,indent=2));print(report,flush=True);bpy.ops.wm.save_as_mainfile(filepath=str(R/'Green_source_import.blend'),compress=True)
