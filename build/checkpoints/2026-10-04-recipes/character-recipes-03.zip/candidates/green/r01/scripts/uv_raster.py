"""Strict-interior raster samples in bounded row tiles; arrays must be cached by caller."""
import numpy as np
def samples(tr,res,row0=0,row1=None):
    row1=res if row1 is None else row1
    area=(tr[:,1,0]-tr[:,0,0])*(tr[:,2,1]-tr[:,0,1])-(tr[:,1,1]-tr[:,0,1])*(tr[:,2,0]-tr[:,0,0])
    for i,q in enumerate(tr):
        if abs(area[i])<1e-18:continue
        lo=np.maximum(np.ceil(q.min(axis=0)*res-.5).astype(int),[0,row0]);hi=np.minimum(np.floor(q.max(axis=0)*res-.5).astype(int),[res-1,row1-1])
        if np.any(hi<lo):continue
        ix,iy=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));xx=(ix+.5)/res;yy=(iy+.5)/res
        u=((q[1,0]-xx)*(q[2,1]-yy)-(q[1,1]-yy)*(q[2,0]-xx))/area[i]
        v=((q[2,0]-xx)*(q[0,1]-yy)-(q[2,1]-yy)*(q[0,0]-xx))/area[i];w=1-u-v
        inside=(u>1e-8)&(v>1e-8)&(w>1e-8)
        if np.any(inside):yield i,iy[inside]-row0,ix[inside],np.column_stack((u[inside],v[inside],w[inside]))

def audit(tr,res):
    face=np.zeros(len(tr),'i8');occupied=total=overlap=0;maximum=0
    for row in range(0,res,1024):
        counts=np.zeros((min(1024,res-row),res),'u2')
        for i,y,x,b in samples(tr,res,row,min(row+1024,res)):
            face[i]+=len(y);counts[y,x]+=1
        occupied+=int(np.count_nonzero(counts));total+=int(counts.astype('u8').sum());overlap+=int(np.count_nonzero(counts>1));maximum=max(maximum,int(counts.max()))
        print(f'UV {res} row{row}: occupied={occupied} overlaps={overlap}',flush=True)
    return {'resolution':res,'occupied_texels':occupied,'raster_samples':total,'multiply_covered_texels':overlap,'maximum_multiplicity':maximum,'missing_faces':np.flatnonzero(face==0).tolist(),'face_sample_quantiles':np.quantile(face,[0,.01,.5,.99,1]).tolist()},face
