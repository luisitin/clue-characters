import pathlib,numpy as np,json
from PIL import Image,ImageDraw
R=pathlib.Path(__file__).resolve().parents[1];d=np.load(R/'audit/forehead_cylinder_source.npz');uv=d['uv_gltf'];rad=d['radius'];a=d['theta'];h=d['height'];im=np.array(Image.open(R.parents[2]/'textures/prelod-cd4c20d/sus-green/0_base_color.webp').convert('RGB'));HH,WW=im.shape[:2];x=np.clip(uv[:,:,0]*WW-.5,0,WW-1);y=np.clip(uv[:,:,1]*HH-.5,0,HH-1);i=np.floor(x).astype(int);j=np.floor(y).astype(int);u=x-i;v=y-j;i2=np.minimum(i+1,WW-1);j2=np.minimum(j+1,HH-1);col=(1-v[:,:,None])*((1-u[:,:,None])*im[j,i]+u[:,:,None]*im[j,i2])+v[:,:,None]*((1-u[:,:,None])*im[j2,i]+u[:,:,None]*im[j2,i2]);np.savez_compressed(R/'audit/forehead_cylinder_color.npz',color_srgb=col.astype('float32'),theta=a,height=h);canvas=Image.new('RGB',(1100,820),(230,230,230));draw=ImageDraw.Draw(canvas);panel=Image.fromarray(col[::-1].astype('uint8')).resize((1080,470));canvas.paste(panel,(10,28));draw.text((10,8),'Exact cylindrical source color: angle -1.35 to +1.35; height .15 top to .02 bottom',fill='black')
for value in [.02,.04,.06,.08,.10,.12,.14]:
 yy=28+int((.15-value)/.13*470);draw.line((10,yy,1090,yy),fill=(250,250,250),width=1);draw.text((12,yy),f'{value:.2f}',fill='yellow')
# Cross-section radius traces at selected angles, with a common physical axis.
colors=[(170,30,30),(0,110,20),(0,50,220),(180,100,0),(140,0,150)];draw.text((10,520),'Radial depth profiles: X=height(.02-.15), Y=radius(.02-.12); angles -.9,-.45,0,.45,.9',fill='black')
for aa,color in zip([-.9,-.45,0,.45,.9],colors):
 k=int(abs(a-aa).argmin());pts=[(20+(vv-.02)/.13*1060,790-(rr-.02)/.10*240)for vv,rr in zip(h,rad[:,k])];draw.line(pts,fill=color,width=3)
canvas.save(R/'audit/forehead_chart.png');print('Chart saved',flush=True)
