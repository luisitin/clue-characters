import pathlib,sys,json,numpy as np
from PIL import Image
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_source_clean_records.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];W=(P*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];center=np.array([-.335189492,-.158833660,.213596714]);axis=np.array([-.38,-.925,.045]);axis/=np.linalg.norm(axis);up=np.array([0.,0.,1.]);up-=axis*(up@axis);up/=np.linalg.norm(up);side=np.cross(axis,up);s=(W-center)@axis;q=W[F];roi=(q[:,:,0].max(1)<-.22)&(q[:,:,1].min(1)<-.04)&(q[:,:,2].max(1)>.08)&(q[:,:,2].min(1)<.38);image=np.array(Image.open(R.parents[2]/'textures/prelod-cd4c20d/sus-green/0_base_color.webp').convert('RGB'));reports=[];bindings={}
for phase in [-.03,-.025,-.02,-.015,-.010,-.005,0]:
 ids=np.flatnonzero(roi&(s[F].min(1)<phase)&(s[F].max(1)>phase));segments=[];colors=[];fs=[]
 for fi in ids:
  tr=F[fi];points=[];tuv=[]
  for a,b in zip(tr,np.roll(tr,-1)):
   if(s[a]-phase)*(s[b]-phase)<0:
    t=(phase-s[a])/(s[b]-s[a]);points.append(W[a]+t*(W[b]-W[a]));tuv.append(UV[a]+t*(UV[b]-UV[a]))
  if len(points)!=2:continue
  segments.append(points);uv=np.mean(tuv,axis=0);xy=np.clip((uv*np.array([image.shape[1],image.shape[0]])).astype(int),[0,0],[image.shape[1]-1,image.shape[0]-1]);colors.append(image[xy[1],xy[0]]);fs.append(int(fi))
 seg=np.array(segments);keys=np.round(seg.reshape(-1,3),7);un,g=np.unique(keys,axis=0,return_inverse=True);edges=g.reshape(-1,2);adj={};duplicates=[];seen={}
 for i,(a,b)in enumerate(edges):
  key=tuple(sorted((int(a),int(b))))
  if key in seen:duplicates.append([seen[key],i]);continue
  seen[key]=i;adj.setdefault(int(a),[]).append(int(b));adj.setdefault(int(b),[]).append(int(a))
 bad={str(k):len(v)for k,v in adj.items()if len(v)!=2};loops=[];left=set(adj)
 if not bad:
  while left:
   first=min(left);loop=[first];prev=None;cur=first
   while True:
    nxt=next(v for v in adj[cur]if v!=prev)
    if nxt==first:break
    if nxt in loop:raise AssertionError('Unexpected contour cycle')
    loop.append(nxt);prev,cur=cur,nxt
   left-=set(loop);loops.append(loop)
 rows=[]
 for loop in loops:
  points=un[loop];local=np.column_stack([(points-center)@side,(points-center)@up]);area=.5*abs(np.sum(local[:,0]*np.roll(local[:,1],-1)-local[:,1]*np.roll(local[:,0],-1)));rows.append({'points':len(loop),'center_world':points.mean(0).tolist(),'width_height_m':np.ptp(local,axis=0).tolist(),'area_m2':float(area)})
 reports.append({'phase_m':phase,'segments':len(segments),'duplicate_segments':len(duplicates),'bad_degrees':bad,'loops':rows,'source_segment_RGB_mean':np.mean(colors,axis=0).tolist()if colors else None});bindings[str(phase)]= {'segments_world':seg.tolist(),'source_faces':fs,'RGB':np.array(colors).tolist()}
rep={'source':'Green_source_clean_records.glb','center':center.tolist(),'axis':axis.tolist(),'plane_side':side.tolist(),'plane_up':up.tolist(),'sections':reports,'scope':'Read-only complete plane-section ownership study; RGB is diagnostic and is not a deletion mask'};(R/'audit/open_wrist_sections.json').write_text(json.dumps(rep,indent=2));(R/'audit/open_wrist_section_segments.json').write_text(json.dumps(bindings));print(rep,flush=True)
