import pathlib,sys,json,numpy as np,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_source_clean_records.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);N=A(pr['attributes']['NORMAL']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];P=P*np.array(node['scale'])+np.array(node['translation']);P=P[:,[0,2,1]]*[1,-1,1];N=N[:,[0,2,1]]*[1,-1,1];tree=BVHTree.FromPolygons(P.tolist(),F.tolist(),all_triangles=True);cam=json.load(open(R/'renders/source_normalized/head_angle_0_paint.json'));C=np.array(cam['camera_world_matrix']);scale=cam['ortho_scale']
def pixel_hit(x,y):
 o=C[:3,3]+C[:3,0]*((x+.5)/1024-.5)*scale+C[:3,1]*(.5-(y+.5)/1024)*scale;h,n,f,d=tree.ray_cast(Vector(o),Vector(-C[:3,2]));assert h is not None;return np.array(h)
left=pixel_hit(432,445);right=pixel_hit(635,455);E=(left+right)/2;X=right-left;X/=np.linalg.norm(X);Z=np.array([0.,0.,1.]);Z-=X*(X@Z);Z/=np.linalg.norm(Z);FR=np.cross(X,Z);origin=E-FR*.07;theta=np.linspace(-1.35,1.35,361);height=np.linspace(.02,.15,175);radius=np.full((len(height),len(theta)),np.nan);uv=np.zeros((*radius.shape,2));owners=np.full(radius.shape,-1,np.int32);cos=np.zeros(radius.shape);winding=np.zeros(radius.shape)
for iy,v in enumerate(height):
 for ix,a in enumerate(theta):
  rd=FR*np.cos(a)+X*np.sin(a);o=origin+Z*v+rd*.25;hit,gn,fi,dist=tree.ray_cast(Vector(o),Vector(-rd),.25)
  if hit is None:continue
  h=np.array(hit);q=P[F[fi]];e1=q[1]-q[0];e2=q[2]-q[0];vv=h-q[0];aa=e1@e1;bb=e1@e2;cc=e2@e2;dd=e1@vv;ee=e2@vv;den=aa*cc-bb*bb
  if abs(den)<1e-22:continue
  w1=(cc*dd-bb*ee)/den;w2=(aa*ee-bb*dd)/den;bc=np.array([1-w1-w2,w1,w2]);cn=bc@N[F[fi]];cn/=np.linalg.norm(cn);co=cn@rd
  if co<.12:continue
  radius[iy,ix]=float((h-origin-Z*v)@rd);uv[iy,ix]=bc@UV[F[fi]];owners[iy,ix]=fi;cos[iy,ix]=co;winding[iy,ix]=np.array(gn)@rd
np.savez_compressed(R/'audit/forehead_cylinder_source.npz',theta=theta,height=height,radius=radius,uv_gltf=uv,triangle=owners,normal_radial_cos=cos,geometric_radial_cos=winding,origin=origin,X=X,front=FR,Z=Z,eye_left=left,eye_right=right)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'eye_anchor_pixels':[[432,445],[635,455]],'eye_world_points':[left.tolist(),right.tolist()],'origin':origin.tolist(),'basis_X_front_Z':[X.tolist(),FR.tolist(),Z.tolist()],'valid_samples':int(np.isfinite(radius).sum()),'total_samples':radius.size,'radius_range_m':[float(np.nanmin(radius)),float(np.nanmax(radius))],'scope':'Read-only first-hit cylindrical forehead chart with source UV binding; repair domain not selected yet'};(R/'audit/forehead_cylinder_source.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
