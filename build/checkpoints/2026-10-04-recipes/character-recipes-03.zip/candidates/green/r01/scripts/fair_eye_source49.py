"""Restore held orbital source volume away from the new physical lid support band."""
import pathlib,json,hashlib,numpy as np
from scipy.spatial import cKDTree
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];src=R/'Green_physical_eyes46_painted_body.glb';j,buf,A=read_glb(src);z=np.load(R/'audit/eye_globes43.npz');a={k:z[k]for k in z.files};z.close();z=np.load(R/'audit/eye_source_shape47.npz');d={k:z[k]for k in z.files};z.close();node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);frame=a['frame_basis'];origin=a['frame_origin'];reports=[]
def norms(Q,F):
 n=np.zeros_like(Q);g=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]])
 for i in range(3):np.add.at(n,F[:,i],g)
 return n/np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-30)
for eye in range(2):
 pr=j['meshes'][0]['primitives'][5+eye*3];oldP=A(pr['attributes']['POSITION']);oldN=A(pr['attributes']['NORMAL']);F=A(pr['indices']).reshape(-1,3);Q=d[f'eye{eye}_positions'];V=Q[:,[0,2]];outer=a[f'eye{eye}_outer'];guide=a[f'eye{eye}_guide_points'];no=len(outer);ni=192;inner=V[no:no+ni];distance=np.full(len(Q),np.inf)
 for p,q in zip(inner,np.roll(inner,-1,axis=0)):
  e=q-p;t=np.clip(((V-p)@e)/(e@e),0,1);distance=np.minimum(distance,np.linalg.norm(V-p-t[:,None]*e,axis=1))
 weight=np.clip((distance-.0015)/.0045,0,1);weight=weight**3*(10-15*weight+6*weight*weight);fixed=np.zeros(len(Q),bool);fixed[:no+2*ni]=True
 for k in range(no):
  tri=np.array([outer[k],outer[(k+1)%no],guide[k,[0,2]]]);e=tri[1]-tri[0];f=tri[2]-tri[0];v=V-tri[0];den=e[0]*f[1]-e[1]*f[0];u=(v[:,0]*f[1]-v[:,1]*f[0])/den;w=(e[0]*v[:,1]-e[1]*v[:,0])/den;fixed|=(u>=-1e-7)&(w>=-1e-7)&(u+w<=1+1e-7)
 # Protect complete first-row triangles, then fade the source prior across the tangent strip.
 outerFaces=np.any(F<no,axis=1);fixed[np.unique(F[outerFaces])]=True
 do=np.full(len(Q),np.inf)
 for p,q in zip(outer,np.roll(outer,-1,axis=0)):
  e=q-p;t=np.clip(((V-p)@e)/(e@e),0,1);do=np.minimum(do,np.linalg.norm(V-p-t[:,None]*e,axis=1))
 fade=np.clip((do-.0004)/.0016,0,1);fade=fade**3*(10-15*fade+6*fade*fade);weight*=fade;weight[fixed]=0;sourceY=d[f'eye{eye}_source_y'].copy();sourceN=d[f'eye{eye}_source_normal'].copy();sfaces=d[f'eye{eye}_source_face'];sp=a['source_eye_frame'][a['source_triangles'][sfaces]];sg=np.cross(sp[:,1]-sp[:,0],sp[:,2]-sp[:,0]);bad=sg[:,1]>=0
 if bad.any():
  good=np.flatnonzero(~bad);_,near=cKDTree(V[good]).query(V[bad]);sourceY[bad]=sourceY[good[near]];sourceN[bad]=sourceN[good[near]]
 new=Q.copy();new[:,1]=(1-weight)*Q[:,1]+weight*sourceY;sourceQ=Q.copy();sourceQ[:,1]=sourceY;oldGeom=norms(Q,F);sourceGeom=norms(sourceQ,F);newGeom=norms(new,F);worldN=(oldN/scale)[:,[0,2,1]]*[1,-1,1];oldQN=worldN@frame;oldQN/=np.linalg.norm(oldQN,axis=1)[:,None];newN=newGeom+(1-weight[:,None])*(oldQN-oldGeom)+weight[:,None]*(sourceN-sourceGeom);newN/=np.linalg.norm(newN,axis=1)[:,None];W=new@frame.T+origin;WN=newN@frame.T;P=(W[:,[0,2,1]]*[1,1,-1]-translation)/scale;N=WN[:,[0,2,1]]*[1,1,-1]*scale;N/=np.linalg.norm(N,axis=1)[:,None];P[fixed]=oldP[fixed];N[fixed]=oldN[fixed]
 for key,arr in [('POSITION',P),('NORMAL',N)]:pr['attributes'][key],buf=append_accessor(j,buf,arr.astype('float32'),'VEC3',34962)
 far=(distance>.006)&~fixed;reports.append({'eye':eye,'vertices':len(Q),'held_outer_lip_tangent_vertices':int(fixed.sum()),'maximum_return_to_source_m':float(abs(new[:,1]-Q[:,1]).max()),'outer_prior_fade_m':[.0004,.002],'maximum_source_depth_error_beyond_6mm_m':float(abs(new[far,1]-sourceY[far]).max()),'source_reverse_face_samples_replaced_by_nearest_good':int(bad.sum()),'source_shape_weight_zone_m':[.0015,.006],'status':'Unadopted source-volume restoration. Fixed outer tangent wedges and lip/cap held; exact crossings and appearance pending.'})
out=R/'Green_physical_eyes49_source_shape_body.glb';write_glb(out,j,buf);rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'eyes':reports};(R/'audit/eyes49.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
