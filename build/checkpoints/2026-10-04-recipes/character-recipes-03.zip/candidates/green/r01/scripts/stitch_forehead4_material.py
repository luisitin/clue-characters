import pathlib,sys,json,hashlib,copy,numpy as np
from PIL import Image
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,write_glb
src=R/'Green_forehead_pslg4_geometry.glb';sha=hashlib.sha256(src.read_bytes()).hexdigest();j,buf,A=read_glb(src);rows=[];images={}
for kind in ['BaseColor','ORM']:
 canvas=Image.new('RGB',(2048,2048))
 for tile in range(16):
  info=json.load(open(R/'textures/forehead4_tiles'/f'tile_{tile:02d}_binding.json'));assert info['candidate_geometry_sha256']==sha and info['occupied_source_misses']==0;im=Image.open(R/'textures/forehead4_tiles'/f'tile_{tile:02d}_{kind}.png');assert im.size==(512,512);canvas.paste(im,((tile%4)*512,(tile//4)*512))
  if kind=='BaseColor':rows.append(info)
 p=R/'textures'/f'Green_Forehead4_{kind}_2K.png';canvas.save(p);images[kind]=p
tex={}
for kind,p in images.items():
 data=p.read_bytes();buf=bytes(buf)+b'\0'*((-len(buf))%4);vi=len(j['bufferViews']);j['bufferViews'].append({'buffer':0,'byteOffset':len(buf),'byteLength':len(data)});buf+=data;ii=len(j['images']);j['images'].append({'name':p.name,'mimeType':'image/png','bufferView':vi});ti=len(j['textures']);texture={'source':ii}
 if j.get('samplers'):texture['sampler']=0
 j['textures'].append(texture);tex[kind]=ti
pr=j['meshes'][0]['primitives'][1];material=copy.deepcopy(j['materials'][0]);material['name']='Green forehead original-color transfer 2K regional atlas';material['pbrMetallicRoughness']['baseColorTexture']['index']=tex['BaseColor'];material['pbrMetallicRoughness']['metallicRoughnessTexture']['index']=tex['ORM'];material['occlusionTexture']['index']=tex['ORM'];j['materials'][pr['material']]=material;binding=np.load(R/'audit/forehead_pslg4_binding.npz');uv=A(pr['attributes']['TEXCOORD_0']).astype(float);low=binding['chart_low'];high=binding['chart_high'];decoded=uv.copy();decoded[:,1]=1-decoded[:,1];decoded=low+decoded*(high-low);error=float(abs(decoded-binding['patch_chart']).max());assert error<1e-7;out=R/'Green_forehead_pslg4_painted.glb';write_glb(out,j,buf);report={'source_geometry_sha256':sha,'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'candidate_bytes':out.stat().st_size,'triangles':sum(j['accessors'][p['indices']]['count']//3 for p in j['meshes'][0]['primitives']),'occupied_atlas_texels':sum(x['occupied_texels']for x in rows),'occupied_source_misses':sum(x['occupied_source_misses']for x in rows),'actual_exported_UV_to_chart_max_error_m':error,'maps':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolution':[2048,2048]}for p in images.values()],'source_hero_base_4K_and_body_material_held':True,'map_method':'Exact radial parameter registration to source surfaces; base color filtered in linear color and reencoded sRGB; ORM filtered as linear data','status':'Actual painted GLB is ready for view inspection; geometry/intersection and final likeness gates remain separate'};(R/'audit/forehead4_painted.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
