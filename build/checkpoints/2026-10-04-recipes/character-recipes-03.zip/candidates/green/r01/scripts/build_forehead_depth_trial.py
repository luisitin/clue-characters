"""Bounded cylindrical forehead graph trial; source attributes/maps are held."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.interpolate import CubicSpline,RegularGridInterpolator
from scipy.ndimage import gaussian_filter,gaussian_filter1d
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
src=R/'Green_source_clean_records.glb';j,buf,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);N=A(pr['attributes']['NORMAL']);F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];sc=np.array(node['scale']);trans=np.array(node['translation']);world=(P*sc+trans)[:,[0,2,1]]*[1,-1,1];NW=N[:,[0,2,1]]*[1,-1,1];d=np.load(R/'audit/forehead_cylinder_source.npz');a=d['theta'];v=d['height'];rho=d['radius'];origin=d['origin'];X=d['X'];FR=d['front'];Z=d['Z'];assert np.isfinite(rho).all()
def s(x):x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))
knots=np.array([[-1.35,.035],[-1.1,.072],[-.9,.092],[-.75,.101],[-.55,.096],[-.3,.082],[0,.072],[.20,.067],[.45,.077],[.75,.079],[1,.075],[1.2,.076],[1.35,.063]])
h=CubicSpline(knots[:,0],knots[:,1],bc_type='natural')(a);center=.046-.009*s((a+.15)/.8);base=[];slope=[]
for k,c in enumerate(center):
 rows=(v>=c-.010)&(v<=c-.002);coef=np.polynomial.polynomial.polyfit(v[rows]-c,rho[rows,k],1);base.append(coef[0]);slope.append(coef[1])
base=gaussian_filter1d(base,2);slope=gaussian_filter1d(np.clip(slope,-.25,.10),2);fore=np.array(base)[None,:]+(v[:,None]-center[None,:])*np.array(slope)[None,:];blend=s((v[:,None]-(h[None,:]-.004))/.016);target=fore*(1-blend)+rho*blend;mask=s((v[:,None]-center[None,:])/.006)*s((a[None,:]+1.30)/.20)*s((1.35-a[None,:])/.18);delta=np.minimum(target-rho,0)*mask;delta=gaussian_filter(delta,.7)*mask;assert -delta.min()<.025
DV,DA=np.gradient(delta,v,a);interp=lambda q,points:RegularGridInterpolator((v,a),q,bounds_error=False,fill_value=0)(points);q=world-origin;z=q@Z;x=q@X;y=q@FR;r=np.sqrt(x*x+y*y);theta=np.arctan2(x,y);pt=np.column_stack([z,theta]);sample_r=interp(rho,pt);change=interp(delta,pt);eligible=(abs(r-sample_r)<.001)&(r>.02);change*=eligible;dv=interp(DV,pt)*eligible;da=interp(DA,pt)*eligible;active=abs(change)>1e-10;rd=np.sin(theta)[:,None]*X+np.cos(theta)[:,None]*FR;td=np.cos(theta)[:,None]*X-np.sin(theta)[:,None]*FR;outworld=world+change[:,None]*rd;grad=(da/np.maximum(r,1e-8))[:,None]*td+dv[:,None]*Z;J=np.eye(3)[None,:,:]+rd[:,:,None]*grad[:,None,:]+(change/np.maximum(r,1e-8))[:,None,None]*td[:,:,None]*td[:,None,:];jac=np.linalg.det(J);assert jac.min()>.65;outN=np.linalg.solve(np.swapaxes(J,1,2),NW[:,:,None])[:,:,0];outN/=np.linalg.norm(outN,axis=1)[:,None];outN[~active]=NW[~active];outP=(outworld[:,[0,2,1]]*[1,1,-1]-trans)/sc;outP[~active]=P[~active];outN=outN[:,[0,2,1]]*[1,1,-1]
# Split UV/material vertices at the same physical source point share the deformation.
_,groups=np.unique(P,axis=0,return_inverse=True)
for group in np.flatnonzero(np.bincount(groups)>1):assert np.ptp(outP[groups==group],axis=0).max()<1e-12
tri=F[active[F].any(1)];aa=world[tri];bb=outworld[tri];n0=np.cross(aa[:,1]-aa[:,0],aa[:,2]-aa[:,0]);n1=np.cross(bb[:,1]-bb[:,0],bb[:,2]-bb[:,0]);ar=np.linalg.norm(n1,axis=1)/np.linalg.norm(n0,axis=1);assert ar.min()>.15
# An eligible-sheet boundary may not silently introduce a displacement jump.
seams=[]
for t in tri:
 for i,k in zip(t,np.roll(t,-1)):
  if eligible[i]!=eligible[k] and max(abs(change[i]),abs(change[k]))>.0001:seams.append([int(i),int(k),float(max(abs(change[i]),abs(change[k])))])
assert not seams,'Selected radial sheet has an unsupported internal boundary'
pi,buf=append_accessor(j,buf,outP.astype('float32'),'VEC3',34962);ni,buf=append_accessor(j,buf,outN.astype('float32'),'VEC3',34962);pr['attributes']['POSITION']=pi;pr['attributes']['NORMAL']=ni;out=R/'Green_forehead_depth_trial01.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/forehead_depth_trial01_binding.npz',old_world=world,new_world=outworld,triangles=F,active_vertices=active,delta_grid=delta,theta=a,height=v,hairline=h,field_jacobian=jac)
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'triangles':len(F),'changed_vertices':int(active.sum()),'changed_triangles':len(tri),'maximum_radial_retraction_m':float(-change.min()),'minimum_field_Jacobian':float(jac.min()),'minimum_triangle_area_ratio':float(ar.min()),'all_source_UVs_maps_materials_nodes_exact':True,'source_same_position_groups_coherent':True,'unsupported_internal_sheet_boundaries':len(seams),'max_unaffected_position_float32_rounding_m':float(np.max(abs(outP[~active].astype('float32')-P[~active]))),'status':'Unadopted bounded shape trial; exact intersection and multi-angle appearance gates pending'};(R/'audit/forehead_depth_trial01.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
