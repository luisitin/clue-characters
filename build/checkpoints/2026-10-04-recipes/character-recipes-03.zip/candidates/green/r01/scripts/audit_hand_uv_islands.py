import pathlib,sys,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_openhand_thumb3.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);_,group=np.unique(np.column_stack([P,UV]),axis=0,return_inverse=True);CF=group[F];parent=np.arange(len(F))
def find(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
edges={}
for fi,tr in enumerate(CF):
 for a,b in zip(tr,np.roll(tr,-1)):
  key=tuple(sorted((int(a),int(b))))
  if key in edges:parent[find(fi)]=find(edges[key])
  else:edges[key]=fi
labels=np.array([find(i)for i in range(len(F))]);keys=np.unique(labels);rows=[]
for k in keys:
 ids=np.flatnonzero(labels==k);uv=UV[F[ids]];q=P[F[ids]];area=float(np.linalg.norm(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]),axis=1).sum()/2);uva=float(abs((uv[:,1,0]-uv[:,0,0])*(uv[:,2,1]-uv[:,0,1])-(uv[:,1,1]-uv[:,0,1])*(uv[:,2,0]-uv[:,0,0])).sum()/2);lo=uv.min((0,1));hi=uv.max((0,1));rows.append({'id':int(k),'triangles':len(ids),'uv_bounds':[lo.tolist(),hi.tolist()],'uv_area':uva,'world_local_area':area,'bbox_fill_fraction':float(uva/np.prod(hi-lo))})
np.savez_compressed(R/'audit/hand_thumb3_uv_islands.npz',labels=labels);(R/'audit/hand_thumb3_uv_islands.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
