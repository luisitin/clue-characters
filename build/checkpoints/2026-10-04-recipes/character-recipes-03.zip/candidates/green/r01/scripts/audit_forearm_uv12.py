import pathlib,sys,json,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
from uv_coverage import audit
j,b,A=read_glb(R/'Green_openhand_forearm6.glb');tr=[]
for pr in j['meshes'][0]['primitives']:tr.append(A(pr['attributes']['TEXCOORD_0'])[A(pr['indices']).reshape(-1,3)])
tr=np.vstack(tr);rep={'2K':audit(tr,2048),'4K':audit(tr,4096)};(R/'audit/hand_forearm12_uv.json').write_text(json.dumps(rep,indent=2));print({k:{a:len(b)if isinstance(b,list)else b for a,b in v.items()}for k,v in rep.items()},flush=True)
