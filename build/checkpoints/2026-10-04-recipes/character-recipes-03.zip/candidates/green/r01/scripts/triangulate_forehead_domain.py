import pathlib,sys,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
D=np.load(R/'audit/forehead_domain_proposal2.npz',allow_pickle=True);loops=D['loops'];assert len(loops)==1;loop=np.array(loops[0],int);first=D['canonical_first'];boundary_source_ids=first[loop];outer=D['chart'][boundary_source_ids];area=.5*np.sum(outer[:,0]*np.roll(outer[:,1],-1)-outer[:,1]*np.roll(outer[:,0],-1))
if area<0:outer=outer[::-1];boundary_source_ids=boundary_source_ids[::-1]
def inside(points):
 hit=np.zeros(len(points),bool);x=points[:,0];y=points[:,1]
 for a,b in zip(outer,np.roll(outer,-1,axis=0)):
  crossing=((a[1]>y)!=(b[1]>y))&(x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1]+1e-300)+a[0]);hit^=crossing
 return hit
# Validate non-adjacent boundary segments before supplying the PSLG.
def c(a,b):return a[0]*b[1]-a[1]*b[0]
for i,(a,b)in enumerate(zip(outer,np.roll(outer,-1,axis=0))):
 for k,(p,q)in enumerate(zip(outer,np.roll(outer,-1,axis=0))):
  if k<=i+1 or(i==0 and k==len(outer)-1):continue
  assert not(c(b-a,p-a)*c(b-a,q-a)<-1e-18 and c(q-p,a-p)*c(q-p,b-p)<-1e-18),'Outer PSLG self-intersects'
x=np.arange(outer[:,0].min()+.0009,outer[:,0].max(),.0018);y=np.arange(outer[:,1].min()+.0009,outer[:,1].max(),.0018);xx,yy=np.meshgrid(x,y);points=np.column_stack([xx.ravel(),yy.ravel()]);points=points[inside(points)];dist=np.full(len(points),np.inf)
for a,b in zip(outer,np.roll(outer,-1,axis=0)):
 e=b-a;t=np.clip(((points-a)@e)/(e@e),0,1);dist=np.minimum(dist,np.linalg.norm(points-a-t[:,None]*e,axis=1))
points=points[dist>.0008];vertices=np.vstack([outer,points]);segments=np.column_stack([np.arange(len(outer)),np.roll(np.arange(len(outer)),-1)]);out=triangle.triangulate({'vertices':vertices,'segments':segments},'pYq20Q');V=out['vertices'];F=out['triangles'];tri=V[F];cross=(tri[:,1,0]-tri[:,0,0])*(tri[:,2,1]-tri[:,0,1])-(tri[:,1,1]-tri[:,0,1])*(tri[:,2,0]-tri[:,0,0]);assert cross.min()>0 and np.array_equal(V[:len(outer)],outer);assert inside(tri.mean(1)).all();edge={}
for fi,tr in enumerate(F):
 for a,b in zip(tr,np.roll(tr,-1)):edge.setdefault(tuple(sorted((int(a),int(b)))),[]).append(fi)
be={e for e,fs in edge.items()if len(fs)==1};expected={tuple(sorted(map(int,e)))for e in segments};assert be==expected and max(map(len,edge.values()))==2
np.savez_compressed(R/'audit/forehead_pslg3_domain.npz',vertices=V,triangles=F,boundary_count=len(outer),boundary_source_ids=boundary_source_ids);report={'boundary_vertices':len(outer),'vertices':len(V),'triangles':len(F),'minimum_projected_triangle_area_m2':float(cross.min()/2),'outer_boundary_exact':True,'all_triangle_centroids_inside_outer_domain':True,'only_outer_boundary_edges':True,'no_center_fan_or_internal_hole':True,'triangle_version':triangle.__version__};(R/'audit/forehead_pslg3_domain.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
