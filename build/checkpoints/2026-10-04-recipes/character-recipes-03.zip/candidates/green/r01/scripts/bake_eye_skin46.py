"""Bounded exact camera-ray atlas transfer onto the physical annular skin.
Source triangles are rasterized in the orthographic source-camera plane with a depth buffer.
No rendered light or geometry-acceptance claim is baked into this material study.
"""
import pathlib,sys,json,hashlib,numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];eye=int(sys.argv[1]);src=R/'Green_physical_eyes45_body.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][5+eye*3];uv=A(pr['attributes']['TEXCOORD_0']);tf=A(pr['indices']).reshape(-1,3);z=np.load(R/'audit/eye_globes43.npz');a={k:z[k]for k in z.files};z.close();outer=a[f'eye{eye}_outer'];low=outer.min(0)-.001;high=outer.max(0)+.001;S=2048
# Raster bounds include pixel centers; strict interior multiplicity is audited independently of edge coverage.
def pixels(tr):
 lo=np.maximum(np.floor(tr.min(0)).astype(int),0);hi=np.minimum(np.ceil(tr.max(0)).astype(int),S-1)
 if (lo>hi).any():return None
 x,y=np.meshgrid(np.arange(lo[0],hi[0]+1),np.arange(lo[1],hi[1]+1));e=tr[1]-tr[0];f=tr[2]-tr[0];den=e[0]*f[1]-e[1]*f[0]
 if abs(den)<1e-14:return None
 qx=x-tr[0,0];qy=y-tr[0,1];v=(qx*f[1]-qy*f[0])/den;w=(e[0]*qy-e[1]*qx)/den;u=1-v-w;return x,y,np.stack([u,v,w],-1)
occupied=np.zeros((S,S),bool);multiple=np.zeros((S,S),np.uint8);sampled=[]
for tri in uv[tf]*S-.5:
 hit=pixels(tri)
 if hit is None:sampled.append(0);continue
 x,y,w=hit;inside=(w>=-1e-7).all(2);strict=(w>1e-6).all(2);occupied[y[inside],x[inside]]=True;multiple[y[strict],x[strict]]+=1;sampled.append(int(inside.sum()))
assert multiple.max()<=1;assert min(sampled)>0
P=a['source_eye_frame'];F=a['source_triangles'];q=P[F];candidate=np.flatnonzero((q[:,:,0].max(1)>=low[0])&(q[:,:,0].min(1)<=high[0])&(q[:,:,2].max(1)>=low[1])&(q[:,:,2].min(1)<=high[1]));depth=np.full((S,S),np.inf,np.float32);field=np.zeros((S,S,2),np.float32);owner=np.full((S,S),-1,np.int8);sf=np.full((S,S),-1,np.int32)
for fi in candidate:
 tri=q[fi];coords=np.column_stack([(tri[:,0]-low[0])/(high[0]-low[0])*S-.5,(high[1]-tri[:,2])/(high[1]-low[1])*S-.5]);hit=pixels(coords)
 if hit is None:continue
 x,y,w=hit;inside=(w>=-1e-7).all(2);d=w@tri[:,1];take=inside&(d<depth[y,x]);yy,xx=y[take],x[take];depth[yy,xx]=d[take];field[yy,xx]=w[take]@a['source_uv'][F[fi]];owner[yy,xx]=a['source_primitive'][fi];sf[yy,xx]=fi
valid=owner>=0;miss=int((occupied&~valid).sum());assert miss==0,miss;inds=distance_transform_edt(~valid,return_distances=False,return_indices=True);field[~valid]=field[tuple(inds[:,~valid])];owner[~valid]=owner[tuple(inds[:,~valid])]
def decode(x):return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
def encode(x):return np.where(x<=.0031308,x*12.92,1.055*np.maximum(x,0)**(1/2.4)-.055)
mapPaths=[]
for kind,files in [('BaseColor',[R.parents[2]/'textures/prelod-cd4c20d/sus-green/0_base_color.webp',R/'textures/Green_Forehead4_BaseColor_2K.png']),('ORM',[R.parents[2]/'textures/prelod-cd4c20d/sus-green/1_metallic_roughness_occlusion.webp',R/'textures/Green_Forehead4_ORM_2K.png'])]:
 out=np.zeros((S,S,3),np.uint8)
 for material,file in enumerate(files):
  take=owner==material
  if not take.any():continue
  im=np.array(Image.open(file).convert('RGB'));H,W=im.shape[:2];xx=np.clip(field[take,0]*W-.5,0,W-1);yy=np.clip(field[take,1]*H-.5,0,H-1);i=np.floor(xx).astype(int);k=np.floor(yy).astype(int);i1=np.minimum(i+1,W-1);k1=np.minimum(k+1,H-1);u=(xx-i)[:,None];v=(yy-k)[:,None];samples=[im[k,i].astype(float)/255,im[k,i1].astype(float)/255,im[k1,i].astype(float)/255,im[k1,i1].astype(float)/255]
  if kind=='BaseColor':samples=[decode(x)for x in samples]
  col=(1-v)*((1-u)*samples[0]+u*samples[1])+v*((1-u)*samples[2]+u*samples[3])
  if kind=='BaseColor':col=encode(col)
  out[take]=np.round(np.clip(col,0,1)*255).astype(np.uint8)
 p=R/'textures'/f'Green_Eye{eye}_Skin46_{kind}_2K.png';Image.fromarray(out).save(p);mapPaths.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report={'source_geometry_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_camera_binding':'eye_globes43.npz / original exact head_angle_0 camera','eye':eye,'resolution':[S,S],'occupied_texels':int(occupied.sum()),'occupied_source_misses':miss,'strict_overlap_texels':int((multiple>1).sum()),'unsampled_target_faces':sum(x==0 for x in sampled),'source_materials_at_occupied':{str(k):int(((owner==k)&occupied).sum())for k in np.unique(owner[occupied])},'maps':mapPaths,'status':'Exact original-color/ORM projection transfer only. Rounded-canthus fringe and final geometry/paint must be inspected in actual views.'};(R/'audit'/f'eye{eye}_skin46_material.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
