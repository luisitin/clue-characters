"""Camera-bound six-view albedo projection. Cache archive arrays once before use."""
import numpy as np
class Projector:
 def __init__(self,a):
  self.a=a;images=a['images'].astype(float)/255;self.images=np.where(images<=.04045,images/12.92,((images+.055)/1.055)**2.4);mask=a['skin_distance']>3;self.fallback=np.median(self.images[mask],axis=0)
 def color(self,P,N):
  colors=np.zeros((len(P),3));weights=np.zeros(len(P));best=np.zeros(len(P));view_count=np.zeros(len(P),np.uint8)
  for k,C in enumerate(self.a['cameras']):
   pc=(P-C[:3,3])@C[:3,:3];xy=np.column_stack([pc[:,0]/self.a['scales'][k]+.5,.5-pc[:,1]/self.a['scales'][k]])*512;ix=np.clip(np.floor(xy[:,0]).astype(int),0,511);iy=np.clip(np.floor(xy[:,1]).astype(int),0,511);facing=np.maximum(N@C[:3,2],0);valid=(xy[:,0]>=.5)&(xy[:,0]<511.5)&(xy[:,1]>=.5)&(xy[:,1]<511.5)&(-pc[:,2]<=self.a['depths'][k,iy,ix]+.0009)&np.isfinite(self.a['depths'][k,iy,ix]);guard=np.clip((self.a['skin_distance'][k,iy,ix]-1)/2,0,1);w=facing**6*valid*guard;xx=np.clip(xy[:,0]-.5,0,510.999);yy=np.clip(xy[:,1]-.5,0,510.999);x=np.floor(xx).astype(int);y=np.floor(yy).astype(int);u=(xx-x)[:,None];v=(yy-y)[:,None];im=self.images[k];c=(1-v)*((1-u)*im[y,x]+u*im[y,x+1])+v*((1-u)*im[y+1,x]+u*im[y+1,x+1]);colors+=c*w[:,None];weights+=w;best=np.maximum(best,w);view_count+=w>.01
  good=weights>1e-6;colors[good]/=weights[good,None];colors[~good]=self.fallback;return colors,good,best,view_count
