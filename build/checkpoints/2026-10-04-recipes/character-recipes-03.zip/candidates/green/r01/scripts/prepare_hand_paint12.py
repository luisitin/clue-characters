"""Extract exact geometry/cameras and rasterize depth for bounded six-view paint transfer."""
import pathlib,sys,json,numpy as np,hashlib
from scipy.spatial.transform import Rotation
from scipy.ndimage import distance_transform_edt
from PIL import Image
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
from uv_raster import samples
src=R/'Green_openhand_forearm6.glb';j,b,A=read_glb(src);node=next(n for n in j['nodes']if'mesh'in n);M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0]);P=[];N=[];UV=[];F=[];owner=[];off=0
for k,pr in enumerate(j['meshes'][node['mesh']]['primitives']):
 p=A(pr['attributes']['POSITION']).astype('float32').astype(float);n=A(pr['attributes']['NORMAL']);w=(p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];nn=(n@np.linalg.inv(M[:3,:3]))[:,[0,2,1]]*[1,-1,1];nn/=np.linalg.norm(nn,axis=1)[:,None];f=A(pr['indices']).reshape(-1,3);P.append(w);N.append(nn);UV.append(A(pr['attributes']['TEXCOORD_0']));F.append(f+off);owner.extend([k]*len(f));off+=len(p)
P=np.vstack(P);N=np.vstack(N);UV=np.vstack(UV);F=np.vstack(F);owner=np.array(owner)
# Depth from the exact unchanged original painting input, including its diagnostic cap.
sj,sb,S=read_glb(R/'Green_openhand_thumb3_islands4.glb');sp=S(sj['meshes'][0]['primitives'][0]['attributes']['POSITION']).astype('float32');sw=(sp@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];sf=S(sj['meshes'][0]['primitives'][0]['indices']).reshape(-1,3)
names=['openhand_angle_-11_paint','openhand_angle_79_paint','openhand_angle_169_paint','openhand_angle_259_paint','openhand_top_paint','openhand_under_paint'];depths=[];cams=[];images=[];masks=[];scales=[];sheet=np.array(Image.open(R/'textures/painting_plates/Green_hand_skin_plate01.png').convert('RGB'));assert sheet.shape==(1024,1536,3)
for k,name in enumerate(names):
 meta=json.loads((R/'renders/hand_paint_inputs'/f'{name}.json').read_text());C=np.array(meta['camera_world_matrix']);pc=(sw-C[:3,3])@C[:3,:3];scale=meta['ortho_scale'];uv=np.column_stack([pc[:,0]/scale+.5,.5-pc[:,1]/scale]);zz=-pc[:,2];depth=np.full((512,512),np.inf,np.float32)
 for fi,y,x,bc in samples(uv[sf],512):
  z=bc@zz[sf[fi]];depth[y,x]=np.minimum(depth[y,x],z)
 im=sheet[(k//3)*512:(k//3+1)*512,(k%3)*512:(k%3+1)*512];mask=(im[:,:,0].astype(float)-im[:,:,2]>25)&(im[:,:,0].astype(float)-im[:,:,1]>12);guard=distance_transform_edt(mask);depths.append(depth);cams.append(C);scales.append(scale);images.append(im);masks.append(guard);print('view',k,'depth',int(np.isfinite(depth).sum()),'skin',int(mask.sum()),flush=True)
np.savez_compressed(R/'audit/hand_paint12_binding.npz',P=P,N=N,UV=UV,F=F,owner=owner,cameras=np.array(cams),scales=np.array(scales),depths=np.array(depths),images=np.array(images),skin_distance=np.array(masks,dtype='float32'));report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'painting_plate_sha256':hashlib.sha256((R/'textures/painting_plates/Green_hand_skin_plate01.png').read_bytes()).hexdigest(),'triangles':len(F),'views':names,'depth_resolution':512,'target_atlas_resolution':2048,'projection':'Exact saved orthographic camera matrices, original held input geometry depth, skin-background guard; new forearm receives continuous boundary colors separately.'};(R/'audit/hand_paint12_binding.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
