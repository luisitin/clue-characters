import pathlib,sys,numpy as np,json,hashlib
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
stem=sys.argv[1];res=int(sys.argv[2])if len(sys.argv)>2 else 2048;src=R/(stem+'.glb');j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);count=np.zeros((res,res),np.uint16);sampled=np.zeros(len(F),bool);area=np.zeros(len(F));deg=[];out=[]
for fi,tr in enumerate(F):
 q=UV[tr]*res;area[fi]=.5*abs(np.cross(q[1]-q[0],q[2]-q[0]));
 if area[fi]<1e-12:deg.append(fi);continue
 if ((q<0)|(q>res)).any():out.append(fi)
 lo=np.maximum(np.ceil(q.min(0)-.5).astype(int),0);hi=np.minimum(np.floor(q.max(0)-.5).astype(int),res-1)
 if(hi<lo).any():continue
 xx,yy=np.meshgrid(np.arange(lo[0],hi[0]+1)+.5,np.arange(lo[1],hi[1]+1)+.5);p=np.stack([xx,yy],-1)-q[0];e1=q[1]-q[0];e2=q[2]-q[0];den=np.cross(e1,e2);u=(p[:,:,0]*e2[1]-p[:,:,1]*e2[0])/den;v=(e1[0]*p[:,:,1]-e1[1]*p[:,:,0])/den;inside=(u>1e-7)&(v>1e-7)&(u+v<1-1e-7);sampled[fi]=inside.any();view=count[lo[1]:hi[1]+1,lo[0]:hi[0]+1];view+=inside.astype('uint16')
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'resolution':res,'triangles':len(F),'strict_interior_occupied_texels':int((count>0).sum()),'overlapping_strict_interior_texels':int((count>1).sum()),'maximum_multiplicity':int(count.max()),'zero_area_uv_faces':deg,'out_of_range_faces':out,'triangles_without_strict_texel_center':np.flatnonzero(~sampled).tolist(),'minimum_uv_area_texels':float(area.min()),'scope':'Unique skin/cap UV atlas; strict edge exclusion avoids shared-edge raster double counting. Subpixel coverage remains separate from zero overlap.'};(R/'audit'/(stem+f'_uv_{res}.json')).write_text(json.dumps(report,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in report.items()},flush=True)
