"""Find an exact retained-face boundary around the old locally nonmanifold eye sheets."""
import pathlib,json,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];z=np.load(R/'audit/eye_domains18.npz');a={k:z[k]for k in z.files};z.close();P=a['source_local'];Q=a['source_eye_frame'];F=a['source_triangles'];_,groups=np.unique(P,axis=0,return_inverse=True);G=groups[F];first=np.zeros(groups.max()+1,int)
for i,g in enumerate(groups):first[g]=i
edges={}
for fi,tr in enumerate(G):
 for u,v in zip(tr,np.roll(tr,-1)):edges.setdefault(tuple(sorted((int(u),int(v)))),[]).append((int(u),int(v),fi))
c=Q[F].mean(1);source_report=json.loads((R/'audit/eye_domains18.json').read_text());reports=[];out={k:v for k,v in a.items()if not k.startswith('eye')};pxscale=.46/1024
for eye in range(2):
 center=a[f'eye{eye}_center'];depth=source_report['eyes'][eye]['sampled_depth'];trials=[];valid=[]
 for rx in [61,64,68,72,76,82]:
  for rz in [44,48,52,56,60]:
   for dep in [.020,.030,.040]:
    mask=(a['source_primitive']==0)&(np.sum(((c[:,[0,2]]-center)/(np.array([rx,rz])*pxscale))**2,axis=1)<1)&(abs(c[:,1]-depth)<dep);ids=np.flatnonzero(mask);touch=set()
    for tr in G[ids]:
     for u,v in zip(tr,np.roll(tr,-1)):touch.add(tuple(sorted((int(u),int(v)))))
    boundary=[];ambig=[]
    for key in touch:
     keep=[x for x in edges[key]if not mask[x[2]]]
     if not keep:continue
     if len(keep)!=1:ambig.append(key);continue
     u,v,fi=keep[0];boundary.append((v,u,fi))
    nxt={};incoming={}
    for u,v,fi in boundary:nxt.setdefault(u,[]).append(v);incoming[v]=incoming.get(v,0)+1
    bad=[u for u,v in nxt.items()if len(v)!=1 or incoming.get(u,0)!=1];loops=[];left=set(nxt)
    if not bad and not ambig:
     while left:
      loop=[min(left)]
      while True:
       nextv=nxt[loop[-1]][0]
       if nextv==loop[0]:break
       if nextv in loop:break
       loop.append(nextv)
      if nextv!=loop[0]:break
      left-=set(loop);loops.append(loop)
    entry={'radii_px':[rx,rz],'depth_band_m':dep,'removed':len(ids),'boundary_edges':len(boundary),'ambiguous_retained_edges':len(ambig),'bad_directed_degrees':len(bad),'loops':[len(x)for x in loops]};trials.append(entry)
    if len(loops)==1 and not left and not bad and not ambig:
     bid=first[loops[0]];outer=Q[bid][:,[0,2]];area=.5*np.sum(outer[:,0]*np.roll(outer[:,1],-1)-outer[:,1]*np.roll(outer[:,0],-1));entry['signed_area_m2']=float(area)
     if area>0:valid.append((len(ids),rx*rz,entry,ids,bid,outer,boundary))
 assert valid,('No complete retained rim found',eye,[x for x in trials if x['bad_directed_degrees']<3 and x['ambiguous_retained_edges']==0])
 valid.sort(key=lambda x:x[:2]);_,_,best,ids,bid,outer,boundary=valid[0];support=[]
 for u,v in zip(groups[bid],np.roll(groups[bid],-1)):
  keep=[x for x in edges[tuple(sorted((int(u),int(v))))]if x[2]not in set(ids)]
  assert len(keep)==1 and keep[0][:2]==(int(v),int(u));support.append(keep[0][2])
 out[f'eye{eye}_selected']=ids;out[f'eye{eye}_boundary_source_ids']=bid;out[f'eye{eye}_outer']=outer;out[f'eye{eye}_center']=center;out[f'eye{eye}_retained_support']=np.array(support);reports.append({'eye':eye,'chosen':best,'valid_candidates':len(valid),'trials':trials})
np.savez_compressed(R/'audit/eye_domains19.npz',**out);report={'source_sha256':source_report['source_sha256'],'method':'Boundary comes from the sole retained source triangle on each touched edge, not from a manifold assumption about the removed layered interior. Directed retained edges must form exactly one positively oriented simple cycle.','eyes':reports,'status':'Domain proposal only; visible ownership, strict aperture containment and tangent/area checks precede construction.'};(R/'audit/eye_domains19.json').write_text(json.dumps(report,indent=2));print([{k:v for k,v in r.items()if k!='trials'}for r in reports],flush=True)
