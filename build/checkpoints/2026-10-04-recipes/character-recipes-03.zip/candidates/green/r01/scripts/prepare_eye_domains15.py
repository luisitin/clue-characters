"""Measure bounded source eye disks and exact rim topology before annulus generation."""
import pathlib,sys,json,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_quality14_body.glb';j,buf,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];sc=np.array(node['scale']);trans=np.array(node['translation']);W=(P*sc+trans)[:,[0,2,1]]*[1,-1,1];WN=(N/sc)[:,[0,2,1]]*[1,-1,1];WN/=np.linalg.norm(WN,axis=1)[:,None];meta=json.loads((R/'renders/forehead_pslg5/head_angle_0_paint.json').read_text());C=np.array(meta['camera_world_matrix']);origin=np.array(meta['target']);basis=np.column_stack([C[:3,0],-C[:3,2],C[:3,1]]);Q=(W-origin)@basis;QN=WN@basis;tree=BVHTree.FromPolygons(W.tolist(),F.tolist(),all_triangles=True);_,groups=np.unique(P,axis=0,return_inverse=True);G=groups[F];first=np.zeros(groups.max()+1,int)
for k,g in enumerate(groups):first[g]=k
reports=[];bindings={'source_world':W,'source_local':P,'source_normal_local':N,'source_normal_eye_frame':QN,'source_triangles':F,'source_uv':UV,'source_eye_frame':Q,'frame_origin':origin,'frame_basis':basis}
for ei,(px,py,rx,rz)in enumerate([(431,443,61,44),(635,455,61,44)]):
 center=np.array([(px/1024-.5)*meta['ortho_scale'],(.5-py/1024)*meta['ortho_scale']]);originRay=origin+basis[:,0]*center[0]+basis[:,2]*center[1]-basis[:,1]*.3;hit,gn,fi,dist=tree.ray_cast(Vector(originRay),Vector(basis[:,1]),.6);assert hit is not None;depth=float((np.array(hit)-origin)@basis[:,1]);c=Q[F].mean(1);radii=np.array([rx,rz])/1024*meta['ortho_scale'];mask=(np.sum(((c[:,[0,2]]-center)/radii)**2,axis=1)<1)&(abs(c[:,1]-depth)<.020);ids=np.flatnonzero(mask);edges={}
 for ti in ids:
  for a,b in zip(G[ti],np.roll(G[ti],-1)):edges.setdefault(tuple(sorted((int(a),int(b)))),[]).append((int(a),int(b),int(ti)))
 boundary=[v[0]for v in edges.values()if len(v)==1];adj={};direct={}
 for a,b,f in boundary:adj.setdefault(a,[]).append(b);adj.setdefault(b,[]).append(a);direct.setdefault(a,[]).append(b)
 bad={str(k):len(v)for k,v in adj.items()if len(v)!=2};loops=[];left=set(adj)
 if not bad:
  while left:
   loop=[min(left)];previous=None
   while True:
    nxt=next(x for x in adj[loop[-1]]if x!=previous)
    if nxt==loop[0]:break
    assert nxt not in loop;previous=loop[-1];loop.append(nxt)
   left-=set(loop);loops.append(loop)
 row={'eye':ei,'center_pixel':[px,py],'center_eye_frame_xz':center.tolist(),'sampled_depth':depth,'selected_triangles':len(ids),'internal_nonmanifold_edges':sum(len(v)>2 for v in edges.values()),'boundary_edges':len(boundary),'boundary_bad_degrees':bad,'loop_sizes':[len(x)for x in loops]}
 if len(loops)==1:
  idsB=first[loops[0]];outer=Q[idsB][:,[0,2]];signed=np.sum(outer[:,0]*np.roll(outer[:,1],-1)-outer[:,1]*np.roll(outer[:,0],-1))*.5
  if signed<0:idsB=idsB[::-1];outer=outer[::-1]
  # Each annulus outer edge must have one unambiguous retained supporting face.
  support=[]
  for a,b in zip(groups[idsB],np.roll(groups[idsB],-1)):
   fs=np.flatnonzero(~mask&np.any(G==a,axis=1)&np.any(G==b,axis=1));support.append(fs.tolist())
  row['unambiguous_retained_edge_support']=all(len(x)==1 for x in support);row['retained_support_faces']=support;bindings[f'eye{ei}_boundary_source_ids']=idsB;bindings[f'eye{ei}_outer']=outer
 bindings[f'eye{ei}_selected']=ids;bindings[f'eye{ei}_center']=center;reports.append(row)
np.savez_compressed(R/'audit/eye_domains15.npz',**bindings);report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'camera_provenance':'Saved exact forehead5 head0 orthographic world matrix','eyes':reports,'status':'Read-only source disk/domain measurement. Apertures, tangent constraints, globe fit and physical eyes are not built or approved.'};(R/'audit/eye_domains15.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
