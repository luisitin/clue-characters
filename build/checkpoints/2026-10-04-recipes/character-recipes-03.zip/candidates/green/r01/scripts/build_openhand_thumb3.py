"""Rebuild a native-UV CC0 hand study; no source-body replacement is performed."""
import bpy,bmesh,pathlib,json,sys,hashlib,math,numpy as np
from mathutils import Vector,Matrix,Quaternion
R=pathlib.Path(__file__).resolve().parents[1];DROOT=R.parents[2]/'shared_sources/makehuman';sys.path.insert(0,str(DROOT/'scripts'));from load_donor import load_donor
D=load_donor();V=D['positions'];F=D['faces'];G=D['face_group'];UV=D['uv'];FU=D['face_uv'];J={g:V[np.unique(np.concatenate([F[i]for i in np.flatnonzero(G==g)]))].mean(0)for g in np.unique(G)if g.startswith('joint-l-')};wrist=J['joint-l-hand'];mid=np.mean([J[f'joint-l-finger-{i}-1']for i in range(2,6)],axis=0);L=mid-wrist;L/=np.linalg.norm(L);A=J['joint-l-finger-2-1']-J['joint-l-finger-5-1'];A-=A.dot(L)*L;A/=np.linalg.norm(A);N=np.cross(L,A);B=np.stack([L,N,A]);Q=(V-wrist)@B.T;faceids=[i for i in D['body_face_ids']if(Q[F[i],0]>-.19).all()and(V[F[i],0]>3.5).all()and(V[F[i],1]<2.9).all()];ids=np.unique(np.concatenate([F[i]for i in faceids]));lookup={int(v):k for k,v in enumerate(ids)};faces=[[lookup[v]for v in F[i]]for i in faceids]
if np.linalg.det(B)<0:faces=[list(reversed(f))for f in faces]
# Explicit rest edge direction audit before any deformation.
edges={}
for fi,face in enumerate(faces):
 for x,y in zip(face,face[1:]+face[:1]):edges.setdefault(tuple(sorted((x,y))),[]).append((x,y))
conflicts=[k for k,v in edges.items()if len(v)==2 and v[0]==v[1]];assert not conflicts and max(map(len,edges.values()))<=2
bpy.ops.wm.read_factory_settings(use_empty=True);me=bpy.data.meshes.new('Native rest hand topology');me.from_pydata(Q[ids].tolist(),[],faces);me.update();o=bpy.data.objects.new('Green anatomical open hand study',me);bpy.context.collection.objects.link(o);uv=me.uv_layers.new(name='Native MakeHuman corner UV')
for p,fi in zip(me.polygons,faceids):
 corner_uv=list(reversed(FU[fi]))if np.linalg.det(B)<0 else FU[fi]
 for li,ui in zip(p.loop_indices,corner_uv):uv.data[li].uv=UV[ui]
for p in me.polygons:p.use_smooth=True
rd=bpy.data.armatures.new('Native hand local pose rig');rig=bpy.data.objects.new('Green hand pose rig',rd);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT');palm=rd.edit_bones.new('palm');palm.head=(0,0,0);palm.tail=(.95,0,0)
for fi in range(1,6):
 parent=palm
 for k in range(1,4):
  bn=rd.edit_bones.new(f'finger{fi}_{k}');bn.head=Vector(B@(J[f'joint-l-finger-{fi}-{k}']-wrist));bn.tail=Vector(B@(J[f'joint-l-finger-{fi}-{k+1}']-wrist));bn.parent=parent;bn.use_connect=k>1;parent=bn
bpy.ops.object.mode_set(mode='OBJECT');weightnames=['palm']+[f'finger{i}_{k}'for i in range(1,6)for k in range(1,4)];weights=np.zeros((len(ids),len(weightnames)))
for col,name in enumerate(D['bone_names']):
 target='palm'
 if name.startswith('finger')and name.endswith('.L'):
  number,segment=name[6:-2].split('-');target=f'finger{number}_{segment}'
 weights[:,weightnames.index(target)]+=D['weights_normalized'][ids,col]
assert np.max(abs(weights.sum(1)-1))<1e-8
for col,name in enumerate(weightnames):
 vg=o.vertex_groups.new(name=name)
 for vi,w in enumerate(weights[:,col]):
  if w>0:vg.add([vi],float(w),'REPLACE')
mod=o.modifiers.new('Official normalized weight deformation','ARMATURE');mod.object=rig;mod.use_deform_preserve_volume=True;angles={1:[0,6,4],2:[32,58,32],3:[32,58,32],4:[32,58,32],5:[38,65,38]}
for fi in range(1,6):
 for k,degree in enumerate(angles[fi],1):
  pb=rig.pose.bones[f'finger{fi}_{k}'];rest=rd.bones[pb.name];axis=(rest.tail_local-rest.head_local).normalized().cross(Vector((0,1,0))).normalized();pb.rotation_mode='QUATERNION';pb.rotation_quaternion=Quaternion(rest.matrix_local.to_3x3().inverted()@axis,math.radians(degree));assert tuple(pb.scale)==(1.,1.,1.)
pb=rig.pose.bones['finger1_1'];rest=rd.bones[pb.name];t=(rest.tail_local-rest.head_local).normalized();hinge=t.cross(Vector((0,1,0))).normalized();inv=rest.matrix_local.to_3x3().inverted();pb.rotation_quaternion=Quaternion(inv@Vector((0,1,0)),math.radians(-42.9718))@Quaternion(inv@hinge,math.radians(-26.6061))@Quaternion(inv@t,math.radians(45.0001))@pb.rotation_quaternion
bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name);posed=np.array([v.co[:]for v in me.vertices]);u=np.array([-.38,-.925,.045]);u/=np.linalg.norm(u);n=np.array([0.,0.,1.]);n-=u*(u@n);n/=np.linalg.norm(n);wide=np.cross(u,n);OB=np.column_stack([u,n,wide]);scale=np.array([.107,.102,.109]);anchor=np.array([-.338,-.158,.207]);world=posed.copy();world[:,2]*=1-.14*np.clip((world[:,0]-.7)/.5,0,1);world=anchor+(world*scale)@OB.T;me.vertices.foreach_set('co',world.astype('float32').ravel());me.update();sub=o.modifiers.new('Anatomical surface subdivision','SUBSURF');sub.levels=2;sub.render_levels=2;bpy.ops.object.modifier_apply(modifier=sub.name);me=o.data
# Close only the hidden proximal cut. It gets a reserved nonoverlapping planar chart.
bm=bmesh.new();bm.from_mesh(me);boundary=[e for e in bm.edges if e.is_boundary];created=bmesh.ops.holes_fill(bm,edges=boundary,sides=0)['faces'];assert len(created)==1;cap=created[0];uvlayer=bm.loops.layers.uv.active;capP=np.array([v.co[:]for v in cap.verts]);center=capP.mean(0);_,_,axes=np.linalg.svd(capP-center,full_matrices=False);xy=(capP-center)@axes[:2].T;low=xy.min(0);high=xy.max(0);mapped=.02+(xy-low)/(high-low)*.035
for loop,coord in zip(cap.loops,mapped):loop[uvlayer].uv=coord
for face in bm.faces:face.smooth=True
bm.to_mesh(me);bm.free();me.update();bpy.data.objects.remove(rig,do_unlink=True);o.location=(.002810508,-.000833660,.006596714);mat=bpy.data.materials.new('Temporary skin diagnostic');mat.use_nodes=True;bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(.63,.32,.18,1);bs.inputs['Roughness'].default_value=.5;me.materials.append(mat);bpy.context.view_layer.update();tri=o.modifiers.new('Exportable explicit triangles','TRIANGULATE');tri.keep_custom_normals=True;bpy.ops.object.modifier_apply(modifier=tri.name);me=o.data;me.calc_loop_triangles();baseworld=np.array([(o.matrix_world@v.co)[:]for v in me.vertices]);F2=np.array([t.vertices[:]for t in me.loop_triangles]);volume=float(np.sum(baseworld[F2[:,0]]*np.cross(baseworld[F2[:,1]],baseworld[F2[:,2]]))/6);assert volume>0,'Rest-space winding orientation failed';np.savez_compressed(R/'audit/openhand_thumb3_binding.npz',donor_vertex_ids=ids,donor_face_ids=faceids,rest_local=Q[ids],posed_lowres_local=posed,normalized_weights=weights,world_positions=baseworld,triangles=F2,native_basis=B,world_basis=OB,scale=scale,anchor=anchor)
# The root pose is an explicit study, not an integrated wrist fit.
root=np.array([[.9438086748123169,.2133011519908905,-.25244367122650146,.07198913395404816],[-.2682882249355316,.048436518758535385,-.9621202349662781,-.04318392276763916],[-.1929938644170761,.9757850766181946,.10294099152088165,.2750556170940399],[0,0,0,1]])
o.matrix_world=Matrix(root.tolist());bpy.context.view_layer.update();report={'source_manifest_sha256':hashlib.sha256((DROOT/'provenance/manifest.json').read_bytes()).hexdigest(),'donor_faces':len(faceids),'donor_vertices':len(ids),'rest_winding_conflicts':0,'negative_determinant_basis_winding_reversed':bool(np.linalg.det(B)<0),'closed_signed_volume_m3':volume,'normalized_weights_max_error':float(abs(weights.sum(1)-1).max()),'joint_scale_one':True,'angles_degrees':angles,'CMC_opposition_flexion_roll_degrees':[-42.9718,-26.6061,45.0001],'CMC_order':'opposition @ flexion @ axial-roll @ held base flexion','triangles':len(me.loop_triangles),'native_corner_UV_preserved_before_reserved_cap_chart':True,'status':'New anatomical hand seed; root orientation is a context study. Self-intersections, cap UV overlap, thumb pose, painting and cuff contact are not cleared'};(R/'audit/openhand_thumb3.json').write_text(json.dumps(report,indent=2));print(report,flush=True);bpy.ops.wm.save_as_mainfile(filepath=str(R/'Green_openhand_thumb3.blend'),compress=True);bpy.ops.export_scene.gltf(filepath=str(R/'Green_openhand_thumb3.glb'),export_format='GLB',export_yup=True,export_tangents=True,export_animations=False,export_cameras=False,export_lights=False)
