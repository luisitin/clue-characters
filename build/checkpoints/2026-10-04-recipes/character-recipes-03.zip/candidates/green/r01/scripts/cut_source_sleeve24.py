"""Remove a complete connected distal hand through an exact shared support-plane contour."""
import pathlib,sys,json,hashlib,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
src=R/'Green_forehead_pslg5_painted.glb';j,buf,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');N=A(pr['attributes']['NORMAL']);UV=A(pr['attributes']['TEXCOORD_0']);F=A(pr['indices']).reshape(-1,3);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);W=(P*scale+translation)[:,[0,2,1]]*[1,-1,1];z=np.load(R/'audit/sleeve_cut24_binding.npz');selected=z['selected_faces'];C=z['center'];axis=z['axis'];phase=float(z['phase']);d=(W-C)@axis-phase
V=[];NN=[];UU=[];FF=[];segments=[];mixed=[];cutcache={};un,g=np.unique(P,axis=0,return_inverse=True)
def corner(a):return (P[a].astype(float),N[a],UV[a])
def cut(a,b):
 t=float(d[a]/(d[a]-d[b]));key=tuple(sorted((int(g[a]),int(g[b]))));pos=cutcache.setdefault(key,(P[a]+t*(P[b]-P[a])).astype('float32'));n=N[a]+t*(N[b]-N[a]);n/=np.linalg.norm(n);return (pos,n,UV[a]+t*(UV[b]-UV[a]))
for fi in selected:
 tr=F[fi]
 if d[tr].min()>=0:continue
 assert d[tr].max()>0;mixed.append(int(fi));poly=[];edge=[]
 for a,b in zip(tr,np.roll(tr,-1)):
  if d[a]<=0:poly.append(corner(a))
  if d[a]*d[b]<0:
   c=cut(a,b);poly.append(c);edge.append(c[0])
 assert len(edge)==2;segments.append(edge);base=len(V)
 for p,n,uv in poly:V.append(p);NN.append(n);UU.append(uv)
 for k in range(1,len(poly)-1):FF.append([base,base+k,base+k+1])
V=np.array(V,dtype='float32');NN=np.array(NN,dtype='float32');UU=np.array(UU,dtype='float32');FF=np.array(FF,dtype='uint32');segments=np.array(segments,dtype='float32');points,groups=np.unique(segments.reshape(-1,3),axis=0,return_inverse=True);E=groups.reshape(-1,2);adj={}
for a,b in E:adj.setdefault(int(a),[]).append(int(b));adj.setdefault(int(b),[]).append(int(a))
assert all(len(v)==2 for v in adj.values());loop=[0];previous=None
while True:
 nxt=next(x for x in adj[loop[-1]]if x!=previous)
 if nxt==loop[0]:break
 assert nxt not in loop;previous=loop[-1];loop.append(nxt)
assert len(loop)==len(points) and 80<len(loop)<220;ringP=points[loop];ringW=(ringP*scale+translation)[:,[0,2,1]]*[1,-1,1];gn=np.sum(np.cross(ringW-ringW.mean(0),np.roll(ringW,-1,axis=0)-ringW.mean(0)),axis=0)
if gn@axis<0:ringP=ringP[::-1];ringW=ringW[::-1]
# Exact source corner normals at cut, averaged only across coincident support positions.
ringN=[]
for p in ringP:
 use=np.all(V==p,axis=1);n=NN[use].mean(0);n/=np.linalg.norm(n);ringN.append(n)
held=np.ones(len(F),bool);held[selected]=False;pr['indices'],buf=append_accessor(j,buf,F[held].astype('uint32').ravel(),'SCALAR',34963);attrs={}
for name,a,kind in [('POSITION',V,'VEC3'),('NORMAL',NN,'VEC3'),('TEXCOORD_0',UU,'VEC2')]:attrs[name],buf=append_accessor(j,buf,a,kind,34962)
ix,buf=append_accessor(j,buf,FF.ravel(),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':pr['material'],'mode':4});out=R/'Green_source_sleeve_cut24.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/sleeve_cut24_exact_ring.npz',ring_local=ringP,ring_world=ringW,ring_local_normals=np.array(ringN),axis=axis,center=C,phase=phase,clipped_positions=V,clipped_triangles=FF,removed_source_faces=selected,mixed_faces=np.array(mixed));report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_component_faces':len(selected),'mixed_source_faces':len(mixed),'new_clipped_triangles':len(FF),'support_ring_vertices':len(ringP),'closed_ring':True,'all_unchanged_source_attributes_maps_materials_node_and_binary_prefix_retained':True,'unapproved':'Open support ring is expected; physical cuff is not present yet.'};(R/'audit/sleeve_cut24_exact.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
