import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
from intersection_kernel_v2 import audit
stem=sys.argv[1];kind=sys.argv[2];src=R/(stem+'.glb');j,b,A=read_glb(src);nodes=[n for n in j['nodes']if'mesh'in n];assert len(nodes)==1;node=nodes[0];mesh=j['meshes'][node['mesh']];positions=[];normals=[];faces=[];offset=0
for pr in mesh['primitives']:
 points=A(pr['attributes']['POSITION']).astype('float32').astype(float);positions.append(points);normals.append(A(pr['attributes']['NORMAL']).astype(float));faces.append(A(pr['indices']).reshape(-1,3)+offset);offset+=len(points)
P=np.vstack(positions);F=np.vstack(faces);N=np.vstack(normals)
if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
else:
 M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
P=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];bounds=None
if kind=='forehead':
 d=np.load(R/'audit/forehead_depth_trial02_binding.npz');q=np.concatenate([d['old_world'][d['active_vertices']],d['new_world'][d['active_vertices']]]);bounds=np.r_[q.min(0)-.002,q.max(0)+.002].tolist()
if kind.startswith('pslg'):
 d=np.load(R/('audit/forehead_'+kind+'_binding.npz'));q=d['patch_world'];bounds=np.r_[q.min(0)-.002,q.max(0)+.002].tolist()
result=audit(P,F,bounds=bounds);used=np.unique(F);length=np.linalg.norm(N[used],axis=1);result.update(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),referenced_nonfinite_normals=int((~np.isfinite(N[used]).all(1)).sum()),referenced_zero_normals=int((length<1e-6).sum()),referenced_max_normal_unit_error=float(abs(length-1).max()),position_decode_precision='float32, matching glTF consumer vertex precision',copy_group_scope='full object even when crossings are bounded',intersection_kernel_sha256=hashlib.sha256((R/'scripts/intersection_kernel.py').read_bytes()).hexdigest());(R/'audit'/(stem+'_surface_audit_v2.json')).write_text(json.dumps(result,indent=2));print({k:len(v)if isinstance(v,list)else v for k,v in result.items()},flush=True)
