import pathlib,sys,json,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_forehead_pslg4_geometry.glb';j,b,A=read_glb(src);n=j['nodes'][0];ps=[];fs=[];off=0
for p in j['meshes'][0]['primitives']:
 P=A(p['attributes']['POSITION']).astype('float32').astype(float);ps.append(P);fs.append(A(p['indices']).reshape(-1,3)+off);off+=len(P)
P=np.vstack(ps);P=(P*np.array(n['scale'])+np.array(n['translation']))[:,[0,2,1]]*[1,-1,1];F=np.vstack(fs);old=json.load(open(R/'audit/Green_forehead_pslg4_geometry_surface_audit.json'));rows=[]
def bary(p,t):
 e=t[1]-t[0];f=t[2]-t[0];q=p-t[0];aa=e@e;bb=e@f;cc=f@f;dd=q@e;ee=q@f;den=aa*cc-bb*bb;v=(cc*dd-bb*ee)/den;w=(aa*ee-bb*dd)/den;return np.array([1-v-w,v,w])
for hit in old['proper_crossings']:
 a,b=hit['faces'];pa=P[F[a]];pb=P[F[b]];na=np.cross(pa[1]-pa[0],pa[2]-pa[0]);nb=np.cross(pb[1]-pb[0],pb[2]-pb[0]);na/=np.linalg.norm(na);nb/=np.linalg.norm(nb);da=(pa-pb[0])@nb;db=(pb-pa[0])@na;point=np.array(hit['midpoint']);ba=bary(point,pa);bb=bary(point,pb);strictA=bool(da.min()<-1e-12 and da.max()>1e-12);strictB=bool(db.min()<-1e-12 and db.max()>1e-12);rows.append({'faces':[a,b],'reported_length_m':hit['length'],'triangle_A_world':pa.tolist(),'triangle_B_world':pb.tolist(),'A_signed_distance_to_B_plane_m':da.tolist(),'B_signed_distance_to_A_plane_m':db.tolist(),'both_strictly_straddle_other_plane':strictA and strictB,'reported_midpoint_barycentric_A':ba.tolist(),'reported_midpoint_barycentric_B':bb.tolist(),'reported_midpoint_inside_both':bool(ba.min()>=-1e-7 and bb.min()>=-1e-7),'normal_cross_length':float(np.linalg.norm(np.cross(na,nb)))})
report={'pairs':rows,'reported_pairs':len(rows),'both_strictly_straddle':sum(r['both_strictly_straddle_other_plane']for r in rows),'reported_midpoints_inside_both':sum(r['reported_midpoint_inside_both']for r in rows),'scope':'Independent plane-side and barycentric verification of every reported patch pair; no geometry change or general tolerance relaxation'};(R/'audit/forehead_crossing_attribution.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items()if k!='pairs'},flush=True)
