import pathlib,numpy as np,json
from scipy.interpolate import CubicSpline,RectBivariateSpline
from scipy.ndimage import gaussian_filter,gaussian_filter1d
R=pathlib.Path(__file__).resolve().parents[1];d=np.load(R/'audit/forehead_cylinder_source.npz');a=d['theta'];v=d['height'];rho=d['radius'];dom=np.load(R/'audit/forehead_pslg3_domain.npz');V=dom['vertices'];nb=int(dom['boundary_count'])
def s(x):x=np.clip(x,0,1);return x*x*x*(10+x*(-15+6*x))
knots=np.array([[-1.35,.035],[-1.1,.072],[-.9,.092],[-.75,.101],[-.55,.096],[-.3,.082],[0,.072],[.20,.067],[.45,.077],[.75,.079],[1,.075],[1.2,.076],[1.35,.063]])
h=CubicSpline(knots[:,0],knots[:,1],bc_type='natural')(a);center=.046-.009*s((a+.15)/.8);base=[];slope=[]
for k,c in enumerate(center):
 rows=(v>=c-.010)&(v<=c-.002);coef=np.polynomial.polynomial.polyfit(v[rows]-c,rho[rows,k],1);base.append(coef[0]);slope.append(coef[1])
base=gaussian_filter1d(base,2);slope=gaussian_filter1d(np.clip(slope,-.25,.10),2);smoothrho=gaussian_filter(rho,1.2);fore=np.array(base)[None]+(v[:,None]-center[None])*slope[None];upper=s((v[:,None]-(h[None]-.006))/.026);bottom=s((v[:,None]-(center[None]-.014))/.020);angular=s((a[None]+1.30)/.20)*s((1.35-a[None])/.18);target=smoothrho+np.minimum(fore-smoothrho,0)*(1-upper)*bottom*angular;target=gaussian_filter(target,.5);theta=V[:,0]/.09;z=V[:,1];query=RectBivariateSpline(v,a,target,kx=3,ky=3).ev(z,theta);distance=np.full(len(V),np.inf)
for p,q in zip(V[:nb],np.roll(V[:nb],-1,axis=0)):
 e=q-p;t=np.clip(((V-p)@e)/(e@e),0,1);distance=np.minimum(distance,np.linalg.norm(V-p-t[:,None]*e,axis=1))
weight=s(distance/.004)*s((theta+1.35)/.07)*s((1.35-theta)/.07)*s((z-.020)/.012)*s((.140-z)/.014);weight[:nb]=0;np.savez_compressed(R/'audit/forehead_surface4_targets.npz',target_radius=query,weight=weight,grid_target=target,theta=a,height=v);print({'min_target_radius_m':float(query.min()),'max_target_radius_m':float(query.max()),'fully_supported_vertices':int((weight>.999).sum()),'boundary_positions_held':nb},flush=True)
