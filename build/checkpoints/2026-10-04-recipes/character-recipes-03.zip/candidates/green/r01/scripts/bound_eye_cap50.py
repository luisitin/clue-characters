"""Close only the hidden extent of the far ellipsoid, holding its analytic visible surface."""
import pathlib,sys,json,hashlib,numpy as np
from glb_source import read_glb,append_accessor,write_glb
R=pathlib.Path(__file__).resolve().parents[1];sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
src=R/'Green_physical_eyes49_source_shape_body.glb';j,buf,A=read_glb(src);z=np.load(R/'audit/eye_globes43.npz');a={k:z[k]for k in z.files};z.close();node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);frame=a['frame_basis'];origin=a['frame_origin'];eye=0;skin=j['meshes'][0]['primitives'][5];p=A(skin['attributes']['POSITION']);W=(p*scale+translation)[:,[0,2,1]]*[1,-1,1];Q=(W-origin)@frame;no=len(a['eye0_outer']);ni=192;outer=Q[no+ni:no+ni*2][:,[0,2]];basis=a['eye0_globe_basis'];C=a['eye0_globe_center'];radii=a['eye0_globe_radii'];n=len(outer)
def inside(poly,pts):
 h=np.zeros(len(pts),bool)
 for u,v in zip(poly,np.roll(poly,-1,axis=0)):h^=((u[1]>pts[:,1])!=(v[1]>pts[:,1]))&(pts[:,0]<(v[0]-u[0])*(pts[:,1]-u[1])/(v[1]-u[1]+1e-300)+u[0])
 return h
x,z=np.meshgrid(np.arange(outer[:,0].min(),outer[:,0].max(),.00042),np.arange(outer[:,1].min(),outer[:,1].max(),.00042));samples=np.column_stack([x.ravel(),z.ravel()]);samples=samples[inside(outer,samples)];distance=np.full(len(samples),np.inf)
for u,v in zip(outer,np.roll(outer,-1,axis=0)):
 e=v-u;t=np.clip(((samples-u)@e)/(e@e),0,1);distance=np.minimum(distance,np.linalg.norm(samples-u-t[:,None]*e,axis=1))
samples=samples[distance>.00012];vertices=np.vstack([outer,samples]);segments=np.column_stack([np.arange(n),np.roll(np.arange(n),-1)]);t=triangle.triangulate({'vertices':vertices,'segments':segments},'pYq24Q');V=t['vertices'];F=t['triangles'];qq=(np.column_stack([V[:,0],np.zeros(len(V)),V[:,1]])-C)@basis;d=np.array([0.,1,0])@basis;aa=np.sum((d/radii)**2);bb=2*np.sum(qq*d/radii**2,axis=1);cc=np.sum((qq/radii)**2,axis=1)-1;disc=bb*bb-4*aa*cc;assert (disc>0).all();Y=(-bb-np.sqrt(disc))/(2*aa);front=np.column_stack([V[:,0],Y,V[:,1]]);local=(front-C)@basis;N=(local/radii**2)@basis.T;N/=np.linalg.norm(N,axis=1)[:,None];back=front+[0,.003,0];side=np.vstack([front[:n],back[:n]]);SF=[]
for i in range(n):k=(i+1)%n;SF.extend([[i,k,k+n],[i,k+n,i+n]])
SF=np.array(SF);SN=np.zeros_like(side);gn=np.cross(side[SF[:,1]]-side[SF[:,0]],side[SF[:,2]]-side[SF[:,0]])
for k in range(3):np.add.at(SN,SF[:,k],gn)
SN/=np.linalg.norm(SN,axis=1)[:,None];capQ=np.vstack([front,back,side]);capN=np.vstack([N,-N,SN]);capF=np.vstack([F,F[:,[0,2,1]]+len(front),SF+2*len(front)]);uv=np.column_stack([.5+np.arctan2(local[:,1]/radii[1],local[:,0]/radii[0])/(2*np.pi),np.arccos(np.clip(local[:,2]/radii[2],-1,1))/np.pi]);backUV=np.column_stack([(uv[:,0]+.5)%1,1-uv[:,1]]);UV=np.vstack([uv,backUV,uv[:n],backUV[:n]]);cu=UV[capF].copy()
for row in cu:
 if np.ptp(row[:,0])>.5:row[row[:,0]<.5,0]+=1
W=capQ@frame.T+origin;WN=capN@frame.T;P=(W[:,[0,2,1]]*[1,1,-1]-translation)/scale;LN=WN[:,[0,2,1]]*[1,1,-1]*scale;LN/=np.linalg.norm(LN,axis=1)[:,None];pr=j['meshes'][0]['primitives'][7];attrs={}
for key,arr,kind in [('POSITION',P[capF].reshape(-1,3),'VEC3'),('NORMAL',LN[capF].reshape(-1,3),'VEC3'),('TEXCOORD_0',cu.reshape(-1,2),'VEC2')]:attrs[key],buf=append_accessor(j,buf,arr.astype('float32'),kind,34962)
ix,buf=append_accessor(j,buf,np.arange(capF.size,dtype='uint32'),'SCALAR',34963);pr['attributes']=attrs;pr['indices']=ix;out=R/'Green_physical_eyes50_bounded_cap_body.glb';write_glb(out,j,buf);rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bounded_eye':0,'closed_cap_triangles':len(capF),'front_triangles':len(F),'rim_vertices':n,'backing_depth_m':.003,'surface_definition':'Same held analytic ellipsoid front; rear extent bounded to the protected outer lip polygon, with an explicit closed backing and independently normaled sidewall.','front_ellipsoid_equation_error':float(abs(np.sum((local/radii)**2,axis=1)-1).max()),'source_cheek_and_other_eye_held':True,'status':'Unadopted bounded cap; exact full changed-region crossings, complete closed edges and appearance pending.'};(R/'audit/eyes50.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
