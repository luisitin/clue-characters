"""Compare revised orbital skin against exact retained-source orthographic first hits."""
import pathlib,sys,json,hashlib,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_physical_eyes45_body.glb';j,b,A=read_glb(src);z=np.load(R/'audit/eye_globes43.npz');a={k:z[k]for k in z.files};z.close();sourceP=a['source_eye_frame'];sourceF=a['source_triangles'];sourceN=a['source_normal_eye_frame'];bvh=BVHTree.FromPolygons(sourceP.tolist(),sourceF.tolist(),all_triangles=True);node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);data={};reports=[]
for eye in range(2):
 pr=j['meshes'][0]['primitives'][5+eye*3];P=A(pr['attributes']['POSITION']);W=(P*scale+translation)[:,[0,2,1]]*[1,-1,1];Q=(W-a['frame_origin'])@a['frame_basis'];inner=a[f'eye{eye}_aperture'];distance=np.full(len(Q),np.inf)
 for p,q in zip(inner,np.roll(inner,-1,axis=0)):
  e=q-p;t=np.clip(((Q[:,[0,2]]-p)@e)/(e@e),0,1);distance=np.minimum(distance,np.linalg.norm(Q[:,[0,2]]-p-t[:,None]*e,axis=1))
 sourceY=np.full(len(Q),np.nan);sourceNormals=np.zeros_like(Q);faces=np.full(len(Q),-1,int);front=[]
 for k,p in enumerate(Q):
  hit,n,fi,d=bvh.ray_cast(Vector((float(p[0]),-2.,float(p[2]))),Vector((0,1,0)),4.)
  if hit is None:continue
  sourceY[k]=hit[1];faces[k]=fi;tri=sourceP[sourceF[fi]];mat=np.column_stack([tri[:,0],tri[:,2],np.ones(3)]);weights=np.array([p[0],p[2],1])@np.linalg.inv(mat);nn=weights@sourceN[sourceF[fi]];nn/=np.linalg.norm(nn);sourceNormals[k]=nn;front.append(float(n[1]))
 good=np.isfinite(sourceY);assert good.all();drift=Q[:,1]-sourceY;rows={}
 for threshold in [.001,.002,.004,.006,.010]:
  mask=distance>threshold;rows[str(threshold)]={'vertices':int(mask.sum()),'max_absolute_depth_m':float(abs(drift[mask]).max()),'p95_absolute_depth_m':float(np.percentile(abs(drift[mask]),95)),'median_signed_depth_m':float(np.median(drift[mask]))}
 data[f'eye{eye}_positions']=Q;data[f'eye{eye}_source_y']=sourceY;data[f'eye{eye}_source_normal']=sourceNormals;data[f'eye{eye}_source_face']=faces;data[f'eye{eye}_distance_to_aperture']=distance;reports.append({'eye':eye,'vertices':len(Q),'source_misses':int((~good).sum()),'source_reverse_facing_first_hits':sum(v>0 for v in front),'distance_regions_m':rows})
np.savez_compressed(R/'audit/eye_source_shape47.npz',**data);rep={'source_candidate_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'coordinate_frame':'Exact stored original head camera; depth is camera-away Y in meters. Aperture distance is projected shortest distance to the measured source opening.','eyes':reports,'status':'Source-shape attribution; any appearance consequence must be inspected before a bounded correction.'};(R/'audit/eye_source_shape47.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
