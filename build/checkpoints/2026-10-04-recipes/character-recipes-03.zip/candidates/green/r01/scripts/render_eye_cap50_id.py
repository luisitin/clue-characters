"""Actual-asset cap front/back/side diagnostic, with exact triangle-position matching."""
import pathlib
p=pathlib.Path(__file__).with_name('render_exact.py');code=p.read_text();injection=r'''
import numpy as np
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));from glb_source import read_glb
j,raw,A=read_glb(src);cap=j['meshes'][0]['primitives'][7];P=A(cap['attributes']['POSITION'])[:,[0,2,1]]*[1,-1,1];F=A(cap['indices']).reshape(-1,3);front=3672;lookup={}
def key(tr):return tuple(sorted(tuple(float(x)for x in v)for v in tr))
for fi,tr in enumerate(P[F]):lookup[key(tr)]=0 if fi<front else 1 if fi<front*2 else 2
assert len(lookup)==len(F)
colors=[(.2,.2,.2,1),(0,1,0,1),(1,0,1,1),(0,0,1,1)];mats=[]
for idx,color in enumerate(colors):
 m=bpy.data.materials.new('Exact cap ID '+str(idx));m.use_nodes=True;ns=m.node_tree.nodes;ns.clear();o=ns.new('ShaderNodeOutputMaterial');e=ns.new('ShaderNodeEmission');e.inputs['Color'].default_value=color;m.node_tree.links.new(e.outputs[0],o.inputs['Surface']);mats.append(m)
found=[0,0,0]
for ob in bpy.context.scene.objects:
 if ob.type!='MESH':continue
 oldslots=list(ob.data.materials);oldface=[f.material_index for f in ob.data.polygons];v=np.array([x.co[:]for x in ob.data.vertices]);ob.data.materials.clear()
 for m in mats:ob.data.materials.append(m)
 for face,mi in zip(ob.data.polygons,oldface):
  oldmat=oldslots[mi];is_cap=oldmat and oldmat.name==j['materials'][cap['material']]['name']
  if is_cap:
   facekey=key(v[list(face.vertices)]);assert facekey in lookup;cl=lookup[facekey];face.material_index=cl+1;found[cl]+=1
  else:face.material_index=0
assert found==[front,front,len(F)-front*2],found
for m in list(bpy.data.materials):
 if m not in mats and m.users==0:bpy.data.materials.remove(m)
for im in list(bpy.data.images):
 if im.users==0:bpy.data.images.remove(im)
'''
code=code.replace('gc.collect();',injection+'\ngc.collect();').replace("'source_textures_unchanged':True","'source_textures_unchanged':False,'material_override':'Diagnostic emission only: green front cap, magenta backing, blue sidewall, gray all other geometry; exact triangle-position classes verified.'")
exec(compile(code,str(p),'exec'))
