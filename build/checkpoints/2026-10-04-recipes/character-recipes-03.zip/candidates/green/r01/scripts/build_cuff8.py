"""Layered cuff study with a complete source support ring and a contained forearm opening."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
src=R/'Green_source_hand_cut7.glb';j,buf,A=read_glb(src);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);z=np.load(R/'audit/hand_cut7_exact_ring.npz');root=z['ring_world'];rootP=z['ring_local'];rootN=z['ring_local_normals'];axis=z['axis'];center=z['center'];rootc=root.mean(0);phase=float(z['phase']);up=np.array([0.,0,1]);up-=axis*(up@axis);up/=np.linalg.norm(up);side=np.cross(up,axis);frame=np.column_stack([side,up]);q=(root-rootc)@frame;assert np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1))>0
# Held forearm section at the new cuff hem, midway between source support and old hand cut.
hemphase=-.015;hj,hb,H=read_glb(R/'Green_openhand_forearm6.glb');hn=next(n for n in hj['nodes']if'mesh'in n);M=np.eye(4);M[:3,:3]=Rotation.from_quat(hn.get('rotation',[0,0,0,1])).as_matrix()@np.diag(hn.get('scale',[1,1,1]));M[:3,3]=hn.get('translation',[0,0,0]);segments=[]
for pr in hj['meshes'][hn['mesh']]['primitives']:
 p=H(pr['attributes']['POSITION']).astype('float32');w=(p@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];f=H(pr['indices']).reshape(-1,3);d=(w-center)@axis-hemphase
 for fi in np.flatnonzero((d[f].min(1)<0)&(d[f].max(1)>0)):
  hits=[]
  for a,b in zip(f[fi],np.roll(f[fi],-1)):
   if d[a]*d[b]<0:hits.append(w[a]+d[a]/(d[a]-d[b])*(w[b]-w[a]))
  if len(hits)==2:segments.append(hits)
sp=np.array(segments).reshape(-1,3);innerc=sp.mean(0);hemdist=hemphase-phase;hemc=rootc+axis*hemdist;outerq=q*.94;inneroffset=(innerc-hemc)@frame;sectionq=(sp-innerc)@frame;radii=np.max(abs(sectionq),axis=0)+.0025;theta=np.arange(96)*2*np.pi/96;innerq=inneroffset+np.column_stack([np.cos(theta),np.sin(theta)])*radii
# Point-in-polygon for complete aperture containment.
def inside(points,poly):
 hit=np.zeros(len(points),bool);x,y=points.T
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):
  cross=((a[1]>y)!=(b[1]>y))&(x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1]+1e-30)+a[0]);hit^=cross
 return hit
assert inside(innerq,outerq).all(),('Aperture outside cuff domain',radii,inneroffset)
V=[];UV=[];F=[];mats=[];n=len(root)
for t in [0,.15,.35,.6,.82,1]:
 ring=rootc+axis*(hemdist*t)+(root-rootc)*(1-.06*t*t*(3-2*t))
 for k,p in enumerate(ring):V.append(p);UV.append([k/n,t*.3])
for r in range(5):
 for k in range(n):a=r*n+k;b=r*n+(k+1)%n;c=(r+1)*n+(k+1)%n;d=(r+1)*n+k;F.extend([[a,b,c],[a,c,d]]);mats.extend([0,0])
# A physical inset annulus closes the coat cross-section around the contained wrist.
ps=np.vstack([outerq,innerq]);edges=np.vstack([np.column_stack([np.arange(n),np.roll(np.arange(n),-1)]),np.column_stack([n+np.arange(96),n+np.roll(np.arange(96),-1)])]);T=triangle.triangulate({'vertices':ps,'segments':edges,'holes':[inneroffset.tolist()]},'pYq20a0.000008');q2=T['vertices'];tr=T['triangles'];offset=len(V);depth=np.zeros(len(q2));
# Small smooth recess toward the interior at the skin opening; source outer hem is fixed.
from scipy.spatial import cKDTree
do=cKDTree(outerq).query(q2)[0];di=cKDTree(innerq).query(q2)[0];w=do/(do+di+1e-12);depth=-.004*(w*w*(3-2*w));depth[:n]=0;depth[n:n+96]=-.004
for k,p in enumerate(q2):V.append(hemc+frame@p+axis*depth[k]);UV.append([.5+p[0]*4,.6+p[1]*4])
F.extend((tr+offset).tolist());mats.extend([1]*len(tr));# triangles face outward (+axis)
# Recessed lining ring, overlaps forearm by depth while maintaining a physical radial gap.
inner_start=offset+n;last=len(V)
for k,p in enumerate(innerq):V.append(hemc+frame@p-axis*.008);UV.append([k/96,.98])
for k in range(96):a=inner_start+k;b=inner_start+(k+1)%96;c=last+(k+1)%96;d=last+k;F.extend([[a,b,c],[a,c,d]]);mats.extend([1,1])
V=np.array(V);F=np.array(F);mats=np.array(mats);UV=np.array(UV);tri=V[F];GN=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);N=np.zeros_like(V)
for k in range(3):np.add.at(N,F[:,k],GN)
# Weld coincident hem records for their shared smooth shading.
_,g=np.unique(np.round(V,8),axis=0,return_inverse=True);S=np.zeros((g.max()+1,3));np.add.at(S,g,N);N=S[g];assert np.linalg.norm(N,axis=1).min()>1e-15;N/=np.linalg.norm(N,axis=1)[:,None];Pg=(V[:,[0,2,1]]*[1,1,-1]-translation)/scale;Ng=N[:,[0,2,1]]*[1,1,-1]*scale;Ng/=np.linalg.norm(Ng,axis=1)[:,None];Pg[:n]=rootP;Ng[:n]=rootN
mi=len(j['materials']);j['materials'].extend([{'name':'Green cuff cloth study','pbrMetallicRoughness':{'baseColorFactor':[.025,.16,.09,1],'metallicFactor':0,'roughnessFactor':.83},'doubleSided':True},{'name':'Charcoal recessed cuff lining study','pbrMetallicRoughness':{'baseColorFactor':[.018,.022,.02,1],'metallicFactor':0,'roughnessFactor':.88},'doubleSided':True}]);attrs={}
for name,a,kind in [('POSITION',Pg,'VEC3'),('NORMAL',Ng,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],buf=append_accessor(j,buf,a.astype('float32'),kind,34962)
for k in [0,1]:
 ix,buf=append_accessor(j,buf,F[mats==k].astype('uint32').ravel(),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs.copy(),'indices':ix,'material':mi+k,'mode':4})
out=R/'Green_cuff8_body.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/cuff8_binding.npz',new_world=V,new_triangles=F,root_local=rootP,root_world=root,innerq=innerq,outerq=outerq,frame=frame,hemc=hemc,innerc=innerc,source_support_count=n);report={'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_support_points':n,'aperture_samples':96,'all_aperture_samples_inside_outer':True,'forearm_section_segments':len(segments),'aperture_center_world':innerc.tolist(),'aperture_radii_m':radii.tolist(),'new_triangles':len(F),'status':'Unadopted layered cuff study; complete exact surface/contact and appearance tests pending. Constant materials diagnostic.'};(R/'audit/cuff8.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
