"""Sample actual source eye surfaces and exact retained tangent constraints for a globe fit."""
import pathlib,json,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=pathlib.Path(__file__).resolve().parents[1];z=np.load(R/'audit/eye_apertures33.npz');a={k:z[k]for k in z.files};z.close();P=a['source_eye_frame'];F=a['source_triangles'];tree=BVHTree.FromPolygons(P.tolist(),F.tolist(),all_triangles=True);out=dict(a);reports=[]
def inside(poly,pts):
 h=np.zeros(len(pts),bool)
 for u,v in zip(poly,np.roll(poly,-1,axis=0)):h^=((u[1]>pts[:,1])!=(v[1]>pts[:,1]))&(pts[:,0]<(v[0]-u[0])*(pts[:,1]-u[1])/(v[1]-u[1]+1e-300)+u[0])
 return h
for eye in range(2):
 outer=a[f'eye{eye}_outer'];inner=a[f'eye{eye}_aperture'];bid=a[f'eye{eye}_boundary_source_ids'];support=a[f'eye{eye}_retained_support'];source=[];srcfaces=[]
 for q in np.vstack([inner,inner.mean(0)[None]]):
  hit,normal,fi,distance=tree.ray_cast(Vector((q[0],-.4,q[1])),Vector((0,1,0)),.8);assert hit is not None;source.append(hit[:]);srcfaces.append(fi)
 source=np.array(source);assert np.ptp(source[:,1])<.06;guides=[];guide_planes=[];dense=[];min_projected_parent_area=1
 for k,(u,v,fi)in enumerate(zip(outer,np.roll(outer,-1,axis=0),support)):
  tri=P[F[fi]];m=np.column_stack([tri[:,0],tri[:,2],np.ones(3)]);det=np.linalg.det(m);min_projected_parent_area=min(min_projected_parent_area,abs(det)/2);assert abs(det)>1e-12;plane=np.linalg.solve(m,tri[:,1]);e=v-u;normal=np.array([-e[1],e[0]])/np.linalg.norm(e);distance=min(.0005,np.linalg.norm(e)*.12)
  for _ in range(12):
   q=(u+v)*.5+normal*distance
   if inside(outer,q[None])[0]and not inside(inner,q[None])[0]:break
   distance*=.5
  assert distance>1e-6;guides.append([q[0],np.r_[q,1]@plane,q[1]]);guide_planes.append(plane);count=max(2,int(np.ceil(np.linalg.norm(e)/.0003))+1)
  for t in np.linspace(0,1,count):dense.append(P[bid[k]]*(1-t)+P[bid[(k+1)%len(bid)]]*t)
 ctrl=P[np.unique(F[support])];out[f'eye{eye}_inner_source']=source[:-1];out[f'eye{eye}_center_source']=source[-1];out[f'eye{eye}_guide_points']=np.array(guides);out[f'eye{eye}_guide_planes']=np.array(guide_planes);out[f'eye{eye}_dense_outer']=np.array(dense);out[f'eye{eye}_exterior_control']=ctrl;reports.append({'eye':eye,'aperture_source_hits':len(inner),'outer_edges':len(outer),'tangent_wedges':len(guides),'dense_exact_outer_samples':len(dense),'minimum_retained_parent_projected_area_m2':min_projected_parent_area,'parent_aperture_depth_range_m':[float(source[:,1].min()),float(source[:,1].max())],'source_center':source[-1].tolist(),'status':'Sampling and tangent constraints only; no eye geometry exists yet.'})
np.savez_compressed(R/'audit/eye_surface37.npz',**out);(R/'audit/eye_surface37.json').write_text(json.dumps(reports,indent=2));print(reports,flush=True)
