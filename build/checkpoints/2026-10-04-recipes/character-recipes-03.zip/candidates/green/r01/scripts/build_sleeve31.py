"""Long sleeve taper with a true forearm-normal hem and narrow rounded cloth/knit layers."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
src=R/'Green_source_sleeve_cut30.glb';j,buf,A=read_glb(src);nd=j['nodes'][0];scale=np.array(nd['scale']);translation=np.array(nd['translation']);z=np.load(R/'audit/sleeve_cut30_exact_ring.npz');root=z['ring_world'];rootP=z['ring_local'];rootN=z['ring_local_normals'];axis=z['axis'];rootc=root.mean(0);n=len(root);up=np.array([0.,1.,0])if abs(axis[2])>.9 else np.array([0.,0,1]);up-=axis*(up@axis);up/=np.linalg.norm(up);side=np.cross(up,axis);frame0=np.column_stack([side,up]);q0=(root-rootc)@frame0
h=np.load(R/'audit/hand_forearm6_binding.npz');rings=h['new_world'][:14*81].reshape(14,81,3)[:,:80];prox=rings[1].mean(0)-rings[0].mean(0);prox/=np.linalg.norm(prox);endaxis=-prox;endc=np.array(json.loads((R/'audit/hand_reference14.json').read_text())['world_landmarks'][0]);turn=np.cross(axis,endaxis);angle=np.arccos(np.clip(axis@endaxis,-1,1));turn/=np.linalg.norm(turn);endrot=Rotation.from_rotvec(turn*angle).as_matrix();frame1=endrot@frame0
hj,hb,H=read_glb(R/'Green_openhand_painted13.glb');hn=next(x for x in hj['nodes']if'mesh'in x);HM=np.eye(4);HM[:3,:3]=Rotation.from_quat(hn.get('rotation',[0,0,0,1])).as_matrix()@np.diag(hn.get('scale',[1,1,1]));HM[:3,3]=hn.get('translation',[0,0,0]);sections=[]
for pr in hj['meshes'][hn['mesh']]['primitives']:
 p=H(pr['attributes']['POSITION']).astype('float32');w=(p@HM[:3,:3].T+HM[:3,3])[:,[0,2,1]]*[1,-1,1];f=H(pr['indices']).reshape(-1,3)
 for level in [0,-.0015,-.0035,-.006]:
  d=(w-endc)@endaxis-level
  for fi in np.flatnonzero((d[f].min(1)<0)&(d[f].max(1)>0)):
   for aa,bb in zip(f[fi],np.roll(f[fi],-1)):
    if d[aa]*d[bb]<0:sections.append(w[aa]+d[aa]/(d[aa]-d[bb])*(w[bb]-w[aa]))
sections=np.array(sections);sec=(sections-endc)@frame1;sectionOffset=(sec.max(0)+sec.min(0))/2;assert np.linalg.norm(sectionOffset)<.012;endc+=frame1@sectionOffset;sec-=sectionOffset;radii=np.max(abs(sec),axis=0);radialScale=max(1.,float(np.sqrt(np.max(np.sum((sec/radii)**2,axis=1)))));radii=radii*radialScale+.0018;outerRadius=radii+.006
assert np.max(np.sum((sec/radii)**2,axis=1))<1;section_envelope={'samples':len(sections),'ellipse_scale_to_contain_actual_sections':radialScale,'maximum_elliptic_radius':float(np.sqrt(np.max(np.sum((sec/radii)**2,axis=1)))),'planes_m':[0,-.0015,-.0035,-.006]}

edgeLength=np.linalg.norm(np.roll(q0,-1,axis=0)-q0,axis=1);theta=np.arctan2(q0[0,1],q0[0,0])+np.r_[0,np.cumsum(edgeLength[:-1])]/edgeLength.sum()*2*np.pi;q1=np.column_stack([np.cos(theta),np.sin(theta)])*outerRadius
length=np.linalg.norm(endc-rootc);t0=(endc-rootc)*.7;t1=endaxis*length*.35
fractions=np.r_[0,.018,.04,.07,.11,.16,.22,.29,.37,.46,.55,.64,.72,.79,.85,.90,.94,.97,1];V=[];UV=[];F=[];part=[]
for row,t in enumerate(fractions):
 blend=t*t*(3-2*t);c=(2*t**3-3*t*t+1)*rootc+(t**3-2*t*t+t)*t0+(-2*t**3+3*t*t)*endc+(t**3-t*t)*t1;rot=Rotation.from_rotvec(turn*(angle*blend)).as_matrix();frame=rot@frame0;q=q0*(1-blend)+q1*blend;ring=c+q@frame.T
 if row==0:ring=root.copy()
 for k,p in enumerate(ring):V.append(p);UV.append([.02+.60*k/n,.02+.96*t])
for row in range(len(fractions)-1):
 for k in range(n):a=row*n+k;b=row*n+(k+1)%n;c=(row+1)*n+(k+1)%n;d=(row+1)*n+k;F.extend([[a,b,c],[a,c,d]]);part.extend([0,0])
outerq=q1;ni=96;thetaI=np.arange(ni)*2*np.pi/ni;innerq=np.column_stack([np.cos(thetaI),np.sin(thetaI)])*radii;knitq=np.column_stack([np.cos(thetaI),np.sin(thetaI)])*(radii+.0035)
def inside(poly,pts):
 hit=np.zeros(len(pts),bool)
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):hit^=((a[1]>pts[:,1])!=(b[1]>pts[:,1]))&(pts[:,0]<(b[0]-a[0])*(pts[:,1]-a[1])/(b[1]-a[1]+1e-300)+a[0])
 return hit
assert inside(outerq,knitq).all();verts=np.vstack([outerq,innerq,knitq]);segments=np.vstack([np.column_stack([np.arange(n),np.roll(np.arange(n),-1)]),np.column_stack([n+np.arange(ni),n+np.roll(np.arange(ni),-1)]),np.column_stack([n+ni+np.arange(ni),n+ni+np.roll(np.arange(ni),-1)])]);tr=triangle.triangulate({'vertices':verts,'segments':segments,'holes':[[0,0]]},'pYq20a0.000004');q=tr['vertices'];ft=tr['triangles'];do=cKDTree(outerq).query(q)[0];di=cKDTree(innerq).query(q)[0];w=do/(do+di+1e-12);t=np.clip((w-.72)/.28,0,1);depth=.0012*4*w*(1-w)-.0015*t*t*(3-2*t);depth[:n]=0;depth[n:n+ni]=-.0015;off=len(V);held=np.array(V[-n:]).copy()
for k,p in enumerate(q):V.append(held[k]if k<n else endc+frame1@p+endaxis*depth[k]);UV.append([.81+p[0]*3,.5+p[1]*3])
F.extend((ft+off).tolist());part.extend(inside(knitq,q[ft].mean(1)).astype(int).tolist());last=len(V)
for k,p in enumerate(innerq):V.append(endc+frame1@p-endaxis*.006);UV.append([.66+.32*k/ni,.985])
for k in range(ni):a=off+n+k;b=off+n+(k+1)%ni;c=last+(k+1)%ni;d=last+k;F.extend([[a,b,c],[a,c,d]]);part.extend([1,1])
V=np.array(V);F=np.array(F);part=np.array(part);UV=np.array(UV);q=V[F];GN=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);N=np.zeros_like(V)
for k in range(3):np.add.at(N,F[:,k],GN)
_,g=np.unique(np.round(V,9),axis=0,return_inverse=True);S=np.zeros((g.max()+1,3));np.add.at(S,g,N);N=S[g];assert np.linalg.norm(N,axis=1).min()>1e-15;N/=np.linalg.norm(N,axis=1)[:,None];Pg=(V[:,[0,2,1]]*[1,1,-1]-translation)/scale;Ng=N[:,[0,2,1]]*[1,1,-1]*scale;Ng/=np.linalg.norm(Ng,axis=1)[:,None];Pg[:n]=rootP;Ng[:n]=rootN
mi=len(j['materials']);j['materials'].extend([{'name':'Long Green sleeve study','pbrMetallicRoughness':{'baseColorFactor':[.025,.16,.09,1],'metallicFactor':0,'roughnessFactor':.83},'doubleSided':True},{'name':'Narrow charcoal knit cuff study','pbrMetallicRoughness':{'baseColorFactor':[.018,.022,.02,1],'metallicFactor':0,'roughnessFactor':.88},'doubleSided':True}]);attrs={}
for name,a,kind in [('POSITION',Pg,'VEC3'),('NORMAL',Ng,'VEC3'),('TEXCOORD_0',UV,'VEC2')]:attrs[name],buf=append_accessor(j,buf,a.astype('float32'),kind,34962)
for k in [0,1]:
 ix,buf=append_accessor(j,buf,F[part==k].astype('uint32').ravel(),'SCALAR',34963);j['meshes'][0]['primitives'].append({'attributes':attrs.copy(),'indices':ix,'material':mi+k,'mode':4})
out=R/'Green_sleeve31_body.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/sleeve31_binding.npz',new_world=V,new_triangles=F,root_local=rootP,root_world=root,source_support_count=n,hem_center=endc,hem_normal=endaxis,hem_frame=frame1,innerq=innerq,outerq=outerq);rep={'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_support_vertices':n,'actual_skin_section_envelope':section_envelope,'new_triangles':len(F),'root_to_hem_distance_m':length,'hem_axis':endaxis.tolist(),'old_cut_to_new_hem_axis_degrees':float(np.degrees(angle)),'skin_radii_m':radii.tolist(),'outer_radii_m':outerRadius.tolist(),'status':'Unadopted long tapered sleeve with a forearm-normal hem; exact surface/contact and actual silhouette tests pending. Diagnostic cloth colors.'};(R/'audit/sleeve31.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
