import bpy,pathlib,sys,json,hashlib,math,gc,ctypes
from mathutils import Vector
args=sys.argv[sys.argv.index('--')+1:];src=pathlib.Path(args[0]).resolve();out=pathlib.Path(args[1]).resolve();tag=args[2];mode=args[3];res=int(args[4])if len(args)>4 else 1024;out.mkdir(parents=True,exist_ok=True);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(src));raw_preserved=False
if src.name in ['sus-green.glb','Green_source_clean_records.glb','Green_forehead_depth_trial02.glb']:
 sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));from glb_source import replace_single_source_mesh
 replace_single_source_mesh(src);raw_preserved=True
scene=bpy.context.scene
regions={'head_top':((.035,.04,.89),.46,0,50),'head_under':((.035,-.005,.77),.46,0,-5),'body_top':((0,0,0),2.2,0,50),'body_under':((0,0,0),2.2,0,-50)}
if tag.startswith(('head_angle_','body_angle_')):
 a=float(tag.rsplit('_',1)[1]);regions[tag]=((.035,-.005,.806),.46,a,.04)if tag.startswith('head')else((0,0,0),2.2,a,.04)
if tag.startswith('openhand_angle_'):
 a=float(tag.rsplit('_',1)[1]);regions[tag]=((-.38,-.18,.175),.28,a,.02)
regions['openhand_top']=((-.38,-.18,.175),.28,-11,50)
regions['openhand_under']=((-.38,-.18,.175),.28,-11,-50)
target,scale,angle,elev=regions[tag];target=Vector(target);rad=math.radians(angle);scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=1;scene.render.resolution_x=res;scene.render.resolution_y=res;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
scene.world=bpy.data.worlds.new('Neutral studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.22,.22,.22,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.6;scene.view_settings.view_transform='Standard';scene.view_settings.look='None';scene.view_settings.exposure=0;scene.view_settings.gamma=1
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=scale;cam.location=target+Vector((math.sin(rad)*5,-math.cos(rad)*5,elev));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size in [('Key',(-3,-4,4),220,4),('Fill',(4,-2,2),140,4),('Rear',(0,3,3),170,3)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,.2))-o.location).to_track_quat('-Z','Y').to_euler()
if mode in ['clay','unlit']:
 for mat in bpy.data.materials:
  if not mat.use_nodes:continue
  ns=mat.node_tree.nodes;bs=next((n for n in ns if n.type=='BSDF_PRINCIPLED'),None)
  if bs is None:continue
  col=tuple(bs.inputs['Base Color'].default_value);tex=bs.inputs['Base Color'].links[0].from_node if bs.inputs['Base Color'].is_linked else None;im=tex.image if tex and tex.type=='TEX_IMAGE'else None;ns.clear();outnode=ns.new('ShaderNodeOutputMaterial')
  if mode=='clay':n=ns.new('ShaderNodeBsdfDiffuse');n.inputs['Color'].default_value=(.55,.55,.55,1);n.inputs['Roughness'].default_value=.7
  else:
   n=ns.new('ShaderNodeEmission');n.inputs['Color'].default_value=col
   if im:t=ns.new('ShaderNodeTexImage');t.image=im;mat.node_tree.links.new(t.outputs['Color'],n.inputs['Color'])
  mat.node_tree.links.new(n.outputs[0],outnode.inputs['Surface'])
 for im in list(bpy.data.images):
  if im.users==0:bpy.data.images.remove(im)
gc.collect();ctypes.CDLL(None).malloc_trim(0);png=out/(tag+'_'+mode+'.png');scene.render.filepath=str(png);bpy.ops.render.render(write_still=True)
metadata={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'shader_mode':mode,'source_textures_unchanged':True,'whole_model_geometry':True,'raw_source_topology_preserved':raw_preserved,'integer_accessors_normalized':True,'camera_world_matrix':[list(r)for r in cam.matrix_world],'target':list(target),'ortho_scale':scale,'angle_deg':angle,'elevation_world_z_offset':elev,'projection_type':'ORTHO','resolution':[res,res],'pixel_center_convention':'Top-left integer PNG coordinates; centers x+.5,y+.5','rendered_image_sha256':hashlib.sha256(png.read_bytes()).hexdigest()};png.with_suffix('.json').write_text(json.dumps(metadata,indent=2))
