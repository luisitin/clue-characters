import pathlib,json,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];report=json.loads((R/'audit/sleeve_root23.json').read_text());z=np.load(R/'audit/sleeve_root23.npz');a={k:z[k]for k in z.files};rows=[]
for r in report['sections']:
 for ci,c in enumerate(r['components']):
  if not c['left_arm_candidate']or c['bad_degrees']:continue
  key=f"z{r['height']}_component{ci}";p=a[key];edge=np.roll(p,-1,axis=0)-p;el=np.linalg.norm(edge,axis=1);u=edge/el[:,None];angles=np.degrees(np.arccos(np.clip(np.sum(np.roll(u,1,axis=0)*u,axis=1),-1,1)));ids=np.argsort(angles)[-5:];rows.append({'height':r['height'],'key':key,'vertices':len(p),'maximum_turn_degrees':float(angles.max()),'turns_over_100':int((angles>100).sum()),'minimum_edge_m':float(el.min()),'worst':[{'vertex':int(k),'position':p[k].tolist(),'turn':float(angles[k])}for k in ids]})
(R/'audit/sleeve_roots34.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
