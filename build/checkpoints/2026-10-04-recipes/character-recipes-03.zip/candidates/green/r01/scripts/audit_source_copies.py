import pathlib,sys,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R.parents[2]/'sources/prelod-cd4c20d/sus-green.glb';j,b,A=read_glb(src);p=j['meshes'][0]['primitives'][0];P=A(p['attributes']['POSITION']);N=A(p['attributes']['NORMAL']);UV=A(p['attributes']['TEXCOORD_0']);F=A(p['indices']).reshape(-1,3);groups={};rows=[]
for i,tr in enumerate(F):groups.setdefault(tuple(sorted(map(tuple,P[tr]))),[]).append(i)
for fs in groups.values():
 if len(fs)<2:continue
 a=F[fs[0]]
 for fi in fs[1:]:
  b=F[fi];match=[next((k for k in range(3)if np.array_equal(P[v],P[b[k]])),-1)for v in a];sameN=all(np.array_equal(N[a[k]],N[b[match[k]]])for k in range(3));sameUV=all(np.array_equal(UV[a[k]],UV[b[match[k]]])for k in range(3));samew=tuple(match)in[(0,1,2),(1,2,0),(2,0,1)];gn=np.cross(P[a[1]]-P[a[0]],P[a[2]]-P[a[0]]);gn/=max(np.linalg.norm(gn),1e-30);rows.append({'triangles':[fs[0],fi],'same_normals':sameN,'same_UV':sameUV,'same_winding':samew,'first_face_GN_vs_storedN':float(gn@N[a].mean(0)),'centroid_gltf':P[a].mean(0).tolist()})
rep={'copy_pairs':rows,'same_all_attributes_and_winding':sum(r['same_normals']and r['same_UV']and r['same_winding']for r in rows),'same_attributes_opposite_winding':sum(r['same_normals']and r['same_UV']and not r['same_winding']for r in rows),'attribute_differences':sum(not(r['same_normals']and r['same_UV'])for r in rows)};(R/'audit/source_copy_attributes.json').write_text(json.dumps(rep,indent=2));print({k:v for k,v in rep.items()if k!='copy_pairs'},flush=True)
