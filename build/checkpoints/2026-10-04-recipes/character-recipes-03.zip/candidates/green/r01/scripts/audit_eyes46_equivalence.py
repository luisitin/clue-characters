import pathlib,json,hashlib,numpy as np
from glb_source import read_glb
R=pathlib.Path(__file__).resolve().parents[1];old=R/'Green_physical_eyes45_body.glb';new=R/'Green_physical_eyes46_painted_body.glb';j,b,A=read_glb(old);k,c,B=read_glb(new);assert j['nodes']==k['nodes'];rows=[]
for pi,(p,q)in enumerate(zip(j['meshes'][0]['primitives'],k['meshes'][0]['primitives'])):
 f=A(p['indices']).reshape(-1,3);g=B(q['indices']).reshape(-1,3);assert f.shape==g.shape;row={'primitive':pi,'triangles':len(f)}
 for key in ['POSITION','NORMAL']:
  x=A(p['attributes'][key])[f];y=B(q['attributes'][key])[g];assert np.array_equal(x,y);row[key+'_ordered_corners_bitwise_equal']=True
 if pi not in [7,10]:assert np.array_equal(A(p['attributes']['TEXCOORD_0'])[f],B(q['attributes']['TEXCOORD_0'])[g]);row['UV_ordered_corners_held']=True
 else:
  uv=B(q['attributes']['TEXCOORD_0'])[g];e=uv[:,1]-uv[:,0];h=uv[:,2]-uv[:,0];area=abs(e[:,0]*h[:,1]-e[:,1]*h[:,0]);assert area.min()>0;row.update(minimum_uv_double_area=float(area.min()),spherical_seam_corner_splits=True,max_U_span=float(np.ptp(uv[:,:,0],axis=1).max()))
 if pi<5:assert p==q;row['complete_primitive_binding_held']=True
 rows.append(row)
for im in j['images']:
 bv=j['bufferViews'][im['bufferView']];i=bv.get('byteOffset',0);assert bytes(b[i:i+bv['byteLength']])==bytes(c[i:i+bv['byteLength']])
rep={'geometry_source_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'painted_candidate_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'original_node_transform_held':True,'original_embedded_maps_held':True,'ordered_corner_equivalence':rows,'preflight_carry_forward':'V4 geometry report eyes45_surface_v4_compact.json applies to the exact held POSITION triangle corners. New material and UV appearance remains separate.'};(R/'audit/eyes46_equivalence.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
