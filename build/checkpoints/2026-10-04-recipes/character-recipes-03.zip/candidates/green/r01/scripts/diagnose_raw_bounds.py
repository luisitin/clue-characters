import bpy,pathlib,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];bpy.ops.wm.open_mainfile(filepath=str(R/'Green_raw_source.blend'));bpy.context.view_layer.update()
for o in bpy.context.scene.objects:
 if o.type=='MESH':
  p=np.array([(o.matrix_world@v.co)[:]for v in o.data.vertices]);print(o.name,'bounds',p.min(0),p.max(0),'matrix',[list(r)for r in o.matrix_world],'visible',o.hide_render,o.visible_get(),'counts',len(o.data.vertices),len(o.data.polygons),flush=True)
