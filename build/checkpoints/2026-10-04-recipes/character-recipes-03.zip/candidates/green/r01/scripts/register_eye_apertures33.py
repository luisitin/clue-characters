"""Measured source-camera sclera/iris opening; exclude the painted eyeliner wing."""
import pathlib,json,numpy as np
from PIL import Image
from scipy.ndimage import binary_closing,binary_fill_holes,label
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
R=pathlib.Path(__file__).resolve().parents[1];path=R/'renders/forehead_pslg4_painted/head_angle_0_unlit.png';im=np.array(Image.open(path).convert('RGB'));z=np.load(R/'audit/eye_domains32.npz');out={k:z[k]for k in z.files};meta=json.loads((R/'renders/forehead_pslg4_painted/head_angle_0_unlit.json').read_text());scale=meta['ortho_scale'];reports=[];fig,axes=plt.subplots(1,2,figsize=(12,5),dpi=160)
def inside(poly,pts):
 h=np.zeros(len(pts),bool)
 for a,b in zip(poly,np.roll(poly,-1,axis=0)):h^=((a[1]>pts[:,1])!=(b[1]>pts[:,1]))&(pts[:,0]<(b[0]-a[0])*(pts[:,1]-a[1])/(b[1]-a[1]+1e-300)+a[0])
 return h
for eye,(x0,y0,x1,y1)in enumerate([(380,418,484,468),(582,430,690,482)]):
 rgb=im[y0:y1,x0:x1].astype(float);rr,gg,bb=rgb[:,:,0],rgb[:,:,1],rgb[:,:,2];white=(gg>rr-30)&(bb>rr*.70)&(gg>85);iris=(gg>rr*1.10)&(gg>bb*1.12)&(gg>35);mask=binary_fill_holes(binary_closing(white|iris,iterations=3));labs,n=label(mask);sizes=np.bincount(labs.ravel());sizes[0]=0;mask=labs==sizes.argmax();ys,xs=np.where(mask);lo=int(xs.min());hi=int(xs.max());leftrows=np.flatnonzero(mask[:,lo]);rightrows=np.flatnonzero(mask[:,hi]);p0=np.array([x0+lo+.5,y0+leftrows.mean()+.5]);p1=np.array([x0+hi+.5,y0+rightrows.mean()+.5]);columns=np.arange(lo,hi+1);top=[];bottom=[]
 for col in columns:
  row=np.flatnonzero(mask[:,col]);top.append(y0+row.min()+.0);bottom.append(y0+row.max()+1.)
 u=(columns-lo)/(hi-lo);b0=(1-u)**3;b1=3*(1-u)**2*u;b2=3*(1-u)*u*u;b3=u**3
 def curve(values,reverse=False):
  coeff=np.linalg.lstsq(np.column_stack([b1,b2]),np.array(values)-b0*p0[1]-b3*p1[1],rcond=None)[0];t=np.linspace(0,1,48,endpoint=False);pp=(1-t)**3*p0[1]+3*(1-t)**2*t*coeff[0]+3*(1-t)*t*t*coeff[1]+t**3*p1[1];x=p0[0]+t*(p1[0]-p0[0]);return np.column_stack([x,pp]),coeff
 upper,cu=curve(top);lower,cl=curve(bottom);# include each canthus once; traverse upper left->right and lower right->left
 pix=np.vstack([upper,p1[None],lower[:0:-1]]);xz=np.column_stack([(pix[:,0]/1024-.5)*scale,(.5-pix[:,1]/1024)*scale]);outer=out[f'eye{eye}_outer'];contain=inside(outer,xz);area=.5*np.sum(xz[:,0]*np.roll(xz[:,1],-1)-xz[:,1]*np.roll(xz[:,0],-1));assert area<0;dist=np.full(len(xz),np.inf)
 for a,b in zip(outer,np.roll(outer,-1,axis=0)):
  e=b-a;t=np.clip(((xz-a)@e)/(e@e),0,1);dist=np.minimum(dist,np.linalg.norm(xz-a-t[:,None]*e,axis=1))
 out[f'eye{eye}_aperture']=xz;out[f'eye{eye}_aperture_pixels']=pix;report={'eye':eye,'opening_canthi_pixels':[p0.tolist(),p1.tolist()],'upper_control_y':cu.tolist(),'lower_control_y':cl.tolist(),'mask_pixels':len(xs),'aperture_samples':len(pix),'all_aperture_samples_inside_outer':bool(contain.all()),'minimum_outer_clearance_m':float(dist.min()),'status':'Measured actual source-camera color boundary; inspect overlay before globe/lid construction. Iris and sclera included; dark eyeliner wings excluded.'};reports.append(report);ax=axes[eye];ax.imshow(im);ax.plot(np.r_[pix[:,0],pix[0,0]],np.r_[pix[:,1],pix[0,1]],color='cyan',lw=.65);op=np.column_stack([(outer[:,0]/scale+.5)*1024,(.5-outer[:,1]/scale)*1024]);ax.plot(np.r_[op[:,0],op[0,0]],np.r_[op[:,1],op[0,1]],color='yellow',lw=.6);ax.scatter([p0[0],p1[0]],[p0[1],p1[1]],c='magenta',s=6);ax.set_xlim(x0-15,x1+15);ax.set_ylim(y1+10,y0-20);ax.set_aspect('equal');ax.set_title(f'Eye{eye}: cyan opening; yellow held rim');ax.axis('off')
fig.tight_layout();fig.savefig(R/'audit/eye_apertures33_overlay.png');plt.close(fig);np.savez_compressed(R/'audit/eye_apertures33.npz',**out);(R/'audit/eye_apertures33.json').write_text(json.dumps({'source_camera':meta,'measurements':reports,'status':'Aperture proposal only; no geometry modified.'},indent=2));print(reports,flush=True)
