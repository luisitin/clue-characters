"""Identify the distal source-hand component through a complete geometric plane cut."""
import pathlib,sys,json,numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_forehead_pslg5_painted.glb';j,b,A=read_glb(src);pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];W=(P*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];C=np.array([0.,0.,.3125]);axis=np.array([0.,0.,-1.]);phase=0.;d=(W-C)@axis-phase
_,g=np.unique(P,axis=0,return_inverse=True);G=g[F];positive=np.flatnonzero(d[F].max(1)>1e-10);ed={};pairs=[]
for fi in positive:
 for k in range(3):
  a,b=F[fi,k],F[fi,(k+1)%3]
  if max(d[a],d[b])<=1e-10:continue
  key=tuple(sorted((int(g[a]),int(g[b]))))
  for fj in ed.get(key,[]):pairs.append((int(fi),fj))
  ed.setdefault(key,[]).append(int(fi))
rows,cols=np.array(pairs).T;mat=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(F),len(F)));n,labels=connected_components(mat,directed=False);mid=W[F].mean(1);seed=(mid[:,0]<-.35)&(mid[:,1]<-.13)&(mid[:,2]>.08)&(mid[:,2]<.30)&(d[F].min(1)>0);vals,counts=np.unique(labels[seed],return_counts=True);groups=[]
for k,c in sorted(zip(vals,counts),key=lambda x:-x[1]):
 ids=np.flatnonzero((labels==k)&(d[F].max(1)>0));q=W[F[ids]];groups.append({'label':int(k),'seed_faces':int(c),'faces':len(ids),'min_world':q.min((0,1)).tolist(),'max_world':q.max((0,1)).tolist(),'mixed_faces':int(np.sum(d[F[ids]].min(1)<0))})
assert len(groups)>0;target=groups[0]['label'];ids=np.flatnonzero((labels==target)&(d[F].max(1)>0));np.savez_compressed(R/'audit/sleeve_cut24_binding.npz',selected_faces=ids,center=C,axis=axis,phase=phase);report={'source':str(src),'groups':groups,'selected':groups[0],'selection':'Connected positive half-space component selected by a distal hand spatial seed; no RGB or material classification'};(R/'audit/sleeve_cut24.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
