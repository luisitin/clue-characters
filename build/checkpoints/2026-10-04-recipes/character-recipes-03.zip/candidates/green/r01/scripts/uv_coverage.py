import numpy as np

def audit(corner_uv,res):
 count=np.zeros((res,res),np.uint16);sampled=np.zeros(len(corner_uv),bool);area=np.zeros(len(corner_uv));bad=[]
 for fi,t in enumerate(corner_uv):
  q=t.astype(float)*res;e1=q[1]-q[0];e2=q[2]-q[0];den=e1[0]*e2[1]-e1[1]*e2[0];area[fi]=abs(den)/2
  if abs(den)<1e-12:bad.append(fi);continue
  low=np.maximum(np.ceil(q.min(0)-.5).astype(int),0);high=np.minimum(np.floor(q.max(0)-.5).astype(int),res-1)
  if(high<low).any():continue
  x,y=np.meshgrid(np.arange(low[0],high[0]+1)+.5,np.arange(low[1],high[1]+1)+.5);x-=q[0,0];y-=q[0,1];u=(x*e2[1]-y*e2[0])/den;v=(e1[0]*y-e1[1]*x)/den;inside=(u>1e-7)&(v>1e-7)&(u+v<1-1e-7);sampled[fi]=inside.any();count[low[1]:high[1]+1,low[0]:high[0]+1]+=inside.astype('uint16')
 return {'resolution':res,'occupied':int((count>0).sum()),'overlapping':int((count>1).sum()),'maximum_multiplicity':int(count.max()),'degenerate_faces':bad,'missing_faces':np.flatnonzero(~sampled).tolist(),'minimum_area_texels':float(area.min())}
