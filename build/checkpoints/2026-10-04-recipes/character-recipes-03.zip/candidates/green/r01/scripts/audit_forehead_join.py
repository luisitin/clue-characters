import pathlib,sys,numpy as np,json,hashlib
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
stem=sys.argv[1];src=R/(stem+'.glb');j,b,A=read_glb(src);prs=j['meshes'][0]['primitives'];assert len(prs)==2;P=[A(p['attributes']['POSITION']).astype('float32')for p in prs];N=[A(p['attributes']['NORMAL']).astype(float)for p in prs];F=[A(p['indices']).reshape(-1,3)for p in prs];allP=np.vstack(P);_,group=np.unique(allP,axis=0,return_inverse=True);G=[group[:len(P[0])],group[len(P[0]):]];edge=[]
for k in range(2):
 e={}
 for fi,tr in enumerate(G[k][F[k]]):
  for a,b in zip(tr,np.roll(tr,-1)):e.setdefault(tuple(sorted((int(a),int(b)))),[]).append((int(a),int(b),fi))
 edge.append(e)
boundary=[e for e,fs in edge[1].items()if len(fs)==1];missing=[];winding=[];nonman=[]
for e in boundary:
 if e not in edge[0]:missing.append(e);continue
 if len(edge[0][e])!=1:nonman.append(e)
 if edge[0][e][0][:2]!=tuple(reversed(edge[1][e][0][:2])):winding.append(e)
shared=set(np.unique(G[0][F[0]]))&set(np.unique(G[1][F[1]]));angles=[]
for g in shared:
 a=N[0][G[0]==g];b=N[1][G[1]==g];a=a/np.linalg.norm(a,axis=1)[:,None];b=b/np.linalg.norm(b,axis=1)[:,None];angles.append(float(np.degrees(np.arccos(np.clip((a@b.T).min(),-1,1)))))
report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'patch_boundary_edges':len(boundary),'missing_retained_partner_edges':missing,'nonmanifold_join_edges':nonman,'same_direction_join_edges':winding,'shared_boundary_position_groups':len(shared),'maximum_boundary_normal_difference_degrees':max(angles,default=0),'scope':'Exact float32 POSITION equivalence and edge incidence/direction at actual exported two-primitive join'};(R/'audit'/(stem+'_join.json')).write_text(json.dumps(report,indent=2));print(report,flush=True)
