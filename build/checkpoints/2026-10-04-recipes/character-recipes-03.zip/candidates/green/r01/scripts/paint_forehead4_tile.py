import pathlib,sys,numpy as np,json
from PIL import Image
from scipy.ndimage import distance_transform_edt
R=pathlib.Path(__file__).resolve().parents[1];tile=int(sys.argv[1]);d=np.load(R/'textures/forehead4_tiles'/f'tile_{tile:02d}_binding.npz');uv=d['uv_source'];valid=d['valid'];occupied=d['occupied'];assert not(occupied&~valid).any()
def decode(x):return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
def encode(x):return np.where(x<=.0031308,x*12.92,1.055*np.maximum(x,0)**(1/2.4)-.055)
for kind,filename in [('BaseColor','0_base_color.webp'),('ORM','1_metallic_roughness_occlusion.webp')]:
 im=np.array(Image.open(R.parents[2]/'textures/prelod-cd4c20d/sus-green'/filename).convert('RGB'));H,W=im.shape[:2];x=np.clip(uv[:,:,0]*W-.5,0,W-1);y=np.clip(uv[:,:,1]*H-.5,0,H-1);i=np.floor(x).astype(int);j=np.floor(y).astype(int);a=(x-i).astype('float32')[:,:,None];b=(y-j).astype('float32')[:,:,None];i1=np.minimum(i+1,W-1);j1=np.minimum(j+1,H-1);colors=[im[j,i].astype('float32')/255,im[j,i1].astype('float32')/255,im[j1,i].astype('float32')/255,im[j1,i1].astype('float32')/255]
 if kind=='BaseColor':colors=[decode(c)for c in colors]
 out=(1-b)*((1-a)*colors[0]+a*colors[1])+b*((1-a)*colors[2]+a*colors[3])
 if kind=='BaseColor':out=encode(out)
 if not valid.all():inds=distance_transform_edt(~valid,return_distances=False,return_indices=True);out[~valid]=out[tuple(inds[:,~valid])]
 Image.fromarray(np.round(np.clip(out,0,1)*255).astype('uint8')).save(R/'textures/forehead4_tiles'/f'tile_{tile:02d}_{kind}.png')
print('PAINTED_TILE',tile,'occupied',int(occupied.sum()),flush=True)
