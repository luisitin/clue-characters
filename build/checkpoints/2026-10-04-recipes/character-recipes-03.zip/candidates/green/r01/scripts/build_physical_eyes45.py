"""Second physical eye study: source-held tangent annuli, controlled lip bands, curved walls and closed ellipsoids."""
import pathlib,sys,json,hashlib,numpy as np
from scipy.interpolate import RBFInterpolator
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb,append_accessor,write_glb
sys.path.append(str(R.parents[2]/'shared_tools/triangle_lib'));import triangle
z=np.load(R/'audit/eye_globes43.npz');a={k:z[k]for k in z.files};z.close();src=R/'Green_sleeve38_body.glb';j,buf,A=read_glb(src);node=j['nodes'][0];scale=np.array(node['scale']);translation=np.array(node['translation']);P0=A(j['meshes'][0]['primitives'][0]['attributes']['POSITION']).astype('float32');F0=A(j['meshes'][0]['primitives'][0]['indices']).reshape(-1,3);sourceF=a['source_triangles'];sourceP=a['source_eye_frame'];sourceN=a['source_normal_eye_frame'];frame=a['frame_basis'];origin=a['frame_origin'];remove_records=np.vstack([sourceF[a[f'eye{e}_selected']]for e in range(2)]);assert all(np.all(a['source_primitive'][a[f'eye{e}_selected']]==0)for e in range(2));record={tuple(map(int,tr))for tr in remove_records};drop=np.array([tuple(map(int,tr))in record for tr in F0]);assert drop.sum()==len(record);j['meshes'][0]['primitives'][0]['indices'],buf=append_accessor(j,buf,F0[~drop].astype('uint32').ravel(),'SCALAR',34963);skinMat=len(j['materials']);j['materials'].extend([{'name':'Green physical orbital skin geometry study','pbrMetallicRoughness':{'baseColorFactor':[.53,.36,.25,1],'roughnessFactor':.6,'metallicFactor':0},'doubleSided':False},{'name':'Green closed eye globe geometry study','pbrMetallicRoughness':{'baseColorFactor':[.85,.87,.82,1],'roughnessFactor':.20,'metallicFactor':0},'doubleSided':False}]);reports=[];bindings={};newPrimitiveStart=len(j['meshes'][0]['primitives'])
def inside(poly,pts):
 h=np.zeros(len(pts),bool)
 for u,v in zip(poly,np.roll(poly,-1,axis=0)):h^=((u[1]>pts[:,1])!=(v[1]>pts[:,1]))&(pts[:,0]<(v[0]-u[0])*(pts[:,1]-u[1])/(v[1]-u[1]+1e-300)+u[0])
 return h

def append_component(label,Q,N,F,uv,material,boundary_ids=None):
 global buf
 W=Q@frame.T+origin;WN=N@frame.T;P=(W[:,[0,2,1]]*[1,1,-1]-translation)/scale;LN=WN[:,[0,2,1]]*[1,1,-1]*scale;LN/=np.linalg.norm(LN,axis=1)[:,None]
 if boundary_ids is not None:
  n=len(boundary_ids);P[:n]=a['source_local'][boundary_ids];LN[:n]=a['source_normal_local'][boundary_ids]
 attrs={}
 for name,arr,kind in [('POSITION',P,'VEC3'),('NORMAL',LN,'VEC3'),('TEXCOORD_0',uv,'VEC2')]:attrs[name],buf=append_accessor(j,buf,arr.astype('float32'),kind,34962)
 ix,buf=append_accessor(j,buf,F.astype('uint32').ravel(),'SCALAR',34963);pi=len(j['meshes'][0]['primitives']);j['meshes'][0]['primitives'].append({'attributes':attrs,'indices':ix,'material':material,'mode':4});bindings[label+'_world']=W;bindings[label+'_triangles']=F;return pi

for eye in range(2):
 outer=a[f'eye{eye}_outer'];inner0=a[f'eye{eye}_aperture'];from scipy.ndimage import gaussian_filter1d
 inner=gaussian_filter1d(inner0,.70,axis=0,mode='wrap');aperture_rounding=float(np.linalg.norm(inner-inner0,axis=1).max());assert aperture_rounding<.0005;arc=np.r_[0,np.cumsum(np.linalg.norm(np.roll(inner,-1,axis=0)-inner,axis=1))];tt=np.linspace(0,arc[-1],192,endpoint=False);closed=np.vstack([inner,inner[0]]);inner=np.column_stack([np.interp(tt,arc,closed[:,k])for k in range(2)]);
 bid=a[f'eye{eye}_boundary_source_ids'];support=a[f'eye{eye}_retained_support'];guide=a[f'eye{eye}_guide_points'];planes=a[f'eye{eye}_guide_planes'];basis=a[f'eye{eye}_globe_basis'];radii=a[f'eye{eye}_globe_radii'];C=a[f'eye{eye}_globe_center'];center=inner.mean(0);no=len(outer);ni=len(inner);lip=center+(inner-center)*1.065
 def globe(q):
  qq=(np.column_stack([q[:,0],np.zeros(len(q)),q[:,1]])-C)@basis;d=np.array([0.,1,0])@basis;aa=np.sum((d/radii)**2);bb=2*np.sum(qq*d/radii**2,axis=1);cc=np.sum((qq/radii)**2,axis=1)-1;disc=bb*bb-4*aa*cc;return (-bb-np.sqrt(np.maximum(disc,0)))/(2*aa),disc>=0
 assert inside(outer,lip).all();innerY,valid=globe(inner);assert valid.all();innerY-=.00035;lipY,valid=globe(lip);assert valid.all();lipY-=.00050
 # Exact retained tangent wedges and an explicit inner lip contour in one constrained annulus.
 ox=np.arange(no);ix=no+np.arange(ni);lx=no+ni+np.arange(ni);gx=no+2*ni+np.arange(no);segments=np.vstack([np.column_stack([ox,np.roll(ox,-1)]),np.column_stack([ix,np.roll(ix,-1)]),np.column_stack([lx,np.roll(lx,-1)]),np.column_stack([ox,gx]),np.column_stack([gx,np.roll(ox,-1)])]);xx,zz=np.meshgrid(np.arange(outer[:,0].min(),outer[:,0].max(),.0008),np.arange(outer[:,1].min(),outer[:,1].max(),.0008));samples=np.column_stack([xx.ravel(),zz.ravel()]);samples=samples[inside(outer,samples)&~inside(inner,samples)];distance=np.full(len(samples),np.inf)
 for loop in [outer,inner,lip]+[np.array([outer[k],guide[k,[0,2]],outer[(k+1)%no]])for k in range(no)]:
  for p,q in zip(loop,np.roll(loop,-1,axis=0)):
   edge=q-p;t=np.clip(((samples-p)@edge)/(edge@edge),0,1);distance=np.minimum(distance,np.linalg.norm(samples-p-t[:,None]*edge,axis=1))
 samples=samples[distance>.00022];verts=np.vstack([outer,inner,lip,guide[:,[0,2]],samples]);tr=triangle.triangulate({'vertices':verts,'segments':segments,'holes':[center.tolist()]},'pYq24Q');V=tr['vertices'];F=tr['triangles'];tri=V[F];areas=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);assert areas.min()>0
 wedge_controls=[]
 for k in range(no):
  q=np.array([outer[k],guide[k,[0,2]],outer[(k+1)%no]])
  for p,q2 in zip(q[:-1],q[1:]):
   t=np.linspace(0,1,max(3,int(np.ceil(np.linalg.norm(q2-p)/.0001))+1));xz=p[None]*(1-t[:,None])+q2[None]*t[:,None];yy=np.column_stack([xz,np.ones(len(xz))])@planes[k];wedge_controls.extend(np.column_stack([xz[:,0],yy,xz[:,1]]))
 controls=np.vstack([np.array(wedge_controls),a[f'eye{eye}_exterior_control'],a[f'eye{eye}_dense_outer'],guide,np.column_stack([inner[:,0],innerY,inner[:,1]]),np.column_stack([lip[:,0],lipY,lip[:,1]])]);key=np.round(controls[:,[0,2]],12);_,first=np.unique(key,axis=0,return_index=True);controls=controls[first];fit=RBFInterpolator((controls[:,[0,2]]-center)/.03,controls[:,1],kernel='thin_plate_spline',smoothing=1e-13);Y=fit((V-center)/.03);Y[:no]=sourceP[bid,1];Y[no:no+ni]=innerY;Y[no+ni:no+2*ni]=lipY
 # The thin inner lip has a controlled analytic depth field, not an unconstrained TPS ridge.
 inlip=inside(lip,V);gy,good=globe(V);from scipy.spatial import cKDTree
 di=cKDTree(inner).query(V)[0];dl=cKDTree(lip).query(V)[0];blend=di/(di+dl+1e-15);controlled=gy-(.00035+.00015*np.clip(blend,0,1));Y[inlip&good]=controlled[inlip&good];Y[no:no+ni]=innerY;Y[no+ni:no+2*ni]=lipY
 fixed=np.zeros(len(V),bool);fixed[:no+2*ni]=True;wedge_members=[]
 for k in range(no):
  q=np.array([outer[k],outer[(k+1)%no],guide[k,[0,2]]]);e=q[1]-q[0];f=q[2]-q[0];den=np.cross(e,f);v=V-q[0];u=np.cross(v,f)/den;w=np.cross(e,v)/den;take=(u>=-1e-8)&(w>=-1e-8)&(u+w<=1+1e-8);Y[take]=np.column_stack([V[take],np.ones(take.sum())])@planes[k];fixed[take]=True;wedge_members.append(take)
 Y[:no]=sourceP[bid,1];required=np.where(good,np.maximum(Y-gy+.00018,0),0);assert required[fixed].max()<1e-8,('Globe breaches fixed skin constraints',eye,float(required[fixed].max()));edges=np.unique(np.sort(np.vstack([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),axis=1),axis=0);degree=np.bincount(edges.ravel(),minlength=len(V));correction=required.copy()
 for _ in range(200):
  total=np.zeros(len(V));np.add.at(total,edges[:,0],correction[edges[:,1]]);np.add.at(total,edges[:,1],correction[edges[:,0]]);new=np.maximum(required,.8*total/np.maximum(degree,1));new[fixed]=0
  if np.max(abs(new-correction))<1e-10:break
  correction=new
 Y-=correction;Q=np.column_stack([V[:,0],Y,V[:,1]]);Q[:no]=sourceP[bid];qn=np.zeros_like(Q);gn=np.cross(Q[F[:,1]]-Q[F[:,0]],Q[F[:,2]]-Q[F[:,0]])
 for k in range(3):np.add.at(qn,F[:,k],gn)
 qn/=np.linalg.norm(qn,axis=1)[:,None];geometricN=qn.copy();residual=np.zeros_like(qn);normalFixed=np.zeros(len(V),bool);normalFixed[inlip]=True;normalFixed[no:no+2*ni]=True
 for k,take in enumerate(wedge_members):
  p=sourceP[sourceF[support[k]]];mat=np.column_stack([p[:,0],p[:,2],np.ones(3)]);bary=np.column_stack([V[take],np.ones(take.sum())])@np.linalg.inv(mat);ns=bary@sourceN[sourceF[support[k]]];ns/=np.linalg.norm(ns,axis=1)[:,None];residual[take]=ns-geometricN[take];normalFixed[take]=True
 residual[:no]=sourceN[bid]-geometricN[:no];normalFixed[:no]=True;fixedResidual=residual.copy()
 for _ in range(250):
  total=np.zeros_like(residual);np.add.at(total,edges[:,0],residual[edges[:,1]]);np.add.at(total,edges[:,1],residual[edges[:,0]]);new=.96*total/np.maximum(degree[:,None],1);new[normalFixed]=fixedResidual[normalFixed]
  if np.max(abs(new-residual))<1e-9:break
  residual=new
 qn+=residual;qn/=np.linalg.norm(qn,axis=1)[:,None];qn[:no]=sourceN[bid]
 # Curved lid wall. Its start normals and positions match the actual lip ring exactly.
 rim=Q[no:no+ni];rimN=qn[no:no+ni];idir=center-inner;idir/=np.linalg.norm(idir,axis=1)[:,None];assert abs(rimN[:,1]).min()>.025;sy=-(rimN[:,0]*idir[:,0]+rimN[:,2]*idir[:,1])/rimN[:,1];width=.00025;endXZ=inner+idir*width;endY,ok=globe(endXZ);assert ok.all();yp,_=globe(inner+idir*1e-6);ym,_=globe(inner-idir*1e-6);gSlope=(yp-ym)/2e-6;d0=(gSlope-sy)*width;d0held=d0.copy();d0=np.clip(d0,-3*.00023,.0004);steps=np.array([0,.025,.06,.11,.18,.27,.38,.5,.62,.73,.82,.89,.94,.975,1]);wall=[];WF=[]
 for t in steps:
  xz=inner+idir*width*t;yy,ok=globe(xz);assert ok.all();offset=(2*t**3-3*t*t+1)*.00035+(t**3-2*t*t+t)*d0+(-2*t**3+3*t*t)*.00012;assert offset.min()>=.000119;wall.extend(np.column_stack([xz[:,0],yy-offset,xz[:,1]]).tolist())

 for row in range(len(steps)-1):
  for k in range(ni):u=row*ni+k;v=(row+1)*ni+k;w=(row+1)*ni+(k+1)%ni;x=row*ni+(k+1)%ni;WF.extend([[u,v,w],[u,w,x]])
 wall=np.array(wall);WF=np.array(WF);wallN=np.zeros_like(wall);wgn=np.cross(wall[WF[:,1]]-wall[WF[:,0]],wall[WF[:,2]]-wall[WF[:,0]])
 for k in range(3):np.add.at(wallN,WF[:,k],wgn)
 wallN/=np.linalg.norm(wallN,axis=1)[:,None];wallN[:ni]=rimN
 # Closed ellipsoid with exact poles and independent analytic normals.
 lon=96;lat=48;local=[[0.,0.,radii[2]]]
 for row in range(1,lat):
  t=np.pi*row/lat
  for k in range(lon):p=2*np.pi*k/lon;local.append([radii[0]*np.sin(t)*np.cos(p),radii[1]*np.sin(t)*np.sin(p),radii[2]*np.cos(t)])
 local.append([0.,0.,-radii[2]]);local=np.array(local);globeQ=local@basis.T+C;globeN=(local/radii**2)@basis.T;globeN/=np.linalg.norm(globeN,axis=1)[:,None];GF=[]
 for k in range(lon):GF.append([0,1+k,1+(k+1)%lon])
 for row in range(lat-2):
  for k in range(lon):u=1+row*lon+k;v=1+row*lon+(k+1)%lon;GF.extend([[u,u+lon,v+lon],[u,v+lon,v]])
 last=len(local)-1
 for k in range(lon):GF.append([last,1+(lat-2)*lon+(k+1)%lon,1+(lat-2)*lon+k])
 GF=np.array(GF);gGN=np.cross(globeQ[GF[:,1]]-globeQ[GF[:,0]],globeQ[GF[:,2]]-globeQ[GF[:,0]]);rev=np.sum(gGN*globeN[GF].mean(1),axis=1)<0;GF[rev]=GF[rev][:,[0,2,1]]
 low=outer.min(0)-.001;high=outer.max(0)+.001;uv=(V-low)/(high-low);uv[:,1]=1-uv[:,1];wu=np.tile(np.column_stack([np.arange(ni)/ni,np.zeros(ni)]),(len(steps),1));wu[:,1]=np.repeat(steps,ni);gu=np.column_stack([.5+np.arctan2(local[:,1]/radii[1],local[:,0]/radii[0])/(2*np.pi),np.arccos(np.clip(local[:,2]/radii[2],-1,1))/np.pi]);pis=[append_component(f'eye{eye}_skin',Q,qn,F,uv,skinMat,bid),append_component(f'eye{eye}_wall',wall,wallN,WF,wu,skinMat),append_component(f'eye{eye}_globe',globeQ,globeN,GF,gu,skinMat+1)];bindings[f'eye{eye}_skin_inner_indices']=np.arange(no,no+ni);bindings[f'eye{eye}_wall_inner_count']=np.array(ni);reports.append({'eye':eye,'primitives':pis,'outer_rim_vertices':no,'aperture_vertices':ni,'annular_triangles':len(F),'wall_triangles':len(WF),'globe_triangles':len(GF),'maximum_projected_canthus_rounding_m':aperture_rounding,'wall_start_derivative_clamped':int(np.sum(d0!=d0held)),'maximum_outward_skin_clearance_correction_m':float(correction.max()),'minimum_projected_triangle_double_area':float(areas.min()),'status':'Unadopted first geometry trial; inner/outer position-normal-dihedral and whole local V4/appearance checks pending. UVs/materials are diagnostic.'})
out=R/'Green_physical_eyes45_body.glb';write_glb(out,j,buf);np.savez_compressed(R/'audit/eyes45_binding.npz',**bindings);rep={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'removed_source_triangles':int(drop.sum()),'first_new_primitive':newPrimitiveStart,'eyes':reports,'status':'Geometry study only; no painted identity or eye-quality acceptance.'};(R/'audit/eyes45.json').write_text(json.dumps(rep,indent=2));print(rep,flush=True)
