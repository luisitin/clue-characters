import pathlib,sys,numpy as np,json
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_source_clean_records.glb';j,b,A=read_glb(src);p=j['meshes'][0]['primitives'][0];P=A(p['attributes']['POSITION']);F=A(p['indices']).reshape(-1,3);n=j['nodes'][0];W=(P*np.array(n['scale'])+np.array(n['translation']))[:,[0,2,1]]*[1,-1,1];d=np.load(R/'audit/forehead_cylinder_source.npz');origin=d['origin'];X=d['X'];FR=d['front'];Z=d['Z'];q=W-origin;theta=np.arctan2(q@X,q@FR);v=q@Z;radius=np.sqrt((q@X)**2+(q@FR)**2);chart=np.column_stack([theta*.09,v]);cent=chart[F].mean(1);sel=(cent[:,0]>-.126)&(cent[:,0]<.1305)&(cent[:,1]>.025)&(cent[:,1]<.130)&(radius[F].min(1)>.025);unique,group=np.unique(P,axis=0,return_inverse=True);canon=group[F];edge={}
for fi in np.flatnonzero(sel):
 for a,b in zip(canon[fi],np.roll(canon[fi],-1)):edge.setdefault(tuple(sorted((int(a),int(b)))),[]).append(int(fi))
be=[e for e,fs in edge.items()if len(fs)==1];adj={}
for a,b in be:adj.setdefault(a,[]).append(b);adj.setdefault(b,[]).append(a)
bad={str(k):v for k,v in adj.items()if len(v)!=2};loops=[];left=set(adj)
if not bad:
 while left:
  first=min(left);loop=[first];prev=None;cur=first
  while True:
   nxt=next(x for x in adj[cur]if x!=prev)
   if nxt==first:break
   assert nxt not in loop;loop.append(nxt);prev,cur=cur,nxt
  left-=set(loop);loops.append(loop)
first=np.zeros(len(unique),int)
for i,g in enumerate(group):first[g]=i
loopuv=[chart[first[l]].tolist()for l in loops];areas=[float(.5*np.sum(np.array(c)[:,0]*np.roll(np.array(c)[:,1],-1)-np.array(c)[:,1]*np.roll(np.array(c)[:,0],-1)))for c in loopuv];report={'selected_triangles':int(sel.sum()),'boundary_edges':len(be),'nonmanifold_selected_edges':sum(len(fs)>2 for fs in edge.values()),'bad_boundary_degree_count':len(bad),'bad_degrees':bad,'loop_lengths':[len(l)for l in loops],'loop_projected_areas':areas,'status':'Read-only cylindrical repair-domain proposal; exact outer loop, containment and replacement shape remain unaccepted'};np.savez_compressed(R/'audit/forehead_domain_proposal.npz',source_positions=P,source_world=W,source_triangles=F,selected=sel,canonical_group=group,canonical_first=first,chart=chart,loops=np.array(loops,dtype=object));(R/'audit/forehead_domain_proposal.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
