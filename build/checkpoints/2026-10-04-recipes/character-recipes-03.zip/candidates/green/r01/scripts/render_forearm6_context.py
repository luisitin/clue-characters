"""Two-source forearm6 diagnostic. Source-hand hiding is not a topology cut; cuff seating is unverified."""
import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parents[1];hand=R/'Green_openhand_forearm6.glb';code=(R/'scripts/render_exact.py').read_text();needle="bpy.ops.import_scene.gltf(filepath=str(src));raw_preserved=False";replace="""bpy.ops.import_scene.gltf(filepath=str(src));bpy.context.view_layer.update();base_objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];hidden_faces=0
transparent=bpy.data.materials.new('Diagnostic hidden source hand');transparent.use_nodes=True;ns=transparent.node_tree.nodes;ns.clear();output=ns.new('ShaderNodeOutputMaterial');shader=ns.new('ShaderNodeBsdfTransparent');transparent.node_tree.links.new(shader.outputs[0],output.inputs['Surface'])
axis=Vector((-.3796110978350356,-.9240533302563367,.04495394579625422));center=Vector((-.335189492,-.158833660,.213596714))
for ob in base_objects:
 slot=len(ob.data.materials);ob.data.materials.append(transparent)
 for poly in ob.data.polygons:
  point=ob.matrix_world@poly.center
  if point.x<-.22 and point.y<-.04 and .08<point.z<.38 and (point-center).dot(axis)>-.03:poly.material_index=slot;hidden_faces+=1
bpy.ops.import_scene.gltf(filepath=str(hand));raw_preserved=False""";assert needle in code;code=code.replace(needle,replace);code=code.replace("target,scale,angle,elev=regions[tag];", "regions['openhand_context']=((-.36,-.17,.21),.42,-11,.04)\ntarget,scale,angle,elev=regions[tag];")
code=code.replace("'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),", "'base_source':str(src),'base_source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'hand_source':str(hand),'hand_source_sha256':hashlib.sha256(hand.read_bytes()).hexdigest(),'scene_override_diagnostic':True,'exported_combined_asset':False,'original_hand_hidden_faces':hidden_faces,'wrist_cuff_interface_expected_open':True,")
exec(compile(code,'render_openhand_context','exec'))
