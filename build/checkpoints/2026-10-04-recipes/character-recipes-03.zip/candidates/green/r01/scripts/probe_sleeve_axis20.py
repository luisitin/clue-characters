"""Read-only full horizontal sections to distinguish the actual sleeve axis from a convenient old cut plane."""
import pathlib,sys,json,numpy as np
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
j,b,A=read_glb(R/'Green_forehead_pslg5_painted.glb');pr=j['meshes'][0]['primitives'][0];P=A(pr['attributes']['POSITION']).astype('float32');F=A(pr['indices']).reshape(-1,3);node=j['nodes'][0];W=(P*np.array(node['scale'])+np.array(node['translation']))[:,[0,2,1]]*[1,-1,1];results=[];bindings={}
for height in [.25,.275,.30,.325,.35,.375,.4]:
 d=W[:,2]-height;ids=np.flatnonzero((d[F].min(1)<0)&(d[F].max(1)>0));seg=[];faces=[]
 for fi in ids:
  pts=[]
  for a,b in zip(F[fi],np.roll(F[fi],-1)):
   if d[a]*d[b]<0:pts.append(W[a]+d[a]/(d[a]-d[b])*(W[b]-W[a]))
  if len(pts)==2:seg.append(pts);faces.append(int(fi))
 seg=np.array(seg);points,g=np.unique(np.round(seg.reshape(-1,3),7),axis=0,return_inverse=True);edges=g.reshape(-1,2);adj={}
 for a,b in edges:adj.setdefault(int(a),set()).add(int(b));adj.setdefault(int(b),set()).add(int(a))
 left=set(adj);comps=[]
 while left:
  todo=[min(left)];seen=set()
  while todo:
   v=todo.pop()
   if v in seen:continue
   seen.add(v);todo.extend(adj[v]-seen)
  left-=seen;pts=points[list(seen)];center=pts.mean(0);bad={int(v):len(adj[v])for v in seen if len(adj[v])!=2};row={'points':len(seen),'center':center.tolist(),'extent':np.ptp(pts,axis=0).tolist(),'bad_degrees':bad,'left_arm_candidate':bool(center[0]<-.22 and center[1]<.03)}
  if not bad:
   loop=[min(seen)];prev=None
   while True:
    nxt=next(v for v in adj[loop[-1]]if v!=prev)
    if nxt==loop[0]:break
    assert nxt not in loop;prev=loop[-1];loop.append(nxt)
   assert len(loop)==len(seen);bindings[f'z{height}_component{len(comps)}']=points[loop]
  comps.append(row)
 results.append({'height':height,'components':comps})
z=np.load(R/'audit/hand_forearm6_binding.npz');rings=z['new_world'][:14*81].reshape(14,81,3)[:,:80];n=rings[1].mean(0)-rings[0].mean(0);n/=np.linalg.norm(n);report={'sections':results,'native_cut_proximal_derivative_world':n.tolist(),'old_convenient_cut_axis_world':[-.379611098,-.92405333,.044953946],'status':'Read-only complete-section evidence; do not infer anatomy solely from the old construction-plane normal.'};np.savez_compressed(R/'audit/sleeve_axis20.npz',**bindings);(R/'audit/sleeve_axis20.json').write_text(json.dumps(report,indent=2));print(report,flush=True)
