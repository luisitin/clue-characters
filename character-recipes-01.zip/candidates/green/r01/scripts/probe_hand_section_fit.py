import pathlib,sys,json,numpy as np
from scipy.spatial.transform import Rotation
R=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'scripts'));from glb_source import read_glb
src=R/'Green_openhand_thumb3_islands4.glb';j,b,A=read_glb(src);node=next(n for n in j['nodes']if'mesh'in n);pr=j['meshes'][node['mesh']]['primitives'][0];P=A(pr['attributes']['POSITION']).astype(float);F=A(pr['indices']).reshape(-1,3)
if'matrix'in node:M=np.array(node['matrix']).reshape((4,4),order='F')
else:M=np.eye(4);M[:3,:3]=Rotation.from_quat(node.get('rotation',[0,0,0,1])).as_matrix()@np.diag(node.get('scale',[1,1,1]));M[:3,3]=node.get('translation',[0,0,0])
W=(P@M[:3,:3].T+M[:3,3])[:,[0,2,1]]*[1,-1,1];center=np.array([-.335189492,-.158833660,.213596714]);axis=np.array([-.38,-.925,.045]);axis/=np.linalg.norm(axis);up=np.array([0.,0.,1.]);up-=axis*(up@axis);up/=np.linalg.norm(up);side=np.cross(axis,up);s=(W-center)@axis;reports=[];data={}
for phase in np.arange(-.025,.071,.005):
 ids=np.flatnonzero((s[F].min(1)<phase)&(s[F].max(1)>phase));segments=[]
 for fi in ids:
  tr=F[fi];points=[]
  for a,b in zip(tr,np.roll(tr,-1)):
   if(s[a]-phase)*(s[b]-phase)<0:t=(phase-s[a])/(s[b]-s[a]);points.append(W[a]+t*(W[b]-W[a]))
  if len(points)==2:segments.append(points)
 if not segments:continue
 seg=np.array(segments);un,g=np.unique(np.round(seg.reshape(-1,3),7),axis=0,return_inverse=True);edges=np.unique(np.sort(g.reshape(-1,2),axis=1),axis=0);adj={}
 for a,b in edges:adj.setdefault(int(a),[]).append(int(b));adj.setdefault(int(b),[]).append(int(a))
 bad={str(k):len(v)for k,v in adj.items()if len(v)!=2};loops=[];left=set(adj)
 if not bad:
  while left:
   first=min(left);loop=[first];prev=None;cur=first
   while True:
    nxt=next(v for v in adj[cur]if v!=prev)
    if nxt==first:break
    assert nxt not in loop;loop.append(nxt);prev,cur=cur,nxt
   left-=set(loop);loops.append(loop)
 rows=[]
 for loop in loops:
  points=un[loop];q=np.column_stack([(points-center)@side,(points-center)@up]);area=.5*abs(np.sum(q[:,0]*np.roll(q[:,1],-1)-q[:,1]*np.roll(q[:,0],-1)));rows.append({'points':len(loop),'world_center':points.mean(0).tolist(),'width_height_m':np.ptp(q,axis=0).tolist(),'area_m2':float(area)})
 reports.append({'phase_m':float(phase),'bad_degrees':bad,'loops':rows});data[f'{phase:.3f}']=[un[l].tolist()for l in loops]
(R/'audit/hand_section_fit.json').write_text(json.dumps({'source':str(src),'center':center.tolist(),'axis':axis.tolist(),'sections':reports,'scope':'Actual posed hand sections, without any geometric deformation'},indent=2));(R/'audit/hand_section_loops.json').write_text(json.dumps(data));print(reports,flush=True)
